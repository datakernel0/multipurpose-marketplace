<div id="page-content" class="page-wrapper clearfix">
    <div class="row">
        <div class="col-sm-3 col-lg-2">
            <?php
            $tab_view['active_tab'] = "cPanel";
            echo view("settings/tabs", $tab_view);
            ?>
        </div>

        <div class="col-sm-9 col-lg-10">

            <div class="card">
                <div class="card-header d-flex justify-content-between">
                    <h4>Control Panel</h4>
                </div>

                <!-- modal-content -->
                <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel"
                    aria-hidden="true">
                    <?php echo form_open(get_uri("settings/save_ip_settings"), array("id" => "ip-settings-form", "class" => "general-form", "role" => "form")); ?>
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h1 class="modal-title fs-5" id="exampleModalLabel">IP Details</h1>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <form>
                                    <div class="row mb-3">
                                        <label for="" class="col-sm-2 col-form-label text-nowrap">IP Owner</label>
                                        <div class="col-sm-10">
                                            <input required name="username" type="text" class="form-control" value="">
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <label class="col-sm-2 col-form-label text-nowrap">IP Number</label>
                                        <div class="col-sm-10">
                                            <input required name="ip" type="text" class="form-control" value="">
                                        </div>
                                    </div>

                                </form>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-primary">Save</button>
                            </div>
                        </div>
                    </div>
                    <?php echo form_close(); ?>
                </div>
                <!-- card-body -->
                <div class="card-body">
                    <?php echo form_open(get_uri("settings/cPanel_update"), array("id" => "ip-settings-form", "class" => "general-form", "role" => "form")); ?>
                        <div class="row">
                            <div class="col-sm-4">
                                <label for="daily_hrs">Daily working hours:</label>
                            </div>
                            <div class="col-sm-8">
                                <input name="daily_hrs" value="<?php echo $c_panel->daily_hrs; ?>" type="number" class="form-control">
                            </div>
                            <br/><br/>

                            <div class="col-sm-4">
                                <label for="screenshot_time">Screenshot Taken time (Seconds):</label>
                            </div>
                            <div class="col-sm-8">
                                <input name="screenshot_time" value="<?php echo $c_panel->scr_time; ?>" type="number" class="form-control">
                            </div>
                            <br/><br/>

                            <div class="col-sm-4">
                                <label for="idle_time">Idle time (Seconds):</label>
                            </div>
                            <div class="col-sm-8">
                                <input name="idle_time" value="<?php echo $c_panel->idle_time; ?>" type="number" class="form-control">
                            </div>
                            <br/><br/>

                            <div class="col-sm-4">
                                <label for="tracking_time">Performance Tracking (Seconds):</label>
                            </div>
                            <div class="col-sm-8">
                                <input name="tracking_time" value="<?php echo $c_panel->tracking_time; ?>" type="number" class="form-control">
                            </div>
                            <br/><br/>
                            <div class="col-sm-4">
                            </div>
                            <div class="col-sm-8">
                               <button type="submit" class="btn btn-primary">Update</button>
                            </div>
                        </div>
                    <?php echo form_close(); ?>

                </div>
            </div>

        </div>
    </div>
</div>

<style>
    select.basic {
        width: 200px;
        border: 0px;
        background-color: transparent;
    }

    select.basic:focus {
        outline: none;
    }

    select.basic:active {
        outline: none;
    }
</style>

<script type="text/javascript">
    $(document).ready(function () {

        $("#status_update").on("change", function(){
            var url = `settings/update_ip_status/${$(this).attr("data-id")}/${$(this).val()}`;
            $.ajax({
                url: "<?php echo get_uri() ?>"+ url,
                dataType: "json",
                success: function (result) {

                }
            });
        })
    });
    // select-2
    $(document).ready(function () {
        $('.js-example-basic-single').select2();
    });
</script>