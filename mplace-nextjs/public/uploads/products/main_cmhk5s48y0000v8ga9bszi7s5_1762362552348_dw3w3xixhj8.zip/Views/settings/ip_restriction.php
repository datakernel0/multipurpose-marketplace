<div id="page-content" class="page-wrapper clearfix">
    <div class="row">
        <div class="col-sm-3 col-lg-2">
            <?php
            $tab_view['active_tab'] = "ip_restriction";
            echo view("settings/tabs", $tab_view);
            ?>
        </div>

        <div class="col-sm-9 col-lg-10">
            
            <div class="card">
                <div class="card-header d-flex justify-content-between">
                    <h4><?php echo app_lang("ip_restriction"); ?></h4>

                    <button type="button" class="btn btn-default" data-bs-toggle="modal" data-bs-target="#exampleModal">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none"
                            stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                            class="feather feather-plus-circle icon-16">
                            <circle cx="12" cy="12" r="10"></circle>
                            <line x1="12" y1="8" x2="12" y2="16"></line>
                            <line x1="8" y1="12" x2="16" y2="12"></line>
                        </svg>
                        Add New IP
                    </button>
                </div>

                <!-- modal-content -->
                <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel"
                    aria-hidden="true">
                    <?php echo form_open(get_uri("settings/save_ip_settings"), array("id" => "ip-settings-form", "class" => "general-form", "role" => "form")); ?>
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h1 class="modal-title fs-5" id="exampleModalLabel">IP Details</h1>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <form>
                                    <div class="row mb-3">
                                        <label for="" class="col-sm-2 col-form-label text-nowrap">IP Owner</label>
                                        <div class="col-sm-10">
                                            <input required name="username" type="text" class="form-control" value="">
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <label class="col-sm-2 col-form-label text-nowrap">IP Number</label>
                                        <div class="col-sm-10">
                                            <input required name="ip" type="text" class="form-control" value="">
                                        </div>
                                    </div>

                                </form>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-primary">Save</button>
                            </div>
                        </div>
                    </div>
                    <?php echo form_close(); ?>
                </div>
                <!-- card-body -->
                <div class="card-body">

                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th scope="row">SL</th>
                                <th class="text-capitalize">user name</th>
                                <th class="text-capitalize">user ip</th>
                                <th class="text-capitalize">Status</th>
                                <th class="text-capitalize text-end">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($ipList as $key => $ip) { ?>
                            <tr>
                                <td scope="row"><?php echo $key + 1; ?></td>
                                <td class="text-capitalize"><?php echo $ip->username; ?></td>
                                <td class="text-capitalize"><?php echo $ip->ip; ?></td>
                                <td class="text-capitalize">
                                    <select id="status_update" data-id="<?php echo $ip->id; ?>" class="basic">
                                        <option <?php echo $ip->status == 1 ? "selected" : ""; ?> value="1">Active</option>
                                        <option <?php echo $ip->status == 0 ? "selected" : ""; ?> value="0">Inactive</option>
                                    </select>
                                </td>
                                <td class="text-end">
                                    <a href="<?php echo get_uri("settings/delete_ip_settings/".$ip->id); ?>">
                                        <button type="button" class="btn-close" aria-label="Close"></button>
                                    </a>
                                </td>
                            </tr>
                            <?php } ?>
                        </tbody>
                    </table>

                </div>
            </div>
            
        </div>
    </div>
</div>

<style>
    select.basic {
        width: 200px;
        border: 0px;
        background-color: transparent;
    }

    select.basic:focus {
        outline: none;
    }

    select.basic:active {
        outline: none;
    }
</style>

<script type="text/javascript">
    $(document).ready(function () {
   
        $("#status_update").on("change", function(){
            var url = `settings/update_ip_status/${$(this).attr("data-id")}/${$(this).val()}`;
            $.ajax({
                url: "<?php echo get_uri() ?>"+ url,
                dataType: "json",
                success: function (result) {
                    
                }
            });
        })
    });
    // select-2
    $(document).ready(function () {
        $('.js-example-basic-single').select2();
    });
</script>