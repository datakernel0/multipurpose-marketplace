<div class="modal-body clearfix">
    <div class="form-group">
        <h4><?php echo app_lang('team_members_for'); ?>: <?php echo $team_info->title; ?></h4>
    </div>
    
    <?php if (count($team_members) > 0) { ?>
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th><?php echo app_lang('member_name'); ?></th>
                        <th><?php echo app_lang('job_title'); ?></th>
                        <th><?php echo app_lang('email'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($team_members as $member) { ?>
                        <tr>
                            <td><?php echo $member->first_name . ' ' . $member->last_name; ?></td>
                            <td><?php echo $member->job_title; ?></td>
                            <td><?php echo $member->email; ?></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    <?php } else { ?>
        <div class="form-group">
            <p><?php echo app_lang('no_team_members_found'); ?></p>
        </div>
    <?php } ?>
</div>

<div class="modal-footer">
    <button type="button" class="btn btn-default" data-bs-dismiss="modal"><span data-feather="x" class="icon-16"></span> <?php echo app_lang('close'); ?></button>
</div>
