<?php echo form_open(get_uri("team/save"), array("id" => "team-form", "class" => "general-form", "role" => "form")); ?>
<div class="modal-header">
    <h4 class="modal-title"><?php echo $model_info ? app_lang('edit_team') : app_lang('add_team'); ?></h4>
</div>
<div class="modal-body clearfix">
    <input type="hidden" name="id" value="<?php echo $model_info ? $model_info->id : ""; ?>" />
    <div class="form-group">
        <div class="row">
            <label for="title" class="col-md-3"><?php echo app_lang('team_name'); ?></label>
            <div class="col-md-9">
                <?php
                echo form_input(array(
                    "id" => "title",
                    "name" => "title",
                    "value" => $model_info ? $model_info->title : "",
                    "class" => "form-control",
                    "placeholder" => app_lang('team_name'),
                    "data-rule-required" => true,
                    "data-msg-required" => app_lang("field_required"),
                ));
                ?>
            </div>
        </div>
    </div>
</div>

<div class="modal-footer">
    <button type="button" class="btn btn-default" data-bs-dismiss="modal"><span data-feather="x" class="icon-16"></span> <?php echo app_lang('close'); ?></button>
    <button type="submit" class="btn btn-primary"><span data-feather="check-circle" class="icon-16"></span> <?php echo app_lang('save'); ?></button>
</div>
<?php echo form_close(); ?>

<script type="text/javascript">
    $(document).ready(function () {
        $("#team-form").appForm({
            onSuccess: function (result) {
                // Close modal first
                $("#ajaxModal").modal('hide');
                
                // Reload the entire table to ensure proper ordering (latest first)
                setTimeout(function() {
                    $("#team-table").appTable({reload: true});
                }, 100);
            }
        });
        $("#title").focus();
    });
</script>