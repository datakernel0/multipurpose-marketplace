<?php echo form_open(get_uri("supervisor_assignments/save"), array("id" => "supervisor-assignment-form", "class" => "general-form", "role" => "form")); ?>
<div class="modal-body clearfix">
    
    <div class="form-group">
        <div class="row">
            <label for="supervisor_id" class="col-md-3"><?php echo app_lang('supervisor'); ?> <span class="help" data-bs-toggle="tooltip" title="<?php echo app_lang('select_supervisor'); ?>"><i data-feather='help-circle' class="icon-16"></i></span></label>
            <div class="col-md-9">
                <?php
                echo form_dropdown("supervisor_id", $supervisors_dropdown, array(), "class='select2' id='supervisor_id'");
                ?>
            </div>
        </div>
    </div>
    
    <div class="form-group">
        <div class="row">
            <label for="member_ids" class="col-md-3"><?php echo app_lang('members'); ?> <span class="help" data-bs-toggle="tooltip" title="<?php echo app_lang('select_members'); ?>"><i data-feather='help-circle' class="icon-16"></i></span></label>
            <div class="col-md-9">
                <?php
                echo form_dropdown("member_ids[]", $members_dropdown, array(), "class='select2' id='member_ids' multiple");
                ?>
                <small class="text-muted">Hold Ctrl/Cmd to select multiple members</small>
            </div>
        </div>
    </div>
    
    <div class="form-group" id="assigned-members-section" style="display: none;">
        <div class="row">
            <label class="col-md-3"><?php echo app_lang('currently_assigned'); ?></label>
            <div class="col-md-9">
                <div id="assigned-members-list">
                    <!-- Assigned members will be loaded here via AJAX -->
                </div>
            </div>
        </div>
    </div>
    
    <div class="form-group" id="available-members-section" style="display: none;">
        <div class="row">
            <label class="col-md-3"><?php echo app_lang('available_members'); ?></label>
            <div class="col-md-9">
                <div id="available-members-list">
                    <!-- Available members will be loaded here via AJAX -->
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal-footer">
    <button type="button" class="btn btn-default" data-bs-dismiss="modal"><span data-feather="x" class="icon-16"></span> <?php echo app_lang('close'); ?></button>
    <button type="submit" class="btn btn-primary"><span data-feather="check-circle" class="icon-16"></span> <?php echo app_lang('save'); ?></button>
</div>
<?php echo form_close(); ?>

<script type="text/javascript">
    $(document).ready(function () {
        $("#supervisor-assignment-form").appForm({
            onSuccess: function (result) {
                $("#supervisor-assignments-table").appTable({reload: true});
            }
        });

        // Load assigned members when supervisor is selected
        $("#supervisor_id").change(function () {
            var supervisorId = $(this).val();
            if (supervisorId) {
                loadAssignedMembers(supervisorId);
                loadAvailableMembers(supervisorId);
                updateMemberDropdown(supervisorId);
            } else {
                $("#assigned-members-section, #available-members-section").hide();
                $("#member_ids").empty().append('<option value="">Select Members</option>');
            }
        });

        // Initialize on page load if supervisor is already selected
        if ($("#supervisor_id").val()) {
            loadAssignedMembers($("#supervisor_id").val());
            loadAvailableMembers($("#supervisor_id").val());
            updateMemberDropdown($("#supervisor_id").val());
        }
    });

    function loadAssignedMembers(supervisorId) {
        $.ajax({
            url: "<?php echo get_uri('supervisor_assignments/get_assigned_members'); ?>",
            type: 'POST',
            data: {supervisor_id: supervisorId},
            dataType: 'json',
            success: function (result) {
                if (result.success && result.data.length > 0) {
                    var html = '<ul class="list-group">';
                    $.each(result.data, function (index, member) {
                        html += '<li class="list-group-item d-flex justify-content-between align-items-center">';
                        html += '<span>' + member.name;
                        if (member.job_title) {
                            html += ' <small class="text-muted">(' + member.job_title + ')</small>';
                        }
                        html += '</span>';
                        html += '<small class="text-muted">' + member.assigned_at + '</small>';
                        html += '</li>';
                    });
                    html += '</ul>';
                    $("#assigned-members-list").html(html);
                    $("#assigned-members-section").show();
                } else {
                    $("#assigned-members-section").hide();
                }
            }
        });
    }

    function loadAvailableMembers(supervisorId) {
        $.ajax({
            url: "<?php echo get_uri('supervisor_assignments/get_available_members'); ?>",
            type: 'POST',
            data: {supervisor_id: supervisorId},
            dataType: 'json',
            success: function (result) {
                if (result.success && result.data.length > 0) {
                    var html = '<p class="text-muted"><?php echo app_lang("available_for_assignment"); ?>:</p>';
                    html += '<ul class="list-group">';
                    $.each(result.data, function (index, member) {
                        html += '<li class="list-group-item">';
                        html += member.name;
                        if (member.job_title) {
                            html += ' <small class="text-muted">(' + member.job_title + ')</small>';
                        }
                        html += '</li>';
                    });
                    html += '</ul>';
                    $("#available-members-list").html(html);
                    $("#available-members-section").show();
                } else {
                    $("#available-members-section").hide();
                }
            }
        });
    }

    function updateMemberDropdown(supervisorId) {
        $.ajax({
            url: "<?php echo get_uri('supervisor_assignments/get_available_members'); ?>",
            type: 'POST',
            data: {supervisor_id: supervisorId},
            dataType: 'json',
            success: function (result) {
                var dropdown = $("#member_ids");
                dropdown.empty();
                
                if (result.success && result.data.length > 0) {
                    $.each(result.data, function (index, member) {
                        var optionText = member.name;
                        if (member.job_title) {
                            optionText += ' (' + member.job_title + ')';
                        }
                        dropdown.append('<option value="' + member.id + '">' + optionText + '</option>');
                    });
                } else {
                    dropdown.append('<option value="">No available members</option>');
                }
                
                // Reinitialize select2 for multiple selection
                dropdown.select2({
                    placeholder: "Select multiple members...",
                    allowClear: true,
                    multiple: true
                });
            }
        });
    }
</script>
