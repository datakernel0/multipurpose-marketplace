<?php

?>

<div id="leave-overview-widget-container">
    <div class="card bg-white">
        <div class="card-header">
            <i data-feather="file-text" class="icon-16"></i> &nbsp;<?php echo app_lang("who_is_out"); ?> this month
            
        </div>

        <div style="height: 330px;" class="card-body rounded-bottom" id="invoice-overview-container">            
            <?php if(count($leave_data)) { ?>
                <?php foreach($leave_data as $data) { ?>
                    
                    <?php 
                            $date_array = explode(",", $data->start_array);
                            $dates = "";
                            $datesCount = array();
                            foreach($date_array as $index => $date) {
                                $current_date = new DateTime($date);
                                $end_date = new DateTime(explode(",", $data->end_array)[$index]);
                            
                                // Include the start date
                                
                                $datesCount[] = $current_date->format('d');
                                while ($current_date < $end_date) {
                                    // Move to the next day
                                    $current_date->modify('+1 day');                                   
                                    $datesCount[] = $current_date->format('d');
                                }
                            }
                            
                            sort($datesCount);
                            $dates = implode(', ', $datesCount);
                            ?>
                            <p style="display: flex; justify-content: space-between;"><a href="#"><?php echo $data->applicant_name ?></a> <span><?php echo date_format(date_create($data->start_date), "M") ." - ". $dates ?></span></p>
                <?php  } ?>

            <?php } else { ?>
                <p>No one is on vacation on this or next month</p>
            <?php } ?>            
        </div>
    </div>
</div>

<script>
    $(document).ready(function () {
    
    });
</script>