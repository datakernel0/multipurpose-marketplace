<div class="table-responsive">
    <table id="leave-reports" class="display" cellspacing="0" width="100%">            
    </table>
</div>

<script type="text/javascript">
    $(document).ready(function () {
        $.post("<?php echo get_uri("leaves/report_columns_data")?>", {}, (res, key) => {  
            const cu_array = [];
            const print = [];
            JSON.parse(res).data.map((item, key) => {
                cu_array.push({title: item});
                print.push(key);
            }); 

            $("#leave-reports").appTable({
            source: '<?php echo_uri("leaves/report_list_data") ?>',
            columns: [
                {title: 'Name', "class": "w20p"},              
                ...cu_array
            ],
            dateRangeType: "yearly",
            printColumns: print,
            xlsColumns: print
        });
        });

        
    });
</script>

