<div class="card bg-white mb15">
    <div class="card-header text-center">
        <?php if (get_setting("show_logo_in_signin_page") === "yes") { ?>
            <img class="p20 mw100p" src="<?php echo get_logo_url(); ?>" />
        <?php } else { ?>
            <h2><?php echo app_lang('signin'); ?></h2>
        <?php } ?>
    </div>
    <div class="card-body p30 rounded-bottom">
        <?php echo form_open("signin/authenticate", array("id" => "signin-form", "class" => "general-form", "role" => "form")); ?>

        <?php
        $session = \Config\Services::session();
        $signin_validation_errors = $session->getFlashdata("signin_validation_errors");
        if ($signin_validation_errors && is_array($signin_validation_errors)) {
            ?>
            <div class="alert alert-danger" role="alert">
                <?php foreach ($signin_validation_errors as $validation_error) { ?>
                    <i data-feather="alert-circle" class="icon-16"></i>
                    <?php echo $validation_error; ?>
                    <br />
                <?php } ?>
            </div>
        <?php } ?>

        <?php
        $session = \Config\Services::session();
        $otp_session = $session->getFlashdata("session_data");


        if ($otp_session) {
            $otp = $otp_session["otp"];
            $email = $otp_session["email"];
            $password = $otp_session["password"];
            ?>
            <div class="alert alert-success" role="alert">

                <i data-feather="alert-circle" class="icon-16"></i>
                    Otp Sent, Please contact with administration for Otp.
                <br />

            </div>
            <div class="form-group">
                <?php
                echo form_input(array(
                    "id" => "otp",
                    "name" => "otp",
                    "class" => "form-control p10",
                    "placeholder" => 'Otp',
                    "data-rule-required" => false
                ));
                ?>
            </div>
            <div style="display: none" class="form-group">
                <?php
                echo form_input(array(
                    "id" => "email_otp",
                    "name" => "email_otp",
                    "value" => $otp,
                    "class" => "form-control p10",
                    "placeholder" => app_lang(lang: 'email'),
                    "autofocus" => true,
                    "data-rule-required" => true,
                    "data-msg-required" => app_lang("field_required"),
                    "data-rule-email" => true,
                    "data-msg-email" => app_lang("enter_valid_email")
                ));
                ?>
            </div>
            <div style="display: none" class="form-group">
                <?php
                echo form_input(array(
                    "id" => "email",
                    "name" => "email",
                    "value" => $email,
                    "class" => "form-control p10",
                    "placeholder" => app_lang(lang: 'email'),
                    "autofocus" => true,
                    "data-rule-required" => true,
                    "data-msg-required" => app_lang("field_required"),
                    "data-rule-email" => true,
                    "data-msg-email" => app_lang("enter_valid_email")
                ));
                ?>
            </div>
            <div style="display: none" class="form-group">
                <?php
                echo form_password(array(
                    "id" => "password",
                    "name" => "password",
                    "value" => $password,
                    "class" => "form-control p10",
                    "placeholder" => app_lang('password'),
                    "data-rule-required" => true,
                    "data-msg-required" => app_lang("field_required")
                ));
                ?>
            </div>
        <?php } else { ?>
            <div class="form-group">
                <?php
                echo form_input(array(
                    "id" => "email",
                    "name" => "email",
                    "class" => "form-control p10",
                    "placeholder" => app_lang('email'),
                    "autofocus" => true,
                    "data-rule-required" => true,
                    "data-msg-required" => app_lang("field_required"),
                    "data-rule-email" => true,
                    "data-msg-email" => app_lang("enter_valid_email")
                ));
                ?>
            </div>
            <div class="form-group">
                <?php
                echo form_password(array(
                    "id" => "password",
                    "name" => "password",
                    "class" => "form-control p10",
                    "placeholder" => app_lang('password'),
                    "data-rule-required" => true,
                    "data-msg-required" => app_lang("field_required")
                ));
                ?>
            </div>
            <?php } ?>
        <input type="hidden" name="redirect" value="<?php
        if (isset($redirect)) {
            echo $redirect;
        }
        ?>" />


        <?php echo view("signin/re_captcha"); ?>

        <button class="w-100 btn btn-lg btn-primary" type="submit"><?php echo app_lang('signin'); ?></button>

        <?php echo form_close(); ?>

        <?php
        app_hooks()->do_action('app_hook_signin_extension');
        ?>
    </div>
</div>


<script type="text/javascript">
    $(document).ready(function () {
        $("#signin-form").appForm({ajaxSubmit: false, isModal: false});
    });
</script>