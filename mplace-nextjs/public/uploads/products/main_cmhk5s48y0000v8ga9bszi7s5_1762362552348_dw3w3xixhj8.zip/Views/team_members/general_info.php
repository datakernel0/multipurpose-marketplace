<div class="tab-content">
    <?php echo form_open(get_uri("team_members/save_general_info/" . $user_info->id), array("id" => "general-info-form", "class" => "general-form dashed-row white", "role" => "form")); ?>
    <div class="card">
        <div class=" card-header">
            <h4> <?php echo app_lang('general_info'); ?></h4>
        </div>
        <div class="card-body">
            <div class="form-group">
                <div class="row">
                    <label for="first_name" class=" col-md-2"><?php echo app_lang('first_name'); ?></label>
                    <div class=" col-md-10">
                        <?php
                        echo form_input(array(
                            "id" => "first_name",
                            "name" => "first_name",
                            "value" => $user_info->first_name,
                            "class" => "form-control",
                            "placeholder" => app_lang('first_name'),
                            "data-rule-required" => true,
                            "data-msg-required" => app_lang("field_required")
                        ));
                        ?>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <div class="row">
                    <label for="last_name" class=" col-md-2"><?php echo app_lang('last_name'); ?></label>
                    <div class=" col-md-10">
                        <?php
                        echo form_input(array(
                            "id" => "last_name",
                            "name" => "last_name",
                            "value" => $user_info->last_name,
                            "class" => "form-control",
                            "placeholder" => app_lang('last_name'),
                            "data-rule-required" => true,
                            "data-msg-required" => app_lang("field_required")
                        ));
                        ?>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <div class="row">
                    <label for="address" class=" col-md-2"><?php echo app_lang('mailing_address'); ?></label>
                    <div class=" col-md-10">
                        <?php
                        echo form_textarea(array(
                            "id" => "address",
                            "name" => "address",
                            "value" => $user_info->address,
                            "class" => "form-control",
                            "placeholder" => app_lang('mailing_address')
                        ));
                        ?>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <div class="row">
                    <label for="alternative_address" class=" col-md-2"><?php echo app_lang('alternative_address'); ?></label>
                    <div class=" col-md-10">
                        <?php
                        echo form_textarea(array(
                            "id" => "alternative_address",
                            "name" => "alternative_address",
                            "value" => $user_info->alternative_address,
                            "class" => "form-control",
                            "placeholder" => app_lang('alternative_address')
                        ));
                        ?>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <div class="row">
                    <label for="phone" class=" col-md-2"><?php echo app_lang('phone'); ?></label>
                    <div class=" col-md-10">
                        <?php
                        echo form_input(array(
                            "id" => "phone",
                            "name" => "phone",
                            "value" => $user_info->phone,
                            "class" => "form-control",
                            "placeholder" => app_lang('phone')
                        ));
                        ?>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <div class="row">
                    <label for="alternative_phone" class=" col-md-2"><?php echo app_lang('alternative_phone'); ?></label>
                    <div class=" col-md-10">
                        <?php
                        echo form_input(array(
                            "id" => "alternative_phone",
                            "name" => "alternative_phone",
                            "value" => $user_info->alternative_phone,
                            "class" => "form-control",
                            "placeholder" => app_lang('alternative_phone')
                        ));
                        ?>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <div class="row">
                    <label for="skype" class=" col-md-2">Skype</label>
                    <div class=" col-md-10">
                        <?php
                        echo form_input(array(
                            "id" => "skype",
                            "name" => "skype",
                            "value" => $user_info->skype ? $user_info->skype : "",
                            "class" => "form-control",
                            "placeholder" => "Skype"
                        ));
                        ?>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <div class="row">
                    <label for="dob" class=" col-md-2"><?php echo app_lang('date_of_birth'); ?></label>
                    <div class=" col-md-10">
                        <?php
                        echo form_input(array(
                            "id" => "dob",
                            "name" => "dob",
                            "value" => $user_info->dob,
                            "class" => "form-control",
                            "placeholder" => app_lang('date_of_birth'),
                            "autocomplete" => "off"
                        ));
                        ?>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <div class="row">
                    <label for="ssn" class=" col-md-2"><?php echo app_lang('ssn'); ?></label>
                    <div class=" col-md-10">
                        <?php
                        echo form_input(array(
                            "id" => "ssn",
                            "name" => "ssn",
                            "value" => $user_info->ssn,
                            "class" => "form-control",
                            "placeholder" => app_lang('ssn')
                        ));
                        ?>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <div class="row">
                    <label for="nid" class=" col-md-2"><?php echo app_lang('nid'); ?></label>
                    <div class=" col-md-10">
                        <?php
                        echo form_input(array(
                            "id" => "nid",
                            "name" => "nid",
                            "value" => $user_info->nid,
                            "class" => "form-control",
                            "placeholder" => app_lang('nid')
                        ));
                        ?>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <div class="row">
                    <label for="gender" class=" col-md-2"><?php echo app_lang('gender'); ?></label>
                    <div class=" col-md-10">
                        <?php
                        echo form_radio(array(
                            "id" => "gender_male",
                            "name" => "gender",
                            "class" => "form-check-input",
                                ), "male", ($user_info->gender === "male") ? true : false, "class='form-check-input'");
                        ?>
                        <label for="gender_male" class="mr15 p0"><?php echo app_lang('male'); ?></label>
                        <?php
                        echo form_radio(array(
                            "id" => "gender_female",
                            "name" => "gender",
                            "class" => "form-check-input",
                                ), "female", ($user_info->gender === "female") ? true : false, "class='form-check-input'");
                        ?>
                        <label for="gender_female" class="p0 mr15"><?php echo app_lang('female'); ?></label>
                        <?php
                        echo form_radio(array(
                            "id" => "gender_other",
                            "name" => "gender",
                            "class" => "form-check-input",
                                ), "other", ($user_info->gender === "other") ? true : false);
                        ?>
                        <label for="gender_other" class=""><?php echo app_lang('other'); ?></label>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <div style="width: 300px" class="uploaded-items" id="uploaded-items">

                    <?php foreach($files as $key => $file) { ?>
                    <div class="uploaded-item">
                        <span><a download href="<?php echo get_file_uri("files/project_files/$file->file_name") ?>"><?php echo $file->name; ?> (<?php echo $file->file_size / 1000; ?> KB)</a></span>
                        <button onclick="handleFileDelete(event, '<?php echo $file->id; ?>')" class="delete-button">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M16 6V5.2C16 4.0799 16 3.51984 15.782 3.09202C15.5903 2.71569 15.2843 2.40973 14.908 2.21799C14.4802 2 13.9201 2 12.8 2H11.2C10.0799 2 9.51984 2 9.09202 2.21799C8.71569 2.40973 8.40973 2.71569 8.21799 3.09202C8 3.51984 8 4.0799 8 5.2V6M10 11.5V16.5M14 11.5V16.5M3 6H21M19 6V17.2C19 18.8802 19 19.7202 18.673 20.362C18.3854 20.9265 17.9265 21.3854 17.362 21.673C16.7202 22 15.8802 22 14.2 22H9.8C8.11984 22 7.27976 22 6.63803 21.673C6.07354 21.3854 5.6146 20.9265 5.32698 20.362C5 19.7202 5 18.8802 5 17.2V6" stroke="#D92D20" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path></svg>
                        </button>
                    </div>
                    <?php } ?>

                </div>
            </div>

            <div style="display: <?php echo $login_user->sv_access == 2 || $login_user->sv_access == 3 ? "block" : "none"; ?>;" class="form-group">
                <div class="row">
                    <label for="is_menu" class=" col-md-2">Is Menu Show</label>
                    <div class=" col-md-10">
                        <select style="text-transform: capitalize;" class="form-control" name="is_menu" id="">
                            <option <?php echo $user_info->is_menu == 1 ? "selected" : ""; ?> value="1">Show</option>
                            <option <?php echo $user_info->is_menu == 0 ? "selected" : ""; ?> value="0">hide</option>
                        </select>
                    </div>
                </div>
            </div>

            <div class="form-group">
                <button type="button" style="position: relative;" class="btn btn-default upload-file-button float-start round" type="button" style="color:#7988a2"><i data-feather="camera" class="icon-16"></i>
                    <input accept=".pdf, .png, .jpeg, .zip, .doc" class="file-upload-input user-story-file-upload" id="file-upload" name="files[]" type="file" multiple>
                    Upload CV
                </button>
            </div>
            <?php echo view("custom_fields/form/prepare_context_fields", array("custom_fields" => $custom_fields, "label_column" => "col-md-2", "field_column" => " col-md-10")); ?>

        </div>
        <div class="card-footer rounded-0">
            <button type="submit" class="btn btn-primary"><span data-feather="check-circle" class="icon-16"></span> <?php echo app_lang('save'); ?></button>
        </div>
    </div>
    <?php echo form_close(); ?>
</div>

<script>
    function handleFileDelete(event, id){
        event.preventDefault();
        event.currentTarget.closest('.uploaded-item').remove();
        $.ajax({
            url: '<?php echo get_uri('api/file_delete'); ?>/' + id,
            type: "POST",
            data: {
                id
            },
            error: function (error) {
                console.log(error);
            },
        });
    }

</script>

<script type="text/javascript">
    $(document).ready(function () {
        $("#general-info-form").appForm({
            isModal: false,
            onSuccess: function (result) {
                appAlert.success(result.message, {duration: 10000});
                setTimeout(function () {
                    window.location.href = "<?php echo get_uri("team_members/view/" . $user_info->id); ?>" + "/general";
                }, 500);
            }
        });
        $("#general-info-form .select2").select2();

        setDatePicker("#dob");

    });
</script>

<script type="text/javascript">

    $(document).ready(function() {

        function handleTaskFileUpload(filesList) {
        if (filesList.length === 0) {
            console.log("No files selected for upload.");
            return;
        }

        const fileData = new FormData();
        for (let i = 0; i < filesList.length; i++) {
            fileData.append('files[]', filesList[i]);
        }
        fileData.append('user_id', '<?php echo $user_info->id ?>');
        fileData.append(AppHelper.csrfTokenName, AppHelper.csrfHash);

        $.ajax({
            url: base_url + 'index.php/api/CV_file_update',
            type: "POST",
            data: fileData,
            processData: false,
            contentType: false,
            success: function (data) {
                const uploadedFiles = JSON.parse(data);
                const uploadedItemsContainer = document.getElementById('uploaded-items');
                uploadedItemsContainer.innerHTML = '';
                uploadedFiles.data.forEach(item => {
                    const fileDiv = document.createElement('div');
                    fileDiv.className = 'uploaded-item';

                    const fileInfo = `
                        <a download href="${base_url}files/project_files/${item.file_name}"><span>${item.name} (${item.file_size / 1000} KB)</span></a>
                        <button onclick="handleFileDelete(event, '${item.id}')" class="delete-button">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path d="M16 6V5.2C16 4.0799 16 3.51984 15.782 3.09202C15.5903 2.71569 15.2843 2.40973 14.908 2.21799C14.4802 2 13.9201 2 12.8 2H11.2C10.0799 2 9.51984 2 9.09202 2.21799C8.71569 2.40973 8.40973 2.71569 8.21799 3.09202C8 3.51984 8 4.0799 8 5.2V6M10 11.5V16.5M14 11.5V16.5M3 6H21M19 6V17.2C19 18.8802 19 19.7202 18.673 20.362C18.3854 20.9265 17.9265 21.3854 17.362 21.673C16.7202 22 15.8802 22 14.2 22H9.8C8.11984 22 7.27976 22 6.63803 21.673C6.07354 21.3854 5.6146 20.9265 5.32698 20.362C5 19.7202 5 18.8802 5 17.2V6" stroke="#D92D20" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                            </svg>
                        </button>
                    `;

                    fileDiv.innerHTML = fileInfo;
                    uploadedItemsContainer.appendChild(fileDiv);
                });
            },
            error: function (xhr, status, error) {
                console.error("Error uploading files:", xhr.responseText, status, error);
                if (xhr.status === 403) {
                    console.error("Forbidden: You don't have permission to access this resource.");
                }
            },
        });
    }


        document.querySelector('#file-upload')?.addEventListener('change', function(event) {
            handleTaskFileUpload(event.target.files)
        });


    })
</script>