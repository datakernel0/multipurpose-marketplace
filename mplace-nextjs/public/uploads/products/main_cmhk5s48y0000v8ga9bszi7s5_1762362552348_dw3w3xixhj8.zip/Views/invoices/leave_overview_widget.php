<?php

?>

<div id="leave-overview-widget-container">
    <div class="card bg-white">
        <div class="card-header">
            <i data-feather="file-text" class="icon-16"></i> &nbsp;<?php echo app_lang("who_is_out"); ?>
            
        </div>

        <div class="card-body rounded-bottom" id="invoice-overview-container">
            <?php if(count($leave_data)) { ?>
                <?php foreach($leave_data as $data) { ?>
                    <p style="display: flex; justify-content: space-between;"><?php echo $data->applicant_name ?> <span><?php echo $data->start_date ." - ". $data->end_date ?></span></p>
                <?php  } ?>

            <?php } else { ?>
                <p>No one is on vacation on this or next month</p>
            <?php } ?>            
        </div>
    </div>
</div>

<script>
    $(document).ready(function () {
    
    });
</script>