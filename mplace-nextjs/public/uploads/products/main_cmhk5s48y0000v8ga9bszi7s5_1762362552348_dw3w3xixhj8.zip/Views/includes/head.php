<head>
    <?php echo view('includes/meta'); ?>
    <?php echo view('includes/helper_js'); ?>
    <?php echo view('includes/plugin_language_js'); ?>
    <meta name="referrer" content="origin">
    <meta name="google-signin-client_id" content="708218150122-9ah93ilgj0904ca36837emb4s3hes37k.apps.googleusercontent.com">
    <script>
        var base_url = '<?php echo base_url(); ?>';
    </script>

    <?php
    
    $css_files = array(
        "assets/bootstrap/css/bootstrap.min.css",
        "assets/js/select2/select2.min.css", //don't combine this css because of the images path
        //"assets/js/select2/select2-bootstrap.min.css",
        "assets/css/app.all.css",
    );

    if (app_lang("text_direction") == "rtl") {
        array_push($css_files, "assets/css/rtl.css");
    }

    array_push($css_files, "assets/css/custom-style.css"); //add to last. custom style should not be merged

    load_css($css_files);

    load_js(array(
        "assets/js/app.all.js"
    ));
    // load_js(array(
    //     "assets/js/ckeditor.min.js"
    // ));
    load_js(array(
        "assets/js/select2/select2.min.js"
    ));
    
    ?>

    <?php echo view("includes/csrf_ajax"); ?>

    <?php app_hooks()->do_action('app_hook_head_extension'); ?>

    <?php echo view("includes/custom_head"); ?>

</head>