<?php

namespace App\Controllers;

use App\Libraries\Stripe;

class User_story extends Security_Controller {
   
    public function __construct()
    {
        parent::__construct();
        if ($this->has_all_projects_restricted_role()) {
            app_redirect("forbidden");
        }

    }
  

    function story_member_assign() {
        $project_id = $this->request->getPost('project_id');
        $data = [            
            "project_id" => $project_id,
            "created_by" => $this->login_user->id,
            "created_at" => get_current_utc_time(),            
            "story_id" => $this->request->getPost('story_id'),            
            "type" => "story",            
            "assign_to" => $this->request->getPost('assign_to')
        ];

        $save_id = $this->Project_members_model->member_assigns_for_backlog($data);
        if ($save_id) {
            $activitys = [
                "type" => "story",
                "type_id" => $data["story_id"],
                "created_by" => $this->login_user->id,
                "action_key" => "Assign",
                "actions" => json_encode(['A new member added'])
            ];
            $this->Project_activity_model->save_activity($activitys);
            echo json_encode(array("success" => true, 'id' => $save_id, 'message' => app_lang('record_saved')));
        } else {
            echo json_encode(array("success" => false, 'message' => app_lang('error_occurred')));
        }
    }

    function story_member_delete($id = 0) {
        $project_id = $this->request->getPost('project_id');
        $data = [            
            "project_id" => $project_id,
            "created_by" => $this->login_user->id,
            "created_at" => get_current_utc_time(),            
            "story_id" => $this->request->getPost('story_id'),            
            "type" => "story",            
            "assign_to" => $this->request->getPost('assign_to')
        ];
        $save_id = $this->Project_members_model->member_delete_for_backlog($data);
        if ($save_id) {
            $activitys = [
                "type" => "story",
                "type_id" => $data["story_id"],
                "created_by" => $this->login_user->id,
                "action_key" => "Assign",
                "actions" => json_encode(['A member deleted'])
            ];
            $this->Project_activity_model->save_activity($activitys);
            echo json_encode(array("success" => true, 'id' => $save_id, 'message' => app_lang('record_saved')));
        } else {
            echo json_encode(array("success" => false, 'message' => app_lang('error_occurred')));
        }
    }

}

/* End of file taxes.php */
/* Location: ./app/controllers/taxes.php */