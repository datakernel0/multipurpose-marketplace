<?php
// Temporary controller to create supervisor_assignments table
namespace App\Controllers;

use App\Controllers\Security_Controller;

class Create_table extends Security_Controller {

    function __construct() {
        parent::__construct();
    }

    function supervisor_assignments() {
        try {
            $db = \Config\Database::connect();
            
            // Create supervisor_assignments table
            $sql = "CREATE TABLE IF NOT EXISTS supervisor_assignments (
                id INT AUTO_INCREMENT PRIMARY KEY,
                supervisor_id INT NOT NULL COMMENT 'User ID of the supervisor',
                member_id INT NOT NULL COMMENT 'User ID of the assigned member',
                assigned_by INT NOT NULL COMMENT 'User ID who made the assignment',
                assigned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                is_active TINYINT(1) DEFAULT 1 COMMENT '1=active, 0=inactive',
                deleted TINYINT(1) DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                INDEX idx_supervisor (supervisor_id),
                INDEX idx_member (member_id),
                INDEX idx_active (is_active),
                UNIQUE KEY unique_assignment (supervisor_id, member_id, deleted)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
            
            $db->query($sql);
            
            // Update sv_access column comment
            $sql = "ALTER TABLE users MODIFY COLUMN sv_access INT(11) NOT NULL DEFAULT 0 COMMENT 'Team Member-0, Manager-1, Supervisor-2, CHRO-3, CEO-4'";
            $db->query($sql);
            
            echo "<h2>✅ Database Setup Complete!</h2>";
            echo "<p><strong>supervisor_assignments</strong> table created successfully!</p>";
            echo "<p><strong>sv_access</strong> column comment updated!</p>";
            echo "<p>You can now access: <strong>Settings → Supervisor Assignments</strong></p>";
            echo "<p><a href='" . get_uri("supervisor_assignments") . "'>Go to Supervisor Assignments</a></p>";
            
        } catch (Exception $e) {
            echo "<h2>❌ Error</h2>";
            echo "<p>Error: " . $e->getMessage() . "</p>";
        }
    }
}
