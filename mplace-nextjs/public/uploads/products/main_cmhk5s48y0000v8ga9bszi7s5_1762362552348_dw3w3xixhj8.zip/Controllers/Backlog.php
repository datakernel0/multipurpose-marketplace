<?php

namespace App\Controllers;

class Backlog extends Security_Controller {

    function index() {
        return $this->template->rander("backlog/index");
    }

}

/* End of file team.php */
/* Location: ./app/controllers/team.php */