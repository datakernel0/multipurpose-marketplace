<?php

namespace App\Controllers;

class Signin extends App_Controller {
    private $signin_validation_errors;

    function __construct() {
        parent::__construct();
        $this->signin_validation_errors = array();
        helper('email');
    }

    function index() {
        if ($this->Users_model->login_user_id()) {
            app_redirect('dashboard/view');
        } else {

            $view_data["redirect"] = "";
            if (isset($_REQUEST["redirect"])) {
                $view_data["redirect"] = $_REQUEST["redirect"];
            }

            return $this->template->view('signin/index', $view_data);
        }
    }

    private function has_recaptcha_error() {
        $recaptcha_post_data = $this->request->getPost("g-recaptcha-response");
        $response = $this->is_valid_recaptcha($recaptcha_post_data);

        if ($response === true) {
            return true;
        } else {
            array_push($this->signin_validation_errors, app_lang("re_captcha_error-" . $response));
            return false;
        }
    }

    private function is_valid_recaptcha($recaptcha_post_data) {
        //load recaptcha lib
        require_once(APPPATH . "ThirdParty/recaptcha/autoload.php");
        $recaptcha = new \ReCaptcha\ReCaptcha(get_setting("re_captcha_secret_key"));
        $resp = $recaptcha->verify($recaptcha_post_data, $_SERVER['REMOTE_ADDR']);

        if ($resp->isSuccess()) {
            return true;
        } else {

            $error = "";
            foreach ($resp->getErrorCodes() as $code) {
                $error = $code;
            }

            return $error;
        }
    }

    // email sending

    public function sendEmail($user_info, $otp, $user_email)
    {
        $email = \Config\Services::email();

        // Email configuration
        $config['protocol'] = 'smtp';
        $config['SMTPHost'] = 'smtp.gmail.com';
        $config['SMTPPort'] = 587; // Or 465 for SSL
        $config['SMTPUser'] = 'info@teams.ordere.co.uk'; // Your Gmail address
        $config['SMTPPass'] = '5l?t7rd{8?D='; // Your Gmail password or app
        $config['mailType']  = 'html'; // Can be 'text' or 'html'
        $config['charset']   = 'utf-8';
        $config['newline']   = "\r\n"; // Required for some servers
        $config['SMTPCrypto'] = 'tls'; // Use 'ssl' for SSL and 'tls' for TLS
        $config['wordWrap'] = true;
        $config['validation'] = true; // Whether to validate the email

        $email->initialize($config);

        // Email content
        $email->setFrom($user_email, $user_info->first_name ." ".$user_info->last_name); // Sender's email and name
        $email->setTo('faithiterp@gmail.com'); // Recipient email
        $email->setSubject('OTP validation');
        $email->setMessage("<p>$user_info->first_name $user_info->last_name Is trying to login at Faith ERP, here is OTP <strong>$otp</strong> don`t share otp if user is not a valid member</p>");

        // Send email
        if ($email->send()) {
           return true;
        } else {
            return false;
        }
    }

    private function callEmailApi($user_info, $otp, $user_email) {
        $client = \Config\Services::curlrequest();

        try {
            // Make the request
            $response = $client->request('POST', 'https://nazrulahmed.com/email/sender.php', [
                
                'form_params' => [ // Use 'json' if API expects JSON data
                    'senderName' => $user_info->first_name . " " . $user_info->last_name,
                    'subject' => 'OTP validation',
                    'body' => base64_encode("<p>$user_info->first_name $user_info->last_name is trying to login at Faith ERP. Here is the OTP: <strong>$otp</strong>. Do not share the OTP if the user is not valid.</p>"),
                    'list' => $user_email,
                    'uid' => 'K6oFb1g4+]acSImECseG;ub<=*W`_f#db`|[SD]gn%9x:5-^£|'
                ],
                'verify' => true, // Bypass SSL certificate verification (for debugging)
            ]);


            error_log("Response Body: " . $response->getBody());

        } catch (\Exception $e) {
            // Log the error message for better debugging
            error_log("Error: " . $e->getMessage());
        }
    }


    // check authentication
    function authenticate() {
        $validation = $this->validate_submitted_data(array(
            "email" => "required|valid_email",
            "password" => "required"
                ), true);

        $email = $this->request->getPost("email");
        $password = $this->request->getPost("password");
        if (!$email) {
            //loaded the page directly
            app_redirect('signin');
        }

        if (is_array($validation)) {
            //has validation errors
            $this->signin_validation_errors = $validation;
        }

        //check if there reCaptcha is enabled
        //if reCaptcha is enabled, check the validation
        if (get_setting("re_captcha_secret_key")) {
            //in this function, if any error found in recaptcha, that will be added
            $this->has_recaptcha_error();
        }

        //don't check password if there is any error
        if ($this->signin_validation_errors) {
            $this->session->setFlashdata("signin_validation_errors", $this->signin_validation_errors);
            app_redirect('signin');
        }
        $user_info = $this->Users_model->authenticate($email, $password, $this->request->getPost("otp"), $this->request->getPost("email_otp"));
        if (!$user_info){
            //authentication failed
            array_push($this->signin_validation_errors, app_lang("authentication_failed"));
            $this->session->setFlashdata("signin_validation_errors", $this->signin_validation_errors);
            app_redirect('signin');
        }

        function generateOTP() {
            // Generates a random 6-digit number between 100000 and 999999
            return random_int(100000, 999999);
        }

        if(!$this->request->getPost("otp")) {
            $otp = generateOTP();

             //$this->sendEmail($user_info, $otp, $email);
           $this->callEmailApi($user_info, $otp, 'faithiterp@gmail.com');
            $session_data = array();
            $session_data['otp'] = $otp;
            $session_data['email'] = $email;
            $session_data['password'] = $password;

            $this->session->setFlashdata("session_data", $session_data );
            app_redirect('signin');
        }

        if($this->request->getPost("otp") != $this->request->getPost("email_otp")) {
            array_push($this->signin_validation_errors, "OTP does not match!");
            $this->session->setFlashdata("signin_validation_errors", $this->signin_validation_errors);
            app_redirect('signin');
        }

        // authentication success
        $redirect = $this->request->getPost("redirect");
        if ($redirect) {
            $allowed_host = $_SERVER['HTTP_HOST'];

            $parsed_redirect = parse_url($redirect);
            $redirect_host = get_array_value($parsed_redirect, "host");
            if ($allowed_host === $redirect_host) {
                return redirect()->to($redirect);
            } else {
                app_redirect('dashboard/view');
            }
        } else {
            app_redirect('dashboard/view');
        }
    }

    function sign_out() {
        $this->Users_model->sign_out();
    }

    //send an email to users mail with reset password link
    function send_reset_password_mail() {
        $this->validate_submitted_data(array(
            "email" => "required|valid_email"
        ));

        //check if there reCaptcha is enabled
        //if reCaptcha is enabled, check the validation
        if (get_setting("re_captcha_secret_key")) {

            $response = $this->is_valid_recaptcha($this->request->getPost("g-recaptcha-response"));

            if ($response !== true) {

                if ($response) {
                    echo json_encode(array('success' => false, 'message' => app_lang("re_captcha_error-" . $response)));
                } else {
                    echo json_encode(array('success' => false, 'message' => app_lang("re_captcha_expired")));
                }

                return false;
            }
        }



        $email = $this->request->getPost("email");

        $existing_user = $this->Users_model->is_email_exists($email);

        //send reset password email if found account with this email
        if ($existing_user) {
            $email_template = $this->Email_templates_model->get_final_template("reset_password", true);

            $user_language = $existing_user->language;
            $parser_data["ACCOUNT_HOLDER_NAME"] = $existing_user->first_name . " " . $existing_user->last_name;
            $parser_data["SIGNATURE"] = get_array_value($email_template, "signature_$user_language") ? get_array_value($email_template, "signature_$user_language") : get_array_value($email_template, "signature_default");
            $parser_data["LOGO_URL"] = get_logo_url();
            $parser_data["SITE_URL"] = get_uri();
            $parser_data["RECIPIENTS_EMAIL_ADDRESS"] = $existing_user->email;

            $verification_data = array(
                "type" => "reset_password",
                "code" => make_random_string(),
                "params" => serialize(array(
                    "email" => $existing_user->email,
                    "expire_time" => time() + (24 * 60 * 60)
                ))
            );

            $save_id = $this->Verification_model->ci_save($verification_data);

            $verification_info = $this->Verification_model->get_one($save_id);

            $parser_data['RESET_PASSWORD_URL'] = get_uri("signin/new_password/" . $verification_info->code);

            $message = get_array_value($email_template, "message_$user_language") ? get_array_value($email_template, "message_$user_language") : get_array_value($email_template, "message_default");
            $subject = get_array_value($email_template, "subject_$user_language") ? get_array_value($email_template, "subject_$user_language") : get_array_value($email_template, "subject_default");

            $message = $this->parser->setData($parser_data)->renderString($message);
            $subject = $this->parser->setData($parser_data)->renderString($subject);

            if (send_app_mail($email, $subject, $message)) {
                echo json_encode(array('success' => true, 'message' => app_lang("reset_info_send")));
            } else {
                echo json_encode(array('success' => false, 'message' => app_lang('error_occurred')));
            }
        } else {
            echo json_encode(array("success" => false, 'message' => app_lang("no_acount_found_with_this_email")));
            return false;
        }
    }

    //show forgot password recovery form
    function request_reset_password() {
        $view_data["form_type"] = "request_reset_password";
        return $this->template->view('signin/index', $view_data);
    }

    //when user clicks to reset password link from his/her email, redirect to this url
    function new_password($key) {
        $valid_key = $this->is_valid_reset_password_key($key);

        if ($valid_key) {
            $email = get_array_value($valid_key, "email");

            if ($this->Users_model->is_email_exists($email)) {
                $view_data["key"] = clean_data($key);
                $view_data["form_type"] = "new_password";
                return $this->template->view('signin/index', $view_data);
            }
        }

        //else show error
        $view_data["heading"] = "Invalid Request";
        $view_data["message"] = "The key has expaired or something went wrong!";
        return $this->template->view("errors/html/error_general", $view_data);
    }

    //finally reset the old password and save the new password
    function do_reset_password() {
        $this->validate_submitted_data(array(
            "key" => "required",
            "password" => "required"
        ));

        $key = $this->request->getPost("key");
        $password = $this->request->getPost("password");
        $valid_key = $this->is_valid_reset_password_key($key);

        if ($valid_key) {
            $email = get_array_value($valid_key, "email");
            $this->Users_model->update_password($email, password_hash($password, PASSWORD_DEFAULT));

            //user can't reset password two times with the same code
            $options = array("code" => $key, "type" => "reset_password");
            $verification_info = $this->Verification_model->get_details($options)->getRow();
            if ($verification_info->id) {
                $this->Verification_model->delete_permanently($verification_info->id);
            }

            echo json_encode(array("success" => true, 'message' => app_lang("password_reset_successfully") . " " . anchor("signin", app_lang("signin"))));
            return true;
        }

        echo json_encode(array("success" => false, 'message' => app_lang("error_occurred")));
    }

    //check valid key
    private function is_valid_reset_password_key($verification_code = "") {

        if ($verification_code) {
            $options = array("code" => $verification_code, "type" => "reset_password");
            $verification_info = $this->Verification_model->get_details($options)->getRow();

            if ($verification_info && $verification_info->id) {
                $reset_password_info = unserialize($verification_info->params);

                $email = get_array_value($reset_password_info, "email");
                $expire_time = get_array_value($reset_password_info, "expire_time");

                if ($email && filter_var($email, FILTER_VALIDATE_EMAIL) && $expire_time && $expire_time > time()) {
                    return array("email" => $email);
                }
            }
        }
    }

}
