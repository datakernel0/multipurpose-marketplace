<?php

namespace App\Controllers;

class Team extends Security_Controller {

    function __construct() {
        parent::__construct();
        // Allow access for admin, settings admin, or users with sv_access level 3 (CHRO) or 4 (CEO)
        if (!($this->login_user->is_admin || 
              get_array_value($this->login_user->permissions, "can_manage_all_kinds_of_settings") ||
              $this->login_user->sv_access == 3 || 
              $this->login_user->sv_access == 4)) {
            app_redirect("forbidden");
        }
    }

    function index() {
        return $this->template->rander("team/index");
    }

    /* load team add/edit modal */

    function modal_form() {
        $this->validate_submitted_data(array(
            "id" => "numeric"
        ));

        $view_data['model_info'] = $this->Team_model->get_one($this->request->getPost('id'));
        
        return $this->template->view('team/modal_form', $view_data);
    }

    /* add/edit a team */

    function save() {
        try {
            // Get POST data first
            $id = $this->request->getPost('id');
            $title = $this->request->getPost('title');
            
            // Basic validation
            if (empty($title)) {
                echo json_encode(array("success" => false, 'message' => 'Team name is required'));
                exit();
            }
            
            // Skip the validate_submitted_data for now to avoid potential issues
            // $this->validate_submitted_data(array("title" => "required"));

            // Check if title already exists
            try {
                if ($this->Team_model->is_team_title_exists($title, $id)) {
                    echo json_encode(array("success" => false, 'message' => 'Team title already exists.'));
                    exit();
                }
            } catch (Exception $e) {
                echo json_encode(array("success" => false, 'message' => 'Error checking title: ' . $e->getMessage()));
                exit();
            }

            // Use direct database operations instead of ci_save
            try {
                $db = \Config\Database::connect();
                $team_table = $db->prefixTable('sv_teams');
                
                if ($id) {
                    // Update existing team
                    $sql = "UPDATE $team_table SET title = ? WHERE id = ?";
                    $result = $db->query($sql, [$title, $id]);
                    $save_id = $id;
                    $operation = "update";
                } else {
                    // Insert new team
                    $sql = "INSERT INTO $team_table (title, deleted) VALUES (?, 0)";
                    $result = $db->query($sql, [$title]);
                    
                    // Try multiple ways to get the insert ID
                    $save_id = $db->insertID();
                    if (!$save_id) {
                        // Alternative method: get the last inserted ID
                        $last_id_result = $db->query("SELECT LAST_INSERT_ID() as id");
                        $last_id_row = $last_id_result->getRow();
                        $save_id = $last_id_row ? $last_id_row->id : null;
                    }
                    $operation = "insert";
                }
                
                // Debug: Log the database operation results
                $db_error = $db->error();
                $affected_rows = $db->affectedRows();
                
                if (!$db_error['code'] && $affected_rows > 0) {
                    // Success if no database error and at least one row was affected
                    if ($save_id) {
                        echo json_encode(array("success" => true, 'id' => $save_id, 'message' => 'Team saved successfully'));
                    } else {
                        // Insert was successful but we don't have the ID - still consider it success
                        echo json_encode(array("success" => true, 'id' => 'unknown', 'message' => 'Team saved successfully (ID not available)'));
                    }
                } else {
                    $error_msg = "Failed to save team. ";
                    $error_msg .= "Operation: $operation, ";
                    $error_msg .= "Save ID: " . ($save_id ? $save_id : 'null') . ", ";
                    $error_msg .= "DB Error: " . ($db_error['message'] ? $db_error['message'] : 'none') . ", ";
                    $error_msg .= "Affected Rows: $affected_rows";
                    echo json_encode(array("success" => false, 'message' => $error_msg));
                }
            } catch (Exception $e) {
                echo json_encode(array("success" => false, 'message' => 'Database error: ' . $e->getMessage()));
                exit();
            }
        } catch (Exception $e) {
            echo json_encode(array("success" => false, 'message' => 'General Error: ' . $e->getMessage()));
        }
    }

    /* delete/undo a team */

    function delete() {
        $this->validate_submitted_data(array(
            "id" => "required|numeric"
        ));

        $id = $this->request->getPost('id');
        
        // Check if team has members
        try {
            $member_count = $this->Team_model->get_sv_team_members_count($id);
            if ($member_count > 0) {
                echo json_encode(array("success" => false, 'message' => 'Cannot delete team. Team has ' . $member_count . ' member(s). Please reassign members first.'));
                exit();
            }
        } catch (Exception $e) {
            // If there's an error getting member count, allow deletion
            echo json_encode(array("success" => false, 'message' => 'Error checking team members: ' . $e->getMessage()));
            exit();
        }

        if ($this->request->getPost('undo')) {
            // Restore deleted team
            $this->Team_model->delete($id, true);
            echo json_encode(array("success" => true, "data" => $this->_row_data($id), "message" => app_lang('record_undone')));
        } else {
            // Soft delete team
            $this->Team_model->delete($id);
            echo json_encode(array("success" => true, 'message' => app_lang('record_deleted')));
        }
    }

    /* list of team prepared for datatable */

    function list_data() {
        $list_data = $this->Team_model->get_sv_team_details()->getResult();
        $result = array();
        foreach ($list_data as $data) {
            $result[] = $this->_make_row($data);
        }
        echo json_encode(array("data" => $result));
    }

    /* reaturn a row of team list table */

    private function _row_data($id) {
        $options = array("id" => $id);
        $data = $this->Team_model->get_sv_team_details($options)->getRow();
        return $this->_make_row($data);
    }

    /* prepare a row of team list table */

    private function _make_row($data) {
        try {
            $member_count = $this->Team_model->get_sv_team_members_count($data->id);
            $total_members = "<span class='badge badge-light w100'><i data-feather='users' class='icon-16'></i> " . $member_count . "</span>";
        } catch (Exception $e) {
            // If there's an error getting member count, show 0
            $total_members = "<span class='badge badge-light w100'><i data-feather='users' class='icon-16'></i> 0</span>";
        }
        
        return array(
            $data->title,
            modal_anchor(get_uri("team/team_members"), $total_members, array("title" => app_lang('team_members'), "data-post-team_id" => $data->id)),
            modal_anchor(get_uri("team/modal_form"), "<i data-feather='edit' class='icon-16'></i>", array("class" => "edit", "title" => app_lang('edit_team'), "data-post-id" => $data->id))
            . js_anchor("<i data-feather='x' class='icon-16'></i>", array('title' => app_lang('delete_team'), "class" => "delete", "data-id" => $data->id, "data-action-url" => get_uri("team/delete"), "data-action" => "delete"))
        );
    }

    function team_members() {
        $team_id = $this->request->getPost('team_id');
        
        // Get team members using Users_model
        $team_members = $this->Users_model->get_all_where(array("deleted" => 0, "team_id" => $team_id, "user_type" => "staff"))->getResult();
        
        $view_data['team_members'] = $team_members;
        $view_data['team_info'] = $this->Team_model->get_sv_team_details(array("id" => $team_id))->getRow();
        
        return $this->template->view('team/team_members', $view_data);
    }

}

/* End of file team.php */
/* Location: ./app/controllers/team.php */