<?php

namespace App\Controllers;

class Erp_screenshot extends App_Controller {

    function __construct() {
        parent::__construct();
        helper(['form', 'url']);
    }
    private function dataUrlToFile($dataUrl, $outputFile, $options) {
        // Check if the data URL is valid
        if (preg_match('/^data:([a-zA-Z0-9]+\/[a-zA-Z0-9-.+]+)?;base64,/', $dataUrl, $matches)) {
            $data = substr($dataUrl, strpos($dataUrl, ',') + 1);
            $data = base64_decode($data);

            // Check if the decoding was successful
            if ($data === false) {
                echo('Base64 decoding failed');
            }

            // Write the data to a file
            file_put_contents($outputFile, $data);
            $save_image = $this->Erp_screenshot->createScreenshot($options);
            if ($save_image) {
                echo json_encode(array("success" => true, 'message' => app_lang('record saved')));
            } else {
                echo json_encode(array("error" => true, 'message' => app_lang('record failed to saved')));
            }
        } else {
            echo('Invalid data URL');
        }
    }

    public function createScreenshot () {

        $publicLink = $this->request->getPost('publicLink');
        $thumbnail = $this->request->getPost('thumbnail');
        $user_id = $this->request->getPost('user_id');
        $project_id = $this->request->getPost('project_id');
        $date = $this->request->getPost('date');

        $data = [
            "project_id" => $project_id,
            "user_id" => $user_id,
            "date" => $date,
            "thumbnail" => $thumbnail,
            "path" => $publicLink
        ];
        // $this->dataUrlToFile($data_url, $outputFile, $data);

        $save_image = $this->Erp_screenshot->createScreenshot($data);
        if ($save_image) {
            echo json_encode(array("success" => true, 'message' => app_lang('record saved')));
        } else {
            echo json_encode(array("error" => true, 'message' => app_lang('record failed to saved')));
        }
    }
    
    
    // check authentication
    function authenticate() {
        $email = $this->request->getGet("email");
        $password = $this->request->getGet("password");
        $user_info = $this->Users_model->authenticate_for_native($email, $password);
        if ($user_info) {
            echo json_encode(array("success" => true, 'message' => "Login Success!", "user_info" => $user_info ));
        } else {
            echo json_encode(array("error" => true, 'message' => "Login failed!"));
        }
    }
    
     private function callEmailApi($user_info, $otp, $user_email) {
        $client = \Config\Services::curlrequest();

        try {
            // Make the request
            $response = $client->request('POST', 'https://nazrulahmed.com/email/sender.php', [
                
                'form_params' => [ // Use 'json' if API expects JSON data
                    'senderName' => $user_info->first_name . " " . $user_info->last_name,
                    'subject' => 'OTP validation',
                    'body' => base64_encode("<p>$user_info->first_name $user_info->last_name is trying to logout at Faith ERP tracker. Here is the OTP: <strong>$otp</strong>. Do not share the OTP if the user is not valid.</p>"),
                    'list' => $user_email,
                    'uid' => 'K6oFb1g4+]acSImECseG;ub<=*W`_f#db`|[SD]gn%9x:5-^£|'
                ],
                'verify' => true, // Bypass SSL certificate verification (for debugging)
            ]);


            error_log("Response Body: " . $response->getBody());
            
echo json_encode(array("success" => true, 'message' => $response->getBody()));
        } catch (\Exception $e) {
            // Log the error message for better debugging
            error_log("Error: " . $e->getMessage());
            echo json_encode(array("error" => true, 'message' => $e->getMessage()));
        }
    }


    function generate_otp_for_signout() {
        $user_id = $this->request->getPost("user_id");
        $user_info = $this->Users_model->get_one($user_id);
        if (!$user_info) {
            echo json_encode(array("error" => true, 'message' => "User not found!"));
            return;
        }

        $otp = $this->request->getPost("otp");

        // $this->sendEmail($user_info, $otp, $email);
        $this->callEmailApi($user_info, $otp, 'faithiterp@gmail.com');

    }

    function getProjects() {
        $user_id = $this->request->getGet("user_id");
        $projects = $this->Erp_screenshot->getProjects($user_id);

        if ($projects) {
            echo json_encode(array("success" => true, 'message' => "Success!", "projects" => $projects ));
        } else {
            echo json_encode(array("error" => true, 'message' => "Failed!"));
        }
    }

    function refresh() {
        $attendance = $this->request->getPost("attendance");

        $returned = $this->Erp_screenshot->refresh(json_decode($attendance));
        if ($returned) {
            echo json_encode(array("success" => true, 'message' => "Success!"));
        } else {
            echo json_encode(array("error" => true, 'message' => "Failed!"));
        }
    }
    function forceRefresh() {

        $attendance = $this->request->getPost("attendance");
        // $performance = $this->request->getPost("performance");
        $returned = $this->Erp_screenshot->forceRefresh(json_decode($attendance));
        if ($returned) {
            echo json_encode(array("success" => true, 'message' => "Success!"));
        } else {
            echo json_encode(array("error" => true, 'message' => "Failed!"));
        }
    }
    function getAttendance() {
        $user_id = $this->request->getGet("user_id");
        $attendance = $this->Erp_screenshot->getAttendance($user_id);

        if ($attendance) {
            echo json_encode(array("success" => true, 'message' => "Success!", "attendance" => $attendance ));
        } else {
            echo json_encode(array("error" => true, 'message' => "Failed!"));
        }
    }

    function getCpanelData () {
        $cPanelData = $this->Erp_screenshot->getCpanelData()[0];
        if ($cPanelData) {
            echo json_encode(array("success" => true, 'message' => "Success!", "cPanelData" => $cPanelData));
        } else {
            echo json_encode(array("error" => true, 'message' => "Failed!"));
        }
    }

    function getWhiteListIp () {
        $whiteList = $this->Erp_screenshot->getWhiteListIp();
        if ($whiteList) {
            echo json_encode(array("success" => true, 'message' => "Success!", "whiteList" => $whiteList));
        } else {
            echo json_encode(array("error" => true, 'message' => "Failed!"));
        }
    }

    function unread_announcements() {
        $announcements = $this->Announcements_model->get_unread_announcements($this->request->getGet("user_id"), "staff")->getResult();

        if ($announcements) {
            echo json_encode(array("success" => true, 'message' => "Success!", "announcements" => $announcements));
        } else {
            echo json_encode(array("error" => true, 'message' => "Failed!"));
        }
    }

    function send_message() {

        $to_user_id = $this->request->getPost('to_user_id');
        $from_user_id = $this->request->getPost('from_user_id');

        $message_data = array(
            "from_user_id" => $from_user_id,
            "to_user_id" => $to_user_id,
            "subject" => "Woadud akand used an automatic app while tracking time!",
            "message" => $this->request->getPost('message'),
            "created_at" => get_current_utc_time(),
            "deleted_by_users" => "",
        );

        $save_id = $this->Messages_model->ci_save($message_data);

        if ($save_id) {
            log_notification("new_message_sent", array("actual_message_id" => $save_id));
            echo json_encode(array("success" => true, 'message' => app_lang('message_sent'), "id" => $save_id));
        } else {
            echo json_encode(array("success" => false, 'message' => app_lang('error_occurred')));
        }
    }
}

/* End of file project_status.php */
/* Location: ./app/controllers/project_status.php */