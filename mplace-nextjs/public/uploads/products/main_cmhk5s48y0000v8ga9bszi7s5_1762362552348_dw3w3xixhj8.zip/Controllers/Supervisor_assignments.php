<?php

namespace App\Controllers;

use App\Controllers\Security_Controller;

class Supervisor_assignments extends Security_Controller {

    function __construct() {
        parent::__construct();
        
        // Allow access for CHRO, CEO, admin, or settings admin
        if (!($this->login_user->is_admin || 
              get_array_value($this->login_user->permissions, "can_manage_all_kinds_of_settings") ||
              $this->login_user->sv_access == 3 || 
              $this->login_user->sv_access == 4)) {
            app_redirect("forbidden");
        }
    }

    function index() {
        return $this->template->rander("supervisor_assignments/index");
    }

    function modal_form() {
        // Get all supervisors (users with sv_access = 2)
        $view_data['supervisors_dropdown'] = array("" => "Select Supervisor") + $this->Users_model->get_dropdown_list(array("first_name", "last_name"), "id", array("deleted" => 0, "user_type" => "staff", "sv_access" => 2));
        
        // Initialize empty members dropdown - will be populated via AJAX when supervisor is selected
        $view_data['members_dropdown'] = array();

        return $this->template->view('supervisor_assignments/modal_form', $view_data);
    }

    function save() {
        $this->validate_submitted_data(array(
            "supervisor_id" => "required",
            "member_ids" => "required"
        ));

        $supervisor_id = $this->request->getPost('supervisor_id');
        $member_ids = $this->request->getPost('member_ids');

        // Ensure member_ids is an array
        if (!is_array($member_ids)) {
            $member_ids = array($member_ids);
        }

        $success_count = 0;
        $error_count = 0;
        $errors = array();

        // Process each member assignment
        foreach ($member_ids as $member_id) {
            // Check if assignment already exists
            if ($this->Supervisor_assignments_model->can_supervisor_access_member($supervisor_id, $member_id)) {
                $error_count++;
                $errors[] = "Assignment for member ID $member_id already exists";
                continue;
            }

            $data = array(
                "supervisor_id" => $supervisor_id,
                "member_id" => $member_id,
                "assigned_by" => $this->login_user->id
            );

            $save_id = $this->Supervisor_assignments_model->ci_save($data);
            if ($save_id) {
                $success_count++;
            } else {
                $error_count++;
                $errors[] = "Failed to assign member ID $member_id";
            }
        }

        // Prepare response
        if ($success_count > 0) {
            $message = "$success_count assignment(s) created successfully";
            if ($error_count > 0) {
                $message .= ", $error_count failed";
            }
            echo json_encode(array("success" => true, 'message' => $message));
        } else {
            $error_message = "No assignments were created. ";
            if (!empty($errors)) {
                $error_message .= implode(', ', $errors);
            }
            echo json_encode(array("success" => false, 'message' => $error_message));
        }
    }

    function delete() {
        $this->validate_submitted_data(array(
            "id" => "required|numeric"
        ));

        $id = $this->request->getPost('id');
        if ($this->Supervisor_assignments_model->delete($id)) {
            echo json_encode(array("success" => true, 'message' => app_lang('record_deleted')));
        } else {
            echo json_encode(array("success" => false, 'message' => app_lang('record_cannot_be_deleted')));
        }
    }

    function list_data() {
        $list_data = $this->Supervisor_assignments_model->get_details()->getResult();
        $result = array();
        foreach ($list_data as $data) {
            $result[] = $this->_make_row($data);
        }
        echo json_encode(array("data" => $result));
    }

    private function _row_data($id) {
        $options = array("id" => $id);
        $data = $this->Supervisor_assignments_model->get_details($options)->getRow();
        return $this->_make_row($data);
    }

    private function _make_row($data) {
        $supervisor_name = $data->supervisor_first_name . ' ' . $data->supervisor_last_name;
        $member_name = $data->member_first_name . ' ' . $data->member_last_name;
        $assigned_by_name = $data->assigned_by_first_name . ' ' . $data->assigned_by_last_name;

        $options = modal_anchor(get_uri("supervisor_assignments/modal_form"), "<i data-feather='edit' class='icon-16'></i>", array("class" => "edit", "title" => app_lang('edit_assignment'), "data-post-id" => $data->id))
            . js_anchor("<i data-feather='x' class='icon-16'></i>", array('title' => app_lang('delete_assignment'), "class" => "delete", "data-id" => $data->id, "data-action-url" => get_uri("supervisor_assignments/delete"), "data-action" => "delete-confirmation"));

        return array(
            get_team_member_profile_link($data->supervisor_id, $supervisor_name),
            get_team_member_profile_link($data->member_id, $member_name),
            $assigned_by_name,
            $data->assigned_at,
            $options
        );
    }

    /**
     * Get assigned members for a supervisor (AJAX endpoint)
     */
    function get_assigned_members() {
        $supervisor_id = $this->request->getPost('supervisor_id');
        
        if (!$supervisor_id) {
            echo json_encode(array("success" => false, 'message' => 'Supervisor ID is required'));
            exit();
        }

        $members = $this->Supervisor_assignments_model->get_assigned_members($supervisor_id)->getResult();
        
        $result = array();
        foreach ($members as $member) {
            $result[] = array(
                'id' => $member->id,
                'name' => $member->first_name . ' ' . $member->last_name,
                'job_title' => $member->job_title,
                'assigned_at' => $member->assigned_at
            );
        }
        
        echo json_encode(array("success" => true, "data" => $result));
    }

    /**
     * Get available members for assignment (AJAX endpoint)
     */
    function get_available_members() {
        $supervisor_id = $this->request->getPost('supervisor_id');
        
        if (!$supervisor_id) {
            echo json_encode(array("success" => false, 'message' => 'Supervisor ID is required'));
            exit();
        }

        $members = $this->Supervisor_assignments_model->get_available_members_for_supervisor($supervisor_id)->getResult();
        
        $result = array();
        foreach ($members as $member) {
            $result[] = array(
                'id' => $member->id,
                'name' => $member->first_name . ' ' . $member->last_name,
                'job_title' => $member->job_title
            );
        }
        
        echo json_encode(array("success" => true, "data" => $result));
    }
}
