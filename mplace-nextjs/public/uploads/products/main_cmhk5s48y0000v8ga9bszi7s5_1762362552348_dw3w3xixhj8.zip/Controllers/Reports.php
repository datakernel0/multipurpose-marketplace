<?php

namespace App\Controllers;

class Reports extends Security_Controller {

    function __construct() {
        parent::__construct();
        $this->access_only_team_members();
    }

    public function index() {
        $redirect_to = "reports/performance";
        $view_data["redirect_to"] = $redirect_to;
        return $this->template->rander("reports/index", $view_data);
    }

    function attendance () {
        $view_data = array();

        return $this->template->rander("reports/attendance", $view_data);
    }

    function monthly_report () {

        if($this->login_user->access_type = 2 || $this->login_user->access_type = 3) {
            $start_date = date('Y-m-01');
            $end_date = date('Y-m-t');
            $startDate = $this->request->getPost('start_date');
            $endDate = $this->request->getPost('end_date');

            if($startDate) {
                $start_date = $startDate;
            }

            if($endDate) {
                $end_date = $endDate;
            }


            $view_data["start_date"] = $start_date;
            $view_data["end_date"] = $end_date;



            $this->Reports_model->createCalender($view_data);
            $view_data['report_data'] = $this->Reports_model->getReports($view_data);

            return $this->template->rander("reports/monthly_report", $view_data);
        } else {
            show_404();
        }


    }

    function performance_old () {

        $view_data = array(
            "date" => date('Y-m-d'),
            "user_id" => $this->login_user->id,
        );
        
        // Check access: CEO, CHRO, Manager, or Supervisor only
        if(!in_array($this->login_user->sv_access, [1, 2, 3, 4])) {
            show_404();
        }

        $get_date = $this->request->getPost('date');
        
        // Role-based user filtering
        if($this->login_user->sv_access == 3 || $this->login_user->sv_access == 4) {
            // CEO or CHRO: Show all staff users
            $where = array("user_type" => "staff");
            $view_data['team_members_dropdown'] = array("" => "-") + $this->Users_model->get_dropdown_list(array("first_name", "last_name"), "id", $where);

            $user_id = $this->request->getPost('user_id');

            if($user_id) {
                $view_data['user_id'] = $user_id;
            }
        } 
        elseif($this->login_user->sv_access == 1) {
            // Manager: Show only team members
            if($this->login_user->team_id) {
                $where = array("user_type" => "staff", "team_id" => $this->login_user->team_id);
                $view_data['team_members_dropdown'] = array("" => "-") + $this->Users_model->get_dropdown_list(array("first_name", "last_name"), "id", $where);
                
                $user_id = $this->request->getPost('user_id');
                if($user_id) {
                    $view_data['user_id'] = $user_id;
                }
            }
        }
        elseif($this->login_user->sv_access == 2) {
            // Supervisor: Show only assigned members
            $assigned_members = $this->Supervisor_assignments_model->get_assigned_members($this->login_user->id);
            $members_list = array("" => "-");
            
            if($assigned_members) {
                foreach($assigned_members->getResult() as $member) {
                    $members_list[$member->id] = $member->first_name . ' ' . $member->last_name;
                }
            }
            
            $view_data['team_members_dropdown'] = $members_list;
            
            $user_id = $this->request->getPost('user_id');
            if($user_id) {
                $view_data['user_id'] = $user_id;
            }
        }

        if($get_date) {
            $view_data['date'] = $get_date;
        }

        $view_data['screenshot'] = $this->Reports_model->getScreenshots($view_data);
       return $this->template->rander("reports/performance", $view_data);


    }
    
    function performance () {

        $view_data = array(
            "date" => date('Y-m-d'),
            "user_id" => $this->login_user->id,
        );
        
        // Check access: CEO, CHRO, Manager, or Supervisor only
        if(!in_array($this->login_user->sv_access, [1, 2, 3, 4])) {
            show_404();
        }

        $get_date = $this->request->getPost('date');
        
        // Role-based user filtering
        if($this->login_user->sv_access == 3 || $this->login_user->sv_access == 4) {
            // CEO or CHRO: Show all staff users
            $where = array("user_type" => "staff");
            $view_data['team_members_dropdown'] = array("" => "-") + $this->Users_model->get_dropdown_list(array("first_name", "last_name"), "id", $where);

            $user_id = $this->request->getPost('user_id');

            if($user_id) {
                $view_data['user_id'] = $user_id;
            }
        } 
        elseif($this->login_user->sv_access == 1) {
            // Manager: Show only team members
            if($this->login_user->team_id) {
                $where = array("user_type" => "staff", "team_id" => $this->login_user->team_id);
                $view_data['team_members_dropdown'] = array("" => "-") + $this->Users_model->get_dropdown_list(array("first_name", "last_name"), "id", $where);
                
                $user_id = $this->request->getPost('user_id');
                if($user_id) {
                    $view_data['user_id'] = $user_id;
                }
            }
        }
        elseif($this->login_user->sv_access == 2) {
            // Supervisor: Show only assigned members
            $assigned_members = $this->Supervisor_assignments_model->get_assigned_members($this->login_user->id);
            $members_list = array("" => "-");
            
            if($assigned_members) {
                foreach($assigned_members->getResult() as $member) {
                    $members_list[$member->id] = $member->first_name . ' ' . $member->last_name;
                }
            }
            
            $view_data['team_members_dropdown'] = $members_list;
            
            $user_id = $this->request->getPost('user_id');
            if($user_id) {
                $view_data['user_id'] = $user_id;
            }
        }

        if($get_date) {
            $view_data['date'] = $get_date;
        }
        
        $client = \Config\Services::curlrequest([
            'http_version' => CURL_HTTP_VERSION_1_1, // force HTTP/1.1
            'timeout'      => 30,
            'verify'       => true,
            'http_errors'  => false,
        ]);

        $body = http_build_query([
                        'refresh_token' => 'WIP5RZKdkUoAAAAAAAAAAUH54WvwG_zjzhxCdNHbuO-Kexy2vwB0qRHcLLliDGfU',
                        'grant_type'    => 'refresh_token',
                        'client_id'     => 'us2esrusj64nfig',
                        'client_secret' => 'ad4689hnztdhzt5',
                    ]);
        
        $response = $client->post('https://api.dropboxapi.com/oauth2/token', [
            'headers' => [
                'Content-Type' => 'application/x-www-form-urlencoded',
            ],
            'body' => $body,
        ]);
        
                
        
        $data = json_decode($response->getBody(), true);
        $newAccessToken = $data['access_token'];

        // $token = 'sl.u.AF-bXtLKOuO2-npOtwNJn1FxrQWVxYB4_qK4d78E3jwo-tPcJUTocDAYkDG_F5xK-gDFfono-6Tht_fj4umpOyafV0p6h6GM9_P8pku41DtxGdPfZDV54XWODRSKG2ohR12nM3Snk4GHEnemsgem6U94FFk0wipE3spDEa2CaCpE44jujUi_LR_taEldUBx-HWvMhGbt0XKo2o2Zol8dKl6n0OBIP6bUMA5yGDr64XkTZTD9jBwL4fLa5QnMo2HpC_jPefsdIvrOzYzxBE8SuQkpbnZ0OwEzcOpqHBqoVjFG65k9q_AyLVtY5oqeA_XfUvB271HMrN_Ux4ue34dBdguE55zzZJ6H-9I1bz31jw5syzY_ydS1Dja9J4R4TivmpqO-B4tYdQbcLk7ADKjNhGVtJeg6dFIvdwWaM5Y6s0u68h4ZjyAT4Ryg8eEQJxyfPNWjP58JmPBQH4zUKBEF1SSePXuteCsOr2lNhKIW7KLxCPYK55aVepW9cR7lx_OjCfqJUSIU_ngacquMgDyjUxh-tG1cm0Qm0m_lDBgj23sSRMxPlUPUtQG_1XNE9JzMpKbUKnJCHJ0k_uvGdyuQeeydazMgjqNzXm-z2tWzzy4Gs-6gLvZwFqN48VSVV_MPigvClcFz4bk-k2lGhahnxAq8A-slRPUU3zkMFnjxGLZO0pv6X3WQEtwTLvbS2xFeVELKRytH95MrN-1N2Km-UOCUiuMSV26iAqF9e2NAwoATPP6CqIcxF7wUJFTSLbEdWAVzUVpDK7xxk77IVMZYnWJ9DdEbdG6wglbZxv3gvaR_MDYKO45iRYhv7uUjG_-jEnI-vRxFMv5-TgvkQx_UQxULZsykC5tmnuI82rZRM3KHNhT2fQjwoWJFoJJuao7Yi9zGGMt1d0XLd4Qxq9_JXyhGOiveeF23OL05iLTkZaIn8pKaQNFrp6f9JIpcMIGybMs8Ti3JadEKGcaDj3w77aVBMz-qonYzZFIpLCwJJu3OzQMHwJqibR-1SdBxmtfmlaEmFK6SoXNlw4TT468ICLp2ml4c6cFliLZsDR3eaASW8sWUkuTPHTznfFLM5hGm0OubqhtGVd0RQIbnd-U-mH7viDpN4fcoAg1JOKnZx3IkpAdBesA4UmsqzYZT5L8RPhEjMx5d92L9yX7NwLwn0_AKNGYFEULmBzr6oSnEIXnMqYVw87zrLsaPsvGGJS9YyEgoBg5_IjKm4nsx_gD-B-X574WZmTUSkmK1rs1CY6Pm15stpPYa-4KD6E4Jps36la3upnKf5KA_duuwnxlbgj1LQuaw_ZBYVu5aC92yMR78ckeaFBVYwIdSU4lsU9bPzc5DBQEmQbxpUIQJH4lDFfPsfNA7JlITGmKcjxa9FIHLdtW3MnpQcHptwCnPwP3UgOPd24cwgX08sr6N-mi7YOHjK0qQzowggT6GwzSrH298UoFGLM0_7dqJhNZolmK7Aiw'; // Put in .env
        
        $token = $newAccessToken;
        
        if (!$token) {
            return $this->response->setStatusCode(500)->setBody('Missing DROPBOX_TOKEN');
        }

        if($user_id) {
            $path = '/screenshots/' . date('Y', strtotime($get_date)) . '/' . date('m', strtotime($get_date)) . '/' . date('d', strtotime($get_date)) . '/user_' . $user_id;
        } else {
        $path   = '/screenshots/2025/09/01/user_0';
            
        }
        
        $cursor = $this->request->getGet('cursor') ?? null;

        $http = \Config\Services::curlrequest();

        // 1) List entries (first page or continue with cursor)
        if ($cursor) {
            $listRes = $http->post('https://api.dropboxapi.com/2/files/list_folder/continue', [
                'headers'     => ['Content-Type' => 'application/json', 'Authorization' => "Bearer {$token}"],
                'body'        => json_encode(['cursor' => $cursor]),
                'http_errors' => false,
                'timeout'     => 20,
            ]);
        } else {
            $listRes = $http->post('https://api.dropboxapi.com/2/files/list_folder', [
                'headers'     => ['Content-Type' => 'application/json', 'Authorization' => "Bearer {$token}"],
                'body'        => json_encode([
                    'path' => $path,
                    'recursive' => false,
                    'include_non_downloadable_files' => false,
                    'limit' => 300, // Dropbox may return fewer/more; use cursor to continue
                ]),
                'http_errors' => false,
                'timeout'     => 20,
            ]);
        }
        $items = array();
        if ($listRes->getStatusCode() !== 200) {
           $data = [
            'items'      => $items,
            'nextCursor' => !empty($list['has_more']) ? ($list['cursor'] ?? null) : null,
            'folderPath' => $path,
        ];
        
        $view_data['gallary'] = $data;
        
      return $this->template->rander("reports/performance", $view_data);
        }

        $list = json_decode($listRes->getBody(), true);
        $entries = array_values(array_filter($list['entries'] ?? [], function ($e) {
            if (($e['.tag'] ?? '') !== 'file') return false;
            $name = strtolower($e['name'] ?? '');
            return preg_match('/\.(jpg|jpeg|png|gif|bmp|tif|tiff)$/', $name);
        }));

        // 2) Build thumbnails in batches of 25 (Dropbox API limit per batch)
        $thumbs = [];
        $chunks = array_chunk(array_column($entries, 'path_lower'), 25);
        foreach ($chunks as $paths) {
            $payload = [
                'entries' => array_map(
                    fn($p) => [
                        'path'   => $p,
                        'format' => 'jpeg',
                        'size'   => 'w256h256',
                        'mode'   => 'bestfit',
                    ],
                    $paths
                ),
            ];
            
            $tr = $http->post('https://content.dropboxapi.com/2/files/get_thumbnail_batch', [
                'headers'     => ['Content-Type' => 'application/json', 'Authorization' => "Bearer {$token}"],
                'body'        => json_encode($payload),
                'http_errors' => false,
                'timeout'     => 30,
            ]);
            if ($tr->getStatusCode() !== 200) continue;
            $result = json_decode($tr->getBody(), true);
            foreach ($result['entries'] ?? [] as $item) {
                if (($item['.tag'] ?? '') === 'success') {
                    $p = $item['metadata']['path_lower'] ?? null;
                    $thumbs[$p] = 'data:image/jpeg;base64,'.$item['thumbnail'];
                }
            }
        }

        // 3) Get temporary download links for full-size images (valid for 4 hours)
        $fullImageLinks = [];
        foreach ($entries as $e) {
            $tempLinkRes = $http->post('https://api.dropboxapi.com/2/files/get_temporary_link', [
                'headers'     => ['Content-Type' => 'application/json', 'Authorization' => "Bearer {$token}"],
                'body'        => json_encode(['path' => $e['path_lower']]),
                'http_errors' => false,
                'timeout'     => 10,
            ]);
            
            if ($tempLinkRes->getStatusCode() === 200) {
                $linkData = json_decode($tempLinkRes->getBody(), true);
                $fullImageLinks[$e['path_lower']] = $linkData['link'] ?? null;
            }
        }

        // 4) Prepare items for the view with both thumbnail and full image link
        $items = array_map(function ($e) use ($thumbs, $fullImageLinks) {
            $p = $e['path_lower'];
            
            return [
                'name'   => $e['name'],
                'path'   => $p,
                'thumb'  => $thumbs[$p] ?? null,
                'full_image' => $fullImageLinks[$p] ?? ($thumbs[$p] ?? null), // Fallback to thumb if link fails
                'size'   => $e['size'] ?? null,
                'client_modified' => $e['client_modified'] ?? null,
            ];
        }, $entries);

        $data = [
            'items'      => $items,
            'nextCursor' => !empty($list['has_more']) ? ($list['cursor'] ?? null) : null,
            'folderPath' => $path,
        ];
        
        $view_data['gallary'] = $data;
        
      return $this->template->rander("reports/performance", $view_data);
        
        


    }

    function projects () {
        $view_data = array();

        return $this->template->rander("reports/projects", $view_data);
    }
}

/* End of file Reports.php */
/* Location: ./app/controllers/Reports.php */