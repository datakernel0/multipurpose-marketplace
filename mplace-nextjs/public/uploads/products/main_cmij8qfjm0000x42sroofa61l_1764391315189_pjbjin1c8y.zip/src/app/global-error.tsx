'use client';

/**
 * Global Error Boundary
 * This catches errors at the root level
 */
export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  return (
    <html lang="en">
      <body>
        <div style={{
          minHeight: '100vh',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          backgroundColor: '#f8f9fa',
          padding: '2rem',
          fontFamily: 'system-ui, sans-serif',
        }}>
          <div style={{
            maxWidth: '600px',
            width: '100%',
            backgroundColor: 'white',
            borderRadius: '12px',
            padding: '3rem 2rem',
            textAlign: 'center',
            boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
          }}>
            <div style={{ fontSize: '64px', marginBottom: '1.5rem' }}>💥</div>
            
            <h1 style={{
              fontSize: '2rem',
              color: '#dc3545',
              marginBottom: '1rem',
              fontWeight: 700,
            }}>
              Critical Error
            </h1>
            
            <p style={{
              color: '#666',
              marginBottom: '2rem',
              fontSize: '1.1rem',
            }}>
              The application encountered a critical error. Please try reloading the page.
            </p>

            <button
              onClick={reset}
              style={{
                padding: '0.75rem 1.5rem',
                backgroundColor: '#667eea',
                color: 'white',
                border: 'none',
                borderRadius: '6px',
                cursor: 'pointer',
                fontSize: '1rem',
                fontWeight: 600,
              }}
            >
              Reload Application
            </button>
          </div>
        </div>
      </body>
    </html>
  );
}

