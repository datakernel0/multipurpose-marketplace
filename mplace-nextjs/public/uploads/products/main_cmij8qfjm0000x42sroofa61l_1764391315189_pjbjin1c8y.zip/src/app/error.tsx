'use client';

import { useEffect } from 'react';
import Link from 'next/link';

/**
 * Next.js Error Boundary for App Router
 * This catches errors at the route level
 */
export default function Error({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    // Log the error to an error reporting service
    console.error('Route error:', error);
  }, [error]);

  return (
    <div className="error-page" style={{
      minHeight: '100vh',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: '#f8f9fa',
      padding: '2rem',
    }}>
      <div style={{
        maxWidth: '600px',
        width: '100%',
        backgroundColor: 'white',
        borderRadius: '12px',
        padding: '3rem 2rem',
        textAlign: 'center',
        boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
      }}>
        <div style={{ fontSize: '64px', marginBottom: '1.5rem' }}>😵</div>
        
        <h1 style={{
          fontSize: '2rem',
          color: '#dc3545',
          marginBottom: '1rem',
          fontWeight: 700,
        }}>
          Something Went Wrong
        </h1>
        
        <p style={{
          color: '#666',
          marginBottom: '0.5rem',
          fontSize: '1.1rem',
        }}>
          {error.message || 'An unexpected error occurred'}
        </p>
        
        {error.digest && (
          <p style={{
            color: '#999',
            fontSize: '0.875rem',
            marginBottom: '2rem',
          }}>
            Error ID: {error.digest}
          </p>
        )}

        <div style={{
          display: 'flex',
          gap: '1rem',
          justifyContent: 'center',
          marginTop: '2rem',
        }}>
          <button
            onClick={reset}
            style={{
              padding: '0.75rem 1.5rem',
              backgroundColor: '#667eea',
              color: 'white',
              border: 'none',
              borderRadius: '6px',
              cursor: 'pointer',
              fontSize: '1rem',
              fontWeight: 600,
              transition: 'background-color 0.2s',
            }}
            onMouseOver={(e) => e.currentTarget.style.backgroundColor = '#5568d3'}
            onMouseOut={(e) => e.currentTarget.style.backgroundColor = '#667eea'}
          >
            Try Again
          </button>
          
          <Link
            href="/"
            style={{
              padding: '0.75rem 1.5rem',
              backgroundColor: '#6c757d',
              color: 'white',
              border: 'none',
              borderRadius: '6px',
              textDecoration: 'none',
              fontSize: '1rem',
              fontWeight: 600,
              display: 'inline-block',
            }}
          >
            Go Home
          </Link>
        </div>
      </div>
    </div>
  );
}

