<?php

namespace Tracebit\Traits;

use Tracebit\Libraries\Error_handler;

/**
 * Error Handling Trait for Tracebit Controllers
 * Provides common error handling methods for all controllers
 */
trait Error_handling_trait {

    /**
     * Execute a function safely with error handling
     *
     * @param callable $callback Function to execute
     * @param string $operation Operation name for logging
     * @param array $default_response Default response on error
     * @return array Response array
     */
    protected function executeWithErrorHandling($callback, $operation, $default_response = null) {
        try {
            $result = call_user_func($callback);

            if ($result === false || $result === null) {
                Error_handler::warning("Operation returned false/null: {$operation}");
                return $default_response ?: Error_handler::formatErrorResponse("Operation failed: {$operation}");
            }

            return is_array($result) ? $result : Error_handler::formatSuccessResponse("Operation completed successfully", $result);

        } catch (\Exception $e) {
            return Error_handler::handleException($e, $operation);
        }
    }

    /**
     * Validate request parameters
     *
     * @param array $required_params List of required parameter names
     * @param string $method Request method (GET/POST)
     * @return array|null Returns error response if validation fails, null if passes
     */
    protected function validateRequestParams($required_params, $method = 'POST') {
        $params = $method === 'GET' ? $this->request->getGet() : $this->request->getPost();
        return Error_handler::validateRequired($params, $required_params);
    }

    /**
     * Get sanitized request parameter
     *
     * @param string $key Parameter key
     * @param mixed $default Default value
     * @param string $method Request method (GET/POST)
     * @return mixed Sanitized parameter value
     */
    protected function getSanitizedParam($key, $default = null, $method = 'POST') {

        $value = $method === 'GET' ? $this->request->getGet($key) : $this->request->getPost($key);

        // Debug logging to help identify the issue
        if (ENVIRONMENT === 'development') {
            Error_handler::debug("getSanitizedParam debug", [
                'key' => $key,
                'raw_value' => $value,
                'value_type' => gettype($value),
                'is_array' => is_array($value),
                'is_null' => is_null($value),
                'is_empty' => empty($value),
                'method' => $method
            ]);
        }

        if ($value === null || $value === '') {
            return $default;
        }

        // Handle array values - if it's an array, process each element
        if (is_array($value)) {
            // If it's an array with one element, return that element
            if (count($value) === 1 && isset($value[0])) {
                $single_value = $value[0];
                if (is_numeric($single_value)) {
                    return $single_value;
                }
                return Error_handler::sanitizeInput($single_value);
            }
            // For multiple elements, sanitize the entire array
            return Error_handler::sanitizeInput($value);
        }

        // For numeric values, preserve them as-is if they're valid numbers
        if (is_numeric($value)) {
            return $value;
        }

        // Check if it looks like JSON data - don't HTML encode it
        if ($this->isJsonData($value)) {
            return $value;
        }

        // For non-numeric values, apply sanitization
        return Error_handler::sanitizeInput($value);
    }

    /**
     * Check if a string looks like JSON data
     *
     * @param string $value
     * @return bool
     */
    private function isJsonData($value) {
        if (!is_string($value)) {
            return false;
        }

        $trimmed = trim($value);
        return (
            (substr($trimmed, 0, 1) === '{' && substr($trimmed, -1) === '}') ||
            (substr($trimmed, 0, 1) === '[' && substr($trimmed, -1) === ']')
        ) && json_decode($trimmed) !== null;
    }

    /**
     * Send JSON response with proper headers
     *
     * @param array $data Response data
     * @param int $status_code HTTP status code
     * @return void
     */
    protected function sendJsonResponse($data, $status_code = 200) {
        $this->response->setStatusCode($status_code);
        $this->response->setContentType('application/json');
        echo json_encode($data);
        exit;
    }

    /**
     * Handle model operation with error checking
     *
     * @param string $model_method Model method name
     * @param array $params Parameters to pass to model method
     * @param string $operation Operation description
     * @return array Response array
     */
    protected function handleModelOperation($model_method, $params = [], $operation = null) {
        $operation = $operation ?: $model_method;

        return $this->executeWithErrorHandling(function() use ($model_method, $params) {
            $model_parts = explode('::', $model_method);

            if (count($model_parts) === 2) {
                // Static method call
                $class = $model_parts[0];
                $method = $model_parts[1];
                return call_user_func_array([$class, $method], $params);
            } else {
                // Instance method call
                $model_property = str_replace('_model', '', strtolower($model_method)) . '_model';

                if (property_exists($this, $model_property)) {
                    $model = $this->$model_property;
                } else {
                    // Try to find the model property dynamically
                    $model = null;
                    foreach (get_object_vars($this) as $prop => $value) {
                        if (strpos($prop, '_model') !== false && is_object($value)) {
                            if (method_exists($value, $model_method)) {
                                $model = $value;
                                break;
                            }
                        }
                    }

                    if (!$model) {
                        throw new \Exception("Model not found for method: {$model_method}");
                    }
                }

                return call_user_func_array([$model, $model_method], $params);
            }
        }, $operation);
    }

    /**
     * Log operation for debugging
     *
     * @param string $operation Operation name
     * @param array $params Operation parameters
     * @param string $level Log level
     * @return void
     */
    protected function logOperation($operation, $params = [], $level = 'INFO') {
        $context = [
            'user_id' => $this->login_user->id ?? 'anonymous',
            'controller' => get_class($this),
            'params' => $params
        ];

        Error_handler::log($level, "Operation: {$operation}", $context);
    }

    /**
     * Check user permissions for operation
     *
     * @param string $operation Operation requiring permission
     * @param array $allowed_roles Allowed user roles
     * @return array|null Returns error response if no permission, null if allowed
     */
    protected function checkPermission($operation, $allowed_roles = ['admin']) {
        if (!$this->login_user) {
            Error_handler::warning("Unauthorized access attempt: {$operation}");
            return Error_handler::formatErrorResponse('Authentication required', 401);
        }

        $user_type = $this->login_user->user_type ?? 'staff';

        if (!in_array($user_type, $allowed_roles) && !in_array('all', $allowed_roles)) {
            Error_handler::warning("Permission denied for user {$this->login_user->id}: {$operation}", [
                'user_type' => $user_type,
                'required_roles' => $allowed_roles
            ]);
            return Error_handler::formatErrorResponse('Insufficient permissions', 403);
        }

        return null;
    }

    /**
     * Handle file upload with error checking
     *
     * @param string $field_name Upload field name
     * @param array $allowed_types Allowed file types
     * @param int $max_size Maximum file size in bytes
     * @return array Response with file info or error
     */
    protected function handleFileUpload($field_name, $allowed_types = ['jpg', 'jpeg', 'png', 'gif'], $max_size = 5242880) {
        return $this->executeWithErrorHandling(function() use ($field_name, $allowed_types, $max_size) {
            $file = $this->request->getFile($field_name);

            if (!$file->isValid()) {
                throw new \Exception('No valid file uploaded');
            }

            if ($file->getSize() > $max_size) {
                throw new \Exception('File size exceeds maximum allowed size');
            }

            $extension = $file->getClientExtension();
            if (!in_array(strtolower($extension), $allowed_types)) {
                throw new \Exception('File type not allowed');
            }

            return [
                'name' => $file->getName(),
                'size' => $file->getSize(),
                'type' => $file->getClientMimeType(),
                'extension' => $extension,
                'temp_path' => $file->getTempName()
            ];
        }, 'file_upload');
    }

    /**
     * Get raw JSON request parameter without HTML encoding
     *
     * @param string $key Parameter key
     * @param mixed $default Default value
     * @param string $method Request method (GET/POST)
     * @return mixed Raw parameter value for JSON data
     */
    protected function getJsonParam($key, $default = null, $method = 'POST') {
        $value = $method === 'GET' ? $this->request->getGet($key) : $this->request->getPost($key);

        if ($value === null || $value === '') {
            return $default;
        }

        // Handle array values
        if (is_array($value) && count($value) === 1 && isset($value[0])) {
            return $value[0];
        }

        return $value;
    }
}
