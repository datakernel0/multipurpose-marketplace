<?php

namespace Tracker\Traits;

use Tracker\Libraries\Error_handler;

/**
 * Model Error Handling Trait for Tracker Models
 * Provides common error handling methods for all models
 */
trait Model_error_handling_trait {

    /**
     * Execute database query with error handling
     *
     * @param callable $callback Database operation to execute
     * @param string $operation Operation name for logging
     * @param mixed $default_return Default value to return on error
     * @return mixed Query result or default value on error
     */
    protected function executeQueryWithErrorHandling($callback, $operation, $default_return = false) {
        try {
            $result = call_user_func($callback);

            if ($result === false) {
                Error_handler::warning("Database operation returned false: {$operation}");
            }

            return $result;

        } catch (\Exception $e) {
            Error_handler::error("Database operation failed: {$operation}", [
                'exception' => $e->getMessage(),
                'file' => $e->getFile(),
                'line' => $e->getLine(),
                'trace' => $e->getTraceAsString()
            ]);

            return $default_return;
        }
    }

    /**
     * Sanitize data for database insertion
     *
     * @param array $data Data to sanitize
     * @return array Sanitized data
     */
    protected function sanitizeData($data) {
        if (!is_array($data)) {
            return Error_handler::sanitizeInput($data);
        }

        $sanitized = [];
        foreach ($data as $key => $value) {
            if (is_array($value)) {
                $sanitized[$key] = $this->sanitizeData($value);
            } else {
                $sanitized[$key] = Error_handler::sanitizeInput($value);
            }
        }

        return $sanitized;
    }

    /**
     * Validate required fields in data
     *
     * @param array $data Data to validate
     * @param array $required_fields Required field names
     * @param string $operation Operation name for logging
     * @return bool True if validation passes, false otherwise
     */
    protected function validateRequiredFields($data, $required_fields, $operation = 'unknown') {
        $missing_fields = [];

        foreach ($required_fields as $field) {
            if (!isset($data[$field]) || empty($data[$field])) {
                $missing_fields[] = $field;
            }
        }

        if (!empty($missing_fields)) {
            Error_handler::warning("Missing required fields in {$operation}", [
                'missing_fields' => $missing_fields,
                'provided_data' => array_keys($data)
            ]);
            return false;
        }

        return true;
    }

    /**
     * Log model operation
     *
     * @param string $operation Operation name
     * @param array $params Operation parameters
     * @param string $level Log level
     * @return void
     */
    protected function logModelOperation($operation, $params = [], $level = 'INFO') {
        $context = [
            'model' => get_class($this),
            'operation' => $operation,
            'params' => $params
        ];

        Error_handler::log($level, "Model operation: {$operation}", $context);
    }

    /**
     * Check if database connection is available
     *
     * @return bool True if connected, false otherwise
     */
    protected function checkDatabaseConnection() {
        try {
            if (isset($this->db) && $this->db) {
                // Try a simple query to check connection
                $this->db->query("SELECT 1");
                return true;
            }

            Error_handler::error('Database connection not available in model: ' . get_class($this));
            return false;

        } catch (\Exception $e) {
            Error_handler::error('Database connection check failed', [
                'model' => get_class($this),
                'exception' => $e->getMessage()
            ]);
            return false;
        }
    }

    /**
     * Execute paginated query with error handling
     *
     * @param string $table Table name
     * @param array $where Where conditions
     * @param int $limit Limit per page
     * @param int $offset Offset
     * @param string $order_by Order by clause
     * @return array|false Result array or false on error
     */
    protected function getPaginatedResults($table, $where = [], $limit = 20, $offset = 0, $order_by = 'id DESC') {
        return $this->executeQueryWithErrorHandling(function() use ($table, $where, $limit, $offset, $order_by) {
            $builder = $this->db->table($table);

            if (!empty($where)) {
                $builder->where($where);
            }

            $builder->orderBy($order_by);
            $builder->limit($limit, $offset);

            $query = $builder->get();
            return $query ? $query->getResultArray() : false;

        }, "get_paginated_results_from_{$table}", []);
    }

    /**
     * Safe insert operation with validation
     *
     * @param string $table Table name
     * @param array $data Data to insert
     * @param array $required_fields Required fields
     * @return int|false Insert ID or false on error
     */
    protected function safeInsert($table, $data, $required_fields = []) {
        return $this->executeQueryWithErrorHandling(function() use ($table, $data, $required_fields) {

            // Validate required fields
            if (!empty($required_fields) && !$this->validateRequiredFields($data, $required_fields, "insert_into_{$table}")) {
                return false;
            }

            // Sanitize data
            $sanitized_data = $this->sanitizeData($data);

            // Add timestamp if not present
            if (!isset($sanitized_data['created_at'])) {
                $sanitized_data['created_at'] = date('Y-m-d H:i:s');
            }

            $builder = $this->db->table($table);
            $insert_result = $builder->insert($sanitized_data);

            if ($insert_result) {
                $insert_id = $this->db->insertID();
                $this->logModelOperation("insert_into_{$table}", ['id' => $insert_id, 'data' => $sanitized_data]);
                return $insert_id;
            }

            return false;

        }, "insert_into_{$table}", false);
    }

    /**
     * Safe update operation with validation
     *
     * @param string $table Table name
     * @param array $data Data to update
     * @param array $where Where conditions
     * @param array $required_fields Required fields
     * @return bool True on success, false on error
     */
    protected function safeUpdate($table, $data, $where, $required_fields = []) {
        return $this->executeQueryWithErrorHandling(function() use ($table, $data, $where, $required_fields) {

            // Validate required fields
            if (!empty($required_fields) && !$this->validateRequiredFields($data, $required_fields, "update_{$table}")) {
                return false;
            }

            // Sanitize data
            $sanitized_data = $this->sanitizeData($data);

            // Add timestamp
            $sanitized_data['updated_at'] = date('Y-m-d H:i:s');

            $builder = $this->db->table($table);
            $builder->where($where);
            $update_result = $builder->update($sanitized_data);

            if ($update_result !== false) {
                $affected_rows = $this->db->affectedRows();
                $this->logModelOperation("update_{$table}", ['affected_rows' => $affected_rows, 'where' => $where, 'data' => $sanitized_data]);
                return true;
            }

            return false;

        }, "update_{$table}", false);
    }

    /**
     * Safe delete operation (soft delete preferred)
     *
     * @param string $table Table name
     * @param array $where Where conditions
     * @param bool $hard_delete True for hard delete, false for soft delete
     * @return bool True on success, false on error
     */
    protected function safeDelete($table, $where, $hard_delete = false) {
        return $this->executeQueryWithErrorHandling(function() use ($table, $where, $hard_delete) {

            $builder = $this->db->table($table);
            $builder->where($where);

            if ($hard_delete) {
                $delete_result = $builder->delete();
            } else {
                // Soft delete - set deleted flag
                $delete_result = $builder->update(['deleted' => 1, 'updated_at' => date('Y-m-d H:i:s')]);
            }

            if ($delete_result !== false) {
                $affected_rows = $this->db->affectedRows();
                $operation = $hard_delete ? 'hard_delete' : 'soft_delete';
                $this->logModelOperation("{$operation}_{$table}", ['affected_rows' => $affected_rows, 'where' => $where]);
                return true;
            }

            return false;

        }, "delete_from_{$table}", false);
    }

    /**
     * Check if record exists
     *
     * @param string $table Table name
     * @param array $where Where conditions
     * @return bool True if exists, false otherwise
     */
    protected function recordExists($table, $where) {
        return $this->executeQueryWithErrorHandling(function() use ($table, $where) {
            $builder = $this->db->table($table);
            $builder->where($where);
            $count = $builder->countAllResults();

            return $count > 0;
        }, "check_exists_{$table}", false);
    }
}
