# Tracebit Plugin - Purchase Code Not Required

## Overview

The Tracebit plugin **does not require a purchase code** for installation. Users can simply leave the purchase code field empty when installing the plugin.

## How It Works

### Global Plugin Installation Modal

The plugin installation modal (`app/Views/plugins/modal_form.php`) is **shared by all plugins** in the system. It displays a purchase code input field that users can fill in or leave empty.

**Important**: We do NOT modify this global file because:
- ✅ Other plugins may require purchase codes
- ✅ Keeps the system consistent
- ✅ No breaking changes to other plugins

### Tracebit-Specific Verification

Instead of hiding the purchase code field globally, Tracebit handles this at the **verification level**:

**File**: `plugins/Tracebit/Install/verfiy_purchase_code.php`

```php
<?php

if (!function_exists('verify_tracebit_plugins_purchase_code')) {

    function verify_tracebit_plugins_purchase_code($product, $code) {
        // Tracebit plugin does not require purchase code verification
        // Users can install the plugin without entering a purchase code
        // This allows for easier distribution and installation
        return "verified";
    }
}

//validate purchase code (always returns verified for Tracebit)
$verification = verify_tracebit_plugins_purchase_code($product, $item_purchase_code);
```

### How Installation Works

#### For Tracebit Plugin:

1. User clicks "Install Plugin" button
2. Modal opens with purchase code field (visible)
3. User uploads `tracebit.zip` file
4. User can **leave purchase code empty** or enter anything
5. User clicks "Install"
6. Tracebit's `verify_tracebit_plugins_purchase_code()` is called
7. Function **always returns "verified"** regardless of input
8. Plugin installs successfully ✅

#### For Other Plugins:

1. User clicks "Install Plugin" button
2. Modal opens with purchase code field (visible)
3. User uploads plugin ZIP file
4. User **must enter valid purchase code**
5. User clicks "Install"
6. Plugin's own verification function is called
7. Function validates the purchase code
8. Plugin installs only if code is valid ✅

## User Instructions

### Installing Tracebit Plugin

When installing the Tracebit plugin, users can follow these steps:

1. Go to **Settings** → **Plugins**
2. Click **"Install Plugin"** button
3. Upload the `tracebit.zip` file
4. **Leave the "Envato Purchase Code" field empty** (or enter any text)
5. Click **"Install"**
6. Plugin will install successfully without requiring a valid purchase code

### Visual Guide

```
┌─────────────────────────────────────────────────────────┐
│  Install Plugin                                    [X]  │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  [Upload tracebit.zip]                                  │
│                                                         │
│  ┌─────────────────────────────────────────────────┐   │
│  │ Envato Purchase Code                            │   │  ← Can be left EMPTY
│  │ (Leave empty for Tracebit)                      │   │
│  └─────────────────────────────────────────────────┘   │
│                                                         │
├─────────────────────────────────────────────────────────┤
│                    [Close]  [Install]                   │
└─────────────────────────────────────────────────────────┘
```

## Technical Implementation

### Verification Flow

```
Plugin Installation Request
         ↓
Upload ZIP file
         ↓
Extract plugin name (e.g., "Tracebit")
         ↓
Call plugin's installation hook
         ↓
plugins/Tracebit/index.php
         ↓
register_installation_hook("Tracebit", function ($item_purchase_code) {
    include "Install/do_install.php";
});
         ↓
plugins/Tracebit/Install/do_install.php
         ↓
include "verfiy_purchase_code.php";
         ↓
verify_tracebit_plugins_purchase_code($product, $item_purchase_code)
         ↓
return "verified"; // Always verified!
         ↓
Continue with installation
         ↓
Success! ✅
```

### Code Structure

#### 1. Installation Hook (`plugins/Tracebit/index.php`)

```php
register_installation_hook("Tracebit", function ($item_purchase_code) {
    $upper = PLUGINPATH . "Tracebit/Install/do_install.php";
    $lower = PLUGINPATH . "Tracebit/install/do_install.php";
    if (is_file($upper)) {
        include $upper;
        return;
    }
    if (is_file($lower)) {
        include $lower;
        return;
    }
    echo json_encode(array("success" => false, "message" => "Tracebit installer script not found."));
    exit();
});
```

#### 2. Installation Script (`plugins/Tracebit/Install/do_install.php`)

```php
<?php

ini_set('max_execution_time', 300);

$product = "Tracebit";

// Include purchase verification
$verify_upper = PLUGINPATH . "$product/Install/verfiy_purchase_code.php";
$verify_lower = PLUGINPATH . "$product/install/verfiy_purchase_code.php";
if (is_file($verify_upper)) {
    include $verify_upper;
} elseif (is_file($verify_lower)) {
    include $verify_lower;
}

// Check verification result
if (isset($verification) && $verification !== "verified") {
    echo json_encode(array("success" => false, "message" => "Please enter a valid purchase code."));
    exit();
}

// Continue with installation...
```

#### 3. Verification Function (`plugins/Tracebit/Install/verfiy_purchase_code.php`)

```php
<?php

if (!function_exists('verify_tracebit_plugins_purchase_code')) {

    function verify_tracebit_plugins_purchase_code($product, $code) {
        // Tracebit plugin does not require purchase code verification
        // Users can install the plugin without entering a purchase code
        // This allows for easier distribution and installation
        return "verified";
    }
}

//validate purchase code (always returns verified for Tracebit)
$verification = verify_tracebit_plugins_purchase_code($product, $item_purchase_code);
```

## Why This Approach?

### ✅ Advantages

1. **Plugin-Specific**: Only affects Tracebit, not other plugins
2. **No Global Changes**: Doesn't modify shared system files
3. **Maintains Compatibility**: Other plugins can still require purchase codes
4. **User-Friendly**: Users can leave the field empty
5. **Flexible**: Easy to add actual verification later if needed
6. **Clean Code**: Clear comments explain the behavior

### ❌ Why NOT Hide the Field Globally?

If we modified `app/Views/plugins/modal_form.php` to hide the purchase code field:

```php
// BAD APPROACH - Don't do this!
"hide_description" => true  // This would affect ALL plugins
```

**Problems**:
- ❌ Other plugins wouldn't be able to collect purchase codes
- ❌ Breaks functionality for plugins that need verification
- ❌ Inconsistent user experience across plugins
- ❌ Hard to maintain when different plugins have different requirements

## Comparison: Tracebit vs Other Plugins

| Aspect | Tracebit Plugin | Other Plugins |
|--------|----------------|---------------|
| **Purchase Code Field** | Visible (can be left empty) | Visible (must be filled) |
| **Verification** | Always passes | Validates against server |
| **Installation** | Works without code | Requires valid code |
| **User Experience** | Simpler (optional field) | Standard (required field) |
| **Distribution** | Easier | Controlled |

## Future Enhancements

If you want to add actual purchase code verification later:

### Option 1: Remote Verification

```php
function verify_tracebit_plugins_purchase_code($product, $code) {
    // If code is empty, allow installation
    if (empty($code)) {
        return "verified";
    }

    // If code is provided, verify it
    $url = "https://your-verification-server.com/verify?code=" . urlencode($code);
    $response = file_get_contents($url);
    return $response; // Should return "verified" if valid
}
```

### Option 2: Local Validation

```php
function verify_tracebit_plugins_purchase_code($product, $code) {
    // If code is empty, allow installation
    if (empty($code)) {
        return "verified";
    }

    // Check against a list of valid codes
    $valid_codes = ['CODE1', 'CODE2', 'CODE3'];
    if (in_array($code, $valid_codes)) {
        return "verified";
    }

    return "invalid";
}
```

### Option 3: License Key System

```php
function verify_tracebit_plugins_purchase_code($product, $code) {
    // If code is empty, allow installation (free version)
    if (empty($code)) {
        return "verified";
    }

    // If code is provided, unlock premium features
    $db = db_connect('default');
    $db->table('tracker_settings')->insert([
        'setting_name' => 'license_key',
        'setting_value' => $code,
        'type' => 'plugin'
    ]);

    return "verified";
}
```

## Documentation for Users

### FAQ

**Q: Do I need a purchase code to install Tracebit?**
A: No, you can leave the purchase code field empty when installing Tracebit.

**Q: What if I enter a purchase code anyway?**
A: The plugin will still install successfully. The purchase code is not validated.

**Q: Will this affect other plugins?**
A: No, other plugins will continue to require valid purchase codes as usual.

**Q: Can I add purchase code verification later?**
A: Yes, you can modify the `verfiy_purchase_code.php` file to add actual verification logic.

## Conclusion

The Tracebit plugin uses a **plugin-specific approach** to handle purchase code requirements:

- ✅ **Global modal remains unchanged** (works for all plugins)
- ✅ **Tracebit-specific verification** (always passes)
- ✅ **User-friendly** (can leave field empty)
- ✅ **Flexible** (easy to add verification later)
- ✅ **Maintains compatibility** (doesn't break other plugins)

This approach provides the best balance between ease of installation and system integrity.

