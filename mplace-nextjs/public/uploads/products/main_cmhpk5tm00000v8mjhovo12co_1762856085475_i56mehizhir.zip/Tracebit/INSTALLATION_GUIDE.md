# Tracebit Plugin - Installation Guide

## Quick Start

Installing the Tracebit plugin is simple and **does not require a purchase code**.

## Installation Steps

### Step 1: Access Plugin Settings
1. Log in to your application
2. Navigate to **Settings** → **Plugins**

### Step 2: Install Plugin
1. Click the **"Install Plugin"** button
2. A modal window will open

### Step 3: Upload Plugin File
1. Drag and drop the `tracebit.zip` file into the upload area
   - OR click to browse and select the file

### Step 4: Purchase Code (Optional)
- You will see a field labeled **"Envato Purchase Code"**
- **You can leave this field EMPTY** ✅
- The Tracebit plugin does not require a purchase code
- If you enter anything, it will be ignored

### Step 5: Complete Installation
1. Click the **"Install"** button
2. Wait for the installation to complete
3. The plugin will be installed successfully!

## Visual Guide

```
Step 1: Click "Install Plugin"
         ↓
Step 2: Upload tracebit.zip
         ↓
Step 3: Leave purchase code empty (or enter anything)
         ↓
Step 4: Click "Install"
         ↓
Step 5: Success! ✅
```

## Important Notes

### ✅ What You Need
- The `tracebit.zip` plugin file
- Admin access to the application
- That's it!

### ❌ What You DON'T Need
- Purchase code
- License key
- Envato account
- Internet connection for verification

## Troubleshooting

### Issue: "Please enter a valid purchase code"

**Solution**: This error should NOT appear for Tracebit. If you see it:
1. Make sure you're uploading the correct `tracebit.zip` file
2. Check that the ZIP file is not corrupted
3. Try re-downloading the plugin file

### Issue: Upload fails

**Solution**:
1. Check file size limits in your PHP configuration
2. Ensure the `writable/uploads` directory has proper permissions
3. Try uploading from a different browser

### Issue: Installation times out

**Solution**:
1. Increase PHP `max_execution_time` in your server configuration
2. The plugin sets it to 300 seconds automatically, but server limits may override this

## After Installation

Once installed, you can access Tracebit features from the left sidebar menu:

- **Dashboard** - Overview of tracking data
- **Employee Status** - Real-time employee status
- **Timesheet** - Time tracking records
- **Activity Log** - Detailed activity history
- **Screenshots** - Captured screenshots
- **Storage Management** - Manage storage usage
- **Settings** - Configure plugin settings

## Uninstallation

If you need to uninstall the plugin:

1. Go to **Settings** → **Plugins**
2. Find "Tracebit" in the plugin list
3. Click **"Uninstall"**
4. Confirm the action

**Warning**: Uninstalling will remove all Tracebit data from the database, including:
- Attendance records
- Screenshots
- Activity logs
- Performance data
- Settings

## Support

For issues or questions:
- Check the plugin documentation
- Review the configuration settings
- Contact your system administrator

## Technical Details

- **Plugin Name**: Tracebit
- **Version**: 1.0
- **Author**: JS Techy
- **Requires**: Application version 3.0 or higher
- **Purchase Code**: Not required

---

**Remember**: The Tracebit plugin is designed for easy installation without purchase code verification. Simply upload and install!

