-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 10, 2025 at 07:26 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tracker_ext`
--

-- --------------------------------------------------------

--
-- Table structure for table `tracker_tracker_breaks`
--

CREATE TABLE IF NOT EXISTS `{dbprefix}tracker_breaks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `value` varchar(50) NOT NULL COMMENT 'Unique value identifier (e.g., b-1, b-2)',
  `name` varchar(100) NOT NULL COMMENT 'Display name of the break',
  `icon` varchar(10) NOT NULL DEFAULT '?' COMMENT 'Emoji icon for the break',
  `description` varchar(255) DEFAULT NULL COMMENT 'Description of the break type',
  `is_minus_break` tinyint(1) NOT NULL DEFAULT 0 COMMENT '1 if this break reduces productive time, 0 if it adds to work time',
  `max_time` int(100) NOT NULL DEFAULT 1200,
  `is_active` tinyint(1) NOT NULL DEFAULT 1 COMMENT '1 if break is available for selection, 0 if hidden',
  `sort_order` int(11) NOT NULL DEFAULT 0 COMMENT 'Display order in dropdown',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  `deleted_at` datetime DEFAULT NULL COMMENT 'Soft delete timestamp',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_value_active` (`value`,`deleted_at`),
  KEY `idx_active_sort` (`is_active`,`sort_order`),
  KEY `idx_minus_break` (`is_minus_break`),
  KEY `idx_deleted` (`deleted_at`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Break options for time tracking system';

--
-- Dumping data for table `{dbprefix}tracker_breaks`
--

INSERT INTO `{dbprefix}tracker_breaks` (`id`, `value`, `name`, `icon`, `description`, `is_minus_break`, `max_time`, `is_active`, `sort_order`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'b-1', 'Team Collaboration', '👥', 'Working with team members', 0, 1200, 1, 1, '2025-06-30 21:27:32', NULL, NULL),
(2, 'b-2', 'General Meeting', '📋', 'Attending meetings', 0, 1200, 1, 2, '2025-06-30 21:27:32', NULL, NULL),
(3, 'b-3', 'Standup Meeting', '🏃', 'Daily standup session', 0, 1200, 1, 3, '2025-06-30 21:27:32', NULL, NULL),
(4, 'b-4', 'Project Planning', '📊', 'Planning and strategizing', 0, 1200, 1, 4, '2025-06-30 21:27:32', NULL, NULL),
(5, 'b-5', 'Personal Break', '☕', 'Short personal break', 1, 1200, 1, 5, '2025-06-30 21:27:32', NULL, NULL),
(6, 'b-6', 'Project Review', '🔍', 'Reviewing project progress', 0, 1200, 1, 6, '2025-06-30 21:27:32', NULL, NULL),
(7, 'b-7', 'Training & Learning', '📚', 'Professional development', 0, 1200, 1, 7, '2025-06-30 21:27:32', NULL, NULL),
(8, 'b-8', 'Client Communication', '📞', 'Client calls and communication', 0, 1200, 1, 8, '2025-06-30 21:27:32', NULL, NULL),
(9, 'b-9', 'Other', '🔧', 'Other work-related activities', 0, 1200, 1, 9, '2025-06-30 21:27:32', NULL, NULL);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
