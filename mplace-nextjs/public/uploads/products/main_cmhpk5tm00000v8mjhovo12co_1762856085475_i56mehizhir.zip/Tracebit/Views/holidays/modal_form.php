<div id="holiday-form-container">
    <?php echo form_open(get_uri("tracebit/tracker_holidays/save"), array("id" => "holiday-form", "class" => "general-form", "role" => "form")); ?>
    <div class="modal-body clearfix">
        <input type="hidden" name="id" value="<?php echo $model_info ? $model_info['id'] : ''; ?>" />

        <div class="form-group">
            <label for="name" class="col-md-3"><?php echo app_lang('name'); ?></label>
            <div class="col-md-9">
                <?php
                echo form_input(array(
                    "id" => "name",
                    "name" => "name",
                    "value" => $model_info ? $model_info['name'] : '',
                    "class" => "form-control",
                    "placeholder" => "Holiday name",
                    "data-rule-required" => true,
                    "data-msg-required" => app_lang("field_required"),
                ));
                ?>
            </div>
        </div>

        <div class="form-group">
            <label for="start_date" class="col-md-3"><?php echo app_lang('start_date'); ?></label>
            <div class="col-md-9">
                <?php
                echo form_input(array(
                    "id" => "start_date",
                    "name" => "start_date",
                    "value" => $model_info ? $model_info['start_date'] : '',
                    "class" => "form-control",
                    "placeholder" => "YYYY-MM-DD",
                    "data-rule-required" => true,
                    "data-msg-required" => app_lang("field_required"),
                ));
                ?>
            </div>
        </div>

        <div class="form-group">
            <label for="end_date" class="col-md-3"><?php echo app_lang('end_date'); ?></label>
            <div class="col-md-9">
                <?php
                echo form_input(array(
                    "id" => "end_date",
                    "name" => "end_date",
                    "value" => $model_info ? $model_info['end_date'] : '',
                    "class" => "form-control",
                    "placeholder" => "YYYY-MM-DD"
                ));
                ?>
                <div class="help-block">Leave empty for single day holiday</div>
            </div>
        </div>

        <div class="form-group">
            <label for="type" class="col-md-3"><?php echo app_lang('type'); ?></label>
            <div class="col-md-9">
                <?php
                $type_dropdown = array(
                    "national" => "National Holiday",
                    "religious" => "Religious Holiday",
                    "company" => "Company Holiday"
                );

                echo form_dropdown("type", $type_dropdown, $model_info ? $model_info['type'] : 'national', "class='select2 form-control'");
                ?>
            </div>
        </div>

    </div>

    <div class="modal-footer">
        <button type="button" class="btn btn-default" data-bs-dismiss="modal"><span data-feather="x" class="icon-16"></span> <?php echo app_lang('close'); ?></button>
        <button type="submit" class="btn btn-primary"><span data-feather="check-circle" class="icon-16"></span> <?php echo app_lang('save'); ?></button>
    </div>
    <?php echo form_close(); ?>
</div>

<script type="text/javascript">
    $(document).ready(function() {
        $("#holiday-form").appForm({
            onSuccess: function(result) {
                // Trigger a custom event that can be caught by the settings page
                $(document).trigger("holidayUpdated");
            },
            onClose: function() {
                // Trigger the same event when modal is closed
                $(document).trigger("holidayUpdated");
            }
        });

        $("#holiday-form .select2").select2();

        setDatePicker("#start_date, #end_date");

        // Calculate duration when dates change
        $("#start_date, #end_date").change(function() {
            var startDate = $("#start_date").val();
            var endDate = $("#end_date").val() || startDate;

            if (startDate && endDate) {
                // Validate end date is not before start date
                if (new Date(endDate) < new Date(startDate)) {
                    appAlert.error("End date cannot be before start date");
                    $("#end_date").val(startDate);
                    endDate = startDate;
                }
            }
        });
    });
</script>
