<div id="page-content" class="page-wrapper clearfix">
    <div class="card">
        <div class="page-title clearfix">
            <h1><?php echo app_lang('holidays'); ?></h1>
            <div class="title-button-group">
                <?php echo modal_anchor(get_uri("tracebit/tracker_holidays/modal_form"), "<i data-feather='plus-circle' class='icon-16'></i> " . app_lang('add_holiday'), array("class" => "btn btn-default", "title" => app_lang('add_holiday'), "data-post-id" => "")); ?>
            </div>
        </div>
        <div class="table-responsive">
            <table id="holiday-table" class="display" cellspacing="0" width="100%">
            </table>
        </div>
    </div>
</div>

<script type="text/javascript">
    $(document).ready(function () {
        $("#holiday-table").appTable({
            source: '<?php echo get_uri("tracebit/tracker_holidays/list_data") ?>',
            order: [[1, "asc"]],
            columns: [
                {title: '<?php echo app_lang("name") ?>', "class": "w15p"},
                {title: '<?php echo app_lang("date") ?>', "class": "w15p"},
                {title: '<?php echo app_lang("day") ?>', "class": "w15p"},
                {title: '<?php echo app_lang("duration") ?>', "class": "w10p"},
                {title: '<?php echo app_lang("type") ?>', "class": "w15p"},
                {title: '<i data-feather="menu" class="icon-16"></i>', "class": "text-center option w100"}
            ],
            printColumns: [0, 1, 2, 3, 4],
            xlsColumns: [0, 1, 2, 3, 4]
        });
    });
</script>
