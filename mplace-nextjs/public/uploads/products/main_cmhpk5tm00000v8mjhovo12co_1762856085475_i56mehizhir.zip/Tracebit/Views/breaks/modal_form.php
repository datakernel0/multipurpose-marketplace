<?php echo form_open(get_uri("tracebit/tracker_breaks/save"), array("id" => "break-form", "class" => "general-form", "role" => "form")); ?>
<div class="modal-body clearfix">

    <input type="hidden" name="id" value="<?php echo $model_info->id; ?>" />
    <div class="form-group">
        <label for="name" class=" col-md-3">Break Name</label>
        <div class=" col-md-9">
            <?php
            echo form_input(array(
                "id" => "name",
                "name" => "name",
                "value" => $model_info->name,
                "class" => "form-control",
                "placeholder" => "Break Name",
                "autofocus" => true,
                "data-rule-required" => true,
                "data-msg-required" => "This field is required.",
            ));
            ?>
        </div>
    </div>
    <div class="form-group">
        <label for="value" class=" col-md-3">Value</label>
        <div class=" col-md-9">
            <?php
            echo form_input(array(
                "id" => "value",
                "name" => "value",
                "value" => $model_info->value,
                "class" => "form-control",
                "placeholder" => "Value",
            ));
            ?>
        </div>
    </div>
    <div class="form-group">
        <label for="icon" class=" col-md-3">Icon</label>
        <div class=" col-md-9">
            <?php
            echo form_input(array(
                "id" => "icon",
                "name" => "icon",
                "value" => $model_info->icon,
                "class" => "form-control",
                "placeholder" => "Icon",
            ));
            ?>
        </div>
    </div>
    <div class="form-group">
        <label for="description" class=" col-md-3">Description</label>
        <div class=" col-md-9">
            <?php
            echo form_textarea(array(
                "id" => "description",
                "name" => "description",
                "value" => $model_info->description,
                "class" => "form-control",
                "placeholder" => "Description",
            ));
            ?>
        </div>
    </div>
    <div class="form-group">
        <label for="is_minus_break" class=" col-md-3">Is Minus Break</label>
        <div class=" col-md-9">
            <?php
            echo form_checkbox("is_minus_break", "1", $model_info->is_minus_break ? true : false, "id='is_minus_break' class='form-check-input'");
            ?>
        </div>
    </div>
    <div class="form-group">
        <label for="max_time" class=" col-md-3">Max Time (minutes)</label>
        <div class=" col-md-9">
            <?php
            echo form_input(array(
                "id" => "max_time",
                "name" => "max_time",
                "value" => $model_info->max_time,
                "class" => "form-control",
                "placeholder" => "Max Time",
                "type" => "number"
            ));
            ?>
        </div>
    </div>
</div>

<div class="modal-footer">
    <button type="button" class="btn btn-default" data-bs-dismiss="modal"><span data-feather="x" class="icon-16"></span> Close</button>
    <button type="submit" class="btn btn-primary"><span data-feather="check-circle" class="icon-16"></span> Save</button>
</div>
<?php echo form_close(); ?>

<script type="text/javascript">
    $(document).ready(function () {
        $("#break-form").appForm({
            onSuccess: function (result) {
                $("#break-table").appTable({newData: result.data, dataId: result.id});
            }
        });
    });
</script>
