<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Breaks</h5>
        <button class="btn btn-primary" id="add-break-btn"><i class="fa fa-plus"></i> Add Break</button>
    </div>
    <div class="card-body">
        <table id="breaks-table" class="table table-striped table-bordered" style="width:100%">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Value</th>
                    <th>Icon</th>
                    <th>Description</th>
                    <th>Is Minus Break</th>
                    <th>Max Time</th>
                    <th>Actions</th>
                </tr>
            </thead>
        </table>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="breakModal" tabindex="-1" role="dialog" aria-labelledby="breakModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="breakModalLabel">Add/Edit Break</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form id="break-form">
        <div class="modal-body">
          <input type="hidden" name="id" id="break-id">
          <div class="form-group">
            <label for="break-name">Name</label>
            <input type="text" class="form-control" id="break-name" name="name" required>
          </div>
          <div class="form-group">
            <label for="break-value">Value</label>
            <input type="text" class="form-control" id="break-value" name="value" required>
          </div>
          <div class="form-group">
            <label for="break-icon">Icon</label>
            <input type="text" class="form-control" id="break-icon" name="icon">
          </div>
          <div class="form-group">
            <label for="break-description">Description</label>
            <textarea class="form-control" id="break-description" name="description"></textarea>
          </div>
          <div class="form-group">
            <label for="break-is-minus-break">Is Minus Break</label>
            <input type="checkbox" id="break-is-minus-break" name="is_minus_break" value="1">
          </div>
          <div class="form-group">
            <label for="break-max-time">Max Time (minutes)</label>
            <input type="number" class="form-control" id="break-max-time" name="max_time">
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Save</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
$(function() {
    var table = $('#breaks-table').DataTable({
        ajax: {
            url: '
