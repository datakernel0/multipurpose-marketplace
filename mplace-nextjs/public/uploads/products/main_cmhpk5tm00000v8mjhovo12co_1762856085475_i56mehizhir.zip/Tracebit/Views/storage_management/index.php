<?php
/**
 * Storage Management Page
 * Dedicated page for managing screenshot storage
 */

// Get current user info from passed data
$login_user_id = get_array_value($login_user, "id", 0);
$current_year = isset($current_year) ? $current_year : date('Y');
?>

<!-- Include the topbar for navigation -->
<?php include(__DIR__ . '/../tracker/topbar.php'); ?>

<style>
/* Modern Storage Management UI Styles */
.storage-management-page {
    /* background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); */
    min-height: 100vh;
    padding: 20px 0;
}

.page-header-modern {
    background: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(10px);
    border-radius: 20px;
    padding: 30px;
    margin-bottom: 30px;
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
    border: 1px solid rgba(255, 255, 255, 0.2);
}

.page-title-modern {
    color: #2c3e50;
    font-weight: 700;
    font-size: 2.5rem;
    margin: 0;
    display: flex;
    align-items: center;
    gap: 15px;
}

.page-title-modern i {
    color: #667eea;
    font-size: 2rem;
}

.page-title-modern ~ p {
    margin-bottom: 15px !important;
}

.card-modern {
    background: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(10px);
    border-radius: 20px;
    border: 1px solid rgba(255, 255, 255, 0.2);
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
    transition: all 0.3s ease;
    overflow: hidden;
}

.card-modern:hover {
    transform: translateY(-5px);
    box-shadow: 0 15px 40px rgba(0, 0, 0, 0.15);
}

.card-header-modern {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    padding: 25px 30px;
    border-bottom: none;
    border-radius: 20px 20px 0 0;
}

.card-header-modern h5 {
    margin: 0;
    font-weight: 600;
    font-size: 1.3rem;
    display: flex;
    align-items: center;
    gap: 10px;
}

.card-body-modern {
    padding: 30px;
}

.reports-tabs .page-wrapper {
    display: flex;
    gap: 6px;
    flex-wrap: wrap;
}

.reports-tabs .page-wrapper a {
    margin: 0 !important;
}

.form-control-modern {
    border: 2px solid #e9ecef;
    border-radius: 12px;
    padding: 12px 16px;
    font-size: 1rem;
    transition: all 0.3s ease;
    background: rgba(255, 255, 255, 0.9);
}

.form-control-modern:focus {
    border-color: #667eea;
    box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
    background: white;
}

.form-select-modern {
    border: 2px solid #e9ecef;
    border-radius: 12px;
    padding: 12px 16px;
    font-size: 1rem;
    transition: all 0.3s ease;
    background: rgba(255, 255, 255, 0.9);
}

.form-select-modern:focus {
    border-color: #667eea;
    box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
    background: white;
}

.btn-modern {
    border-radius: 12px;
    padding: 12px 24px;
    font-weight: 600;
    font-size: 1rem;
    transition: all 0.3s ease;
    border: none;
    display: inline-flex;
    align-items: center;
    gap: 8px;
}

.btn-primary-modern {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white !important;
}

.btn-primary-modern:hover {
    background: linear-gradient(135deg, #5a6fd8 0%, #6a4190 100%);
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(102, 126, 234, 0.4);
}

.btn-secondary-modern {
    background: linear-gradient(135deg, #6c757d 0%, #495057 100%);
    color: white;
}

.btn-secondary-modern:hover {
    background: linear-gradient(135deg, #5a6268 0%, #343a40 100%);
    transform: translateY(-2px);
}

.btn-danger-modern {
    background: linear-gradient(135deg, #dc3545 0%, #c82333 100%);
    color: white;
}

.btn-danger-modern:hover {
    background: linear-gradient(135deg, #c82333 0%, #bd2130 100%);
    transform: translateY(-2px);
}

.btn-info-modern {
    background: linear-gradient(135deg, #17a2b8 0%, #138496 100%);
    color: white;
}

.btn-info-modern:hover {
    background: linear-gradient(135deg, #138496 0%, #117a8b 100%);
    transform: translateY(-2px);
}

.section-modern {
    background: rgba(255, 255, 255, 0.7);
    border-radius: 15px;
    padding: 20px;
    margin-bottom: 20px;
    border: 1px solid rgba(255, 255, 255, 0.3);
}

.section-title-modern {
    color: #2c3e50;
    font-weight: 600;
    font-size: 1.2rem;
    margin-bottom: 15px;
    display: flex;
    align-items: center;
    gap: 10px;
}

.alert-modern {
    border-radius: 15px;
    border: none;
    padding: 20px;
    margin-bottom: 20px;
    backdrop-filter: blur(10px);
}

.alert-warning-modern {
    background: rgba(255, 193, 7, 0.1);
    border-left: 4px solid #ffc107;
    color: #856404;
}

.table-modern {
    border-radius: 15px;
    overflow: hidden;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
}

.table-modern thead th {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    border: none;
    padding: 15px;
    font-weight: 600;
}

.table-modern tbody td {
    padding: 12px 15px;
    border-bottom: 1px solid #e9ecef;
    vertical-align: middle;
}

.table-modern tbody tr:hover {
    background-color: rgba(102, 126, 234, 0.05);
}

.preview-content-modern {
    background: rgba(255, 255, 255, 0.9);
    border-radius: 15px;
    padding: 25px;
    border: 1px solid rgba(255, 255, 255, 0.3);
}

.loading-spinner-modern {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 15px;
    padding: 40px;
}

.spinner-modern {
    width: 50px;
    height: 50px;
    border: 4px solid #f3f3f3;
    border-top: 4px solid #667eea;
    border-radius: 50%;
    animation: spin 1s linear infinite;
}

@keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}

/* Responsive Design */
@media (max-width: 768px) {
    .page-title-modern {
        font-size: 2rem;
    }
    
    .card-body-modern {
        padding: 20px;
    }
}

/* Animation for form sections */
.section-fade-in {
    animation: fadeInUp 0.6s ease-out;
}

@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(30px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

/* Topbar integration styles */
.reports-tabs {
    margin-bottom: 20px;
}


</style>

<div class="storage-management-page">
    <div class="container-fluid">
        <!-- Modern Page Header -->
        <div class="page-header-modern section-fade-in">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h1 class="page-title-modern">
                        <i data-feather='hard-drive'></i>
                        <?php echo app_lang("storage_management") ?: "Storage Management"; ?>
                    </h1>
                    <p class="text-muted mb-0 mt-2">Manage and organize your screenshots efficiently</p>
                </div>
                <div class="col-md-4 text-end">
                    <div class="d-flex justify-content-end gap-2">
                        <button type="button" class="btn btn-modern btn-secondary-modern" onclick="resetForm()">
                            <i data-feather='refresh-cw'></i> Reset
                        </button>
                        <button type="button" class="btn btn-modern btn-primary-modern" id="executeStorageAction" disabled>
                            <i data-feather='play'></i> Execute Action
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <!-- Action Selection Card -->
            <div class="col-lg-4 mb-4">
                <div class="card card-modern section-fade-in">
                    <div class="card-header card-header-modern">
                        <h5><i data-feather='settings'></i> Action Selection</h5>
                    </div>
                    <div class="card-body card-body-modern">
                        <form id="storageManagementForm">
                            <div class="mb-4">
                                <label for="actionType" class="form-label fw-bold">Action Type</label>
                                <select class="form-select form-select-modern" id="actionType" name="action_type" onchange="updateActionType()">
                                    <option value="">Select Action</option>
                                    <option value="export">📤 Export Screenshots</option>
                                    <option value="delete">🗑️ Delete Screenshots</option>
                                    <option value="stats">📊 View Statistics</option>
                                </select>
                            </div>
                            <div class="mb-4">
                                <label for="selectionType" class="form-label fw-bold">Selection Type</label>
                                <select class="form-select form-select-modern" id="selectionType" name="selection_type" onchange="updateSelectionType()">
                                    <option value="">Select Type</option>
                                    <option value="date_range">📅 By Date Range</option>
                                    <option value="user">👤 By User</option>
                                    <option value="year">📆 By Year</option>
                                </select>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Configuration Card -->
            <div class="col-lg-8 mb-4">
                <div class="card card-modern section-fade-in">
                    <div class="card-header card-header-modern">
                        <h5><i data-feather='sliders'></i> Configuration</h5>
                    </div>
                    <div class="card-body card-body-modern">
                        <!-- Date Range Section -->
                        <div id="dateRangeSection" class="section-modern" style="display: none;">
                            <h6 class="section-title-modern">
                                <i data-feather='calendar'></i> Date Range Selection
                            </h6>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="startDate" class="form-label fw-bold">Start Date</label>
                                    <input type="date" class="form-control form-control-modern" id="startDate" name="start_date" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="endDate" class="form-label fw-bold">End Date</label>
                                    <input type="date" class="form-control form-control-modern" id="endDate" name="end_date" required>
                                </div>
                            </div>
                        </div>
                        
                        <!-- User Selection Section -->
                        <div id="userSection" class="section-modern" style="display: none;">
                            <h6 class="section-title-modern">
                                <i data-feather='users'></i> User Selection
                            </h6>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="userId" class="form-label fw-bold">Select User</label>
                                    <select class="form-select form-select-modern" id="userId" name="user_id">
                                        <option value="">👥 All Users</option>
                                        <?php
                                        // Get users list
                                        $users_model = model("App\Models\Users_model");
                                        $users = $users_model->get_dropdown_list(array("first_name", "last_name"), "id");
                                        if ($users) {
                                            foreach ($users as $user_id => $user_name) {
                                                echo "<option value='{$user_id}'>👤 {$user_name}</option>";
                                            }
                                        }
                                        ?>
                                    </select>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="userYear" class="form-label fw-bold">Year (Optional)</label>
                                    <select class="form-select form-select-modern" id="userYear" name="year">
                                        <option value="">📅 All Years</option>
                                        <?php
                                        for ($year = $current_year; $year >= 2020; $year--) {
                                            echo "<option value='{$year}'>📅 {$year}</option>";
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Year Selection Section -->
                        <div id="yearSection" class="section-modern" style="display: none;">
                            <h6 class="section-title-modern">
                                <i data-feather='calendar'></i> Year Selection
                            </h6>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="yearSelect" class="form-label fw-bold">Select Year</label>
                                    <select class="form-select form-select-modern" id="yearSelect" name="year" required>
                                        <option value="">📅 Select Year</option>
                                        <?php
                                        for ($year = $current_year; $year >= 2020; $year--) {
                                            echo "<option value='{$year}'>📅 {$year}</option>";
                                        }
                                        ?>
                                    </select>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="yearMonth" class="form-label fw-bold">Month (Optional)</label>
                                    <select class="form-select form-select-modern" id="yearMonth" name="month">
                                        <option value="">📅 All Months</option>
                                        <?php
                                        for ($month = 1; $month <= 12; $month++) {
                                            $month_name = date('F', mktime(0, 0, 0, $month, 1));
                                            $month_num = str_pad($month, 2, '0', STR_PAD_LEFT);
                                            echo "<option value='{$month_num}'>📅 {$month_name}</option>";
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Export Options -->
                        <div id="exportOptions" class="section-modern" style="display: none;">
                            <h6 class="section-title-modern">
                                <i data-feather='download'></i> Export Options
                            </h6>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="exportFormat" class="form-label fw-bold">Export Format</label>
                                    <select class="form-select form-select-modern" id="exportFormat" name="format">
                                        <option value="zip">📦 ZIP Archive</option>
                                        <option value="csv">📊 CSV Report</option>
                                        <option value="json">📄 JSON Data</option>
                                    </select>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="includeMetadata" class="form-label fw-bold">Include Metadata</label>
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" id="includeMetadata" name="include_metadata" checked>
                                        <label class="form-check-label" for="includeMetadata">
                                            Include file information and statistics
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Delete Confirmation -->
                        <div id="deleteConfirmation" class="section-modern" style="display: none;">
                            <div class="alert alert-modern alert-warning-modern">
                                <h6 class="fw-bold">
                                    <i data-feather='alert-triangle'></i> Warning
                                </h6>
                                <p class="mb-3">This action will permanently delete the selected screenshots. This action cannot be undone.</p>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="confirmDelete" required>
                                    <label class="form-check-label" for="confirmDelete">
                                        I understand that this action cannot be undone
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Preview Section -->
        <div class="row">
            <div class="col-12">
                <div class="card card-modern section-fade-in">
                    <div class="card-header card-header-modern">
                        <h5><i data-feather='eye'></i> Preview</h5>
                    </div>
                    <div class="card-body card-body-modern">
                        <div id="previewContent" class="preview-content-modern">
                            <div class="text-center text-muted">
                                <i data-feather='info' style="width: 48px; height: 48px; color: #6c757d;"></i>
                                <p class="mt-3 mb-0">Select an action and type to see a preview of the files that will be affected.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// Enhanced Storage Management Functions with Modern UI
function updateActionType() {
    const actionType = $('#actionType').val();
    const selectionType = $('#selectionType').val();
    
    // Show/hide relevant sections with smooth transitions
    $('#exportOptions, #deleteConfirmation').fadeOut(300);
    
    if (actionType === 'export') {
        $('#exportOptions').fadeIn(300);
        $('#executeStorageAction')
            .removeClass('btn-danger-modern btn-info-modern')
            .addClass('btn-primary-modern')
            .html('<i data-feather="download"></i> Export');
    } else if (actionType === 'delete') {
        $('#deleteConfirmation').fadeIn(300);
        $('#executeStorageAction')
            .removeClass('btn-primary-modern btn-info-modern')
            .addClass('btn-danger-modern')
            .html('<i data-feather="trash-2"></i> Delete');
    } else if (actionType === 'stats') {
        $('#executeStorageAction')
            .removeClass('btn-danger-modern btn-primary-modern')
            .addClass('btn-info-modern')
            .html('<i data-feather="bar-chart-2"></i> View Stats');
    }
    
    // Enable/disable execute button
    updateExecuteButton();
    
    // Load preview if both action and selection are chosen
    if (actionType && selectionType) {
        loadPreview();
    }
}

function updateSelectionType() {
    const actionType = $('#actionType').val();
    const selectionType = $('#selectionType').val();
    
    // Hide all selection sections with smooth transitions
    $('#dateRangeSection, #userSection, #yearSection').fadeOut(300);
    
    // Show relevant selection section with smooth transition
    if (selectionType === 'date_range') {
        $('#dateRangeSection').fadeIn(300);
    } else if (selectionType === 'user') {
        $('#userSection').fadeIn(300);
    } else if (selectionType === 'year') {
        $('#yearSection').fadeIn(300);
    }
    
    // Enable/disable execute button
    updateExecuteButton();
    
    // Load preview if both action and selection are chosen
    if (actionType && selectionType) {
        loadPreview();
    }
}

function updateExecuteButton() {
    const actionType = $('#actionType').val();
    const selectionType = $('#selectionType').val();
    
    if (actionType && selectionType) {
        $('#executeStorageAction').prop('disabled', false);
    } else {
        $('#executeStorageAction').prop('disabled', true);
    }
}

function loadPreview() {
    const actionType = $('#actionType').val();
    const selectionType = $('#selectionType').val();
    
    if (!actionType || !selectionType) {
        $('#previewContent').html(`
            <div class="text-center text-muted">
                <i data-feather='info' style="width: 48px; height: 48px; color: #6c757d;"></i>
                <p class="mt-3 mb-0">Select an action and type to see a preview.</p>
            </div>
        `);
        return;
    }
    
    const formData = new FormData($('#storageManagementForm')[0]);
    
    // Show modern loading state
    $('#previewContent').html(`
        <div class="loading-spinner-modern">
            <div class="spinner-modern"></div>
            <p class="text-muted mb-0">Loading preview...</p>
        </div>
    `);
    
    $.ajax({
        url: '<?php echo get_uri("tracebit/storage/preview"); ?>',
        type: 'POST',
        data: formData,
        processData: false,
        contentType: false,
        success: function(response) {
            if (response.success) {
                $('#previewContent').html(response.html);
                // Reinitialize feather icons
                if (typeof feather !== 'undefined') {
                    feather.replace();
                }
            } else {
                $('#previewContent').html(`
                    <div class="alert alert-modern alert-warning-modern">
                        <i data-feather='alert-circle'></i> ${response.message}
                    </div>
                `);
            }
        },
        error: function() {
            $('#previewContent').html(`
                <div class="alert alert-modern alert-warning-modern">
                    <i data-feather='alert-triangle'></i> Failed to load preview
                </div>
            `);
        }
    });
}

function resetForm() {
    $('#storageManagementForm')[0].reset();
    $('#dateRangeSection, #userSection, #yearSection, #exportOptions, #deleteConfirmation').fadeOut(300);
    $('#executeStorageAction').prop('disabled', true);
    $('#previewContent').html(`
        <div class="text-center text-muted">
            <i data-feather='info' style="width: 48px; height: 48px; color: #6c757d;"></i>
            <p class="mt-3 mb-0">Select an action and type to see a preview.</p>
        </div>
    `);
}

// Execute storage action with enhanced UI
$('#executeStorageAction').click(function() {
    const actionType = $('#actionType').val();
    const formData = new FormData($('#storageManagementForm')[0]);
    
    // Handle stats action differently
    if (actionType === 'stats') {
        showStorageStats();
        return;
    }
    
    // Show enhanced loading state
    const originalText = $(this).html();
    $(this)
        .prop('disabled', true)
        .html('<div class="spinner-modern" style="width: 20px; height: 20px; margin-right: 8px;"></div> Processing...');
    
    $.ajax({
        url: '<?php echo get_uri("tracebit/storage/execute"); ?>',
        type: 'POST',
        data: formData,
        processData: false,
        contentType: false,
        success: function(response) {
            if (response.success) {
                appAlert.success(response.message);
                
                // Refresh page if needed
                if (response.refresh) {
                    setTimeout(() => {
                        location.reload();
                    }, 2000);
                }
            } else {
                appAlert.error(response.message);
            }
        },
        error: function() {
            appAlert.error('An error occurred while processing the request');
        },
        complete: function() {
            $('#executeStorageAction').prop('disabled', false).html(originalText);
            updateExecuteButton();
        }
    });
});

function showStorageStats() {
    // Open stats in a new window
    window.open('<?php echo get_uri("tracebit/storage/stats"); ?>', '_blank');
}

// Auto-update preview when form changes
$('#storageManagementForm input, #storageManagementForm select').change(function() {
    const actionType = $('#actionType').val();
    const selectionType = $('#selectionType').val();
    
    if (actionType && selectionType) {
        loadPreview();
    }
});

// Initialize with enhanced animations
$(document).ready(function() {
    // Initialize feather icons
    if (typeof feather !== 'undefined') {
        feather.replace();
    }
    
    // Add entrance animations
    $('.section-fade-in').each(function(index) {
        $(this).css('animation-delay', (index * 0.1) + 's');
    });
});
</script> 
