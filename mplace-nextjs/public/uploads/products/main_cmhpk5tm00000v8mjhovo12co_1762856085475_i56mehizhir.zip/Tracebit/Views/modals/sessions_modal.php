<?php echo form_open(get_uri("tracebit/export_sessions"), array("id" => "sessions-form", "class" => "general-form", "role" => "form")); ?>

<div class="modal-body clearfix">
    <div class="container-fluid">
        <!-- Sessions Summary -->
        <div class="row mb-3">
            <div class="col-md-4">
                <div class="session-stat text-center">
                    <h4 class="text-primary" id="totalSessions">
                        <?php echo count($sessions_data ?: []); ?>
                    </h4>
                    <small>Total Sessions</small>
                </div>
            </div>
            <div class="col-md-4">
                <div class="session-stat text-center">
                    <h4 class="text-success" id="totalHours">
                        <?php
                        $total_minutes = 0;
                        if ($sessions_data) {
                            foreach ($sessions_data as $session) {
                                if (isset($session->duration) && $session->duration !== 'Active') {
                                    preg_match('/(\d+)h/', $session->duration, $h_matches);
                                    preg_match('/(\d+)m/', $session->duration, $m_matches);
                                    $total_minutes += (isset($h_matches[1]) ? $h_matches[1] * 60 : 0) + (isset($m_matches[1]) ? $m_matches[1] : 0);
                                }
                            }
                        }
                        $hours = floor($total_minutes / 60);
                        $minutes = $total_minutes % 60;
                        echo ($hours > 0 ? $hours . 'h ' : '') . $minutes . 'm';
                        ?>
                    </h4>
                    <small>Total Hours</small>
                </div>
            </div>
            <div class="col-md-4">
                <div class="session-stat text-center">
                    <h4 class="text-info" id="avgSession">
                        <?php
                        $avg_minutes = count($sessions_data ?: []) > 0 ? round($total_minutes / count($sessions_data)) : 0;
                        $avg_hours = floor($avg_minutes / 60);
                        $avg_mins = $avg_minutes % 60;
                        echo ($avg_hours > 0 ? $avg_hours . 'h ' : '') . $avg_mins . 'm';
                        ?>
                    </h4>
                    <small>Avg Session</small>
                </div>
            </div>
        </div>        <!-- Sessions Table -->
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Session Time</th>
                        <th>Project</th>
                        <th>Description</th>
                        <th>Duration</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($sessions_data && count($sessions_data) > 0): ?>
                        <?php
                        $totals = [];
                        $grand_total_minutes = 0;

                        foreach ($sessions_data as $session):
                            // Parse duration to minutes for totals calculation
                            $duration_minutes = 0;
                            if (isset($session->duration) && $session->duration !== 'Active') {
                                preg_match('/(\d+)h/', $session->duration, $h_matches);
                                preg_match('/(\d+)m/', $session->duration, $m_matches);
                                $duration_minutes = (isset($h_matches[1]) ? $h_matches[1] * 60 : 0) + (isset($m_matches[1]) ? $m_matches[1] : 0);
                            }

                            if (!isset($totals[$session->description])) {
                                $totals[$session->description] = 0;
                            }
                            $totals[$session->description] += $duration_minutes;
                            $grand_total_minutes += $duration_minutes;

                            // Get project name or default
                            $project_display = $session->project_name ?? 'Other';
                        ?>
                            <tr data-session-id="<?php echo $session->id; ?>">
                                <td class="fw-semibold"><?php echo $session->session_time; ?></td>
                                <td>
                                    <span class="badge bg-light text-dark border"><?php echo $project_display; ?></span>
                                </td>
                                <td><?php echo $session->description; ?></td>
                                <td>
                                    <span class="badge bg-light text-dark border"><?php echo $session->duration; ?></span>
                                </td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-outline-danger delete-session-btn"
                                            data-session-id="<?php echo $session->id; ?>"
                                            title="Delete Session">
                                        <i data-feather="trash-2" class="icon-16"></i>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5" class="text-center text-muted py-3">
                                <i data-feather="info" class="icon-16"></i>
                                No sessions found for this date
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>        <!-- Total Time Summary -->
        <?php if ($sessions_data && count($sessions_data) > 0 && $grand_total_minutes > 0): ?>
        <div class="mt-3">
            <h6>Total Time Summary</h6>
            <div class="table-responsive">
                <table class="table table-bordered table-sm">
                    <thead>
                        <tr>
                            <th>Description</th>
                            <th>Total Time</th>
                            <th>Percentage</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($totals as $desc => $minutes):
                            $percentage = ($minutes / $grand_total_minutes) * 100;
                            $hours = floor($minutes / 60);
                            $mins = $minutes % 60;
                            $time_str = ($hours > 0 ? $hours . 'h ' : '') . $mins . 'm';
                        ?>
                            <tr>
                                <td class="fw-semibold"><?php echo $desc; ?></td>
                                <td>
                                    <span class="badge bg-primary"><?php echo $time_str; ?></span>
                                </td>
                                <td>
                                    <div class="progress" style="height: 8px;">
                                        <div class="progress-bar" role="progressbar"
                                             style="width: <?php echo $percentage; ?>%"
                                             aria-valuenow="<?php echo $percentage; ?>"
                                             aria-valuemin="0"
                                             aria-valuemax="100"></div>
                                    </div>
                                    <small class="text-muted"><?php echo number_format($percentage, 1); ?>%</small>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        <tr class="table-active border-top-2">
                            <td class="fw-bold">Total Time</td>
                            <td>
                                <span class="badge bg-success fs-6">
                                    <?php
                                    $total_hours = floor($grand_total_minutes / 60);
                                    $total_mins = $grand_total_minutes % 60;
                                    echo ($total_hours > 0 ? $total_hours . 'h ' : '') . $total_mins . 'm';
                                    ?>
                                </span>
                            </td>
                            <td>
                                <small class="text-success fw-semibold">100% Complete</small>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<div class="modal-footer">
    <button type="button" class="btn btn-default" data-bs-dismiss="modal"><span data-feather="x" class="icon-16"></span> <?php echo app_lang('close'); ?></button>
    <button type="submit" class="btn btn-primary"><span data-feather="download" class="icon-16"></span> Export Sessions</button>
</div>

<?php echo form_close(); ?>

<script type="text/javascript">
    $(document).ready(function () {
        // Set modal title
        <?php if (isset($modal_title)): ?>
        var modalTitle = <?php echo json_encode($modal_title); ?>;
        $("#ajaxModalTitle").html('<i data-feather="clock" class="icon-16"></i> ' + modalTitle);
        <?php endif; ?>
        
        // Initialize feather icons
        if (typeof feather !== 'undefined') {
            feather.replace();
        }

        // Handle delete session button clicks
        $('.delete-session-btn').on('click', function() {
            const sessionId = $(this).data('session-id');
            const row = $(this).closest('tr');
            const deleteBtn = $(this);

            if (confirm('Are you sure you want to delete this session?')) {
                // Show loading state
                deleteBtn.prop('disabled', true).html('<i class="fa fa-spinner fa-spin"></i>');

                $.ajax({
                    url: '<?php echo get_uri("tracebit/delete_session"); ?>',
                    type: 'POST',
                    data: {
                        session_id: sessionId,
                        date: '<?php echo $date; ?>',
                        user_id: '<?php echo $user_id; ?>'
                    },
                    success: function(response) {
                        try {
                            const result = typeof response === 'string' ? JSON.parse(response) : response;

                            if (result.success) {
                                // Remove the row with animation
                                row.fadeOut(300, function() {
                                    $(this).remove();

                                    // Check if table is empty now
                                    const remainingRows = $('.table tbody tr:visible').length;
                                    if (remainingRows === 0) {
                                        $('.table tbody').html(`
                                            <tr>
                                                <td colspan="5" class="text-center text-muted py-3">
                                                    <i data-feather="info" class="icon-16"></i>
                                                    No sessions found for this date
                                                </td>
                                            </tr>
                                        `);
                                        feather.replace();
                                    }

                                    // Update summary statistics
                                    updateSummaryStats();
                                });

                                appAlert.success(result.message || 'Session deleted successfully', {duration: 3000});
                            } else {
                                appAlert.error(result.message || result.error || 'Failed to delete session');
                                // Restore button state
                                deleteBtn.prop('disabled', false).html('<i data-feather="trash-2" class="icon-16"></i>');
                                feather.replace();
                            }
                        } catch (e) {
                            appAlert.error('An error occurred while deleting the session');
                            // Restore button state
                            deleteBtn.prop('disabled', false).html('<i data-feather="trash-2" class="icon-16"></i>');
                            feather.replace();
                        }
                    },
                    error: function() {
                        appAlert.error('Network error occurred while deleting session');
                        // Restore button state
                        deleteBtn.prop('disabled', false).html('<i data-feather="trash-2" class="icon-16"></i>');
                        feather.replace();
                    }
                });
            }
        });        // Function to update summary statistics after deletion
        function updateSummaryStats() {
            let totalSessions = 0;
            let totalMinutes = 0;

            $('.table tbody tr:visible').each(function() {
                if (!$(this).find('.text-muted').length) { // Skip "no sessions" row
                    totalSessions++;

                    const durationText = $(this).find('.badge').text();
                    if (durationText && durationText !== 'Active') {
                        const hMatch = durationText.match(/(\d+)h/);
                        const mMatch = durationText.match(/(\d+)m/);
                        const hours = hMatch ? parseInt(hMatch[1]) : 0;
                        const minutes = mMatch ? parseInt(mMatch[1]) : 0;
                        totalMinutes += (hours * 60) + minutes;
                    }
                }
            });

            // Update summary displays
            $('#totalSessions').text(totalSessions);

            const totalHours = Math.floor(totalMinutes / 60);
            const remainingMinutes = totalMinutes % 60;
            const totalTimeStr = (totalHours > 0 ? totalHours + 'h ' : '') + remainingMinutes + 'm';
            $('#totalHours').text(totalTimeStr);

            const avgMinutes = totalSessions > 0 ? Math.round(totalMinutes / totalSessions) : 0;
            const avgHours = Math.floor(avgMinutes / 60);
            const avgMins = avgMinutes % 60;
            const avgTimeStr = (avgHours > 0 ? avgHours + 'h ' : '') + avgMins + 'm';
            $('#avgSession').text(avgTimeStr);
        }

        $("#sessions-form").appForm({
            onSuccess: function (result) {
                if (result.success) {
                    appAlert.success(result.message, {duration: 10000});
                } else {
                    appAlert.error(result.message);
                }
            }
        });
    });
</script>
