<?php
$label_column = "col-md-3";
$field_column = "col-md-9";
?>
<?php echo form_open(get_uri("tracebit/save_manual_time"), array("id" => "manual-time-form", "class" => "general-form", "role" => "form")); ?>

<div class="modal-body clearfix">
    <div class="container-fluid">
        <input type="hidden" name="date" value="<?php echo $date; ?>" />
        <input type="hidden" name="user_id" value="<?php echo $user_id; ?>" />

        <!-- Team member display -->
        <div class="form-group">
            <label for="team_member" class="<?php echo $label_column; ?>">Team member</label>
            <div class="<?php echo $field_column; ?>">
                <div style="display: flex; align-items: center; padding: 8px 0;">
                    <?php
                    $user_avatar = get_avatar($user_avatar_url ?? '');
                    $display_name = strtoupper($user_name ?? 'UNKNOWN USER');
                    echo "<span class='avatar avatar-xs' style='margin-right: 10px;'><img src='{$user_avatar}' alt='{$display_name}' style='border-radius: 50%;'></span>";
                    echo "<span style='font-weight: 500;'>" . $display_name . "</span>";
                    ?>
                </div>
            </div>
        </div>

        <!-- In Time -->
        <div class="form-group">
            <label for="in_time" class="<?php echo $label_column; ?>">In Time <span class="help" title="<?php echo app_lang('required'); ?>">*</span></label>
            <div class="<?php echo $field_column; ?>">
                <?php
                echo form_input(array(
                    "id" => "in_time",
                    "name" => "in_time",
                    "type" => "time",
                    "value" => "",
                    "class" => "form-control",
                    "placeholder" => "In Time",
                    "autofocus" => true,
                    "data-rule-required" => true,
                    "data-msg-required" => app_lang("field_required"),
                ));
                ?>
            </div>
        </div>

        <!-- Out Time -->
        <div class="form-group">
            <label for="out_time" class="<?php echo $label_column; ?>">Out Time <span class="help" title="<?php echo app_lang('required'); ?>">*</span></label>
            <div class="<?php echo $field_column; ?>">
                <?php
                echo form_input(array(
                    "id" => "out_time",
                    "name" => "out_time",
                    "type" => "time",
                    "value" => "",
                    "class" => "form-control",
                    "placeholder" => "Out Time",
                    "data-rule-required" => true,
                    "data-msg-required" => app_lang("field_required"),
                ));
                ?>
            </div>
        </div>

        <!-- Description -->
        <div class="form-group">
            <label for="description" class="<?php echo $label_column; ?>">Description</label>
            <div class="<?php echo $field_column; ?>">
                <?php
                echo form_textarea(array(
                    "id" => "description",
                    "name" => "description",
                    "value" => "",
                    "class" => "form-control",
                    "placeholder" => "Description",
                    "rows" => 3,
                    "style" => "resize: vertical;"
                ));
                ?>
            </div>
        </div>

        <!-- Duration display -->
        <div class="alert alert-info" style="margin-top: 20px;">
            <i data-feather="clock" class="icon-16"></i>
            <strong>Duration:</strong> <span id="calculatedDuration">Please select in and out times</span>
        </div>
    </div>
</div>

<div class="modal-footer">
    <button type="button" class="btn btn-default" data-bs-dismiss="modal">
        <span data-feather="x" class="icon-16"></span> Close
    </button>
    <button type="submit" class="btn btn-primary">
        <span data-feather="check-circle" class="icon-16"></span> Submit
    </button>
</div>

<?php echo form_close(); ?>

<script type="text/javascript">
    $(document).ready(function () {
        // Initialize feather icons
        if (typeof feather !== 'undefined') {
            feather.replace();
        }

        // Calculate duration when times change
        $('#in_time, #out_time').on('change', function() {
            calculateDuration();
        });

        function calculateDuration() {
            const inTime = $('#in_time').val();
            const outTime = $('#out_time').val();

            if (inTime && outTime) {
                const start = new Date(`2000-01-01T${inTime}:00`);
                const end = new Date(`2000-01-01T${outTime}:00`);

                if (end > start) {
                    const diffMs = end - start;
                    const diffHrs = Math.floor(diffMs / (1000 * 60 * 60));
                    const diffMins = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));

                    $('#calculatedDuration').html(`<strong>${diffHrs}h ${diffMins}m</strong>`);
                } else {
                    $('#calculatedDuration').html('<span class="text-danger">Out time must be after in time</span>');
                }
            } else {
                $('#calculatedDuration').text('Please select in and out times');
            }
        }

        $("#manual-time-form").appForm({
            onSuccess: function (result) {
                if (result.success) {
                    appAlert.success(result.message, {duration: 3000});
                    $("#ajaxModal").modal('hide');

                    // Refresh the timesheet table
                    if (typeof members_calling === 'function') {
                        setTimeout(() => {
                            members_calling();
                        }, 1000);
                    }
                } else {
                    appAlert.error(result.message);
                }
            }
        });

        // Set modal title
        <?php if (isset($modal_title)): ?>
        var modalTitle = <?php echo json_encode($modal_title); ?>;
        $("#ajaxModalTitle").html('<i data-feather="edit-3" class="icon-16"></i> ' + modalTitle);
        feather.replace();
        <?php endif; ?>
    });
</script>
