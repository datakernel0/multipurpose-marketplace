<?php
/**
 * Tracker Dashboard View
 * Clean, organized dashboard with separated business logic
 */

// Force no-cache headers to ensure updated data
header("Cache-Control: no-cache, no-store, must-revalidate");
header("Pragma: no-cache");
header("Expires: 0");

// Load required styles
tracker_load_css(array("assets/css/tracker_styles.css"));
tracker_load_css(array("assets/css/tracker_dashboard_styles.css"));
tracker_load_css(array("assets/css/tracker_responsive.css"));

// Include helper functions
require_once(__DIR__ . '/dashboard_helpers.php');
use Tracebit\Helpers\TrackerDashboardHelper;

// Initialize dashboard helper
$dashboardHelper = TrackerDashboardHelper::getInstance();

// Get all dashboard data in one call
$dashboardData = $dashboardHelper->getDashboardData($user_id ?? 0);

// Extract data for template
$dashboard_checkin_active = $dashboardData['dashboard_checkin_active'];
$attendance_data = $dashboardData['attendance'];
$working_hours_data = $dashboardData['working_hours'];
$time_chart_data = $dashboardData['time_chart'];
$productivity_data = $dashboardData['productivity'];
$project_time_data = $dashboardData['project_time'];
$project_recap_data = $dashboardData['project_recap'];
$idle_time_data = $dashboardData['idle_time'];
$manual_time_data = $dashboardData['manual_time'];
$away_time_data = $dashboardData['away_time'];

// Extract team members and screenshots data
// Check if data was passed directly from controller (legacy mode) or from dashboard helper
if (isset($team_members) && isset($screenshots)) {
    // Data was passed directly from controller - use as is
    // Ensure team_members has the correct structure for status display
    $team_members = $team_members ?? [];
    $screenshots = $screenshots ?? [];
} else {
    // Data should come from dashboard helper
    $team_members = $dashboardData['team_members'] ?? [];
    $screenshots = $dashboardData['screenshots'] ?? [];
}

// Variables for template use (maintaining backwards compatibility)
$attendance_status = $attendance_data['status'];
$is_checked_in = $attendance_data['is_checked_in'];
$error_message = $attendance_data['error_message'];
$button_class = $attendance_data['button_class'];
$button_text = $attendance_data['button_text'];
$button_icon = $attendance_data['button_icon'];
$status_text = $attendance_data['status_text'];

$total_working_time = $working_hours_data['total_working_time'];
$total_working_seconds = $working_hours_data['total_working_seconds'];
$daily_target_hours = $working_hours_data['daily_target_hours'];

$chart_labels = $time_chart_data['labels'];
$chart_values = $time_chart_data['values'];
$chart_colors = $time_chart_data['colors'];

$productivity_percentage = $productivity_data['percentage'];
$productivity_display = $productivity_data['display'];
$productivity_chart_labels = $productivity_data['chart_labels'];
$productivity_chart_values = $productivity_data['chart_values'];
$productivity_chart_colors = $productivity_data['chart_colors'];

$project_time_display = $project_time_data['total_project_time'];
$project_chart_labels = $project_time_data['chart_labels'];
$project_chart_values = $project_time_data['chart_values'];
$project_chart_colors = $project_time_data['chart_colors'];

$idle_time_display = $idle_time_data['total_idle_time'];
$idle_chart_labels = $idle_time_data['chart_labels'];
$idle_chart_values = $idle_time_data['chart_values'];
$idle_chart_colors = $idle_time_data['chart_colors'];

$manual_time_display = $manual_time_data['total_manual_time'];
$manual_chart_labels = $manual_time_data['chart_labels'];
$manual_chart_values = $manual_time_data['chart_values'];
$manual_chart_colors = $manual_time_data['chart_colors'];

$away_time_display = $away_time_data['total_away_time'];
$away_chart_labels = $away_time_data['chart_labels'];
$away_chart_values = $away_time_data['chart_values'];
$away_chart_colors = $away_time_data['chart_colors'];

// Extract project recap chart data
$project_recap_chart_labels = $project_recap_data['chart_labels'];
$project_recap_chart_values = $project_recap_data['chart_values'];
$project_recap_chart_colors = $project_recap_data['chart_colors'];

// Calculate Attendance Recap for current month
$attendance_recap = $dashboardHelper->calculateAttendanceRecap($user_id);
$present_days = $attendance_recap['present_days'];
$absent_days = $attendance_recap['absent_days'];
$late_arrivals = $attendance_recap['late_arrivals'];
$leave_days = $attendance_recap['leave_days'];
$workable_days = $attendance_recap['workable_days'];
$attendance_chart_data = $attendance_recap['chart_data'];

// Top navigation removed - now handled by left sidebar menu
?>

<div id="page-content" class="page-wrapper clearfix grid-button tracker-dashboard">
<br/>   
<div class="card">
        <div class="page-title clearfix">
            <h1><i data-feather="activity" class="icon-16 mr10"></i>Dashboard</h1>
            <div class="title-button-group">
                <?php if ($dashboard_checkin_active) { ?>
                <div class="attendance-controls">
                    <?php if (!empty($error_message)) { ?>
                        <div class="alert alert-warning">
                            <strong>Database Setup Required</strong><br>
                            Please run the tracker database schema to enable check-in functionality.
                        </div>
                    <?php } else { ?>
                        <button type="button" class="<?php echo $button_class; ?>" id="attendance-toggle"
                                data-action="<?php echo $is_checked_in ? 'checkout' : 'checkin'; ?>"
                                data-attendance-id="<?php echo ($is_checked_in && $attendance_status) ? $attendance_status->id : ''; ?>">
                            <i data-feather="<?php echo $button_icon; ?>" class="icon-12 mr5"></i>
                            <?php echo $button_text; ?>
                        </button>
                        <div class="attendance-status"><?php echo $status_text; ?></div>
                    <?php } ?>
                </div>
                <?php } else {
                    // If dashboard check-in is not enabled, show a message or do nothing
                    $originalTimezone = date_default_timezone_get();
                    date_default_timezone_set('Asia/Dhaka');
                    $currentDate = date('F d, Y');
                    date_default_timezone_set($originalTimezone);
                    echo '<span class="badge bg-primary">' . $currentDate . '</span>';
                } ?>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-8 col-md-12">
            <!-- Overview Cards Grid -->
            <div class="tracker-overview-grid">
                <div class="card tracker-overview">
                    <article>
                        <p><strong>Total time tracked</strong></p>
                        <p><?php echo $total_working_time; ?></p>
                    </article>
                    <canvas id="time-track"></canvas>
                </div>

                <div class="card tracker-overview">
                    <article>
                        <p><strong>Productivity</strong></p>
                        <p><?php echo $productivity_display; ?></p>
                    </article>
                    <canvas id="productive-time"></canvas>
                </div>
                <div class="card tracker-overview">
                    <article>
                        <p><strong>Project Time</strong></p>
                        <p><?php echo $project_time_display; ?></p>
                    </article>
                    <canvas id="project-time"></canvas>
                </div>
                <div class="card tracker-overview">
                    <article>
                        <p><strong>Idle Times</strong></p>
                        <p><?php echo $idle_time_display; ?></p>
                    </article>
                    <canvas id="idle-time"></canvas>
                </div>
                <div class="card tracker-overview">
                    <article>
                        <p><strong>Manual Time</strong></p>
                        <p><?php echo $manual_time_display; ?></p>
                    </article>
                    <canvas id="manual-time"></canvas>
                </div>
                <div class="card tracker-overview">
                    <article>
                        <p><strong>Away Time</strong></p>
                        <p><?php echo $away_time_display; ?></p>
                    </article>
                    <canvas id="away-time"></canvas>
                </div>
            </div>

            <!-- Recent Screenshots Section -->
            <div class="card tracker-widget">
                <header>
                    <p><strong><i data-feather="camera" class="icon-16 mr5"></i>Recent snapshots</strong></p>
                    <a href="<?php echo get_uri('tracebit/tracker/screenshots'); ?>"><i data-feather="external-link" class="icon-12 mr5"></i>All snapshots</a>
                </header>

                <div class="recent-screenshots-grid">
                    <?php if(count($screenshots)) {
                        // Limit to only 4 most recent screenshots
                        $recentScreenshots = array_slice($screenshots, 0, 4);
                        foreach ($recentScreenshots as $key => $value) {
                            // Convert timestamp to Asia/Dhaka timezone
                            $originalTimezone = date_default_timezone_get();
                            date_default_timezone_set('Asia/Dhaka');
                            $time = date('H:i a', strtotime($value->created_at));
                            date_default_timezone_set($originalTimezone);
                            ?>
                    <div class="img-thumbnail">
                        <a class="image-popup-vertical-fit" href="<?php echo base_url($value->path); ?>">
                            <img src="<?php echo base_url($value->path); ?>" alt="Screenshot" onerror="this.src='<?php echo base_url('plugins/Tracebit/assets/demo/screenshot-placeholder.svg'); ?>'">
                            <div class="caption">
                                <p><i data-feather="clock" class="icon-12 mr5"></i>Snapshot at <?php echo $time; ?></p>
                            </div>
                        </a>
                    </div>
                    <?php }} else { ?>
                    <!-- Placeholder screenshots for demo -->
                    <div class="img-thumbnail">
                        <a class="image-popup-vertical-fit" href="#">
                            <img src="<?php echo base_url('plugins/Tracebit/assets/demo/screenshot-placeholder.svg'); ?>" alt="Screenshot" style="background: linear-gradient(45deg, #f8f9fa, #e9ecef);">
                            <div class="caption">
                                <p><i data-feather="clock" class="icon-12 mr5"></i>Snapshot at 10:00 AM</p>
                            </div>
                        </a>
                    </div>
                    <div class="img-thumbnail">
                        <a class="image-popup-vertical-fit" href="#">
                            <img src="<?php echo base_url('plugins/Tracebit/assets/demo/screenshot-placeholder.svg'); ?>" alt="Screenshot" style="background: linear-gradient(45deg, #e9ecef, #dee2e6);">
                            <div class="caption">
                                <p><i data-feather="clock" class="icon-12 mr5"></i>Snapshot at 11:30 AM</p>
                            </div>
                        </a>
                    </div>
                    <div class="img-thumbnail">
                        <a class="image-popup-vertical-fit" href="#">
                            <img src="<?php echo base_url('plugins/Tracebit/assets/demo/screenshot-placeholder.svg'); ?>" alt="Screenshot" style="background: linear-gradient(45deg, #dee2e6, #ced4da);">
                            <div class="caption">
                                <p><i data-feather="clock" class="icon-12 mr5"></i>Snapshot at 02:15 PM</p>
                            </div>
                        </a>
                    </div>
                    <div class="img-thumbnail">
                        <a class="image-popup-vertical-fit" href="#">
                            <img src="<?php echo base_url('plugins/Tracebit/assets/demo/screenshot-placeholder.svg'); ?>" alt="Screenshot" style="background: linear-gradient(45deg, #ced4da, #adb5bd);">
                            <div class="caption">
                                <p><i data-feather="clock" class="icon-12 mr5"></i>Snapshot at 04:45 PM</p>
                            </div>
                        </a>
                    </div>
                    <?php } ?>
                </div>
            </div>
            <!-- Activity Log Section -->
            <div class="card tracker-widget activity-log">
                <header>
                    <p><strong><i data-feather="users" class="icon-16 mr5"></i>Team Activity</strong></p>
                    <small class="text-muted">Real-time status</small>
                </header>

                <ul>
                    <?php

                    if (isset($team_members) && count($team_members)) {
                        foreach ($team_members as $key => $value) {
                            $status = 'absent'; // Default to absent

                            if($value->applicant_id ?? false) {
                                // User has approved leave for today
                                $status = 'leave';
                            } else if (!empty($value->attendance_status) && ($value->attendance_date ?? '') == $dashboardHelper->getCurrentDate()) {
                                // User has status record for today, use that status
                                $status = $value->attendance_status;
                            } else {
                                // No status record for today = absent
                                $status = 'absent';
                            }

                            $statusClass = 'status-' . $status;
                            $statusIcon = [
                                'active' => 'check-circle',
                                'inactive' => 'minus-circle',
                                'absent' => 'x', // x-circle is not a valid feather icon, use 'x'
                                'leave' => 'calendar'
                            ][$status] ?? 'minus-circle';

                            // Validate icon name to prevent JS errors
                            $validIcons = ['check-circle', 'minus-circle', 'x', 'calendar', 'clock', 'camera', 'users', 'activity', 'external-link', 'folder', 'bar-chart-2', 'check'];
                            if (!in_array($statusIcon, $validIcons)) {
                                $statusIcon = 'minus-circle';
                            }
                        ?>
                    <li>
                        <figure>
                            <img src="<?php echo get_avatar($value->employee_image ?? ''); ?>" alt="<?php echo $value->first_name ?? 'User'; ?>">
                            <div>
                                <p><?php echo ($value->employee_name ?? ''); ?></p>
                                <small class="text-muted">
                                    <?php if($status === 'active') echo 'Currently working';
                                          elseif($status === 'leave') echo 'On leave';
                                          elseif($status === 'absent') echo 'Not checked in';
                                          else echo 'Inactive'; ?>
                                </small>
                            </div>
                        </figure>
                        <span class="<?php echo $statusClass; ?>">
                            <i data-feather="<?php echo $statusIcon; ?>" class="icon-12 mr5"></i>
                            <?php echo ucfirst($status); ?>
                        </span>
                    </li>
                    <?php }
                    } ?>
                </ul>
            </div>
        </div>

        <!-- Right Sidebar -->
        <div class="col-lg-4 col-md-12">
             <!-- Attendance Recap Widget -->
            <div class="card tracker-widget">
                <header>
                    <p><strong><i data-feather="check" class="icon-16 mr5"></i>Attendance Recap</strong></p>
                    <a href="<?php echo get_uri('tracebit/tracker/attendance'); ?>"><i data-feather="external-link" class="icon-12 mr5"></i>Current Month</a>
                </header>



                <canvas id="attendance"></canvas>

                <!-- Debug: Show current colors being used -->
                <?php if (isset($_GET['debug_attendance'])): ?>
                <div style="font-size: 12px; margin-top: 10px; background: #f8f9fa; padding: 10px; border-radius: 4px;">
                    <strong>Debug - Current Colors:</strong><br>
                    Present: <?php echo $attendance_chart_data['colors'][0]; ?><br>
                    Late: <?php echo $attendance_chart_data['colors'][1]; ?><br>
                    Absent: <?php echo $attendance_chart_data['colors'][2]; ?><br>
                    Leave: <?php echo $attendance_chart_data['colors'][3]; ?>
                </div>
                <?php endif; ?>

                <ul class="tracker-projects">
                    <li>
                        <span class="project-name">
                            <i data-feather="calendar" class="icon-12 mr5 text-primary"></i>
                            Workable Days
                        </span>
                        <span class="text-primary font-weight-bold"><?php echo $workable_days; ?> day<?php echo $workable_days != 1 ? 's' : ''; ?></span>
                    </li>
                    <li>
                        <span class="project-name">
                            <i data-feather="check" class="icon-12 mr5 text-success"></i>
                            Present Days
                        </span>
                        <span class="text-success font-weight-bold"><?php echo $present_days; ?> day<?php echo $present_days != 1 ? 's' : ''; ?></span>
                    </li>
                    <li>
                        <span class="project-name">
                            <i data-feather="x" class="icon-12 mr5 text-danger"></i>
                            Absent Days
                        </span>
                        <span class="text-danger font-weight-bold"><?php echo $absent_days; ?> day<?php echo $absent_days != 1 ? 's' : ''; ?></span>
                    </li>
                    <li>
                        <span class="project-name">
                            <i data-feather="clock" class="icon-12 mr5 text-warning"></i>
                            Late Arrivals
                        </span>
                        <span class="text-warning font-weight-bold"><?php echo $late_arrivals; ?> day<?php echo $late_arrivals != 1 ? 's' : ''; ?></span>
                    </li>
                    <li>
                        <span class="project-name">
                            <i data-feather="calendar" class="icon-12 mr5 text-info"></i>
                            Leave Days
                        </span>
                        <span class="text-info font-weight-bold"><?php echo $leave_days; ?> day<?php echo $leave_days != 1 ? 's' : ''; ?></span>
                    </li>
                </ul>
            </div>

            <!-- Project Recap Widget -->
            <div class="card tracker-widget">
                <header>
                    <p><strong><i data-feather="bar-chart-2" class="icon-16 mr5"></i>Project Recap</strong></p>
                    <div class="filter-buttons">
                        <a href="javascript:void(0)" class="filter-btn active" data-filter="weekly">
                            <i data-feather="calendar" class="icon-12 mr5"></i>Weekly
                        </a>
                        <a href="javascript:void(0)" class="filter-btn" data-filter="monthly">
                            <i data-feather="calendar" class="icon-12 mr5"></i>Monthly
                        </a>
                    </div>
                </header>
                <canvas id="project-recap"></canvas>
                <ul class="tracker-projects">
                    <?php if (!empty($project_recap_data['projects'])): ?>
                        <?php foreach ($project_recap_data['projects'] as $index => $project): ?>
                            <?php if ($index < 5): // Show only top 5 projects ?>
                                <li>
                                    <span class="project-name">
                                        <i data-feather="folder" class="icon-12 mr5"></i>
                                        <?php echo htmlspecialchars($project['title']); ?>
                                        <?php if (!empty($project['status'])): ?>
                                            <span class="project-status <?php echo strtolower($project['status']); ?>">
                                                <?php echo ucfirst($project['status']); ?>
                                            </span>
                                        <?php endif; ?>
                                        <?php if (!empty($project['is_leader'])): ?>
                                            <span class="project-leader">
                                                <i data-feather="star" class="icon-10"></i>Leader
                                            </span>
                                        <?php endif; ?>
                                    </span>
                                    <span class="text-primary font-weight-bold">
                                        <?php echo $project['formatted_time']; ?>
                                    </span>
                                </li>
                            <?php endif; ?>
                        <?php endforeach; ?>

                        <?php if (count($project_recap_data['projects']) > 5): ?>
                            <li>
                                <span class="project-name">
                                    <i data-feather="more-horizontal" class="icon-12 mr5"></i>
                                    <?php echo count($project_recap_data['projects']) - 5; ?> more projects
                                </span>
                                <span class="text-muted">
                                    <?php
                                    $otherTime = 0;
                                    for ($i = 5; $i < count($project_recap_data['projects']); $i++) {
                                        $otherTime += $project_recap_data['projects'][$i]['seconds'];
                                    }
                                    echo $dashboardHelper->formatTime($otherTime);
                                    ?>
                                </span>
                            </li>
                        <?php endif; ?>
                    <?php else: ?>
                        <li>
                            <span class="project-name">
                                <i data-feather="info" class="icon-12 mr5"></i>
                                No project activity
                            </span>
                            <span class="text-muted">0m</span>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>
</div>

<!-- Include external JavaScript file -->
<script src="<?php echo base_url('plugins/Tracebit/Views/tracker/dashboard.js'); ?>?v=<?php echo time(); ?>"></script>

<!-- Include responsive JavaScript enhancements -->
<script src="<?php echo base_url('plugins/Tracebit/assets/js/tracker_responsive.js'); ?>?v=<?php echo time(); ?>"></script>

<script type="text/javascript">
    // Initialize dashboard when DOM is ready
    $(document).ready(function() {
        // Prepare chart data from PHP
        var chartData = {
            time: {
                labels: <?php echo json_encode($chart_labels); ?>,
                values: <?php echo json_encode($chart_values); ?>,
                colors: <?php echo json_encode($chart_colors); ?>
            },
            productivity: {
                labels: <?php echo json_encode($productivity_chart_labels); ?>,
                values: <?php echo json_encode($productivity_chart_values); ?>,
                colors: <?php echo json_encode($productivity_chart_colors); ?>
            },
            project: {
                labels: <?php echo json_encode($project_chart_labels); ?>,
                values: <?php echo json_encode($project_chart_values); ?>,
                colors: <?php echo json_encode($project_chart_colors); ?>
            },
            idle: {
                labels: <?php echo json_encode($idle_chart_labels); ?>,
                values: <?php echo json_encode($idle_chart_values); ?>,
                colors: <?php echo json_encode($idle_chart_colors); ?>
            },
            manual: {
                labels: <?php echo json_encode($manual_chart_labels); ?>,
                values: <?php echo json_encode($manual_chart_values); ?>,
                colors: <?php echo json_encode($manual_chart_colors); ?>
            },
            away: {
                labels: <?php echo json_encode($away_chart_labels); ?>,
                values: <?php echo json_encode($away_chart_values); ?>,
                colors: <?php echo json_encode($away_chart_colors); ?>
            },
            project_recap: {
                labels: <?php echo json_encode($project_recap_chart_labels); ?>,
                values: <?php echo json_encode($project_recap_chart_values); ?>,
                colors: <?php echo json_encode($project_recap_chart_colors); ?>
            },
            attendance: {
                labels: <?php echo json_encode($attendance_chart_data['labels']); ?>,
                values: <?php echo json_encode($attendance_chart_data['values']); ?>,
                colors: <?php echo json_encode($attendance_chart_data['colors']); ?>
            }
        };

        // Dashboard configuration
        var trackerConfig = {
            clockToggleUrl: '<?php echo get_uri("tracebit/tracker/clock_toggle"); ?>',
            projectRecapUrl: '<?php echo get_uri("tracebit/tracker"); ?>',
            autoReload: true
        };

        // Initialize the dashboard
        initTrackerDashboard(chartData, trackerConfig);
    });
</script>
