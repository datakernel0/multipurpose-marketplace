<?php tracker_load_css(array("assets/css/tracker_styles.css", "assets/css/tracker_responsive.css")); ?>
<?php // Top navigation removed - now handled by left sidebar menu ?>
<div id="page-content" class="page-wrapper clearfix grid-button">
    <div class="card">
        <?php echo form_open(get_uri("tracebit/screenshots"), array("id" => "search-form", "autocomplete" => "off", "class" => "search-form", "role" => "form")); ?>
        <div class="page-title clearfix">
            <h1>Snapshots- <?php echo count($screenshot) ?></h1>
            <div class="title-button-group">
                <input required name="date" autocomplete="off" type="text" class="form-control" id="date" placeholder="date">

                <select class="user_list form-control" id="user_list" name="user_id">
                    <?php foreach ($team_members_dropdown as $key => $team) { ?>
                    <option <?php  echo $user_id == $key ? "selected" : "" ?> value="<?php  echo $key; ?>">
                        <?php  echo $team; ?></option>
                    <?php  } ?>
                </select>

                <button class="btn btn-primary" type="submit">Filter</button>
            </div>
        </div>
        <?php echo form_close(); ?>

        <div class="container-fluid">
            <div class="row">
                <?php if(count($screenshot)) { foreach ($screenshot as $key => $item) {
                    $time = date('H:i:s a', strtotime($item->date. ' +6 hours'));
                ?>
                <div class="col-md-3 col-sm-6 mb-3">
                    <div class="caption">
                        <p class="text-center"><strong><?php echo $item->title ? $item->title : 'Screenshot'; ?></strong></p>
                    </div>
                    <div class="img-thumbnail">
                        <a class="image-popup-vertical-fit" href="<?php echo base_url($item->path); ?>">
                            <img src="<?php echo base_url($item->path); ?>" style="width:100%; height: 200px; object-fit: cover;" alt="Screenshot" onerror="this.src='<?php echo base_url('assets/images/placeholder.png'); ?>'">
                            <div style="margin-top: 15px" class="caption">
                                <p class="text-left">&nbsp; &nbsp; Snapshot taken at- <?php echo $time; ?></p>
                            </div>
                        </a>
                    </div>
                </div>
                <?php }} else { ?>
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-body text-center">
                                <i data-feather="image" class="icon-40 text-muted mb-3"></i>
                                <h4 class="text-muted">No Screenshots Available!</h4>
                                <p class="text-muted">No screenshots found for the selected date and user.</p>
                            </div>
                        </div>
                    </div>
                <?php } ?>
            </div>
        </div>

    </div>
</div>


<script>
    $(document).ready(function () {
        $('#date').datepicker({
            format: 'yyyy-mm-dd',
            autoclose: true,
            todayHighlight: true
        });
        $('#date').datepicker('setDate', '<?php echo $date; ?>');

        // magnetic pop up

        $('.image-popup-vertical-fit').magnificPopup({
            type: 'image',
            mainClass: 'mfp-with-zoom',
            gallery: {
                enabled: true
            },

            zoom: {
                enabled: true,

                duration: 300, // duration of the effect, in milliseconds
                easing: 'ease-in-out', // CSS transition easing function

                opener: function (openerElement) {

                    return openerElement.is('img') ? openerElement : openerElement.find('img');
                }
            }

        });

        $('#user_list').select2({
            maximumInputLength: 20 // only allow terms up to 20 characters long
        });
    });
</script>
