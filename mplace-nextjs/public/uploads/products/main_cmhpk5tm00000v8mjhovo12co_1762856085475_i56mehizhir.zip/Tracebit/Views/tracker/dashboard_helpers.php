<?php
/**
 * Tracker Dashboard Helper Functions
 * Separating business logic from presentation for better maintainability
 */

namespace Tracebit\Helpers;

/**
 * Class to handle all dashboard data operations
 */
class TrackerDashboardHelper
{
    private static $instance = null;
    private $settings_model = null;
    private $attendance_model = null;
    private $employee_status_model = null;
    private $screenshots_model = null;

    private function __construct()
    {
        $this->initializeModels();
    }

    public static function getInstance()
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Initialize model instances
     */
    private function initializeModels()
    {
        try {
            if (class_exists("Tracebit\Models\Tracker_settings_model")) {
                $this->settings_model = model("Tracebit\Models\Tracker_settings_model");
            }
            if (class_exists("Tracebit\Models\Tracker_attendance_model")) {
                $this->attendance_model = model("Tracebit\Models\Tracker_attendance_model");
            }
            if (class_exists("Tracebit\Models\Employee_status_model")) {
                $this->employee_status_model = model("Tracebit\Models\Employee_status_model");
            }
            if (class_exists("Tracebit\Models\Screenshots_model")) {
                $this->screenshots_model = model("Tracebit\Models\Screenshots_model");
            }
        } catch (\Exception $e) {
            error_log("Failed to initialize tracker models: " . $e->getMessage());
        }
    }

    /**
     * Check if dashboard check-in feature is enabled
     */
    public function isDashboardCheckinEnabled()
    {
        static $dashboard_checkin_active = null;

        if ($dashboard_checkin_active === null) {
            $dashboard_checkin_active = true; // Default to true
           
            if ($this->settings_model) {
                try {
                    $setting_value = $this->settings_model->get_setting('dashboard_checkin');
                    error_log( print_r( "Setting value: " . $setting_value, true ) );
                    if ($setting_value !== null) {
                        $dashboard_checkin_active = $setting_value === '1' || $setting_value === 'true';
                    }
                } catch (\Exception $e) {
                    error_log("Failed to get dashboard_checkin_active setting: " . $e->getMessage());
                }
            }
        }

        return $dashboard_checkin_active;
    }

    /**
     * Get current date in user's timezone
     */
    public function getCurrentDate()
    {
        $originalTimezone = date_default_timezone_get();
        date_default_timezone_set('Asia/Dhaka'); // Set to local timezone
        $today = date('Y-m-d');
        date_default_timezone_set($originalTimezone); // Reset to original
        error_log( print_r( "Today's date: " . $today, true ) );
        return $today;
    }

    /**
     * Get current attendance status for user
     */
    public function getAttendanceStatus($user_id)
    {
        $result = [
            'status' => null,
            'is_checked_in' => false,
            'error_message' => '',
            'button_class' => 'attendance-button',
            'button_text' => 'Check In',
            'button_icon' => 'log-in',
            'status_text' => 'Not checked in'
        ];

        if (!$this->attendance_model) {
            $result['error_message'] = 'Attendance model not available. Please run database setup.';
            return $result;
        }

        try {
            $attendance_status = $this->attendance_model->get_current_status($user_id);
            $is_checked_in = $attendance_status ? true : false;

            $result['status'] = $attendance_status;
            $result['is_checked_in'] = $is_checked_in;
            $result['button_class'] = $is_checked_in ? 'attendance-button checked-in' : 'attendance-button';
            $result['button_text'] = $is_checked_in ? 'Check Out' : 'Check In';
            $result['button_icon'] = $is_checked_in ? 'log-out' : 'log-in';

            // Format check-in time safely
            if ($is_checked_in && $attendance_status && $attendance_status->inTime) {
                try {
                    $timestamp = $attendance_status->inTime / 1000; // Convert from milliseconds
                    $result['status_text'] = 'Checked in at ' . date('H:i:s', $timestamp);
                } catch (\Exception $e) {
                    $result['status_text'] = 'Currently checked in';
                }
            }
        } catch (\Exception $e) {
            $result['error_message'] = $e->getMessage();
            error_log("Failed to get current attendance status: " . $result['error_message']);

            // If table doesn't exist, show a different message
            if (strpos($result['error_message'], "doesn't exist") !== false) {
                $result['error_message'] = "Attendance table not found. Please run database setup.";
            }
        }

        return $result;
    }

    /**
     * Calculate today's total working hours
     */
    public function calculateWorkingHours($user_id)
    {
        $result = [
            'total_working_time' => '0h 0m',
            'total_working_seconds' => 0,
            'daily_target_hours' => 8.0
        ];

        try {
            // Get daily worked time target from settings
            if ($this->settings_model) {
                $daily_worked_time_setting = $this->settings_model->get_setting('daily_worked_time');
                if ($daily_worked_time_setting && is_numeric($daily_worked_time_setting)) {
                    $result['daily_target_hours'] = (float)$daily_worked_time_setting;
                }
            }

            // Check if we're in a test environment or if Database class exists
            if (!class_exists('Config\\Database')) {
                $result['total_working_time'] = 'Test Mode';
                return $result;
            }

            $db = \Config\Database::connect();
            $tracker_attendance_table = $db->prefixTable('tracker_attendance');

            // Use user's timezone for date calculation instead of server UTC
            $today = $this->getCurrentDate();

            // Get working hours using direct SQL query for consistency with other methods
            $sql = "SELECT
                        SUM(CASE
                            WHEN inTime IS NOT NULL AND outTime IS NOT NULL
                            THEN (outTime - inTime) / 1000
                            WHEN inTime IS NOT NULL AND outTime IS NULL
                            THEN (UNIX_TIMESTAMP() * 1000 - inTime) / 1000
                            ELSE 0
                        END) as total_seconds
                    FROM {$tracker_attendance_table}
                    WHERE user_id = ?
                    AND DATE(FROM_UNIXTIME(inTime / 1000)) = ?
                    AND deleted = 0
                    AND (isMinusBreak IS NULL OR isMinusBreak = 0)";

            $query = $db->query($sql, [$user_id, $today]);

            if ($query && $query_result = $query->getRow()) {
                $total_seconds = $query_result->total_seconds;
                if ($total_seconds !== null && $total_seconds > 0) {
                    $result['total_working_seconds'] = $total_seconds;

                    // Format the time
                    $hours = floor($total_seconds / 3600);
                    $minutes = floor(($total_seconds % 3600) / 60);
                    $result['total_working_time'] = $hours . 'h ' . $minutes . 'm';
                }
            }
        } catch (\Exception $e) {
            error_log("Failed to calculate total working time: " . $e->getMessage());
            $result['total_working_time'] = 'N/A';
        }

        return $result;
    }

    /**
     * Calculate time tracking chart data
     */
    public function calculateTimeTrackingChart($working_hours_data)
    {
        $worked_hours = $working_hours_data['total_working_seconds'] / 3600;
        $target_hours = $working_hours_data['daily_target_hours'];

        if ($worked_hours <= $target_hours) {
            // Still have time remaining
            return [
                'labels' => ['Worked', 'Remaining'],
                'values' => [round($worked_hours, 1), round($target_hours - $worked_hours, 1)],
                'colors' => ['#10b981', '#f1f5f9']
            ];
        } else {
            // Overtime situation
            return [
                'labels' => ['Target', 'Overtime'],
                'values' => [round($target_hours, 1), round($worked_hours - $target_hours, 1)],
                'colors' => ['#10b981', '#f59e0b']
            ];
        }
    }

    /**
     * Calculate productivity data from tracker_performance table
     */
    public function calculateProductivity($user_id)
    {
        $result = [
            'percentage' => 0,
            'display' => '0%',
            'chart_labels' => ['No Data', 'Unavailable'],
            'chart_values' => [1, 99],
            'chart_colors' => ['#94a3b8', '#f1f5f9']
        ];

        try {
            // Check if we're in a test environment or if Database class exists
            if (!class_exists('Config\\Database')) {
                $result['display'] = 'Test Mode';
                $result['chart_labels'] = ['Test', 'Environment'];
                return $result;
            }

            $db = \Config\Database::connect();
            $tracker_performance_table = $db->prefixTable('tracker_performance');

            // Use user's timezone for date calculation instead of server UTC
            $today = $this->getCurrentDate();

            $sql = "SELECT AVG(performance) as avg_performance
                    FROM {$tracker_performance_table}
                    WHERE user_id = ?
                    AND DATE(FROM_UNIXTIME(timestamp / 1000)) = ?
                    AND deleted = 0
                    AND performance > 0";

            $query = $db->query($sql, [$user_id, $today]);

            if ($query && $query_result = $query->getRow()) {
                $avg_performance = $query_result->avg_performance;
                if ($avg_performance !== null && $avg_performance > 0) {
                    $result['percentage'] = round($avg_performance, 1);
                    $result['display'] = $result['percentage'] . '%';

                    $unproductive_percentage = max(0, 100 - $result['percentage']);
                    $result['chart_labels'] = ['Productive', 'Less Productive'];
                    $result['chart_values'] = [$result['percentage'], $unproductive_percentage];
                    $result['chart_colors'] = ['#3b82f6', '#f1f5f9'];
                } else {
                    // No performance data available, check if user has active sessions
                    $tracker_attendance_table = $db->prefixTable('tracker_attendance');
                    $active_session_sql = "SELECT COUNT(*) as active_sessions
                                          FROM {$tracker_attendance_table}
                                          WHERE user_id = ?
                                          AND DATE(FROM_UNIXTIME(inTime / 1000)) = ?
                                          AND deleted = 0
                                          AND inTime IS NOT NULL
                                          AND outTime IS NULL";

                    $active_query = $db->query($active_session_sql, [$user_id, $today]);
                    $active_result = $active_query ? $active_query->getRow() : null;

                    if ($active_result && $active_result->active_sessions > 0) {
                        // User has active sessions but no performance data yet
                        $result['percentage'] = 0;
                        $result['display'] = 'Calculating...';
                        $result['chart_labels'] = ['In Progress', 'Pending'];
                        $result['chart_values'] = [50, 50];
                        $result['chart_colors'] = ['#fbbf24', '#f1f5f9'];
                    }
                }
            } else {
                // No performance data available, check if user has active sessions
                $tracker_attendance_table = $db->prefixTable('tracker_attendance');
                $active_session_sql = "SELECT COUNT(*) as active_sessions
                                      FROM {$tracker_attendance_table}
                                      WHERE user_id = ?
                                      AND DATE(FROM_UNIXTIME(inTime / 1000)) = ?
                                      AND deleted = 0
                                      AND inTime IS NOT NULL
                                      AND outTime IS NULL";

                $active_query = $db->query($active_session_sql, [$user_id, $today]);
                $active_result = $active_query ? $active_query->getRow() : null;

                if ($active_result && $active_result->active_sessions > 0) {
                    // User has active sessions but no performance data yet
                    $result['percentage'] = 0;
                    $result['display'] = 'Calculating...';
                    $result['chart_labels'] = ['In Progress', 'Pending'];
                    $result['chart_values'] = [50, 50];
                    $result['chart_colors'] = ['#fbbf24', '#f1f5f9'];
                }
            }
        } catch (\Exception $e) {
            error_log("Failed to calculate productivity: " . $e->getMessage());
            $result['display'] = 'N/A';
        }

        return $result;
    }

    /**
     * Calculate project time data from tracker_attendance table
     */
    public function calculateProjectTime($user_id)
    {
        $result = [
            'total_project_time' => '0m',
            'total_project_seconds' => 0,
            'chart_labels' => ['No Project Time', 'Available'],
            'chart_values' => [1, 99],
            'chart_colors' => ['#94a3b8', '#f1f5f9'],
            'projects' => []
        ];

        try {
            // Check if we're in a test environment or if Database class exists
            if (!class_exists('Config\\Database')) {
                $result['total_project_time'] = 'Test Mode';
                $result['chart_labels'] = ['Test', 'Environment'];
                return $result;
            }

            $db = \Config\Database::connect();
            $tracker_attendance_table = $db->prefixTable('tracker_attendance');
            $projects_table = $db->prefixTable('projects');
            $today = $this->getCurrentDate();

            // Get project time data for current user today
            $sql = "SELECT
                        ta.project,
                        p.title as project_name,
                        SUM(CASE
                            WHEN ta.inTime IS NOT NULL AND ta.outTime IS NOT NULL
                            THEN (ta.outTime - ta.inTime) / 1000
                            WHEN ta.inTime IS NOT NULL AND ta.outTime IS NULL
                            THEN (UNIX_TIMESTAMP() * 1000 - ta.inTime) / 1000
                            ELSE 0
                        END) as total_seconds
                    FROM {$tracker_attendance_table} ta
                    LEFT JOIN {$projects_table} p ON ta.project = p.id
                    WHERE ta.user_id = ?
                    AND DATE(FROM_UNIXTIME(ta.inTime / 1000)) = ?
                    AND ta.deleted = 0
                    AND ta.project IS NOT NULL
                    AND ta.project != ''
                    AND ta.project != '0'
                    AND ta.project NOT LIKE 'b-%'
                    AND ta.project NOT LIKE 'idle-%'
                    AND ta.project NOT LIKE 'manual-%'
                    AND (ta.isMinusBreak IS NULL OR ta.isMinusBreak = 0)
                    GROUP BY ta.project, p.title
                    ORDER BY total_seconds DESC";

            $query = $db->query($sql, [$user_id, $today]);

            if ($query && $projects = $query->getResult()) {
                $total_project_seconds = 0;
                $project_data = [];

                foreach ($projects as $project) {
                    // Additional PHP-side filtering for excluded projects
                    if ($project->total_seconds > 0 && !$this->shouldExcludeProjectFromTimeTracking($project->project)) {
                        $total_project_seconds += $project->total_seconds;
                        $project_data[] = [
                            'id' => $project->project,
                            'name' => $project->project_name ?? 'Unknown Project',
                            'seconds' => $project->total_seconds,
                            'formatted' => $this->formatTime($project->total_seconds)
                        ];
                    }
                }

                $result['total_project_seconds'] = $total_project_seconds;
                $result['projects'] = $project_data;

                // Format total time
                if ($total_project_seconds > 0) {
                    $result['total_project_time'] = $this->formatTime($total_project_seconds);

                    // Create chart data
                    if (count($project_data) > 0) {
                        $chart_labels = [];
                        $chart_values = [];
                        $chart_colors = [];

                        // Use predefined colors
                        $colors = ['#8b5cf6', '#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#06b6d4'];

                        foreach ($project_data as $index => $project) {
                            $chart_labels[] = $project['name'];
                            $chart_values[] = round($project['seconds'] / 3600, 1); // Convert to hours
                            $chart_colors[] = $colors[$index % count($colors)];
                        }

                        $result['chart_labels'] = $chart_labels;
                        $result['chart_values'] = $chart_values;
                        $result['chart_colors'] = $chart_colors;
                    }
                }
            }
        } catch (\Exception $e) {
            error_log("Failed to calculate project time: " . $e->getMessage());
            $result['total_project_time'] = 'N/A';
        }

        return $result;
    }

    /**
     * Calculate idle time data from tracker_attendance table
     * Only includes projects with IDs starting with 'idle-'
     * Creates comparison chart with daily worked hours
     */
    public function calculateIdleTime($user_id, $working_hours_data = null)
    {
        $result = [
            'total_idle_time' => '0m',
            'total_idle_seconds' => 0,
            'chart_labels' => ['No Idle Time', 'Available'],
            'chart_values' => [1, 99],
            'chart_colors' => ['#94a3b8', '#f1f5f9'],
            'idle_sessions' => []
        ];

        try {
            // Check if we're in a test environment or if Database class exists
            if (!class_exists('Config\\Database')) {
                $result['total_idle_time'] = 'Test Mode';
                $result['chart_labels'] = ['Test', 'Environment'];
                return $result;
            }

            $db = \Config\Database::connect();
            $tracker_attendance_table = $db->prefixTable('tracker_attendance');
            $projects_table = $db->prefixTable('projects');
            $today = $this->getCurrentDate();

            // Get idle time data for current user today - only projects starting with 'idle-'
            $sql = "SELECT
                        ta.project,
                        p.title as project_name,
                        SUM(CASE
                            WHEN ta.inTime IS NOT NULL AND ta.outTime IS NOT NULL
                            THEN (ta.outTime - ta.inTime) / 1000
                            WHEN ta.inTime IS NOT NULL AND ta.outTime IS NULL
                            THEN (UNIX_TIMESTAMP() * 1000 - ta.inTime) / 1000
                            ELSE 0
                        END) as total_seconds
                    FROM {$tracker_attendance_table} ta
                    LEFT JOIN {$projects_table} p ON ta.project = p.id
                    WHERE ta.user_id = ?
                    AND DATE(FROM_UNIXTIME(ta.inTime / 1000)) = ?
                    AND ta.deleted = 0
                    AND ta.project IS NOT NULL
                    AND ta.project != ''
                    AND ta.project != '0'
                    AND ta.project LIKE 'idle-%'
                    AND (ta.isMinusBreak IS NULL OR ta.isMinusBreak = 0)
                    GROUP BY ta.project, p.title
                    ORDER BY total_seconds DESC";

            $query = $db->query($sql, [$user_id, $today]);

            if ($query && $idle_sessions = $query->getResult()) {
                $total_idle_seconds = 0;
                $idle_data = [];

                foreach ($idle_sessions as $session) {
                    if ($session->total_seconds > 0) {
                        $total_idle_seconds += $session->total_seconds;
                        $idle_data[] = [
                            'id' => $session->project,
                            'name' => $session->project_name ?? 'Idle Session',
                            'seconds' => $session->total_seconds,
                            'formatted' => $this->formatTime($session->total_seconds)
                        ];
                    }
                }

                $result['total_idle_seconds'] = $total_idle_seconds;
                $result['idle_sessions'] = $idle_data;

                // Format total time
                if ($total_idle_seconds > 0) {
                    $result['total_idle_time'] = $this->formatTime($total_idle_seconds);
                }

                // Create comparison chart with working hours
                $working_seconds = 0;
                if ($working_hours_data && isset($working_hours_data['total_working_seconds'])) {
                    $working_seconds = $working_hours_data['total_working_seconds'];
                }

                // Calculate productive time (working time minus idle time)
                $productive_seconds = max(0, $working_seconds - $total_idle_seconds);

                if ($working_seconds > 0 || $total_idle_seconds > 0) {
                    $idle_hours = round($total_idle_seconds / 3600, 1);
                    $productive_hours = round($productive_seconds / 3600, 1);

                    if ($total_idle_seconds > 0 && $productive_seconds > 0) {
                        // Both idle and productive time
                        $result['chart_labels'] = ['Productive Time', 'Idle Time'];
                        $result['chart_values'] = [$productive_hours, $idle_hours];
                        $result['chart_colors'] = ['#10b981', '#ef4444']; // Green for productive, red for idle
                    } else if ($total_idle_seconds > 0) {
                        // Only idle time
                        $result['chart_labels'] = ['Idle Time', 'No Productive Time'];
                        $result['chart_values'] = [$idle_hours, 0.1]; // Small value to show in chart
                        $result['chart_colors'] = ['#ef4444', '#f1f5f9']; // Red for idle, light gray for empty
                    } else if ($productive_seconds > 0) {
                        // Only productive time
                        $result['chart_labels'] = ['Productive Time', 'No Idle Time'];
                        $result['chart_values'] = [$productive_hours, 0.1]; // Small value to show in chart
                        $result['chart_colors'] = ['#10b981', '#f1f5f9'];
                    }
                }
            }
        } catch (\Exception $e) {
            error_log("Failed to calculate idle time: " . $e->getMessage());
            $result['total_idle_time'] = 'N/A';
        }

        return $result;
    }

    /**
     * Calculate manual time data from tracker_attendance table
     * Only includes projects with IDs starting with 'manual-'
     * Creates comparison chart with daily worked hours
     */
    public function calculateManualTime($user_id, $working_hours_data = null)
    {
        $result = [
            'total_manual_time' => '0m',
            'total_manual_seconds' => 0,
            'chart_labels' => ['No Manual Time', 'Available'],
            'chart_values' => [1, 99],
            'chart_colors' => ['#94a3b8', '#f1f5f9'],
            'manual_sessions' => []
        ];

        try {
            // Check if we're in a test environment or if Database class exists
            if (!class_exists('Config\\Database')) {
                $result['total_manual_time'] = 'Test Mode';
                $result['chart_labels'] = ['Test', 'Environment'];
                return $result;
            }

            $db = \Config\Database::connect();
            $tracker_attendance_table = $db->prefixTable('tracker_attendance');
            $projects_table = $db->prefixTable('projects');
            $today = $this->getCurrentDate();

            // Get manual time data for current user today - only projects starting with 'manual-'
            $sql = "SELECT
                        ta.project,
                        p.title as project_name,
                        SUM(CASE
                            WHEN ta.inTime IS NOT NULL AND ta.outTime IS NOT NULL
                            THEN (ta.outTime - ta.inTime) / 1000
                            WHEN ta.inTime IS NOT NULL AND ta.outTime IS NULL
                            THEN (UNIX_TIMESTAMP() * 1000 - ta.inTime) / 1000
                            ELSE 0
                        END) as total_seconds
                    FROM {$tracker_attendance_table} ta
                    LEFT JOIN {$projects_table} p ON ta.project = p.id
                    WHERE ta.user_id = ?
                    AND DATE(FROM_UNIXTIME(ta.inTime / 1000)) = ?
                    AND ta.deleted = 0
                    AND ta.project IS NOT NULL
                    AND ta.project != ''
                    AND ta.project != '0'
                    AND ta.project LIKE 'manual-%'
                    AND (ta.isMinusBreak IS NULL OR ta.isMinusBreak = 0)
                    GROUP BY ta.project, p.title
                    ORDER BY total_seconds DESC";

            $query = $db->query($sql, [$user_id, $today]);

            if ($query && $manual_sessions = $query->getResult()) {
                $total_manual_seconds = 0;
                $manual_data = [];

                foreach ($manual_sessions as $session) {
                    if ($session->total_seconds > 0) {
                        $total_manual_seconds += $session->total_seconds;
                        $manual_data[] = [
                            'id' => $session->project,
                            'name' => $session->project_name ?? 'Manual Entry',
                            'seconds' => $session->total_seconds,
                            'formatted' => $this->formatTime($session->total_seconds)
                        ];
                    }
                }

                $result['total_manual_seconds'] = $total_manual_seconds;
                $result['manual_sessions'] = $manual_data;

                // Format total time
                if ($total_manual_seconds > 0) {
                    $result['total_manual_time'] = $this->formatTime($total_manual_seconds);
                }

                // Create comparison chart with working hours
                $working_seconds = 0;
                if ($working_hours_data && isset($working_hours_data['total_working_seconds'])) {
                    $working_seconds = $working_hours_data['total_working_seconds'];
                }

                // Calculate automatic time (working time minus manual time)
                $automatic_seconds = max(0, $working_seconds - $total_manual_seconds);

                if ($working_seconds > 0 || $total_manual_seconds > 0) {
                    $manual_hours = round($total_manual_seconds / 3600, 1);
                    $automatic_hours = round($automatic_seconds / 3600, 1);

                    if ($total_manual_seconds > 0 && $automatic_seconds > 0) {
                        // Both manual and automatic time
                        $result['chart_labels'] = ['Automatic Time', 'Manual Time'];
                        $result['chart_values'] = [$automatic_hours, $manual_hours];
                        $result['chart_colors'] = ['#06b6d4', '#f59e0b']; // Cyan for automatic, amber for manual
                    } else if ($total_manual_seconds > 0) {
                        // Only manual time
                        $result['chart_labels'] = ['Manual Time', 'No Automatic Time'];
                        $result['chart_values'] = [$manual_hours, 0.1]; // Small value to show in chart
                        $result['chart_colors'] = ['#f59e0b', '#f1f5f9']; // Amber for manual
                    } else if ($automatic_seconds > 0) {
                        // Only automatic time
                        $result['chart_labels'] = ['Automatic Time', 'No Manual Time'];
                        $result['chart_values'] = [$automatic_hours, 0.1]; // Small value to show in chart
                        $result['chart_colors'] = ['#06b6d4', '#f1f5f9']; // Cyan for automatic
                    }
                }
            }
        } catch (\Exception $e) {
            error_log("Failed to calculate manual time: " . $e->getMessage());
            $result['total_manual_time'] = 'N/A';
        }

        return $result;
    }

    /**
     * Calculate away time (break time) data from tracker_attendance table
     * Only includes projects with IDs starting with 'b-'
     * Creates comparison chart with daily worked hours
     */
    public function calculateAwayTime($user_id, $working_hours_data = null)
    {
        $result = [
            'total_away_time' => '0m',
            'total_away_seconds' => 0,
            'chart_labels' => ['No Away Time', 'Available'],
            'chart_values' => [1, 99],
            'chart_colors' => ['#94a3b8', '#f1f5f9'],
            'away_sessions' => []
        ];

        try {
            // Check if we're in a test environment or if Database class exists
            if (!class_exists('Config\\Database')) {
                $result['total_away_time'] = 'Test Mode';
                $result['chart_labels'] = ['Test', 'Environment'];
                return $result;
            }

            $db = \Config\Database::connect();
            $tracker_attendance_table = $db->prefixTable('tracker_attendance');
            $projects_table = $db->prefixTable('projects');
            $today = $this->getCurrentDate();

            // Get away time (break time) data for current user today - only projects starting with 'b-'
            $sql = "SELECT
                        ta.project,
                        p.title as project_name,
                        SUM(CASE
                            WHEN ta.inTime IS NOT NULL AND ta.outTime IS NOT NULL
                            THEN (ta.outTime - ta.inTime) / 1000
                            WHEN ta.inTime IS NOT NULL AND ta.outTime IS NULL
                            THEN (UNIX_TIMESTAMP() * 1000 - ta.inTime) / 1000
                            ELSE 0
                        END) as total_seconds
                    FROM {$tracker_attendance_table} ta
                    LEFT JOIN {$projects_table} p ON ta.project = p.id
                    WHERE ta.user_id = ?
                    AND DATE(FROM_UNIXTIME(ta.inTime / 1000)) = ?
                    AND ta.deleted = 0
                    AND ta.project IS NOT NULL
                    AND ta.project != ''
                    AND ta.project != '0'
                    AND ta.project LIKE 'b-%'
                    AND (ta.isMinusBreak IS NULL OR ta.isMinusBreak = 0)
                    GROUP BY ta.project, p.title
                    ORDER BY total_seconds DESC";

            $query = $db->query($sql, [$user_id, $today]);

            if ($query && $away_sessions = $query->getResult()) {
                $total_away_seconds = 0;
                $away_data = [];

                foreach ($away_sessions as $session) {
                    if ($session->total_seconds > 0) {
                        $total_away_seconds += $session->total_seconds;
                        $away_data[] = [
                            'id' => $session->project,
                            'name' => $session->project_name ?? 'Break Time',
                            'seconds' => $session->total_seconds,
                            'formatted' => $this->formatTime($session->total_seconds)
                        ];
                    }
                }

                $result['total_away_seconds'] = $total_away_seconds;
                $result['away_sessions'] = $away_data;

                // Format total time
                if ($total_away_seconds > 0) {
                    $result['total_away_time'] = $this->formatTime($total_away_seconds);
                }

                // Create comparison chart with working hours
                $working_seconds = 0;
                if ($working_hours_data && isset($working_hours_data['total_working_seconds'])) {
                    $working_seconds = $working_hours_data['total_working_seconds'];
                }

                // Calculate present time (working time minus away time)
                $present_seconds = max(0, $working_seconds - $total_away_seconds);

                if ($working_seconds > 0 || $total_away_seconds > 0) {
                    $away_hours = round($total_away_seconds / 3600, 1);
                    $present_hours = round($present_seconds / 3600, 1);

                    if ($total_away_seconds > 0 && $present_seconds > 0) {
                        // Both present and away time
                        $result['chart_labels'] = ['Present Time', 'Away Time'];
                        $result['chart_values'] = [$present_hours, $away_hours];
                        $result['chart_colors'] = ['#10b981', '#f59e0b']; // Green for present, amber for away
                    } else if ($total_away_seconds > 0) {
                        // Only away time
                        $result['chart_labels'] = ['Away Time', 'No Present Time'];
                        $result['chart_values'] = [$away_hours, 0.1]; // Small value to show in chart
                        $result['chart_colors'] = ['#f59e0b', '#f1f5f9']; // Amber for away
                    } else if ($present_seconds > 0) {
                        // Only present time
                        $result['chart_labels'] = ['Present Time', 'No Away Time'];
                        $result['chart_values'] = [$present_hours, 0.1]; // Small value to show in chart
                        $result['chart_colors'] = ['#10b981', '#f1f5f9']; // Green for present
                    }
                }
            }
        } catch (\Exception $e) {
            error_log("Failed to calculate away time: " . $e->getMessage());
            $result['total_away_time'] = 'N/A';
        }

        return $result;
    }

    /**
     * Get team members activity status
     */
    public function getTeamMembersStatus()
    {
        try {

            // Get team members with their current status from tracker_status table
            $db = \Config\Database::connect();

            // Get current date in user's timezone
            $currentDate = $this->getCurrentDate();

            // Get table names with proper prefixes
            $users_table = $db->prefixTable('users');
            $leave_applications_table = $db->prefixTable('leave_applications');

            // Check if leave_applications table exists
            $has_leave_table = $db->tableExists($leave_applications_table);
            if (!$has_leave_table) {
                error_log("leave_applications table not found: " . $leave_applications_table);
            }

            // Check for tracker_status table with and without prefix
            $tracker_status_table = $db->prefixTable('tracker_status');
            // Build SQL query based on available table
            if (strpos($tracker_status_table, 'tracker_attendance') !== false) {
                // Using tracker_attendance table - different column structure
                if ($has_leave_table) {
                    $sql = "
                        SELECT
                            u.id as user_id,
                            u.first_name,
                            u.last_name,
                            CONCAT(u.first_name, ' ', u.last_name) as employee_name,
                            u.image as employee_image,
                            CASE
                                WHEN ta.inTime IS NOT NULL AND ta.outTime IS NULL THEN 'checked_in'
                                WHEN ta.inTime IS NOT NULL AND ta.outTime IS NOT NULL THEN 'checked_out'
                                ELSE 'idle'
                            END as attendance_status,
                            COALESCE(ta.inTime, ta.outTime) as last_status_update,
                            DATE(FROM_UNIXTIME(COALESCE(ta.inTime, ta.outTime) / 1000)) as attendance_date,
                            CASE
                                WHEN la.id IS NOT NULL THEN la.id
                                ELSE NULL
                            END as applicant_id
                        FROM {$users_table} u
                        LEFT JOIN {$tracker_status_table} ta ON u.id = ta.user_id
                            AND DATE(last_activity) = ?
                        LEFT JOIN {$leave_applications_table} la ON u.id = la.applicant_id
                            AND ? BETWEEN la.start_date AND la.end_date
                            AND la.status = 'approved'
                        WHERE u.deleted = 0
                            AND u.status = 'active'
                            AND u.user_type = 'staff'
                        ORDER BY u.first_name, u.last_name
                    ";
                } else {
                    $sql = "
                        SELECT
                            u.id as user_id,
                            u.first_name,
                            u.last_name,
                            CONCAT(u.first_name, ' ', u.last_name) as employee_name,
                            u.image as employee_image,
                            CASE
                                WHEN ta.inTime IS NOT NULL AND ta.outTime IS NULL THEN 'checked_in'
                                WHEN ta.inTime IS NOT NULL AND ta.outTime IS NOT NULL THEN 'checked_out'
                                ELSE 'idle'
                            END as attendance_status,
                            COALESCE(ta.inTime, ta.outTime) as last_status_update,
                            DATE(FROM_UNIXTIME(COALESCE(ta.inTime, ta.outTime) / 1000)) as attendance_date,
                            NULL as applicant_id
                        FROM {$users_table} u
                        LEFT JOIN {$tracker_status_table} ta ON u.id = ta.user_id
                            AND DATE(last_activity) = ?
                        WHERE u.deleted = 0
                            AND u.status = 'active'
                            AND u.user_type = 'staff'
                        ORDER BY u.first_name, u.last_name
                    ";
                }
            } else {
                // Using tracker_status table - original structure
                if ($has_leave_table) {
                    $sql = "
                        SELECT
                            u.id as user_id,
                            u.first_name,
                            u.last_name,
                            CONCAT(u.first_name, ' ', u.last_name) as employee_name,
                            u.image as employee_image,
                            ts.status as attendance_status,
                            ts.last_activity as last_status_update,
                            DATE(ts.last_activity) as attendance_date,
                            CASE
                                WHEN la.id IS NOT NULL THEN la.id
                                ELSE NULL
                            END as applicant_id
                        FROM {$users_table} u
                        LEFT JOIN {$tracker_status_table} ts ON u.id = ts.user_id
                            AND DATE(ts.last_activity) = ?
                        LEFT JOIN {$leave_applications_table} la ON u.id = la.applicant_id
                            AND ? BETWEEN la.start_date AND la.end_date
                            AND la.status = 'approved'
                        WHERE u.deleted = 0
                            AND u.status = 'active'
                            AND u.user_type = 'staff'
                        ORDER BY u.first_name, u.last_name
                    ";
                } else {
                    $sql = "
                        SELECT
                            u.id as user_id,
                            u.first_name,
                            u.last_name,
                            CONCAT(u.first_name, ' ', u.last_name) as employee_name,
                            u.image as employee_image,
                            ts.status as attendance_status,
                            ts.last_activity as last_status_update,
                            DATE(ts.last_activity) as attendance_date,
                            NULL as applicant_id
                        FROM {$users_table} u
                        LEFT JOIN {$tracker_status_table} ts ON u.id = ts.user_id
                            AND DATE(ts.last_activity) = ?
                        WHERE u.deleted = 0
                            AND u.status = 'active'
                            AND u.user_type = 'staff'
                        ORDER BY u.first_name, u.last_name
                    ";
                }
            }

            // Execute query with error handling
            try {

                // Prepare parameters based on query structure
                $params = [];
                if (strpos($tracker_status_table, 'tracker_attendance') !== false) {
                    // tracker_attendance table queries
                    if ($has_leave_table) {
                        $params = [$currentDate, $currentDate];
                    } else {
                        $params = [$currentDate];
                    }
                } else {
                    // tracker_status table queries
                    if ($has_leave_table) {
                        $params = [$currentDate, $currentDate];
                    } else {
                        $params = [$currentDate];
                    }
                }

                $query = $db->query($sql, $params);

                if (!$query) {
                    $error = $db->error();
                    error_log("SQL query failed with error: " . print_r($error, true));
                    return $this->getDemoTeamMembers();
                }

                $team_members = $query->getResult();
            } catch (\Exception $e) {
                return $this->getDemoTeamMembers();
            }

            // If no team members found, return demo data
            if (empty($team_members)) {
                return $this->getDemoTeamMembers();
            }

            return $team_members;

        } catch (\Exception $e) {
            // Return demo data when there's an error
            return $this->getDemoTeamMembers();
        }
    }

    /**
     * Get latest screenshots for dashboard
     */
    public function getLatestScreenshots($user_id, $limit = 4)
    {
        try {
            // Initialize screenshots model if not already done
            if (!$this->screenshots_model) {
                if (class_exists("Tracebit\Models\Screenshots_model")) {
                    $this->screenshots_model = model("Tracebit\Models\Screenshots_model");
                } else {
                    // Return demo data when model is not available
                    return $this->getDemoScreenshots($limit);
                }
            }

            $screenshot_data = array(
                'user_id' => $user_id,
                'limit' => $limit
            );

            $screenshots = $this->screenshots_model->getLatestScreenshots($screenshot_data);
            return $screenshots === false ? [] : $screenshots;
        } catch (\Exception $e) {
            error_log("Failed to get screenshots: " . $e->getMessage());
            // Return demo data when there's an error
            return $this->getDemoScreenshots($limit);
        }
    }

    /**
     * Get demo team members data when model is not available
     */
    private function getDemoTeamMembers()
    {
        return [
            (object)[
                'user_id' => 1,
                'first_name' => 'John',
                'last_name' => 'Doe',
                'employee_name' => 'John Doe',
                'employee_image' => '',
                'attendance_status' => 'active',
                'last_status_update' => date('Y-m-d H:i:s'),
                'attendance_date' => $this->getCurrentDate(),
                'applicant_id' => null
            ],
            (object)[
                'user_id' => 2,
                'first_name' => 'Jane',
                'last_name' => 'Smith',
                'employee_name' => 'Jane Smith',
                'employee_image' => '',
                'attendance_status' => 'inactive',
                'last_status_update' => date('Y-m-d H:i:s', time() - 3600),
                'attendance_date' => $this->getCurrentDate(),
                'applicant_id' => null
            ],
            (object)[
                'user_id' => 3,
                'first_name' => 'Mike',
                'last_name' => 'Johnson',
                'employee_name' => 'Mike Johnson',
                'employee_image' => '',
                'attendance_status' => 'inactive',
                'last_status_update' => date('Y-m-d H:i:s', time() - 86400),
                'attendance_date' => $this->getCurrentDate(),
                'applicant_id' => 1 // This will make status 'leave'
            ],
            (object)[
                'user_id' => 4,
                'first_name' => 'Sarah',
                'last_name' => 'Wilson',
                'employee_name' => 'Sarah Wilson',
                'employee_image' => '',
                'attendance_status' => null, // No status set, will be 'absent'
                'last_status_update' => null,
                'attendance_date' => null,
                'applicant_id' => null
            ]
        ];
    }

    /**
     * Get demo screenshots data when model is not available
     */
    private function getDemoScreenshots($limit = 4)
    {
        $demo_screenshots = [];
        $base_time = time();

        for ($i = 0; $i < $limit; $i++) {
            $demo_screenshots[] = (object)[
                'path' => 'plugins/Tracebit/screenshots/placeholder.png',
                'created_at' => date('Y-m-d H:i:s', $base_time - ($i * 3600)) // Each hour back
            ];
        }

        return $demo_screenshots;
    }

    /**
     * Helper method to format time in seconds to readable format
     */
    public function formatTime($seconds)
    {
        if ($seconds < 60) {
            return '0m';
        }

        $hours = floor($seconds / 3600);
        $minutes = floor(($seconds % 3600) / 60);

        if ($hours > 0) {
            return $hours . 'h ' . $minutes . 'm';
        } else {
            return $minutes . 'm';
        }
    }

    /**
     * Check if project should be excluded from time counting
     * Projects with IDs starting with 'b-', 'idle-', or 'manual-' should be excluded
     */
    protected function shouldExcludeProjectFromTimeTracking($projectId)
    {
        if (empty($projectId) || $projectId === '0' || $projectId === 0) {
            return true;
        }

        $projectIdStr = strtolower((string)$projectId);
        $excludedPrefixes = ['b-', 'idle-', 'manual-'];

        foreach ($excludedPrefixes as $prefix) {
            if (strpos($projectIdStr, $prefix) === 0) {
                return true;
            }
        }

        return false;
    }

    /**
     * Calculate project recap with time tracking
     * @param int $user_id User ID
     * @param string $filter Filter type: 'weekly' or 'monthly'
     * @return array Project recap data
     */
    public function calculateProjectRecap($user_id, $filter = 'weekly')
    {
        $result = [
            'total_project_time' => '0m',
            'total_project_seconds' => 0,
            'chart_labels' => ['No Project Time', 'Available'],
            'chart_values' => [1, 99],
            'chart_colors' => ['#94a3b8', '#f1f5f9'],
            'projects' => [],
            'filter' => $filter
        ];

        try {
            // Check if we're in a test environment or if Database class exists
            if (!class_exists('Config\\Database')) {
                $result['total_project_time'] = 'Test Mode';
                $result['chart_labels'] = ['Test', 'Environment'];
                return $result;
            }

            $db = \Config\Database::connect();
            $tracker_attendance_table = $db->prefixTable('tracker_attendance');
            $projects_table = $db->prefixTable('projects');
            $project_members_table = $db->prefixTable('project_members');

            // Calculate date range based on filter
            $today = $this->getCurrentDate();
            if ($filter === 'weekly') {
                // Get start of current week (Monday)
                $startDate = date('Y-m-d', strtotime('monday this week', strtotime($today)));
                $endDate = $today;
            } else {
                // Monthly filter - get start of current month
                $startDate = date('Y-m-01', strtotime($today));
                $endDate = $today;
            }

            // Get project time data for current user within date range
            // Only include projects with pure numeric IDs and where user is a member
            $sql = "SELECT
                        ta.project,
                        p.title as project_title,
                        p.description as project_description,
                        p.status as project_status,
                        pm.is_leader as is_project_leader,
                        SUM(CASE
                            WHEN ta.inTime IS NOT NULL AND ta.outTime IS NOT NULL
                            THEN (ta.outTime - ta.inTime) / 1000
                            WHEN ta.inTime IS NOT NULL AND ta.outTime IS NULL
                            THEN (UNIX_TIMESTAMP() * 1000 - ta.inTime) / 1000
                            ELSE 0
                        END) as total_seconds,
                        COUNT(DISTINCT DATE(FROM_UNIXTIME(ta.inTime / 1000))) as active_days
                    FROM {$tracker_attendance_table} ta
                    LEFT JOIN {$projects_table} p ON ta.project = p.id
                    LEFT JOIN {$project_members_table} pm ON p.id = pm.project_id AND pm.user_id = ?
                    WHERE ta.user_id = ?
                    AND DATE(FROM_UNIXTIME(ta.inTime / 1000)) >= ?
                    AND DATE(FROM_UNIXTIME(ta.inTime / 1000)) <= ?
                    AND ta.deleted = 0
                    AND ta.project IS NOT NULL
                    AND ta.project != ''
                    AND ta.project != '0'
                    AND ta.project REGEXP '^[0-9]+$'
                    AND (ta.isMinusBreak IS NULL OR ta.isMinusBreak = 0)
                    AND (pm.id IS NOT NULL OR p.created_by = ?)
                    AND (pm.deleted IS NULL OR pm.deleted = 0)
                    AND (p.deleted IS NULL OR p.deleted = 0)
                    GROUP BY ta.project, p.title, p.description, p.status, pm.is_leader
                    ORDER BY total_seconds DESC";

            $query = $db->query($sql, [$user_id, $user_id, $startDate, $endDate, $user_id]);

            if ($query && $projects = $query->getResult()) {
                $total_project_seconds = 0;
                $project_data = [];

                foreach ($projects as $project) {
                    if ($project->total_seconds > 0) {
                        $total_project_seconds += $project->total_seconds;
                        $project_data[] = [
                            'id' => $project->project,
                            'title' => $project->project_title ?? 'Project #' . $project->project,
                            'description' => $project->project_description ?? '',
                            'status' => $project->project_status ?? 'active',
                            'is_leader' => $project->is_project_leader ?? false,
                            'seconds' => $project->total_seconds,
                            'formatted_time' => $this->formatTime($project->total_seconds),
                            'active_days' => $project->active_days
                        ];
                    }
                }

                $result['total_project_seconds'] = $total_project_seconds;
                $result['projects'] = $project_data;
                $result['date_range'] = [
                    'start' => $startDate,
                    'end' => $endDate,
                    'filter' => $filter
                ];

                // Format total time
                if ($total_project_seconds > 0) {
                    $result['total_project_time'] = $this->formatTime($total_project_seconds);

                    // Create chart data - show top 5 projects
                    if (count($project_data) > 0) {
                        $chart_labels = [];
                        $chart_values = [];
                        $chart_colors = [];

                        // Use predefined colors
                        $colors = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#06b6d4', '#f97316', '#ec4899'];
                        $max_projects = min(5, count($project_data));

                        for ($i = 0; $i < $max_projects; $i++) {
                            $project = $project_data[$i];
                            $chart_labels[] = $project['title'];
                            $chart_values[] = round($project['seconds'] / 3600, 1); // Convert to hours
                            $chart_colors[] = $colors[$i % count($colors)];
                        }

                        // If there are more than 5 projects, group the rest as "Others"
                        if (count($project_data) > 5) {
                            $others_seconds = 0;
                            for ($i = 5; $i < count($project_data); $i++) {
                                $others_seconds += $project_data[$i]['seconds'];
                            }
                            if ($others_seconds > 0) {
                                $chart_labels[] = 'Others (' . (count($project_data) - 5) . ' projects)';
                                $chart_values[] = round($others_seconds / 3600, 1);
                                $chart_colors[] = '#94a3b8';
                            }
                        }

                        $result['chart_labels'] = $chart_labels;
                        $result['chart_values'] = $chart_values;
                        $result['chart_colors'] = $chart_colors;
                    }
                }
            }
        } catch (\Exception $e) {
            error_log("Failed to calculate project recap: " . $e->getMessage());
            $result['total_project_time'] = 'N/A';
            $result['error'] = $e->getMessage();
        }

        return $result;
    }

    /**
     * Get all dashboard data in one call
     */
    public function getDashboardData($user_id)
    {
        $data = [
            'dashboard_checkin_active' => $this->isDashboardCheckinEnabled(),
            'attendance' => $this->getAttendanceStatus($user_id),
            'working_hours' => $this->calculateWorkingHours($user_id),
            'productivity' => $this->calculateProductivity($user_id),
            'project_time' => $this->calculateProjectTime($user_id),
            'project_recap' => $this->calculateProjectRecap($user_id, 'weekly') // Default to weekly
        ];

        // Calculate idle time with working hours data for comparison
        $data['idle_time'] = $this->calculateIdleTime($user_id, $data['working_hours']);

        // Calculate manual time with working hours data for comparison
        $data['manual_time'] = $this->calculateManualTime($user_id, $data['working_hours']);

        // Calculate away time (break time) with working hours data for comparison
        $data['away_time'] = $this->calculateAwayTime($user_id, $data['working_hours']);

        // Add chart data
        $data['time_chart'] = $this->calculateTimeTrackingChart($data['working_hours']);

        // Add team members and screenshots data
        $data['team_members'] = $this->getTeamMembersStatus();
        $data['screenshots'] = $this->getLatestScreenshots($user_id, 4);

        return $data;
    }

    /**
     * Calculate attendance recap for current month
     * @param int $user_id User ID
     * @return array Attendance recap data
     */
    public function calculateAttendanceRecap($user_id)
    {
        try {
            $db = \Config\Database::connect();

            // Get current month dates using the same timezone logic as getCurrentDate()
            $originalTimezone = date_default_timezone_get();
            date_default_timezone_set('Asia/Dhaka'); // Set to local timezone
            
            $currentMonth = date('Y-m');
            $startDate = $currentMonth . '-01';
            $endDate = date('Y-m-d'); // Use current date instead of end of month for current calculations
            $totalDaysInMonth = date('t');
            $currentDayOfMonth = date('j'); // Current day of the month
            
            // Reset timezone
            date_default_timezone_set($originalTimezone);
            


            // Get settings for calculations
            $settings = [];
            if ($this->settings_model) {
                $working_hours_start = $this->settings_model->get_setting('working_hours_start') ?: '09:00';
                $weekend_days_setting = $this->settings_model->get_setting('weekend_days') ?: 'Friday,Saturday';

                // Convert day names to numeric values (0=Sunday, 1=Monday, etc.)
                $day_name_to_number = [
                    'sunday' => 0, 'monday' => 1, 'tuesday' => 2, 'wednesday' => 3,
                    'thursday' => 4, 'friday' => 5, 'saturday' => 6
                ];

                $weekend_days = [];
                $day_names = explode(',', strtolower($weekend_days_setting));
                foreach ($day_names as $day_name) {
                    $day_name = trim($day_name);
                    if (isset($day_name_to_number[$day_name])) {
                        $weekend_days[] = $day_name_to_number[$day_name];
                    } elseif (is_numeric($day_name) && $day_name >= 0 && $day_name <= 6) {
                        // Support numeric format as well (0-6)
                        $weekend_days[] = (int)$day_name;
                    }
                }

                // Default to Friday,Saturday if no valid days found
                if (empty($weekend_days)) {
                    $weekend_days = [5, 6]; // Friday, Saturday
                }

                $settings = [
                    'working_hours_start' => $working_hours_start,
                    'weekend_days' => $weekend_days
                ];
            } else {
                $settings = [
                    'working_hours_start' => '09:00',
                    'weekend_days' => [5, 6] // Friday, Saturday (default)
                ];
            }

            // Get all days in current month up to today
            $workableDays = 0;
            $weekendDays = 0;
            $workableDatesArray = []; // Store all workable dates for comparison

            // Calculate workable days only up to current date (excluding weekends)
            for ($day = 1; $day <= $currentDayOfMonth; $day++) {
                $date = $currentMonth . '-' . str_pad($day, 2, '0', STR_PAD_LEFT);
                $dayOfWeek = date('w', strtotime($date));

                if (in_array($dayOfWeek, $settings['weekend_days'])) {
                    $weekendDays++;
                } else {
                    $workableDays++;
                    $workableDatesArray[] = $date; // Store workable date
                }
            }

            // Get holidays for current month up to today
            $holidaysQuery = $db->query("
                SELECT DATE(start_date) as holiday_date
                FROM " . $db->prefixTable('tracker_holidays') . "
                WHERE deleted = 0
                AND start_date >= ?
                AND start_date <= ?
            ", [$startDate, $endDate]);

            $holidayDays = 0;
            $holidayDatesArray = [];
            if ($holidaysQuery) {
                $holidayResults = $holidaysQuery->getResult();
                foreach ($holidayResults as $holiday) {
                    $holidayDatesArray[] = $holiday->holiday_date;
                }
                $holidayDays = count($holidayDatesArray);
            }

            // Remove holidays from workable days
            $workableDatesArray = array_diff($workableDatesArray, $holidayDatesArray);
            $workableDays = max(0, $workableDays - $holidayDays);

            // Get leave days for current month up to today (only on workable days)
            $leaveQuery = $db->query("
                SELECT DISTINCT DATE(start_date) as leave_date
                FROM " . $db->prefixTable('leave_applications') . "
                WHERE deleted = 0
                AND status = 'approved'
                AND applicant_id = ?
                AND start_date >= ?
                AND start_date <= ?
            ", [$user_id, $startDate, $endDate]);

            $leaveDays = 0;
            $leaveDatesArray = [];
            if ($leaveQuery) {
                $leaveResults = $leaveQuery->getResult();
                foreach ($leaveResults as $leave) {
                    // Only count leave days that fall on workable days
                    if (in_array($leave->leave_date, $workableDatesArray)) {
                        $leaveDatesArray[] = $leave->leave_date;
                    }
                }
                $leaveDays = count($leaveDatesArray);
            }

            // Get attendance data for current month up to today (only on workable days)
            $attendanceQuery = $db->query("
                SELECT
                    DATE(FROM_UNIXTIME(inTime / 1000)) as attendance_date,
                    MIN(TIME(FROM_UNIXTIME(inTime / 1000))) as first_activity
                FROM " . $db->prefixTable('tracker_attendance') . "
                WHERE user_id = ?
                AND DATE(FROM_UNIXTIME(inTime / 1000)) >= ?
                AND DATE(FROM_UNIXTIME(inTime / 1000)) <= ?
                AND deleted = 0
                AND inTime IS NOT NULL
                GROUP BY DATE(FROM_UNIXTIME(inTime / 1000))
                ORDER BY attendance_date
            ", [$user_id, $startDate, $endDate]);



            $attendanceDays = [];
            $lateArrivals = 0;

            if ($attendanceQuery) {
                $attendanceResults = $attendanceQuery->getResult();
                foreach ($attendanceResults as $attendance) {
                    // Only count attendance that falls on workable days (excluding weekends, holidays, and leave days)
                    if (in_array($attendance->attendance_date, $workableDatesArray) &&
                        !in_array($attendance->attendance_date, $leaveDatesArray)) {

                        $attendanceDays[] = $attendance->attendance_date;

                        // Check if late (first activity after working hours start)
                        if ($attendance->first_activity > $settings['working_hours_start']) {
                            $lateArrivals++;
                        }
                    }
                }
            }

            // Calculate final numbers based on workable days only
            $presentDays = count($attendanceDays);
            $absentDays = max(0, $workableDays - $presentDays - $leaveDays);

            // Prepare chart data
            $chartData = [
                'labels' => ['Present', 'Late', 'Absent', 'Leave'],
                'values' => [$presentDays - $lateArrivals, $lateArrivals, $absentDays, $leaveDays],
                'colors' => ['#28a745', '#ffb822', '#dc3545', '#38a4f8']
            ];

            return [
                'present_days' => $presentDays,
                'absent_days' => $absentDays,
                'late_arrivals' => $lateArrivals,
                'leave_days' => $leaveDays,
                'workable_days' => $workableDays,
                'total_days' => $totalDaysInMonth,
                'current_day' => $currentDayOfMonth,
                'weekend_days' => $weekendDays,
                'holiday_days' => $holidayDays,
                'chart_data' => $chartData
            ];

        } catch (\Exception $e) {

            // Return default data on error
            return [
                'present_days' => 0,
                'absent_days' => 0,
                'late_arrivals' => 0,
                'leave_days' => 0,
                'workable_days' => 0,
                'total_days' => date('t'),
                'weekend_days' => 0,
                'holiday_days' => 0,
                'chart_data' => [
                    'labels' => ['Present', 'Late', 'Absent', 'Leave'],
                    'values' => [0, 0, 0, 0],
                    'colors' => ['#28a745', '#ffb822', '#dc3545', '#38a4f8']
                ]
            ];
        }
    }
}

// Backwards compatibility functions for existing code
function isDashboardCheckinEnabled()
{
    return TrackerDashboardHelper::getInstance()->isDashboardCheckinEnabled();
}

function getAttendanceStatus($user_id)
{
    return TrackerDashboardHelper::getInstance()->getAttendanceStatus($user_id);
}

function calculateWorkingHours($user_id)
{
    return TrackerDashboardHelper::getInstance()->calculateWorkingHours($user_id);
}

function calculateTimeTrackingChart($working_hours_data)
{
    return TrackerDashboardHelper::getInstance()->calculateTimeTrackingChart($working_hours_data);
}

function calculateProductivity($user_id)
{
    return TrackerDashboardHelper::getInstance()->calculateProductivity($user_id);
}

function calculateProjectTime($user_id)
{
    return TrackerDashboardHelper::getInstance()->calculateProjectTime($user_id);
}

function calculateIdleTime($user_id, $working_hours_data = null)
{
    return TrackerDashboardHelper::getInstance()->calculateIdleTime($user_id, $working_hours_data);
}

function calculateManualTime($user_id, $working_hours_data = null)
{
    return TrackerDashboardHelper::getInstance()->calculateManualTime($user_id, $working_hours_data);
}

function calculateAwayTime($user_id, $working_hours_data = null)
{
    return TrackerDashboardHelper::getInstance()->calculateAwayTime($user_id, $working_hours_data);
}

function calculateProjectRecap($user_id, $filter = 'weekly')
{
    return TrackerDashboardHelper::getInstance()->calculateProjectRecap($user_id, $filter);
}

function calculateAttendanceRecap($user_id)
{
    return TrackerDashboardHelper::getInstance()->calculateAttendanceRecap($user_id);
}
