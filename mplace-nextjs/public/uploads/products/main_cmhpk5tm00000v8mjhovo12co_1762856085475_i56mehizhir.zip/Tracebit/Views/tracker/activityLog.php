
<style>
    /* Enhanced Search Input Styling */
    .search-row {
        margin-bottom: 20px;
        padding: 0 15px;
    }
    
    .search-container {
        text-align: center;
        margin-bottom: 0;
    }
    
    .search-container label {
        display: none; /* Hide default "Search:" label */
    }
    
    .search-input-wrapper {
        position: relative;
        display: inline-block;
        width: 100%;
        max-width: 400px;
        margin: 0 auto;
    }
    
    .enhanced-search {
        width: 100% !important;
        padding: 12px 45px 12px 45px !important;
        border: 2px solid #e9ecef !important;
        border-radius: 25px !important;
        font-size: 14px !important;
        background-color: #f8f9fa !important;
        transition: all 0.3s ease !important;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1) !important;
    }
    
    .enhanced-search:focus {
        outline: none !important;
        border-color: #007bff !important;
        background-color: #fff !important;
        box-shadow: 0 4px 12px rgba(0,123,255,0.15) !important;
        transform: translateY(-1px);
    }
    
    .enhanced-search::placeholder {
        color: #6c757d !important;
        font-style: italic;
    }
    
    .search-icon {
        position: absolute;
        left: 15px;
        top: 50%;
        transform: translateY(-50%);
        color: #6c757d;
        font-size: 16px;
        pointer-events: none;
        z-index: 10;
    }
    
    .search-clear {
        position: absolute;
        right: 15px;
        top: 50%;
        transform: translateY(-50%);
        color: #6c757d;
        font-size: 14px;
        cursor: pointer;
        padding: 5px;
        border-radius: 50%;
        transition: all 0.2s ease;
        z-index: 10;
    }
    
    .search-clear:hover {
        color: #dc3545;
        background-color: #f8f9fa;
    }
    
    .pagination-row {
        margin-top: 20px;
        padding: 0 15px;
    }
    
    /* Enhanced pagination styling */
    .dataTables_paginate .paginate_button {
        padding: 8px 12px !important;
        margin: 0 2px !important;
        border-radius: 6px !important;
        border: 1px solid #dee2e6 !important;
        background: #fff !important;
        color: #495057 !important;
        transition: all 0.2s ease !important;
    }
    
    .dataTables_paginate .paginate_button:hover {
        background: #007bff !important;
        color: white !important;
        border-color: #007bff !important;
        transform: translateY(-1px);
        box-shadow: 0 2px 4px rgba(0,123,255,0.2);
    }
    
    .dataTables_paginate .paginate_button.current {
        background: #007bff !important;
        color: white !important;
        border-color: #007bff !important;
        font-weight: 600 !important;
    }
    
    .dataTables_paginate .paginate_button.disabled {
        opacity: 0.5 !important;
        cursor: not-allowed !important;
    }
    
    .dataTables_info {
        color: #6c757d;
        font-size: 14px;
        font-weight: 500;
    }
    
    /* Search input focus animation */
    .enhanced-search:focus + .search-icon {
        color: #007bff;
    }
    
    /* Searching animation */
    .search-input-wrapper.searching {
        position: relative;
    }
    
    .search-input-wrapper.searching::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 2px;
        background: linear-gradient(90deg, transparent, #007bff, transparent);
        animation: searchProgress 0.3s ease-in-out;
        border-radius: 25px 25px 0 0;
        z-index: 11;
    }
    
    @keyframes searchProgress {
        0% { transform: translateX(-100%); }
        100% { transform: translateX(100%); }
    }
    
    /* Responsive search styling */
    @media (max-width: 768px) {
        .search-input-wrapper {
            max-width: 100%;
        }
        
        .enhanced-search {
            padding: 10px 40px 10px 40px !important;
            font-size: 13px !important;
        }
        
        .search-icon {
            left: 12px;
            font-size: 14px;
        }
        
        .search-clear {
            right: 12px;
            font-size: 12px;
        }
    }

    /* Timesheet-style table design */
    #activity_log_list {
        border-collapse: separate;
        border-spacing: 0;
        border-radius: 8px;
        overflow: hidden;
        box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }
    
    /* Avatar styling */
    .avatar-wrapper {
        display: flex;
        justify-content: center;
        align-items: center;
        padding: 5px;
    }
    
    .user-avatar {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        object-fit: cover;
        border: 2px solid #e9ecef;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        transition: all 0.3s ease;
    }
    
    .user-avatar:hover {
        border-color: #007bff;
        box-shadow: 0 4px 8px rgba(0,123,255,0.3);
        transform: scale(1.05);
    }
    
    #activity_log_list thead th {
        background: linear-gradient(135deg, #2c3e50, #34495e);
        color: white;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 1.2px;
        border: none;
        padding: 18px 12px;
        font-size: 0.85em;
        text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.3);
        position: relative;
    }

    #activity_log_list thead th:before {
        content: '';
        position: absolute;
        bottom: 0;
        left: 0;
        right: 0;
        height: 3px;
        background: linear-gradient(90deg, #3498db, #2ecc71, #f39c12);
    }
    
    #activity_log_list thead th:first-child {
        border-top-left-radius: 8px;
    }
    
    #activity_log_list thead th:last-child {
        border-top-right-radius: 8px;
    }
    
    #activity_log_list tbody td {
        padding: 12px 8px;
        border-bottom: 1px solid #e9ecef;
        font-size: 0.875rem;
        vertical-align: middle;
        background-color: #fff;
    }
    
    .timesheet-row:hover td {
        background-color: #f8f9fa !important;
    }
    
    .timesheet-row:nth-child(even) td {
        background-color: #fdfdfd;
    }
    
    /* Status badge styling */
    .status-badge {
        padding: 4px 12px;
        border-radius: 20px;
        font-size: 0.75rem;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }
    
    .status-present {
        background-color: #d4edda;
        color: #155724;
        border: 1px solid #c3e6cb;
    }
    
    .status-absent {
        background-color: #f8d7da;
        color: #721c24;
        border: 1px solid #f5c6cb;
    }
    
    .status-leave {
        background-color: #fff3cd;
        color: #856404;
        border: 1px solid #ffeaa7;
    }
    
    /* Sessions icon styling */
    .sessions-icon {
        color: #6c757d;
        font-size: 1.2rem;
        cursor: pointer;
    }
    
    .sessions-icon:hover {
        color: #007bff;
    }
    
    /* Manual time icon styling */
    .manual-time-icon {
        color: #dc3545;
        font-size: 1.1rem;
        cursor: pointer;
    }
    
    .manual-time-icon:hover {
        color: #c82333;
    }
    
    /* Date filter styling */
    .title-button-group {
        display: flex;
        align-items: center;
        gap: 10px;
    }
    
    .title-button-group .form-group {
        margin-bottom: 0;
    }
    
    .title-button-group input[type="date"] {
        width: 160px;
        padding: 6px 10px;
        border-radius: 4px;
        border: 1px solid #ced4da;
    }
    
    .title-button-group .btn {
        padding: 6px 15px;
        border-radius: 4px;
    }
    
    /* Responsive adjustments */
    @media (max-width: 768px) {
        .title-button-group {
            flex-direction: column;
            align-items: stretch;
        }
        
        .title-button-group input[type="date"] {
            width: 100%;
            margin-bottom: 10px;
        }
        
        #activity_log_list {
            font-size: 0.75rem;
        }
        
        #activity_log_list thead th,
        #activity_log_list tbody td {
            padding: 8px 4px;
        }
    }
    
    /* Loading and No Data States */
    .loading-spinner {
        text-align: center;
        padding: 40px;
        color: #007bff;
        font-size: 16px;
        font-weight: 500;
    }
    
    .loading-spinner i {
        font-size: 24px;
        margin-right: 10px;
    }
    
    .no-data-message {
        text-align: center;
        padding: 60px 20px;
        color: #6c757d;
        font-size: 16px;
        line-height: 1.6;
    }
    
    .no-data-message i {
        font-size: 48px;
        margin-bottom: 15px;
        color: #dee2e6;
    }
    
    .no-data-message small {
        display: block;
        margin-top: 10px;
        font-size: 14px;
        color: #adb5bd;
    }

    /* Loading state */
    .dataTables_processing {
        background: rgba(255, 255, 255, 0.95) !important;
        border: none !important;
        border-radius: 8px !important;
        padding: 20px !important;
        text-align: center !important;
        font-weight: 600 !important;
        box-shadow: 0 4px 20px rgba(0,0,0,0.1) !important;
    }
</style>

<?php tracker_load_css(array("assets/css/tracker_styles.css", "assets/css/employee_status_enhanced.css", "assets/css/tracker_responsive.css")); ?>

<?php // Top navigation removed - now handled by left sidebar menu ?>

<div id="page-content" class="page-wrapper clearfix">
    <div class="card">
        <div class="page-title clearfix enhanced-header">
            <div class="header-content">
                <h1 class="page-main-title"><?php echo app_lang("activity_log"); ?></h1>
            </div>
            <div class="tab-title clearfix no-border time-card-page-title">
                <div class="title-button-group">
                    <!-- Date Range Filter -->
                    <div class="form-group mr15">
                        <input type="date" id="start_date" class="form-control" placeholder="Start Date" value="<?php echo date('Y-m-01'); ?>">
                    </div>
                    <div class="form-group mr15">
                        <input type="date" id="end_date" class="form-control" placeholder="End Date" value="<?php echo date('Y-m-d'); ?>">
                    </div>
                    <button type="button" class="btn btn-primary" id="search_btn">
                        <i class="fa fa-search"></i> <?php echo app_lang('search'); ?>
                    </button>
                </div>
            </div>
        </div>
        <div class="table-responsive">
            <table id="activity_log_list" class="display tableFixHead" cellspacing="0" width="100%">
                <thead>
                    <tr>
                        <th class="w80 all text-center">Avatar</th>
                        <th class="w200 all text-center"><?php echo app_lang('name'); ?></th>
                        <th class="w80 all text-center">Wrk-Days</th>
                        <th class="w80 all text-center">Present</th>
                        <th class="w80 all text-center">Leave</th>
                        <th class="w80 all text-center">Absent</th>
                        <th class="w80 all text-center">Late</th>
                        <th class="w100 all text-center">Est.hours</th>
                        <th class="w120 all text-center">Worked Hours</th>
                        <th class="w100 all text-center">Due Hours</th>
                        <th class="w100 all text-center">Overtime</th>
                        <th class="w140 all text-center">Group Discussion</th>
                        <th class="w100 all text-center">Activities</th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
        </div>
    </div>
</div>

<script type="text/javascript">
    // Wait for jQuery to be available
    if (typeof jQuery === 'undefined') {
        
        var checkJQuery = setInterval(function() {
            if (typeof jQuery !== 'undefined') {
                clearInterval(checkJQuery);
                initActivityLog();
            }
        }, 100);
    } else {
        jQuery(document).ready(function($) {
            initActivityLog();
        });
    }

    function initActivityLog() {
        var $ = jQuery; // Ensure $ is defined

        // Set default values for date inputs
        $('#start_date').val('<?php echo date('Y-m-01'); ?>');
        $('#end_date').val('<?php echo date('Y-m-d'); ?>');

        // Search button click handler
        $('#search_btn').on('click', function() {
            if ($.fn.DataTable.isDataTable('#activity_log_list')) {
                $('#activity_log_list').DataTable().ajax.reload();
            } else {
                initDataTable();
            }
        });

        function initDataTable() {
            const url = '<?php echo get_uri("tracebit/get_activityLog_list") ?>';
            
            $("#activity_log_list").DataTable({
                destroy: true,
                processing: true,
                serverSide: true,
                ajax: {
                    url: url,
                    type: 'POST',
                    data: function(d) {
                        d.start_date = $('#start_date').val();
                        d.end_date = $('#end_date').val();
                        return d;
                    }
                },
                
                searching: true,
                lengthChange: false, // Disable length change dropdown
                pageLength: 25,
                
                // Columns matching the employee summary screenshot
                columns: [
                    {
                        title: "Avatar", 
                        data: "avatar",
                        className: "text-center",
                        orderable: false,
                        width: "80px"
                    },
                    {
                        title: "<?php echo app_lang('name'); ?>", 
                        data: "name",
                        className: "text-left",
                        orderable: false,
                        width: "200px"
                    },
                    {
                        title: "Wrk-Days", 
                        data: "work_days",
                        className: "text-center",
                        orderable: false,
                        width: "80px"
                    },
                    {
                        title: "Present", 
                        data: "present",
                        className: "text-center",
                        orderable: false,
                        width: "80px"
                    },
                    {
                        title: "Leave", 
                        data: "leave",
                        className: "text-center",
                        orderable: false,
                        width: "80px"
                    },
                    {
                        title: "Absent", 
                        data: "absent",
                        className: "text-center",
                        orderable: false,
                        width: "80px"
                    },
                    {
                        title: "Late", 
                        data: "late",
                        className: "text-center",
                        orderable: false,
                        width: "80px"
                    },
                    {
                        title: "Est.hours", 
                        data: "estimated_hours",
                        className: "text-center",
                        orderable: false,
                        width: "100px"
                    },
                    {
                        title: "Worked Hours", 
                        data: "worked_hours",
                        className: "text-center",
                        orderable: false,
                        width: "120px"
                    },
                    {
                        title: "Due Hours", 
                        data: "due_hours",
                        className: "text-center",
                        orderable: false,
                        width: "100px"
                    },
                    {
                        title: "Overtime", 
                        data: "overtime",
                        className: "text-center",
                        orderable: false,
                        width: "100px"
                    },
                    {
                        title: "Group Discussion", 
                        data: "group_discussion",
                        className: "text-center",
                        orderable: false,
                        width: "140px"
                    },
                    {
                        title: "Activities", 
                        data: "activities",
                        className: "text-center",
                        orderable: false,
                        width: "100px"
                    }
                ],

                // Styling and language
                language: {
                    processing: "<div class='loading-spinner'><i class='fa fa-spinner fa-spin'></i> Loading employee data...</div>",
                    lengthMenu: "Show _MENU_ entries",
                    zeroRecords: "<div class='no-data-message'><i class='fa fa-users'></i><br>No employees found matching your criteria<br><small>Try adjusting your search or date range</small></div>",
                    info: "Showing _START_ to _END_ of _TOTAL_ employees",
                    infoEmpty: "No employees to display",
                    infoFiltered: "(filtered from _MAX_ total employees)",
                    search: "",  // Remove default search label since we're using placeholder
                    searchPlaceholder: "Search employees, activities, hours...",
                    paginate: {
                        first: "First",
                        last: "Last",
                        next: "Next",
                        previous: "Previous"
                    }
                },

                // DOM structure with improved search layout
                dom: '<"row search-row"<"col-sm-12"f>>' +
                     '<"row"<"col-sm-12"tr>>' +
                     '<"row pagination-row"<"col-sm-5"i><"col-sm-7"p>>',

                // Custom styling
                createdRow: function(row, data, dataIndex) {
                    // Add hover effects and styling consistent with timesheet
                    $(row).addClass('timesheet-row');
                },

                drawCallback: function(settings) {
                    // Apply enhanced styling after table draw
                    $('.dataTables_wrapper .dataTables_filter').addClass('search-container');
                    $('.dataTables_wrapper .dataTables_filter input')
                        .addClass('form-control enhanced-search')
                        .attr('placeholder', 'Search employees, activities, hours...')
                        .wrap('<div class="search-input-wrapper"></div>');
                    
                    // Add search icon
                    if (!$('.search-input-wrapper .search-icon').length) {
                        $('.search-input-wrapper').prepend('<i class="fa fa-search search-icon"></i>');
                    }
                    
                    // Add clear button
                    if (!$('.search-input-wrapper .search-clear').length) {
                        $('.search-input-wrapper').append('<i class="fa fa-times search-clear" title="Clear search"></i>');
                    }
                    
                    // Clear search functionality
                    $('.search-clear').off('click').on('click', function() {
                        $('.enhanced-search').val('').trigger('keyup');
                    });
                    
                    // Show/hide clear button based on input with animation
                    $('.enhanced-search').off('input').on('input', function() {
                        const clearBtn = $(this).siblings('.search-clear');
                        if ($(this).val().length > 0) {
                            clearBtn.fadeIn(150);
                        } else {
                            clearBtn.fadeOut(150);
                        }
                    });
                    
                    // Hide clear button initially if no value
                    if ($('.enhanced-search').val().length === 0) {
                        $('.search-clear').hide();
                    }
                    
                    // Add debounced search for better performance
                    let searchTimeout;
                    $('.enhanced-search').off('keyup.debounce').on('keyup.debounce', function() {
                        clearTimeout(searchTimeout);
                        const searchTerm = $(this).val();
                        searchTimeout = setTimeout(function() {
                            // Search is already handled by DataTables, just add visual feedback
                            if (searchTerm.length > 0) {
                                $('.search-input-wrapper').addClass('searching');
                                setTimeout(function() {
                                    $('.search-input-wrapper').removeClass('searching');
                                }, 300);
                            }
                        }, 300);
                    });
                }
            });
        }

        // Initialize the table on page load
        initDataTable();
    }
</script>
