<?php
// Load CSS files - use correct path from plugin folder
tracker_load_css(array("assets/css/tracker_styles.css", "assets/css/employee_status_enhanced.css", "assets/css/sessions_modal.css", "assets/css/tracker_responsive.css"));
?>

<?php // Top navigation removed - now handled by left sidebar menu ?>

<div id="page-content" class="page-wrapper clearfix">
    <div class="card">
        <div class="page-title clearfix enhanced-header">
            <div class="header-content">
                <h1 class="page-main-title"><?php echo app_lang("timesheet"); ?></h1>
            </div>
            <div class="title-button-group custom-toolbar events-title-button skip-dropdown-migration">
                <div class="status-indicator">
                    <span class="badge badge-info pulse-badge" id="date-range-indicator">
                        <i class="fa fa-calendar"></i> <span id="current-month">Current Period</span>
                    </span>
                    <small id="last-updated">
                        Last updated: <span id="update-time">--:--</span>
                    </small>
                </div>
            </div>
        </div>

        <!-- Summary Statistics Bar -->
        <div class="summary-bar">
            <div class="summary-item">
                <span class="summary-number" id="workable-days">0</span>
                <span class="summary-label">Workable Days</span>
            </div>
            <div class="summary-item">
                <span class="summary-number text-success" id="present-days">0</span>
                <span class="summary-label">Present Days</span>
            </div>
            <div class="summary-item">
                <span class="summary-number text-danger" id="absent-days">0</span>
                <span class="summary-label">Absent Days</span>
            </div>
            <div class="summary-item">
                <span class="summary-number text-warning" id="weekend-days">0</span>
                <span class="summary-label">Weekend Days</span>
            </div>
            <div class="summary-item">
                <span class="summary-number text-secondary" id="leave-days">0</span>
                <span class="summary-label">Leave/Holiday</span>
            </div>
            <div class="summary-item">
                <span class="summary-number text-primary" id="worked-hours">0h</span>
                <span class="summary-label">Worked Hours</span>
            </div>
            <div class="summary-item">
                <span class="summary-number text-info" id="estimate-hours">0h</span>
                <span class="summary-label">Estimate Hours</span>
            </div>
            <div class="summary-item">
                <span class="summary-number text-success" id="overtime-hours">0h</span>
                <span class="summary-label">Overtime</span>
            </div>
            <div class="summary-item">
                <span class="summary-number text-warning" id="due-hours">0h</span>
                <span class="summary-label">Due Hours</span>
            </div>
        </div>

        <!-- Filter Section -->
        <div class="filter-section">
            <div class="filter-group">
                <label for="user-filter"><strong>Select User:</strong></label>
                <select id="user-filter" class="form-control">
                    <option value="">All Users</option>
                    <?php
                    if (isset($team_members_dropdown) && is_array($team_members_dropdown)) {
                        foreach ($team_members_dropdown as $id => $name) {
                            echo '<option value="' . htmlspecialchars($id) . '">' . htmlspecialchars($name) . '</option>';
                        }
                    } else {
                        // Fallback options for testing
                        echo '<option value="1">John Doe</option>';
                        echo '<option value="2">Jane Smith</option>';
                        echo '<option value="3">Mike Johnson</option>';
                    }
                    ?>
                </select>
            </div>
            <div class="filter-group">
                <label for="month-filter"><strong>Select Month:</strong></label>
                <input type="month" id="month-filter" class="form-control" value="<?php echo date('Y-m'); ?>">
            </div>
            <div class="filter-group">
                <button type="button" class="btn btn-primary" id="apply-filter">Apply Filter</button>
                <button type="button" class="btn btn-secondary" id="reset-filter">Reset</button>
            </div>
        </div>

        <div class="table-responsive">
            <table id="timeSheet_table" class="display responsive nowrap" cellspacing="0" width="100%">
                
            </table>
        </div>
    </div>
</div>

<script type="text/javascript">
    $(document).ready(function () {
        // State management
        let tableInstance;
        let currentUser = '';
        let currentMonth = '<?php echo date('Y-m'); ?>';

        function members_calling() {
            const currentMonth = $('#month-filter').val() || '<?php echo date('Y-m'); ?>';
            const currentUser = $('#user-filter').val() || '';

            const [year, month] = currentMonth.split('-');
            const startDate = `${year}-${month.padStart(2, '0')}-01`;
            const lastDay = new Date(year, month, 0).getDate();
            const endDate = `${year}-${month.padStart(2, '0')}-${lastDay.toString().padStart(2, '0')}`;

            // Test backend endpoint first
            $.ajax({
                url: "<?php echo get_uri('tracebit/get_timeSheet_list'); ?>",
                type: "POST",
                dataType: "json",
                data: {
                    start_date: startDate,
                    end_date: endDate,
                    applicant_id: currentUser || null // Send null if no user selected
                },
                success: function(response) {
                    if (response && response.data && response.data.length > 0) {
                        populateTableManually(response.data);
                        return;
                    }
                    generateFallbackData(startDate, endDate);
                },
                error: function(xhr, status, error) {
                    generateFallbackData(startDate, endDate);
                }
            });
        }        // Initialize DataTable with responsive features
        tableInstance = $("#timeSheet_table").DataTable({
            responsive: {
                details: {
                    display: $.fn.dataTable.Responsive.display.modal({
                        header: function(row) {
                            var data = row.data();
                            return 'Details for ' + data[0]; // Date column
                        }
                    }),
                    renderer: $.fn.dataTable.Responsive.renderer.tableAll()
                },
                breakpoints: [
                    { name: 'desktop', width: Infinity },
                    { name: 'tablet', width: 1024 },
                    { name: 'mobile', width: 768 }
                ]
            },
            processing: true,
            serverSide: false,
            paging: false, // Disable pagination
            info: false, // Hide "Showing X of Y entries" info
            searching: false, // Disable search functionality
            order: [[0, 'asc']], // Sort by date by default
            scrollX: true,
            scrollCollapse: true,
            autoWidth: true, // Allow table to determine its own width
            scrollXInner: '100%', // Ensure proper horizontal scroll
            columnDefs: [
                { 
                    title: "Date",
                    responsivePriority: 1, 
                    targets: 0,
                    width: '120px',
                    className: 'text-center',
                    visible: true
                }, // Date - highest priority
                { 
                    title: "Day",
                    responsivePriority: 2, 
                    targets: 1,
                    width: '100px',
                    className: 'text-center',
                    visible: true
                }, // Day - second priority
                { 
                    title: "Clock In",
                    responsivePriority: 3, 
                    targets: 2,
                    width: '100px',
                    className: 'text-center',
                    visible: true
                }, // Clock In - third priority
                { 
                    title: "Clock Out",
                    responsivePriority: 4, 
                    targets: 3,
                    width: '100px',
                    className: 'text-center',
                    visible: true
                }, // Clock Out - fourth priority
                { 
                    title: "Hours",
                    responsivePriority: 5, 
                    targets: 4,
                    width: '80px',
                    className: 'text-center',
                    visible: true
                }, // Hours - fifth priority
                { 
                    title: "Activity",
                    responsivePriority: 6, 
                    targets: 5,
                    width: '100px',
                    className: 'text-center',
                    visible: true
                }, // Activity (Status) - sixth priority
                { 
                    title: "Sessions",
                    responsivePriority: 7, 
                    targets: 6,
                    width: '80px',
                    className: 'text-center',
                    visible: true
                }, // Sessions - seventh priority
                { 
                    title: "Status",
                    responsivePriority: 8, 
                    targets: 7,
                    width: '80px',
                    className: 'text-center',
                    visible: true
                }, // Status - eighth priority
                { 
                    title: "Manual Time",
                    responsivePriority: 9, 
                    targets: 8,
                    width: '100px',
                    className: 'text-center',
                    visible: true
                }  // Manual Time - lowest priority
            ],
            language: {
                search: "Search:",
                lengthMenu: "Show _MENU_ entries per page",
                info: "Showing _START_ to _END_ of _TOTAL_ entries",
                infoEmpty: "Showing 0 to 0 of 0 entries",
                infoFiltered: "(filtered from _MAX_ total entries)",
                emptyTable: "No data available in table",
                zeroRecords: "No matching records found"
            }
        });

        // Initialize table
        members_calling();
        updateLastUpdatedTime();

        // Handle window resize for table responsiveness
        $(window).on('resize', function() {
            if (tableInstance) {
                setTimeout(() => {
                    tableInstance.columns.adjust();
                    tableInstance.responsive.recalc();
                    
                    // Force all columns to be visible on larger screens
                    if (window.innerWidth >= 768) {
                        tableInstance.columns().every(function() {
                            this.visible(true);
                        });
                        tableInstance.draw();
                        
                        // Override nowrap behavior for better column title visibility
                        $('#timeSheet_table').removeClass('nowrap').addClass('responsive-table');
                    }
                    
                    // Extra small screen optimizations
                    if (window.innerWidth <= 425) {
                        $('#timeSheet_table').addClass('extra-small-screen');
                        // Force compact column widths
                        tableInstance.columns.adjust();
                    } else {
                        $('#timeSheet_table').removeClass('extra-small-screen');
                    }
                }, 100);
            }
        });

        // Force all columns visible on larger screens after table initialization
        setTimeout(() => {
            if (window.innerWidth >= 768 && tableInstance) {
                tableInstance.columns().every(function() {
                    this.visible(true);
                });
                tableInstance.draw();
                
                // Override nowrap behavior for better column title visibility
                $('#timeSheet_table').removeClass('nowrap').addClass('responsive-table');
            }
            
            // Extra small screen optimizations on initialization
            if (window.innerWidth <= 425 && tableInstance) {
                $('#timeSheet_table').addClass('extra-small-screen');
                // Force compact column widths
                tableInstance.columns.adjust();
            }
        }, 500);

        // Event handlers for control buttons
        $('#refresh-btn').click(function() {
            members_calling();
            $(this).addClass('spin');
            setTimeout(() => {
                $(this).removeClass('spin');
                setTimeout(() => {
                    // Try backend summary first, fallback to frontend calculation
                    fetchBackendSummary();
                }, 500);
            }, 1000);
        });

        $('#apply-filter').click(function() {
            currentUser = $('#user-filter').val();
            currentMonth = $('#month-filter').val();
            members_calling();
            // Update summary after filter change
            setTimeout(() => {
                fetchBackendSummary();
            }, 1000);
        });

        $('#reset-filter').click(function() {
            $('#user-filter').val('');
            $('#month-filter').val('<?php echo date('Y-m'); ?>');
            currentUser = '';
            currentMonth = '<?php echo date('Y-m'); ?>';
            members_calling();
            // Update summary after reset
            setTimeout(() => {
                fetchBackendSummary();
            }, 1000);
        });

        $('#export-btn').click(function() {
            // Export logic can be implemented here
        });

        $('#print-btn').click(function() {
            window.print();
        });

        $('#debug-btn').click(function() {
            updateSummaryStats();
        });

        // Utility functions
        function populateTableManually(data) {
            // Clear existing DataTable data
            if (tableInstance) {
                tableInstance.clear();
            }

            // Process data for DataTable
            const processedData = data.map(row => {
                // Ensure we have exactly 9 columns
                if (Array.isArray(row)) {
                    // If row has more than 9 columns, take only first 9
                    if (row.length > 9) {
                        row = row.slice(0, 9);
                    }
                    // If row has less than 9 columns, pad with empty cells
                    else if (row.length < 9) {
                        while (row.length < 9) {
                            row.push('--');
                        }
                    }
                }
                return row;
            });

            // Add data to DataTable
            if (tableInstance) {
                tableInstance.rows.add(processedData).draw();
                
                // Force table to recalculate column widths
                setTimeout(() => {
                    tableInstance.columns.adjust();
                    tableInstance.responsive.recalc();
                    
                    // Ensure horizontal scroll is properly initialized
                    if (tableInstance.scrollX()) {
                        tableInstance.scrollX().draw();
                    }
                }, 100);
            }

            // Update stats with proper delay
            setTimeout(() => {
                // Try backend summary first, fallback to frontend calculation
                fetchBackendSummary();
                updateLastUpdatedTime();
                updateCurrentMonthDisplay();
            }, 200);
        }

        function generateFallbackData(startDate, endDate) {
            const testData = [];
            const start = new Date(startDate);
            const end = new Date(endDate);

            for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
                const currentDate = d.toISOString().split('T')[0];
                const dayOfWeek = d.getDay();
                const dayName = d.toLocaleDateString('en-US', { weekday: 'long' });
                const dayNum = d.getDate();

                let status = '';
                let inTime = '--';
                let outTime = '--';
                let duration = '--';
                let activity = '--';
                let sessions = '--';
                let manualTime = '--';

                if (dayOfWeek === 0 || dayOfWeek === 6) { // Weekend
                    status = "<span class='badge bg-primary' data-status='weekend'>Weekend</span>";
                    sessions = "<i data-feather='minus' class='text-muted' style='width:16px;height:16px;'></i>";
                    manualTime = "<i data-feather='minus' class='text-muted' style='width:16px;height:16px;'></i>";
                } else if (currentDate === '2025-07-06') { // Holiday
                    status = "<span class='badge bg-info' data-status='holiday'>Holiday</span>";
                    sessions = "<i data-feather='minus' class='text-muted' style='width:16px;height:16px;'></i>";
                    manualTime = "<i data-feather='minus' class='text-muted' style='width:16px;height:16px;'></i>";
                } else if (dayNum === 15) { // Leave day
                    status = "<span class='badge bg-secondary' data-status='on_leave'>On Leave</span>";
                    sessions = "<i data-feather='minus' class='text-muted' style='width:16px;height:16px;'></i>";
                    manualTime = "<i data-feather='minus' class='text-muted' style='width:16px;height:16px;'></i>";
                } else if (dayNum === 10) { // Half leave
                    status = "<span class='badge bg-warning' data-status='half_leave'>Half Leave</span>";
                    inTime = '09:00 AM';
                    outTime = '01:00 PM';
                    duration = '04:00:00';
                    activity = "<span style='color: black;'>65%</span>";
                    sessions = "<i data-feather='clock' class='text-info' style='width:16px;height:16px;' title='View Sessions'></i>";
                    manualTime = "<i data-feather='edit-3' class='text-warning' style='width:16px;height:16px;' title='Add Manual Time'></i>";
                } else if (Math.random() > 0.8) { // 20% chance of absence
                    status = "<span class='badge bg-danger' data-status='absent'>Absent</span>";
                    sessions = "<i data-feather='minus' class='text-muted' style='width:16px;height:16px;'></i>";
                    manualTime = "<i data-feather='edit-3' class='text-danger' style='width:16px;height:16px;' title='Add Manual Time'></i>";
                } else { // Present
                    status = "<span class='badge bg-success' data-status='present'>Present</span>";
                    inTime = '09:' + String(Math.floor(Math.random() * 15)).padStart(2, '0') + ' AM';
                    outTime = '05:' + String(30 + Math.floor(Math.random() * 30)).padStart(2, '0') + ' PM';
                    duration = '08:' + String(15 + Math.floor(Math.random() * 30)).padStart(2, '0') + ':00';
                    const activityVal = 60 + Math.floor(Math.random() * 30);
                    activity = `<span style='color: green;'>${activityVal}%</span>`;
                    sessions = "<i data-feather='clock' class='text-primary' style='width:16px;height:16px;' title='View Sessions'></i>";
                    manualTime = "<i data-feather='edit-3' class='text-success' style='width:16px;height:16px;' title='Add Manual Time'></i>";
                }

                testData.push([
                    currentDate,        // Date
                    dayName,            // Day
                    inTime,             // Clock In
                    outTime,            // Clock Out
                    duration,           // Hours
                    status,             // Activity (Status)
                    sessions,           // Sessions
                    '--',               // Status (empty for now)
                    manualTime          // Manual Time
                ]);
            }

            populateTableManually(testData);
        }

        /**
         * Fetch summary statistics from backend
         */
        function fetchBackendSummary() {
            // Use the SAME date range calculation as main data call
            const currentMonthValue = $('#month-filter').val() || '<?php echo date('Y-m'); ?>';
            const currentUserValue = $('#user-filter').val() || '';

            const [year, month] = currentMonthValue.split('-');
            const startDate = `${year}-${month.padStart(2, '0')}-01`;
            const lastDay = new Date(year, month, 0).getDate();
            const endDate = `${year}-${month.padStart(2, '0')}-${lastDay.toString().padStart(2, '0')}`;

            $.ajax({
                url: "<?php echo get_uri('tracebit/get_timesheet_summary'); ?>",
                type: "POST",
                dataType: "json",
                data: {
                    start_date: startDate,
                    end_date: endDate,
                    applicant_id: currentUserValue
                },
                success: function(response) {
                    if (response) {
                        updateSummaryFromBackend(response);
                        return;
                    }
                    updateSummaryStats();
                },
                error: function(xhr, status, error) {
                    updateSummaryStats();
                }
            });
        }

        /**
         * Update summary UI with backend data
         */
        function updateSummaryFromBackend(data) {
            $('#workable-days').text(data.workable_days || 0);
            $('#present-days').text(data.present_days || 0);
            $('#absent-days').text(data.absent_days || 0);
            $('#weekend-days').text(data.weekend_days || 0);
            $('#leave-days').text(data.leave_days || 0);
            $('#worked-hours').text((data.worked_hours || 0) + 'h');
            $('#estimate-hours').text((data.estimate_hours || 0) + 'h');
            $('#overtime-hours').text((data.overtime_hours || 0) + 'h');
            $('#due-hours').text((data.due_hours || 0) + 'h');
        }

        function updateSummaryStats() {
            const $table = $('#timeSheet_table');
            const $tbody = $table.find('tbody');

            if ($table.length === 0 || $tbody.length === 0) {
                return;
            }

            // Get daily work hours setting - default 8 hours
            const dailyWorkHours = 8;

            let stats = {
                totalDays: 0,
                workableDays: 0,
                present: 0,
                absent: 0,
                weekend: 0,
                leave: 0,
                halfLeave: 0,
                workedHours: 0,
                estimateHours: 0,
                overtime: 0,
                dueHours: 0
            };

            $tbody.find('tr').each(function(index) {
                const $row = $(this);
                const $cells = $row.find('td');

                if ($cells.length > 0 && !$row.hasClass('dataTables_empty')) {
                    stats.totalDays++; // Count every day

                    // Count status types - look for badges in the 8th column (status column)
                    const $statusBadge = $row.find('td:nth-child(8) .badge');

                    if ($statusBadge.length > 0) {
                        const dataStatus = $statusBadge.attr('data-status') || '';

                        // Count based on data-status attribute for accuracy
                        switch(dataStatus) {
                            case 'present':
                                stats.present++;
                                stats.estimateHours += dailyWorkHours;
                                break;
                            case 'absent':
                                stats.absent++;
                                stats.estimateHours += dailyWorkHours;
                                break;
                            case 'weekend':
                                stats.weekend++;
                                // Weekends don't count as workable days
                                break;
                            case 'half_leave':
                                stats.halfLeave++;
                                stats.leave++; // Half leave counts in leave category
                                stats.present++; // But also counts as present
                                stats.estimateHours += dailyWorkHours / 2; // Half day estimate
                                break;
                            case 'on_leave':
                            case 'holiday':
                                stats.leave++;
                                // Full leave/holidays don't add to estimate hours
                                break;
                        }
                    }

                    // Parse worked hours duration (5th column - index 4, which is Hours)
                    const durationText = $row.find('td:nth-child(5)').text().trim();
                    if (durationText && durationText !== '--' && durationText !== '---') {
                        const timeMatch = durationText.match(/(\d{1,2}):(\d{2})(?::(\d{2}))?/);
                        if (timeMatch) {
                            const hours = parseInt(timeMatch[1]);
                            const minutes = parseInt(timeMatch[2]);
                            const totalHours = hours + (minutes / 60);
                            stats.workedHours += totalHours;

                            // Calculate overtime for this day (only if present/half-leave)
                            const dataStatus = $row.find('td:nth-child(8) .badge').attr('data-status') || '';
                            if (dataStatus === 'present' || dataStatus === 'half_leave') {
                                const expectedHours = dataStatus === 'half_leave' ? dailyWorkHours / 2 : dailyWorkHours;
                                if (totalHours > expectedHours) {
                                    stats.overtime += (totalHours - expectedHours);
                                }
                            }
                        }
                    }
                }
            });

            // Calculate workable days: Total Days - Weekend Days - Full Leave Days
            // Half leaves are counted in leave but should still be workable, so we add them back
            const fullLeaveDays = stats.leave - stats.halfLeave;
            stats.workableDays = stats.totalDays - stats.weekend - fullLeaveDays;

            // Calculate due hours (estimate - worked, but only positive values)
            stats.dueHours = Math.max(0, stats.estimateHours - stats.workedHours);

            // Update UI elements with rounded values
            $('#workable-days').text(stats.workableDays);
            $('#present-days').text(stats.present);
            $('#absent-days').text(stats.absent);
            $('#weekend-days').text(stats.weekend);
            $('#leave-days').text(stats.leave);

            const workedHoursFormatted = Math.round(stats.workedHours * 10) / 10;
            const estimateHoursFormatted = Math.round(stats.estimateHours * 10) / 10;
            const overtimeFormatted = Math.round(stats.overtime * 10) / 10;
            const dueHoursFormatted = Math.round(stats.dueHours * 10) / 10;

            $('#worked-hours').text(workedHoursFormatted + 'h');
            $('#estimate-hours').text(estimateHoursFormatted + 'h');
            $('#overtime-hours').text(overtimeFormatted + 'h');
            $('#due-hours').text(dueHoursFormatted + 'h');
        }
        
        function updateLastUpdatedTime() {
            const now = new Date();
            const timeString = now.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
            $('#update-time').text(timeString);
        }

        function updateCurrentMonthDisplay() {
            const monthValue = $('#month-filter').val() || currentMonth;
            const date = new Date(monthValue + '-01');
            const monthName = date.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
            $('#current-month').text(monthName);
        }

        // Add spinning animation for refresh button
        $(document).on('click', '.spin', function() {
            $(this).addClass('fa-spin');
        });

        // Update month display when changed
        $('#month-filter').change(function() {
            updateCurrentMonthDisplay();
        });

        // Initial month display
        updateCurrentMonthDisplay();

        function formatDuration(minutes) {
            const hours = Math.floor(minutes / 60);
            const mins = minutes % 60;
            if (hours > 0) {
                return `${hours}h ${mins}m`;
            }
            return `${mins}m`;
        }

        function parseDuration(durationStr) {
            const hoursMatch = durationStr.match(/(\d+)h/);
            const minutesMatch = durationStr.match(/(\d+)m/);

            let totalMinutes = 0;
            if (hoursMatch) totalMinutes += parseInt(hoursMatch[1]) * 60;
            if (minutesMatch) totalMinutes += parseInt(minutesMatch[1]);

            return totalMinutes;
        }

        function getActivityColor(activity) {
            const percent = parseInt(activity);
            if (percent >= 80) return 'success';
            if (percent >= 60) return 'warning';
            return 'danger';
        }

        // Initialize Feather icons after DOM is ready
        if (typeof feather !== 'undefined') {
            feather.replace();
        }

        // Re-initialize Feather icons after any dynamic content is added
        function initializeFeatherIcons() {
            if (typeof feather !== 'undefined') {
                setTimeout(() => {
                    feather.replace();
                }, 100);
            }
        }

        // Force icon initialization after page load
        $(window).on('load', function() {
            setTimeout(() => {
                if (typeof feather !== 'undefined') {
                    feather.replace();

                    // Check if icons rendered, show fallback if not
                    setTimeout(() => {
                        $('.manual-time-link').each(function() {
                            const $icon = $(this).find('[data-feather]');
                            const $fallback = $(this).find('.feather-fallback');

                            if ($icon.length && !$icon.find('svg').length) {
                                console.log('Feather icon not rendered, showing fallback');
                                $icon.hide();
                                $fallback.show();
                            }
                        });
                    }, 200);
                } else {
                    // Feather not loaded, show all fallbacks
                    $('.feather-fallback').show();
                    $('[data-feather]').hide();
                }
            }, 500);
        });


    });
</script>

<script>
    // Wait for all dependencies to load before executing
    $(document).ready(function () {
        // Ensure all required functions are available
        if (typeof setCookie === 'undefined') {
            window.setCookie = function(name, value) {
                document.cookie = name + "=" + value + "; path=/";
            };
        }

        if (typeof getCookie === 'undefined') {
            window.getCookie = function(name) {
                var nameEQ = name + "=";
                var ca = document.cookie.split(';');
                for(var i=0;i < ca.length;i++) {
                    var c = ca[i];
                    while (c.charAt(0)==' ') c = c.substring(1,c.length);
                    if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
                }
                return null;
            };
        }

        //save the selected tab in browser cookie
        $(".js-reports-link").click(function () {
            var link = $(this).attr("href");
            if (link) {
                setCookie("selected_report_" + "<?php echo $login_user->id; ?>", link);
            }
        });

        var selectedReport = getCookie("selected_report_" + "<?php echo $login_user->id; ?>");
        if (selectedReport) {
            $(".js-reports-link").removeClass("btn-info").addClass("btn-default");
            $(".js-reports-link[href='" + selectedReport + "']").removeClass("btn-default").addClass("btn-info");
        } else {
            //active current tab
            var currentUrl = window.location.href;
            $(".js-reports-link").each(function () {
                var link = $(this).attr("href");
                if (currentUrl.indexOf(link) !== -1) {
                    $(this).removeClass("btn-default").addClass("btn-info");
                    return false;
                }
            });
        }
    });
</script>
