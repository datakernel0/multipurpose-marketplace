<?php
// Load CSS files - use correct path from plugin folder
tracker_load_css(array("assets/css/tracker_styles.css", "assets/css/employee_status_enhanced.css", "assets/css/tracker_responsive.css"));
?>
<?php // Top navigation removed - now handled by left sidebar menu ?>
<div id="page-content" class="page-wrapper clearfix">
    <div class="card">
        <div class="page-title clearfix enhanced-header">
            <div class="header-content">
                <h1 class="page-main-title"><?php echo app_lang("employee_status"); ?></h1>
            </div>
            <div class="tab-title clearfix no-border time-card-page-title">
                <div class="title-button-group">
                    <!-- Live Status Indicator -->
                    <div class="status-indicator">
                        <span class="badge badge-success pulse-badge" id="live-indicator">
                            <i class="fa fa-circle"></i> LIVE
                        </span>
                        <small id="last-updated">
                            Last updated: <span id="update-time">--:--</span>
                        </small>
                    </div>

                </div>
            </div>
        </div>

        <!-- Summary Statistics Bar -->
        <div class="summary-bar">
            <div class="summary-item">
                <span class="summary-number" id="total-employees">0</span>
                <span class="summary-label">Total Employees</span>
            </div>
            <div class="summary-item">
                <span class="summary-number text-success" id="active-summary">0</span>
                <span class="summary-label">Active Now</span>
            </div>
            <div class="summary-item">
                <span class="summary-number text-warning" id="idle-summary">0</span>
                <span class="summary-label">On Break/Idle</span>
            </div>
            <div class="summary-item">
                <span class="summary-number text-danger" id="offline-summary">0</span>
                <span class="summary-label">Offline</span>
            </div>
            <div class="summary-item">
                <span class="summary-number text-info" id="avg-productivity">0%</span>
                <span class="summary-label">Avg Productivity</span>
            </div>
        </div>

        <div class="table-responsive">
            <table id="attendance_table" class="display tableFixHead" cellspacing="0" width="100%"></table>
        </div>
    </div>
</div>

<script type="text/javascript">
    $(document).ready(function () {
        // State management
        let currentFilter = 'all';
        let statusCounts = { active: 0, idle: 0, inactive: 0, total: 0 };
        let tableInstance;

        // Auto-refresh functionality
        let autoRefreshInterval;
        let isAutoRefreshEnabled = true;

        function members_calling() {
            const url = '<?php echo get_uri("tracebit/get_attendance_list") ?>';
            // Check if DataTable exists and destroy it properly before reinitializing
            if ($.fn.DataTable.isDataTable('#attendance_table')) {
                $('#attendance_table').DataTable().clear().destroy();
                $('#attendance_table').empty();
            }

            tableInstance = $("#attendance_table").appTable({
                destroy: true,
                source: url,
                order: [], // Disable initial sorting
                dateRangeType: "daily",
                serverSide: true,
                processing: true,
                pageLength: 10,
                lengthMenu: [[10, 25, 50, 100], [10, 25, 50, 100]],
                searchDelay: 500,
                drawCallback: function(settings) {
                    console.log('DataTable drawCallback triggered');
                    console.log('Table rows after draw:', $('#attendance_table tbody tr').length);

                    updateStatusCounts();
                    updateLastUpdatedTime();
                    applyCurrentFilter();

                    // Force remove sorting classes from Clock In column (3rd column, index 2)
                    $('#attendance_table thead th:eq(2)').removeClass('sorting sorting_asc sorting_desc').addClass('sorting_disabled');

                    // Add tooltips to activity percentages
                    $('[data-toggle="tooltip"]').tooltip();

                    // Add hover effects for better UX
                    $('.status-row').hover(
                        function() { $(this).addClass('table-hover-highlight'); },
                        function() { $(this).removeClass('table-hover-highlight'); }
                    );
                },
                columns: [
                    {title: "<?php echo app_lang("name") ?>", "class": "w50 all text-right"},
                    {title: "", "class": "w350 all"},
                    {title: "<?php echo app_lang("inAt") ?>", "class": "w350 all text-center", "orderable": false},
                    {title: "<?php echo app_lang("last_out") ?>", "class": "w350 all text-center"},
                    {title: "<?php echo app_lang("workedTime") ?>", "class": "w350 all text-center"},
                    {title: "<?php echo app_lang("overtime") ?>", "class": "w350 all text-center"},
                    {title: "<?php echo app_lang("due_time") ?>", "class": "w350 all text-center"},
                    {title: "<?php echo app_lang("idleTime") ?>", "class": "w350 all text-center"},
                    {title: "Away Time", "class": "w350 all text-center"},
                    {title: "<?php echo app_lang("activity") ?>", "class": "w350 all text-center"}
                ],
                printColumns: combineCustomFieldsColumns([1, 2, 3, 4, 5, 6, 7, 8, 9], ''),
                xlsColumns: combineCustomFieldsColumns([1, 2, 3, 4, 5, 6, 7, 8, 9], ''),
                initComplete: function(settings, json) {
                    console.log('DataTable initialization complete');
                    console.log('Initial data received:', json);
                },
                error: function(xhr, error, thrown) {
                    console.error('DataTable error:', error);
                    console.error('XHR:', xhr);
                    console.error('Thrown:', thrown);
                }

            });
        }

        // Initialize table and set up auto-refresh
        members_calling();

        // Initialize the last updated time immediately
        updateLastUpdatedTime();

        // Debug: Check if table loaded after 2 seconds
        setTimeout(function() {
            updateStatusCounts();
        }, 2000);

        // Event handlers for control buttons
        $('#refresh-btn').click(function() {
            // Use proper DataTable refresh
            if ($.fn.DataTable.isDataTable('#attendance_table')) {
                $('#attendance_table').DataTable().ajax.reload();
            } else {
                members_calling();
            }
            $(this).addClass('spin');
            setTimeout(() => $(this).removeClass('spin'), 1000);
        });

        $('#auto-refresh-toggle').click(function() {
            isAutoRefreshEnabled = !isAutoRefreshEnabled;
            const icon = $(this).find('i');

            if (isAutoRefreshEnabled) {
                icon.removeClass('fa-play').addClass('fa-pause');
                $(this).removeClass('btn-success').addClass('btn-secondary');
                startAutoRefresh();
            } else {
                icon.removeClass('fa-pause').addClass('fa-play');
                $(this).removeClass('btn-secondary').addClass('btn-success');
                stopAutoRefresh();
            }
        });

        // Functions for filtering and status management
        function applyFilter(filterType) {
            currentFilter = filterType;

            // Update button states
            $('.btn-group .btn').removeClass('active');
            $(`#filter-${filterType}`).addClass('active');

            // Apply filter to table rows
            const table = $('#attendance_table').DataTable();
            // Since status column is removed, we'll just refresh the table for any filter changes
            // The filtering will be handled server-side if needed
            table.search('').draw();
        }

        function applyCurrentFilter() {
            if (currentFilter !== 'all') {
                applyFilter(currentFilter);
            }
        }

        function updateStatusCounts() {
            console.log('updateStatusCounts called at', new Date().toLocaleTimeString());
            // Get status counts from server-side
            $.ajax({
                url: '<?php echo get_uri("tracebit/employee_status/get_status_counts"); ?>',
                type: 'GET',
                dataType: 'json',
                success: function(data) {
                    console.log('Status counts received:', data);

                    if (data) {
                        // Update UI counters
                        $('#total-employees').text(data.total || 0);
                        $('#active-summary').text(data.active || 0);
                        $('#idle-summary').text(data.idle || 0);
                        $('#offline-summary').text(data.inactive || 0);
                        $('#avg-productivity').text((data.avg_productivity || 0) + '%');

                        // Update the last updated time
                        updateLastUpdatedTime();

                        console.log('UI updated with counts:', {
                            total: data.total,
                            active: data.active,
                            idle: data.idle,
                            inactive: data.inactive,
                            productivity: data.avg_productivity
                        });
                    } else {
                        console.warn('No data received from server');
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Failed to get status counts from server:', error);
                    console.error('XHR response:', xhr.responseText);
                    console.error('Status:', status);
                    // Fallback to DOM counting if server fails
                    updateStatusCountsFromDOM();
                }
            });
        }

        function updateStatusCountsFromDOM() {
            // Fallback method using DOM elements
            const $table = $('#attendance_table');
            const $tbody = $table.find('tbody');

            // Count based on status badge classes
            statusCounts.active = $tbody.find('.bg-success').length;
            statusCounts.idle = $tbody.find('.bg-warning, .bg-info').length;
            statusCounts.inactive = $tbody.find('.bg-danger, .bg-secondary').length;
            statusCounts.total = $tbody.find('tr').length;

            // Update UI counters
            $('#total-employees').text(statusCounts.total);
            $('#active-summary').text(statusCounts.active);
            $('#idle-summary').text(statusCounts.idle);
            $('#offline-summary').text(statusCounts.inactive);

            // Calculate productivity
            let totalProductivity = 0;
            let productivityCount = 0;

            $tbody.find('td:last-child').each(function() {
                const $cell = $(this);
                let activityText = $cell.text().trim();
                let match = activityText.match(/(\d+(?:\.\d+)?)%/);
                if (match) {
                    const activityValue = parseFloat(match[1]);
                    if (!isNaN(activityValue) && activityValue >= 0) {
                        totalProductivity += activityValue;
                        productivityCount++;
                    }
                }
            });

            const avgProductivity = productivityCount > 0 ?
                Math.round(totalProductivity / productivityCount) : 0;
            $('#avg-productivity').text(avgProductivity + '%');

            console.log('Status counts from DOM fallback:', statusCounts);
        }        function updateLastUpdatedTime() {
            const now = new Date();
            const timeString = now.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
            $('#update-time').text(timeString);
            console.log('Last updated time set to:', timeString);
        }

        // Auto-refresh every 30 seconds
        function startAutoRefresh() {
            if (isAutoRefreshEnabled) {
                console.log('Starting auto-refresh with 30 second interval');
                autoRefreshInterval = setInterval(function() {
                    console.log('Auto-refresh triggered at', new Date().toLocaleTimeString());
                    // Use proper DataTable refresh instead of appTable
                    if ($.fn.DataTable.isDataTable('#attendance_table')) {
                        $('#attendance_table').DataTable().ajax.reload(null, false);
                    } else {
                        members_calling();
                    }

                    // Also update status counts from server
                    updateStatusCounts();
                }, 30000); // 30 seconds
            } else {
                console.log('Auto-refresh is disabled');
            }
        }

        function stopAutoRefresh() {
            if (autoRefreshInterval) {
                clearInterval(autoRefreshInterval);
            }
        }

        // Start auto-refresh
        startAutoRefresh();

        // Toggle auto-refresh when page visibility changes
        document.addEventListener('visibilitychange', function() {
            if (document.hidden) {
                stopAutoRefresh();
            } else {
                startAutoRefresh();
            }
        });


    });
</script>
