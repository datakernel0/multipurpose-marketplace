<div class="reports-tabs">
    <div id="tracker_topbar" class="page-wrapper pb-0">
        <?php
            echo anchor(get_uri("tracebit"), "<i data-feather='home' class='icon-16 mr5'></i> " . app_lang('dashboard'), array("class" => "btn btn-default round me-2 js-reports-link", "title" => app_lang("dashboard")));
            echo anchor(get_uri("tracebit/employee_status"), "<i data-feather='bar-chart' class='icon-16 mr5'></i> " . app_lang('employee_status'), array("class" => "btn btn-default round me-2 js-reports-link", "title" => app_lang("employee_status")));
            echo anchor(get_uri("tracebit/timesheet"), "<i data-feather='clock' class='icon-16 mr5'></i> " . app_lang("attendance_title"), array("class" => "btn btn-default round me-2 js-reports-link", "title" => app_lang("attendance_title")));
            echo anchor(get_uri("tracebit/activity-log"), "<i data-feather='activity' class='icon-16 mr5'></i> " . app_lang("activity_log"), array("class" => "btn btn-default round me-2 js-reports-link", "title" => app_lang("activity_log")));
            echo anchor(get_uri("tracebit/screenshots"), "<i data-feather='image' class='icon-16 mr5'></i> " . app_lang("screenshot_title"), array("class" => "btn btn-default round me-2 js-reports-link", "title" => app_lang("screenshot_title")));
            
            // Storage Management Button (simple link to dedicated page)
            echo anchor(get_uri("tracebit/storage_management"), "<i data-feather='hard-drive' class='icon-16 mr5'></i> " . (app_lang("storage_management") ?: "Storage Management"), array("class" => "btn btn-default round me-2 js-reports-link", "title" => "Storage Management"));
            
            echo anchor(get_uri("tracebit/tracker_settings"), "<i data-feather='settings' class='icon-16 mr5'></i> " . app_lang("settings"), array("class" => "btn btn-default round me-2 js-reports-link", "title" => app_lang("settings")));
        ?>
    </div>
</div>

<script>
//save the selected tab in browser cookie
$(document).ready(function () {
    $(".js-reports-link").click(function () {
        var link = $(this).attr("href");
        if (link) {
            setCookie("selected_report_" + "<?php echo isset($login_user) ? $login_user->id : 0; ?>", link);
        }
    });

    // Simple and reliable active state logic
    const currentPath = window.location.pathname.toLowerCase();

    // Remove any existing active classes first
    $("#tracker_topbar a").removeClass('active');

    // Find and set active link with simple matching
    $("#tracker_topbar a").each(function () {
        const $link = $(this);
        const linkHref = $link.attr("href");
        
        if (!linkHref) return;
        
        const linkPath = new URL(linkHref, window.location.origin).pathname.toLowerCase();

        // Check if current path matches link path
        let isMatch = false;
        
        // Exact match
        if (currentPath === linkPath) {
            isMatch = true;
        }
        // Route contains matching
        else if (linkPath.includes('/timesheet') && currentPath.includes('/timesheet')) {
            isMatch = true;
        }
        else if (linkPath.includes('/activity-log') && currentPath.includes('/activity-log')) {
            isMatch = true;
        }
        else if (linkPath.includes('/employee_status') && currentPath.includes('/employee_status')) {
            isMatch = true;
        }
        else if (linkPath.includes('/screenshots') && currentPath.includes('/screenshots')) {
            isMatch = true;
        }
        else if (linkPath.endsWith('/tracebit') && currentPath.endsWith('/tracebit')) {
            isMatch = true;
        }
        
        if (isMatch) {
            $link.addClass('active');
            return false; // Stop looking
        }
    });
});
</script>
