/**
 * Tracker Dashboard JavaScript
 * Handles chart initialization and attendance button functionality
 */

// Chart initialization function
function initTrackerChart(
    labels,
    data,
    id,
    colorPlate = ['#17B26A', '#47CD89']
) {
    var color =
        data.length <= 50
            ? colorPlate.slice(0, data.length)
            : generateColors(data.length);
    var chartCanvas = document.getElementById(id);

    // Check if element exists and Chart.js is loaded
    if (!chartCanvas) {
        console.warn('Chart canvas not found:', id);
        return;
    }

    if (typeof Chart === 'undefined') {
        console.error('Chart.js library not loaded');
        return;
    }

    try {
        var chartOptions = {
            cutoutPercentage: 50,
            responsive: true,
            maintainAspectRatio: true,
            legend: {
                display: false,
            },
            tooltips: {
                enabled: true,
                backgroundColor: 'rgba(0, 0, 0, 0.9)',
                titleFontColor: '#ffffff',
                bodyFontColor: '#ffffff',
                titleFontSize: 14,
                bodyFontSize: 13,
                cornerRadius: 8,
                xPadding: 12,
                yPadding: 10,
                displayColors: true,
                callbacks: {
                    label: function (tooltipItem, data) {
                        var label = data.labels[tooltipItem.index] || '';
                        var value = data.datasets[0].data[tooltipItem.index];

                        // Special formatting for time-track chart
                        if (id === 'time-track') {
                            var hours = Math.floor(value);
                            var minutes = Math.round((value - hours) * 60);
                            var timeString = hours + 'h ' + minutes + 'm';
                            return label + ': ' + timeString;
                        } // Special formatting for productivity chart
                        else if (id === 'productive-time') {
                            return label + ': ' + Math.round(value) + '%';
                        }
                        // Special formatting for project time chart
                        else if (id === 'project-time') {
                            var hours = Math.floor(value);
                            var minutes = Math.round((value - hours) * 60);
                            var timeString =
                                hours > 0
                                    ? hours + 'h ' + minutes + 'm'
                                    : minutes + 'm';
                            return label + ': ' + timeString;
                        }
                        // Special formatting for attendance chart - show actual numbers
                        else if (id === 'attendance') {
                            var dayText = value === 1 ? 'day' : 'days';
                            return label + ': ' + value + ' ' + dayText;
                        } else {
                            // Default percentage for other charts
                            var total = data.datasets[0].data.reduce(
                                (a, b) => a + b,
                                0
                            );
                            var percentage = Math.round((value / total) * 100);
                            return label + ': ' + percentage + '%';
                        }
                    },
                },
            },
            elements: {
                arc: {
                    borderWidth: 3,
                    borderColor: '#ffffff',
                },
            },
            animation: {
                duration: 1200,
                easing: 'easeOutQuart',
            },
        };

        new Chart(chartCanvas, {
            type: 'doughnut',
            data: {
                labels: labels,
                datasets: [
                    {
                        data: data,
                        backgroundColor: color,
                        borderWidth: 3,
                        borderColor: '#ffffff',
                        hoverBorderWidth: 4,
                        hoverBorderColor: '#ffffff',
                    },
                ],
            },
            options: chartOptions,
        });
    } catch (error) {
        console.error('Error creating chart:', id, error);
    }
}

// Modern color palette generator
function generateColors(count) {
    var modernColors = [
        '#10b981',
        '#3b82f6',
        '#8b5cf6',
        '#f59e0b',
        '#ef4444',
        '#06b6d4',
        '#84cc16',
        '#f97316',
        '#ec4899',
        '#6366f1',
        '#14b8a6',
        '#eab308',
    ];

    var colors = [];
    for (var i = 0; i < count; i++) {
        colors.push(modernColors[i % modernColors.length]);
    }
    return colors;
}

// Initialize all dashboard charts
function initializeDashboardCharts(chartData) {
    // Use real data from PHP for time tracking chart
    initTrackerChart(
        chartData.time.labels,
        chartData.time.values,
        'time-track',
        chartData.time.colors
    );

    // Use real data from PHP for productivity chart
    initTrackerChart(
        chartData.productivity.labels,
        chartData.productivity.values,
        'productive-time',
        chartData.productivity.colors
    );

    // Static charts (to be made dynamic later)
    initTrackerChart(
        chartData.project.labels,
        chartData.project.values,
        'project-time',
        chartData.project.colors
    );

    // Use real data from PHP for idle time chart (compares idle vs productive time)
    initTrackerChart(
        chartData.idle.labels,
        chartData.idle.values,
        'idle-time',
        chartData.idle.colors
    );

    // Use real data from PHP for manual time chart (compares manual vs automatic time)
    initTrackerChart(
        chartData.manual.labels,
        chartData.manual.values,
        'manual-time',
        chartData.manual.colors
    );

    // Use real data from PHP for away time chart (compares present vs away/break time)
    initTrackerChart(
        chartData.away.labels,
        chartData.away.values,
        'away-time',
        chartData.away.colors
    );

    // Use real data from PHP for project recap chart
    initTrackerChart(
        chartData.project_recap.labels,
        chartData.project_recap.values,
        'project-recap',
        chartData.project_recap.colors
    );

    // Use real data from PHP for attendance recap chart
    initTrackerChart(
        chartData.attendance.labels,
        chartData.attendance.values,
        'attendance',
        chartData.attendance.colors
    );
}

// Icon replacement function
function initTrackerFeatherIcons() {
    $('[data-feather]').each(function () {
        var $this = $(this);
        var iconName = $this.attr('data-feather');
        var classes = $this.attr('class') || '';
        var iconHtml = getIconHtml(iconName, classes);
        $this.replaceWith(iconHtml);
    });

    return true;
}

// Generate safe icon HTML
function getIconHtml(iconName, classes) {
    var iconMap = {
        activity: '<span class="' + classes + '">📊</span>',
        clock: '<span class="' + classes + '">⏰</span>',
        users: '<span class="' + classes + '">👥</span>',
        camera: '<span class="' + classes + '">📷</span>',
        calendar: '<span class="' + classes + '">📅</span>',
        check: '<span class="' + classes + '">✅</span>',
        'bar-chart-2': '<span class="' + classes + '">📊</span>',
        'external-link': '<span class="' + classes + '">🔗</span>',
        'check-circle': '<span class="' + classes + '">✅</span>',
        'minus-circle': '<span class="' + classes + '">⊖</span>',
        x: '<span class="' + classes + '">❌</span>',
        folder: '<span class="' + classes + '">📁</span>',
        'log-in': '<span class="' + classes + '">🔑</span>',
        'log-out': '<span class="' + classes + '">🚪</span>',
    };

    return iconMap[iconName] || '<span class="' + classes + '">●</span>';
}

// Attendance button functionality
function initAttendanceButton() {
    $('#attendance-toggle')
        .off('click')
        .on('click', function (e) {
            e.preventDefault();

            var $button = $(this);
            var action = $button.data('action');
            var attendanceId = $button.data('attendance-id');

            if ($button.prop('disabled')) {
                return;
            }

            // Disable button during request
            $button.prop('disabled', true);

            // Show loading state
            var originalText = $button.html();
            $button.html('<i class="icon-12 mr5">⏳</i>Processing...');

            $.ajax({
                url: trackerConfig.clockToggleUrl,
                type: 'POST',
                dataType: 'json',
                data: {
                    action: action,
                    attendance_id: attendanceId,
                    note: '',
                },
                success: function (response) {
                    if (response.success) {
                        // Show success message
                        if (typeof appAlert !== 'undefined') {
                            appAlert.success(response.message);
                        }

                        // Update button state
                        updateAttendanceButton(response);
                    } else {
                        if (typeof appAlert !== 'undefined') {
                            appAlert.error(
                                response.message || 'An error occurred'
                            );
                        }

                        // Restore button
                        $button.html(originalText);
                        $button.prop('disabled', false);
                    }
                },
                error: function (xhr, status, error) {
                    console.error('Attendance toggle error:', error);
                    if (typeof appAlert !== 'undefined') {
                        appAlert.error(
                            'Failed to update attendance. Please try again.'
                        );
                    }

                    // Restore button
                    $button.html(originalText);
                    $button.prop('disabled', false);
                },
            });
        });
}

// Update attendance button state after successful action
function updateAttendanceButton(response) {
    var $button = $('#attendance-toggle');
    var $status = $('.attendance-status');

    if (response.action === 'checkin') {
        // Update to check-out state
        $button
            .removeClass('attendance-button')
            .addClass('attendance-button checked-in');
        $button.html(
            '<i data-feather="log-out" class="icon-12 mr5"></i>Check Out'
        );
        $button.data('action', 'checkout');
        $button.data(
            'attendance-id',
            response.status ? response.status.id : ''
        );
        $status.text(
            'Checked in at ' +
                (response.time || new Date().toLocaleTimeString())
        );
    } else if (response.action === 'checkout') {
        // Update to check-in state
        $button.removeClass('checked-in').addClass('attendance-button');
        $button.html(
            '<i data-feather="log-in" class="icon-12 mr5"></i>Check In'
        );
        $button.data('action', 'checkin');
        $button.data('attendance-id', '');
        $status.text('Not checked in');

        // Update the total working time display and chart
        updateWorkingTimeDisplay();
    }

    // Re-enable button
    $button.prop('disabled', false);

    // Re-initialize feather icons for the updated button
    initTrackerFeatherIcons();
}

// Function to update working time display and chart after check-out
function updateWorkingTimeDisplay() {
    // Reload the page to get updated working time calculation
    // Could be improved with AJAX to get just the updated data
    setTimeout(function () {
        if (typeof trackerConfig !== 'undefined' && trackerConfig.autoReload) {
            location.reload();
        }
    }, 1000);
}

// Dashboard initialization
function initTrackerDashboard(chartData, config) {
    // Store config globally
    window.trackerConfig = config;

    // Initialize icons
    initTrackerFeatherIcons();

    // Initialize attendance button
    initAttendanceButton();

    // Initialize project recap filter buttons
    initProjectRecapFilters();

    // Initialize charts with delay to ensure everything is loaded
    setTimeout(function () {
        initializeDashboardCharts(chartData);
    }, 300);
}

// Initialize project recap filter functionality
function initProjectRecapFilters() {
    const filterButtons = document.querySelectorAll('.filter-btn');

    filterButtons.forEach((button) => {
        button.addEventListener('click', function (e) {
            e.preventDefault();

            const filter = this.dataset.filter;

            // Update active state
            filterButtons.forEach((btn) => btn.classList.remove('active'));
            this.classList.add('active');

            // Load new data
            loadProjectRecapData(filter);
        });
    });
}

// Load project recap data with filter
function loadProjectRecapData(filter) {
    // Show loading state
    const projectRecapWidget = document.querySelector(
        '.tracker-widget:has(#project-recap)'
    );
    if (projectRecapWidget) {
        projectRecapWidget.style.opacity = '0.6';
    }

    // Get the URL from configuration
    const url = window.trackerConfig && window.trackerConfig.projectRecapUrl 
        ? window.trackerConfig.projectRecapUrl 
        : 'index.php/tracebit/tracker';

    // Make AJAX request to get filtered data
    fetch(url, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-Requested-With': 'XMLHttpRequest',
        },
        body: `action=get_project_recap&filter=${filter}`,
    })
        .then((response) => response.json())
        .then((data) => {
            if (data.success) {
                // Update chart
                updateProjectRecapChart(data.chart);

                // Update project list
                updateProjectList(data.projects);
            } else {
                console.error('Failed to load project recap data:', data.error);
            }
        })
        .catch((error) => {
            console.error('Error loading project recap data:', error);
        })
        .finally(() => {
            // Remove loading state
            if (projectRecapWidget) {
                projectRecapWidget.style.opacity = '1';
            }
        });
}

// Update project recap chart
function updateProjectRecapChart(chartData) {
    const chartElement = document.getElementById('project-recap');
    if (chartElement && chartData) {
        // Destroy existing chart if exists
        if (chartElement.chart) {
            chartElement.chart.destroy();
        }

        // Create new chart
        initTrackerChart(
            chartData.labels,
            chartData.values,
            'project-recap',
            chartData.colors
        );
    }
}

// Update project list
function updateProjectList(projects) {
    const projectList = document.querySelector('.tracker-projects');
    if (!projectList) return;

    let html = '';

    if (projects && projects.length > 0) {
        projects.slice(0, 5).forEach((project) => {
            html += `
                <li>
                    <span class="project-name">
                        <i data-feather="folder" class="icon-12 mr5"></i>
                        ${escapeHtml(project.title)}
                        ${
                            project.status
                                ? `<span class="project-status ${project.status.toLowerCase()}">${
                                      project.status
                                  }</span>`
                                : ''
                        }
                        ${
                            project.is_leader
                                ? `<span class="project-leader">
                                      <i data-feather="star" class="icon-10"></i>Leader
                                   </span>`
                                : ''
                        }
                    </span>
                    <span class="text-primary font-weight-bold">
                        ${project.formatted_time}
                    </span>
                </li>
            `;
        });

        if (projects.length > 5) {
            const otherTime = projects
                .slice(5)
                .reduce((sum, project) => sum + project.seconds, 0);
            html += `
                <li>
                    <span class="project-name">
                        <i data-feather="more-horizontal" class="icon-12 mr5"></i>
                        ${projects.length - 5} more projects
                    </span>
                    <span class="text-muted">
                        ${formatTime(otherTime)}
                    </span>
                </li>
            `;
        }
    } else {
        html = `
            <li>
                <span class="project-name">
                    <i data-feather="info" class="icon-12 mr5"></i>
                    No project activity
                </span>
                <span class="text-muted">0m</span>
            </li>
        `;
    }

    projectList.innerHTML = html;

    // Re-initialize feather icons
    if (typeof feather !== 'undefined') {
        feather.replace();
    }
}

// Helper function to escape HTML
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Helper function to format time
function formatTime(seconds) {
    if (seconds < 60) {
        return '0m';
    }

    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);

    if (hours > 0) {
        return `${hours}h ${minutes}m`;
    } else {
        return `${minutes}m`;
    }
}

// Backwards compatibility
window.initExpenseCategoryChart = initTrackerChart;
