<?php
/**
 * Weekend Settings Tab Content
 * Contains settings related to weekend configuration
 */
?>
<div class="mt-3">
    <h5>Weekend Settings</h5>
    <p class="text-muted mb-4">Configure which weekdays (Monday-Friday) should be treated as weekends for attendance and time tracking purposes.</p>

    <?php echo form_open(get_uri("tracebit/tracker_settings/save_by_type"), array("id" => "weekend-settings-form", "class" => "general-form dashed-row", "role" => "form")); ?>
    <input type="hidden" name="type" value="weekend_settings">

    <div class="row">
        <div class="col-md-6">
            <div class="form-group card p-3">
                <label class="mb-3 font-weight-bold">Weekend Days Configuration:</label>
                <div>
                    <?php
                    // Get saved weekend days or default to empty array (since Saturday & Sunday are always weekends)
                    $weekend_days = get_array_value($weekend_settings, "weekend_days") ? explode(",", get_array_value($weekend_settings, "weekend_days")) : [];

                    // Define weekdays and weekend days separately
                    $weekdays = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];

                    // Show weekdays with checkboxes (these can be selected as weekend days)
                    echo '<div class="mb-3">';
                    echo '<p class="text-muted small mb-2"><i class="fa fa-info-circle"></i> Select which days should be treated as weekend days:</p>';

                    // Debug info
                    echo '<!-- Current weekend days: ' . print_r($weekend_days, true) . ' -->';

                    foreach ($weekdays as $day) {
                        $checked = in_array($day, $weekend_days) ? "checked" : "";
                        echo '<div class="form-check weekday-option">';
                        // Ensure the name has array notation properly formatted
                        echo '<input class="form-check-input weekend-day-checkbox" type="checkbox" name="settings[weekend_days][]" value="' . $day . '" id="weekend_' . strtolower($day) . '" ' . $checked . '>';
                        echo '<label class="form-check-label" for="weekend_' . strtolower($day) . '">' . $day . ' <small class="text-muted">(Select to make this a weekend)</small></label>';
                        echo '</div>';
                    }
                    echo '</div>';
                    ?>
                </div>
            </div>
        </div>
    </div>

    <div class="form-group mt-4">
        <button type="submit" id="save-weekend-settings" class="btn btn-primary">
            <span data-feather="check-circle" class="icon-16"></span> Save Weekend Settings
        </button>
        <span id="save-status" class="ml-3 d-none"></span>
    </div>
    <?php echo form_close(); ?>
</div>

<script type="text/javascript">
$(document).ready(function() {
    // Initialize feather icons
    if (typeof feather !== 'undefined') {
        feather.replace();
    }

    // Add a click handler to manually verify checkboxes are toggled correctly
    $(".weekend-day-checkbox").on("change", function() {
        console.log("Checkbox changed: " + $(this).val() + " is now " + ($(this).is(":checked") ? "checked" : "unchecked"));
    });

    // Form submission handler
    $("#weekend-settings-form").on("submit", function(e) {
        e.preventDefault();

        // Show loading indicator
        $("#save-weekend-settings").prop("disabled", true).html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Saving...');
        $("#save-status").removeClass("d-none text-success text-danger").addClass("text-muted").html("Saving your settings...");

        // Collect all selected weekend days
        var weekendDays = [];
        $(".weekend-day-checkbox:checked").each(function() {
            weekendDays.push($(this).val());
        });

        console.log("Selected weekend days:", weekendDays);

        // Create the data object
        var data = {
            type: 'weekend_settings'
        };

        // Add weekend days as an array with proper index notation for PHP
        if (weekendDays.length > 0) {
            for (var i = 0; i < weekendDays.length; i++) {
                data["settings[weekend_days][" + i + "]"] = weekendDays[i];
            }
        } else {
            // Send an empty value to clear any existing setting
            data["settings[weekend_days]"] = '';
        }

        console.log("Data being sent:", data);

        // Submit the form via AJAX
        $.ajax({
            url: $(this).attr("action"),
            type: "POST",
            data: data,
            dataType: "json",
            success: function(response) {
                if (response.success) {
                    // Show success message
                    appAlert.success("Weekend settings saved successfully!", {duration: 3000});
                    $("#save-status").removeClass("text-muted text-danger d-none").addClass("text-success").html('<i class="fa fa-check-circle"></i> Settings saved successfully');
                } else {
                    // Show error message
                    appAlert.error(response.message || "Error saving settings", {duration: 5000});
                    $("#save-status").removeClass("text-muted text-success d-none").addClass("text-danger").html('<i class="fa fa-times-circle"></i> ' + (response.message || "Error saving settings"));
                }

                // Reset button state
                $("#save-weekend-settings").prop("disabled", false).html('<span data-feather="check-circle" class="icon-16"></span> Save Weekend Settings');
                if (typeof feather !== 'undefined') {
                    feather.replace();
                }
            },
            error: function() {
                // Show error message
                appAlert.error("An error occurred while saving the settings", {duration: 5000});
                $("#save-status").removeClass("text-muted text-success d-none").addClass("text-danger").html('<i class="fa fa-times-circle"></i> Connection error');

                // Reset button state
                $("#save-weekend-settings").prop("disabled", false).html('<span data-feather="check-circle" class="icon-16"></span> Save Weekend Settings');
                if (typeof feather !== 'undefined') {
                    feather.replace();
                }
            }
        });
    });
});
</script>

<style>
.weekday-option {
    background-color: #f8f9fa;
    padding: 8px 12px;
    margin-bottom: 8px;
    border-radius: 5px;
    border-left: 3px solid #6c757d;
    transition: all 0.2s ease;
}
.weekday-option:hover {
    background-color: #e9ecef;
    border-left-color: #007bff;
}
.weekday-option input[type="checkbox"]:checked + label {
    font-weight: bold;
    color: #007bff;
}
.form-check-label {
    cursor: pointer;
    padding-left: 5px;
}

/* Animation for saving indicator */
@keyframes pulse {
    0% { opacity: 1; }
    50% { opacity: 0.5; }
    100% { opacity: 1; }
}

#save-status {
    animation: pulse 1.5s infinite;
}

/* Improve selected checkbox styling */
.form-check-input:checked ~ .form-check-label {
    font-weight: bold;
}

/* Card styling */
.card {
    box-shadow: 0 2px 8px rgba(0,0,0,.1);
    border: none;
}

/* Add subtle hover effect to settings options */
.form-check {
    transition: transform 0.2s ease;
}

.form-check:hover {
    transform: translateX(5px);
}

/* Style for the alert box */
.alert-info {
    background-color: #e8f4f8;
    border-color: #b8e2ef;
}

/* Highlight active tab */
.nav-tabs .nav-link.active {
    border-bottom: 3px solid #007bff;
    font-weight: bold;
}
</style>