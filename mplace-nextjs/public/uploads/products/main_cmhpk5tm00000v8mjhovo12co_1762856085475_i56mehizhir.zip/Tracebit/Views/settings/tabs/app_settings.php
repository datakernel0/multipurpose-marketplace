<?php
/**
 * App Settings Tab Content
 * Contains application-specific settings like screenshot interval, idle timeout, etc.
 */
?>
<div class="mt-3">
    <h5>Application Settings</h5>
    <?php echo form_open(get_uri("tracebit/tracker_settings/save_by_type"), array("id" => "app-settings-form", "class" => "general-form dashed-row", "role" => "form")); ?>
    <input type="hidden" name="type" value="app_settings">

    <div class="row">
        <!-- Core Tracking Settings -->
        <div class="col-md-6">
            
            <div class="form-group">
                <label for="idle_timeout">Idle Timeout (seconds):</label>
                <?php echo form_input(array(
                    "id" => "idle_timeout",
                    "name" => "settings[idle_timeout]",
                    "value" => get_array_value($app_settings, "idle_timeout") ?: "150",
                    "class" => "form-control",
                    "type" => "number",
                    "min" => "30"
                )); ?>
                <small class="form-text text-muted">Idle detection timeout in seconds</small>
            </div>

            <div class="form-group">
                <label for="auto_update_time">Auto Update Time (seconds):</label>
                <?php echo form_input(array(
                    "id" => "auto_update_time",
                    "name" => "settings[auto_update_time]",
                    "value" => get_array_value($app_settings, "auto_update_time") ?: "150",
                    "class" => "form-control",
                    "type" => "number",
                    "min" => "30"
                )); ?>
                <small class="form-text text-muted">Idle detection timeout in seconds</small>
            </div>

            <div class="form-group">
                <label for="working_hours_start">Work Day Start Time:</label>
                <?php echo form_input(array(
                    "id" => "working_hours_start",
                    "name" => "settings[working_hours_start]",
                    "value" => get_array_value($app_settings, "working_hours_start") ?: "09:00",
                    "class" => "form-control",
                    "type" => "time"
                )); ?>
            </div>

            <div class="form-group">
                <label for="working_hours_end">Work Day End Time:</label>
                <?php echo form_input(array(
                    "id" => "working_hours_end",
                    "name" => "settings[working_hours_end]",
                    "value" => get_array_value($app_settings, "working_hours_end") ?: "17:00",
                    "class" => "form-control",
                    "type" => "time"
                )); ?>
            </div>

            <h6 class="mt-4 mb-3">Feature Toggles</h6>

            <div class="form-group">
                <div class="form-check">
                    <?php echo form_checkbox(array(
                        "id" => "enable_screenshots",
                        "name" => "settings[enable_screenshots]",
                        "value" => "1",
                        "checked" => get_array_value($app_settings, "enable_screenshots") == "1",
                        "class" => "form-check-input"
                    )); ?>
                    <label class="form-check-label" for="enable_screenshots">Enable Screenshot Capture</label>
                </div>
            </div>

            <div class="form-group">
                <div class="form-check">
                    <?php echo form_checkbox(array(
                        "id" => "screen_shot_on_break",
                        "name" => "settings[screen_shot_on_break]",
                        "value" => "1",
                        "checked" => get_array_value($app_settings, "screen_shot_on_break") == "1",
                        "class" => "form-check-input"
                    )); ?>
                    <label class="form-check-label" for="screen_shot_on_break">Enable Screenshot on Break</label>
                </div>
            </div>

            <div class="form-group">
                <div class="form-check">
                    <?php echo form_checkbox(array(
                        "id" => "enable_activity_tracking",
                        "name" => "settings[enable_activity_tracking]",
                        "value" => "1",
                        "checked" => get_array_value($app_settings, "enable_activity_tracking") == "1",
                        "class" => "form-check-input"
                    )); ?>
                    <label class="form-check-label" for="enable_activity_tracking">Enable Activity Tracking</label>
                </div>
            </div>

            <div class="form-group">
                <div class="form-check">
                    <?php echo form_checkbox(array(
                        "id" => "enable_idle_detection",
                        "name" => "settings[enable_idle_detection]",
                        "value" => "1",
                        "checked" => get_array_value($app_settings, "enable_idle_detection") == "1",
                        "class" => "form-check-input"
                    )); ?>
                    <label class="form-check-label" for="enable_idle_detection">Enable Idle Detection</label>
                </div>
            </div>

            <div class="form-group">
                <div class="form-check">
                    <?php echo form_checkbox(array(
                        "id" => "productivity_tracking",
                        "name" => "settings[productivity_tracking]",
                        "value" => "1",
                        "checked" => get_array_value($app_settings, "productivity_tracking") == "1",
                        "class" => "form-check-input"
                    )); ?>
                    <label class="form-check-label" for="productivity_tracking">Enable Productivity Tracking</label>
                </div>
            </div>

            
        </div>

        <!-- Screenshot & Performance Settings -->
        <div class="col-md-6">
           
            <div class="form-group">
                <label for="screenshot_interval">Screenshot Interval (seconds):</label>
                <?php echo form_input(array(
                    "id" => "screenshot_interval",
                    "name" => "settings[screenshot_interval]",
                    "value" => get_array_value($app_settings, "screenshot_interval") ?: "300",
                    "class" => "form-control",
                    "type" => "number",
                    "min" => "30"
                )); ?>
                <small class="form-text text-muted">Screenshot capture interval in seconds</small>
            </div>
            <div class="form-group">
                <label for="screenshot_quality">Screenshot Quality (1-100):</label>
                <?php echo form_input(array(
                    "id" => "screenshot_quality",
                    "name" => "settings[screenshot_quality]",
                    "value" => get_array_value($app_settings, "screenshot_quality") ?: "80",
                    "class" => "form-control",
                    "type" => "number",
                    "min" => "1",
                    "max" => "100"
                )); ?>
            </div>

            <div class="form-group">
                <label for="screenshot_width">Screenshot width size:</label>
                <?php echo form_input(array(
                    "id" => "screenshot_width",
                    "name" => "settings[screenshot_width]",
                    "value" => get_array_value($app_settings, "screenshot_width") ?: "80",
                    "class" => "form-control",
                    "type" => "number",
                    "min" => "600",
                    "max" => "1920"
                )); ?>
            </div>

            <div class="form-group">
                <label for="screenshot_height">Screenshot height:</label>
                <?php echo form_input(array(
                    "id" => "screenshot_height",
                    "name" => "settings[screenshot_height]",
                    "value" => get_array_value($app_settings, "screenshot_height") ?: "80",
                    "class" => "form-control",
                    "type" => "number",
                    "min" => "400",
                    "max" => "1080"
                )); ?>
            </div>

            <div class="form-group">
                <label for="max_screenshot_size">Max Screenshot Size (bytes):</label>
                <?php echo form_input(array(
                    "id" => "max_screenshot_size",
                    "name" => "settings[max_screenshot_size]",
                    "value" => get_array_value($app_settings, "max_screenshot_size") ?: "5242880",
                    "class" => "form-control",
                    "type" => "number",
                    "min" => "1024"
                )); ?>
                <small class="form-text text-muted">Maximum screenshot size (default: 5MB)</small>
            </div>

            <h6 class="mt-4 mb-3">Performance & Monitoring</h6>

            <div class="form-group">
                <label for="performance_threshold">Performance Threshold (%):</label>
                <?php echo form_input(array(
                    "id" => "performance_threshold",
                    "name" => "settings[performance_threshold]",
                    "value" => get_array_value($app_settings, "performance_threshold") ?: "50",
                    "class" => "form-control",
                    "type" => "number",
                    "min" => "0",
                    "max" => "100"
                )); ?>
            </div>

            
        </div>
    </div>

    <div class="form-group">
        <button type="submit" class="btn btn-primary" id="app-settings-submit-btn">
            <span data-feather="check-circle" class="icon-16"></span> 
            <span class="btn-text">Save App Settings</span>
            <span class="btn-loader d-none">
                <span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                Saving...
            </span>
        </button>
    </div>
    <?php echo form_close(); ?>
</div>

<script>
$(document).ready(function() {
    // Handle form submission with loader
    $("#app-settings-form").on("submit", function(e) {
        e.preventDefault();
        
        const $form = $(this);
        const $submitBtn = $("#app-settings-submit-btn");
        const $btnText = $submitBtn.find(".btn-text");
        const $btnLoader = $submitBtn.find(".btn-loader");
        
        // Show loader
        $submitBtn.prop("disabled", true);
        $btnText.addClass("d-none");
        $btnLoader.removeClass("d-none");
        
        // Create FormData object
        const formData = new FormData(this);
        
        // Submit via AJAX
        fetch("<?php echo get_uri('tracebit/tracker_settings/save_by_type'); ?>", {
            method: "POST",
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                appAlert.success(data.message || "App settings saved successfully!");
            } else {
                appAlert.error(data.message || "Failed to save app settings");
            }
        })
        .catch(error => {
            console.error("Error:", error);
            appAlert.error("An error occurred while saving app settings");
        })
        .finally(() => {
            // Hide loader and restore button state
            $submitBtn.prop("disabled", false);
            $btnText.removeClass("d-none");
            $btnLoader.addClass("d-none");
        });
    });
});
</script>
