<?php
/**
 * Break Settings Tab Content
 * Contains settings related to break configuration
 */
?>
<div class="mt-3">
    <h5>Break Settings</h5>
    <?php echo form_open(get_uri("tracebit/tracker_settings/save_by_type"), array("id" => "breaks-settings-form", "class" => "general-form dashed-row", "role" => "form")); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header d-flex flex-wrap justify-content-between align-items-center">
                    <h6 class="mb-0">Break List</h6>
                    <div>
                        <button type="button" id="refresh-break-list" class="btn btn-default btn-sm me-2">
                            <i data-feather="refresh-cw" class="icon-16"></i> Refresh
                        </button>
                        <?php echo modal_anchor(get_uri("tracebit/tracker_breaks/modal_form"), "<i data-feather='plus-circle' class='icon-16'></i> Add Break", array("class" => "btn btn-primary btn-sm", "title" => "Add Break", "data-post-id" => "")); ?>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="break-table" class="display" width="100%">
                            <thead>
                                <tr>
                                    <th>Break Name</th>
                                    <th>Value</th>
                                    <th>Icon</th>
                                    <th>Description</th>
                                    <th>Is Minus Break</th>
                                    <th>Max Time</th>
                                    <th class="text-center">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php echo form_close(); ?>
</div>

<script type="text/javascript">
$(document).ready(function() {
    // Initialize tooltips
    $('[data-bs-toggle="tooltip"]').tooltip();

    // Initialize feather icons
    feather.replace();

    // Initialize appTable for breaks
    var breakTable = null;

    function initializeBreakTable() {
        if ($("#break-table").length) {
            // If DataTable is already initialized, destroy it first
            if ($.fn.DataTable.isDataTable("#break-table")) {
                $("#break-table").DataTable().destroy();
                $("#break-table").empty();
            }

            // Now initialize or reload the table
            breakTable = $("#break-table").appTable({
                source: '<?php echo get_uri("tracebit/tracker_breaks/list_data") ?>',
                columns: [
                    {title: 'Break Name'},
                    {title: 'Value'},
                    {title: 'Icon'},
                    {title: 'Description'},
                    {title: 'Is Minus Break'},
                    {title: 'Max Time'},
                    {title: 'Actions', "class": "text-center option w100"}
                ],
                order: [[0, "asc"]],
                displayLength: 25,
                responsive: false,
                paging: false,
                searching: true,
                info: false,
                autoWidth: false,
                lengthChange: false,
                onInitComplete: function() {
                    // Reinitialize feather icons after table is loaded
                    feather.replace();
                }
            });
        }
    }

    // Initialize table when tab is shown (for tab navigation)
    $(document).on("show.bs.tab", 'a[data-bs-toggle="tab"][href="#break-settings"]', function(e) {

        setTimeout(function() {
            initializeBreakTable();
        }, 100);
    });

    // For direct navigation to the breaks tab
    if (window.location.hash && window.location.hash.includes("break")) {
        setTimeout(function() {
            initializeBreakTable();
        }, 100);
    }

    // Check if this tab is already active on page load
    if ($('a[data-bs-toggle="tab"][href="#break-settings"]').parent().hasClass('active')) {

        setTimeout(function() {
            initializeBreakTable();
        }, 100);
    }

    // Refresh button handler
    $("#refresh-break-list").click(function() {
        initializeBreakTable();
    });

    // Listen for modal updates
    $(document).on('appModal:close', function() {
        initializeBreakTable();
    });

    // Listen for custom break update event
    $(document).on('breakUpdated', function() {
        initializeBreakTable();
    });

    // Handle form submission
    $("#breaks-settings-form").submit(function(e) {
        e.preventDefault();

        $.ajax({
            url: $(this).attr('action'),
            type: 'POST',
            data: $(this).serialize(),
            success: function(response) {
                // Show success message with appAlert
                appAlert.success("Break settings saved successfully!", {duration: 3000});

                // Reload the break table
                initializeBreakTable();

                // Reinitialize feather icons after showing the message
                feather.replace();
            },
            error: function(xhr) {
                appAlert.error("Error saving settings. Please try again.", {duration: 5000});
            }
        });
    });
});
</script>
