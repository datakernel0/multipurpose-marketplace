<?php
/**
 * Holiday Settings Tab Content
 * Contains settings related to holiday configuration
 */
?>
<div class="mt-3">
    <h5>Holiday Settings</h5>
    <?php echo form_open(get_uri("tracebit/tracker_settings/save_by_type"), array("id" => "holidays-settings-form", "class" => "general-form dashed-row", "role" => "form")); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header d-flex flex-wrap justify-content-between align-items-center">
                    <h6 class="mb-0">Holiday List</h6>
                    <div>
                        <button type="button" id="refresh-holiday-list" class="btn btn-default btn-sm me-2">
                            <i data-feather="refresh-cw" class="icon-16"></i> Refresh
                        </button>
                        <?php echo modal_anchor(get_uri("tracebit/tracker_holidays/modal_form"), "<i data-feather='plus-circle' class='icon-16'></i> Add Holiday", array("class" => "btn btn-primary btn-sm", "title" => "Add Holiday", "data-post-id" => "")); ?>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="holiday-table" class="display" width="100%">
                            <thead>
                                <tr>
                                    <th>Holiday Name</th>
                                    <th>Date Range</th>
                                    <th>Day Name</th>
                                    <th>Duration (Days)</th>
                                    <th>Type</th>
                                    <th class="text-center">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $holidays = get_array_value($holidays_settings, "holidays") ? json_decode(get_array_value($holidays_settings, "holidays"), true) : [];

                                if (empty($holidays)) {
                                    echo '<tr><td colspan="6" class="text-center">No holidays found. Click "Add Holiday" to create one.</td></tr>';
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php echo form_close(); ?>
</div>

<script type="text/javascript">
$(document).ready(function() {
    // Initialize tooltips
    $('[data-bs-toggle="tooltip"]').tooltip();

    // Initialize feather icons
    feather.replace();

    // Initialize appTable for holidays
    var holidayTable = null;

    function initializeHolidayTable() {
        if ($("#holiday-table").length) {
            // If DataTable is already initialized, destroy it first
            if ($.fn.DataTable.isDataTable("#holiday-table")) {
                $("#holiday-table").DataTable().destroy();
                $("#holiday-table").empty();
            }

            // Now initialize or reload the table
            holidayTable = $("#holiday-table").appTable({
                source: '<?php echo get_uri("tracebit/tracker_holidays/list_data") ?>',
                columns: [
                    {title: 'Holiday Name'},
                    {title: 'Date Range'},
                    {title: 'Day Name'},
                    {title: 'Duration (Days)'},
                    {title: 'Type'},
                    {title: 'Actions', "class": "text-center option w100"}
                ],
                order: [[1, "asc"]],
                displayLength: 25,
                responsive: false,
                paging: false,
                searching: true,
                info: false,
                autoWidth: false,
                lengthChange: false,
                onInitComplete: function() {
                    // Reinitialize feather icons after table is loaded
                    feather.replace();
                }
            });
        }
    }    // Don't initialize on page load - only when tab is shown

    // Initialize table when tab is shown (for tab navigation)
    $(document).on("show.bs.tab", 'a[data-bs-toggle="tab"][href="#holidays-settings"]', function(e) {
        setTimeout(function() {
            initializeHolidayTable();
        }, 100);
    });

    // For direct navigation to the holidays tab
    if (window.location.hash && window.location.hash.includes("holidays")) {
        setTimeout(function() {
            initializeHolidayTable();
        }, 100);
    }

    // Check if this tab is already active on page load
    if ($('a[data-bs-toggle="tab"][href="#holidays-settings"]').parent().hasClass('active')) {
        setTimeout(function() {
            initializeHolidayTable();
        }, 100);
    }

    // Refresh button handler
    $("#refresh-holiday-list").click(function() {
        initializeHolidayTable();
    });

    // Listen for modal updates
    $(document).on('appModal:close', function() {
        initializeHolidayTable();
    });

    // Listen for custom holiday update event
    $(document).on('holidayUpdated', function() {
        initializeHolidayTable();
    });

    // Handle form submission
    $("#holidays-settings-form").submit(function(e) {
        e.preventDefault();

        $.ajax({
            url: $(this).attr('action'),
            type: 'POST',
            data: $(this).serialize(),
            success: function(response) {
                // Show success message with appAlert
                appAlert.success("Holiday settings saved successfully!", {duration: 3000});

                // Reload the holiday table
                initializeHolidayTable();

                // Reinitialize feather icons after showing the message
                feather.replace();
            },
            error: function(xhr) {
                appAlert.error("Error saving settings. Please try again.", {duration: 5000});
            }
        });
    });
});
</script>
