<?php
/**
 * Web Settings Tab Content
 * Contains web-specific settings like web portal settings
 */
?>
<div class="mt-3">
    <h5>Desktop App & Interface Settings</h5>
    <?php
    $form_action = get_uri("tracebit/tracker_settings/save_by_type");

    echo form_open($form_action, array("id" => "web-settings-form", "class" => "general-form dashed-row", "role" => "form"));
    ?>
    <input type="hidden" name="type" value="web_settings">

    <div class="row">
        <!-- Desktop App Settings -->
      

        <!-- Display Settings -->
        <div class="col-md-6">
            <h6 class="mt-3 mb-3">Display Settings</h6>

            <div class="form-group">
                <div class="form-check">
                    <?php echo form_checkbox(array(
                        "id" => "dashboard_checkin",
                        "name" => "settings[dashboard_checkin]",
                        "value" => "1",
                        "checked" => get_array_value($web_settings, "dashboard_checkin") == "1",
                        "class" => "form-check-input"
                    )); ?>
                    <label class="form-check-label" for="dashboard_checkin">Dashboard CheckIn ON-Off</label>
                </div>
            </div>

        </div>
    </div>

    <div class="form-group">
        <button type="submit" class="btn btn-primary"><span data-feather="check-circle" class="icon-16"></span> Save Interface Settings</button>
    </div>
    <?php echo form_close(); ?>
</div>

<script>
$(document).ready(function() {
    $("#web-settings-form").on("submit", function(e) {
        e.preventDefault();

        // Show loading state
        $("button[type=\"submit\"]", this).prop("disabled", true).html("<span class=\"spinner-border spinner-border-sm\" role=\"status\" aria-hidden=\"true\"></span> Saving...");

        // Collect form data manually
        const formData = new FormData();
        formData.append("type", "web_settings");

        // Collect checkboxes
        const checkboxes = ["enable_notifications", "minimize_to_tray", "start_with_system", "show_detailed_stats", "dashboard_checkin", "compact_view"];
        checkboxes.forEach(function(name) {
            const element = document.getElementById(name);
            if (element && element.checked) {
                formData.append("settings[" + name + "]", "1");
            } else {
                formData.append("settings[" + name + "]", "0");
            }
        });

        // Collect text inputs and dropdowns
        const textInputs = ["auto_sync_interval", "theme_preference", "language", "web_portal_url", "web_session_timeout", "web_login_attempts", "web_notification_emails"];
        textInputs.forEach(function(name) {
            const element = document.getElementById(name);
            if (element) {
                formData.append("settings[" + name + "]", element.value);
            }
        });

        // Submit via AJAX
        fetch("<?php echo get_uri('tracebit/tracker_settings/save_by_type'); ?>", {
            method: "POST",
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                appAlert.success(data.message || "Web settings saved successfully!");
            } else {
                appAlert.error(data.message || "Failed to save web settings");
            }
        })
        .catch(error => {
            console.error("Error:", error);
            appAlert.error("An error occurred while saving web settings");
        })
        .finally(() => {
            // Restore button state
            $("button[type=\"submit\"]", "#web-settings-form").prop("disabled", false).html("<span data-feather=\"check-circle\" class=\"icon-16\"></span> Save Interface Settings");
            feather.replace();
        });
    });
});
</script>
