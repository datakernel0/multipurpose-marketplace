<?php tracker_load_css(array("assets/css/tracker_styles.css", "assets/css/tracker_responsive.css")); ?>
<?php // Top navigation removed - now handled by left sidebar menu ?>
<div id="page-content" class="page-wrapper clearfix">
    <div class="row">
        
        <div class="col-sm-12 col-lg-12">
            <div class="card">

                <div class="page-title clearfix enhanced-header">
                    <div class="header-content">
                        <h1 class="page-main-title"><?php echo app_lang("settings"); ?></h1>
                    </div>
                    <div class="tab-title clearfix no-border time-card-page-title">
                        <div class="title-button-group">
                          

                        </div>
                    </div>
                </div>

                <div class="card-body">
                    <!-- Settings Navigation Tabs -->
                    <ul class="nav nav-tabs" id="settingsTabs" role="tablist">
                        <li class="nav-item" role="presentation">
                            <a class="nav-link active" id="app-settings-tab" data-bs-toggle="tab" href="#app-settings" role="tab">
                                <i data-feather="settings" class="icon-16"></i> App Settings
                            </a>
                        </li>
                        <li class="nav-item" role="presentation">
                            <a class="nav-link" id="web-settings-tab" data-bs-toggle="tab" href="#web-settings" role="tab">
                                <i data-feather="monitor" class="icon-16"></i> Web Settings
                            </a>
                        </li>
                        <li class="nav-item" role="presentation">
                            <a class="nav-link" id="break-settings-tab" data-bs-toggle="tab" href="#break-settings" role="tab">
                                <i data-feather="coffee" class="icon-16"></i> Break Settings
                            </a>
                        </li>
                        <li class="nav-item" role="presentation">
                            <a class="nav-link" id="weekend-settings-tab" data-bs-toggle="tab" href="#weekend-settings" role="tab">
                                <i data-feather="calendar" class="icon-16"></i> Weekend Settings
                            </a>
                        </li>
                        <li class="nav-item" role="presentation">
                            <a class="nav-link" id="holidays-settings-tab" data-bs-toggle="tab" href="#holidays-settings" role="tab">
                                <i data-feather="sun" class="icon-16"></i> Holiday Settings
                            </a>
                        </li>
                    </ul>

                    <!-- Settings Tab Content -->
                    <div class="tab-content" id="settingsTabContent">

                        <!-- App Settings Tab -->
                        <div class="tab-pane fade show active" id="app-settings" role="tabpanel">
                            <?php
                            // Include the app settings tab content
                            require_once ROOTPATH . 'plugins/Tracebit/Views/settings/tabs/app_settings.php';
                            ?>
                        </div>

                        <!-- Web Settings Tab -->
                        <div class="tab-pane fade" id="web-settings" role="tabpanel">
                            <?php
                            // Include the web settings tab content
                            require_once ROOTPATH . 'plugins/Tracebit/Views/settings/tabs/web_settings.php';
                            ?>
                        </div>

                        <!-- Break Settings Tab -->
                        <div class="tab-pane fade" id="break-settings" role="tabpanel">
                            <?php
                            // Include the break settings tab content
                            require_once ROOTPATH . 'plugins/Tracebit/Views/settings/tabs/break_settings.php';
                            ?>
                        </div>

                        <!-- Weekend Settings Tab -->
                        <div class="tab-pane fade" id="weekend-settings" role="tabpanel">
                            <?php
                            // Include the weekend settings tab content
                            require_once ROOTPATH . 'plugins/Tracebit/Views/settings/tabs/weekend_settings.php';
                            ?>
                        </div>

                        <!-- Holidays Settings Tab -->
                        <div class="tab-pane fade" id="holidays-settings" role="tabpanel">
                            <?php
                            // Include the holidays settings tab content
                            require_once ROOTPATH . 'plugins/Tracebit/Views/settings/tabs/holidays_settings.php';
                            ?>
                        </div>
                    </div>

                   
                </div>

            </div>
        </div>
    </div>
</div>


<script type="text/javascript">
    $(document).ready(function () {

        // Handle form submissions with AJAX
        $('form[id$="-settings-form"]').on('submit', function(e) {
            e.preventDefault();

            console.log('Form submission intercepted by JavaScript');

            var form = $(this);
            var formData = form.serialize();
            var formAction = form.attr('action');

            console.log('Form action:', formAction);
            console.log('Form data:', formData);

            $.ajax({
                url: formAction,
                type: 'POST',
                data: formData,
                dataType: 'json',
                beforeSend: function() {
                    console.log('AJAX request starting...');
                    form.find('button[type="submit"]').prop('disabled', true);
                },
                success: function(response) {
                    console.log('AJAX success:', response);
                    if (response.success) {
                        appAlert.success(response.message);
                    } else {
                        appAlert.error(response.message);
                    }
                },
                error: function(xhr, status, error) {
                    console.log('AJAX error:', status, error);
                    console.log('Response text:', xhr.responseText);
                    appAlert.error('An error occurred while saving settings');
                },
                complete: function() {
                    console.log('AJAX request completed');
                    form.find('button[type="submit"]').prop('disabled', false);
                }
            });
        });

        // Initialize feather icons
        feather.replace();
    });

    function initializeDefaults() {
        if (confirm('This will initialize all default settings. Are you sure?')) {
            $.ajax({
                url: '<?php echo get_uri("tracebit/tracker_settings/initialize_defaults"); ?>',
                type: 'POST',
                dataType: 'json',
                beforeSend: function() {
                    $('.btn:contains("Initialize Defaults")').prop('disabled', true);
                },
                success: function(response) {
                    if (response.success) {
                        appAlert.success(response.message);
                        location.reload();
                    } else {
                        appAlert.error(response.message);
                    }
                },
                error: function() {
                    appAlert.error('An error occurred while initializing settings');
                },
                complete: function() {
                    $('.btn:contains("Initialize Defaults")').prop('disabled', false);
                }
            });
        }
    }
</script>

<script type="text/javascript">
    "use strict";

    $(document).ready(function () {
        $("#tracker-settings-form").appForm({
            isModal: false,
            onSuccess: function (result) {
                appAlert.success(result.message, {duration: 10000});
            }
        });

        // Only initialize dropzone if the form exists
        if ($("#tracker-settings-form").length) {
            var uploadUrl = "<?php echo get_uri("tracebit/tracker_settings/upload_file"); ?>";
            var validationUrl = "<?php echo get_uri("tracebit/tracker_settings/validate_demo_file"); ?>";

            var dropzone = attachDropzoneWithForm("#tracker-settings-form", uploadUrl, validationUrl, {maxFiles: 1});
        }
    });
</script>
