<?php tracker_load_css(array("assets/css/tracker_styles.css")); ?>
<div id="page-content" class="page-wrapper clearfix">
    <div class="card">
        <div class="page-title clearfix">
            <h1>Invalid App Detections</h1>
            <div class="title-button-group">
                <a href="#" class="btn btn-default" id="btn-refresh-data"><i class="fa fa-refresh"></i> Refresh</a>
            </div>
        </div>

        <div class="table-responsive">
            <table id="invalid-apps-table" class="display" width="100%">
            </table>
        </div>
    </div>

    <!-- Stats Cards -->
    <div class="row">
        <div class="col-md-3">
            <div class="card dashboard-icon-widget">
                <div class="card-body">
                    <div class="widget-icon bg-danger">
                        <i class="fa fa-exclamation-triangle"></i>
                    </div>
                    <div class="widget-details">
                        <h1 id="total-detections">0</h1>
                        <span class="text-muted">Total Detections</span>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card dashboard-icon-widget">
                <div class="card-body">
                    <div class="widget-icon bg-warning">
                        <i class="fa fa-users"></i>
                    </div>
                    <div class="widget-details">
                        <h1 id="affected-users">0</h1>
                        <span class="text-muted">Affected Users</span>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card dashboard-icon-widget">
                <div class="card-body">
                    <div class="widget-icon bg-primary">
                        <i class="fa fa-desktop"></i>
                    </div>
                    <div class="widget-details">
                        <h1 id="unique-apps">0</h1>
                        <span class="text-muted">Unique Applications</span>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card dashboard-icon-widget">
                <div class="card-body">
                    <div class="widget-icon bg-success">
                        <i class="fa fa-check-circle"></i>
                    </div>
                    <div class="widget-details">
                        <h1 id="resolved-issues">0</h1>
                        <span class="text-muted">Resolved Issues</span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Charts -->
    <div class="row">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h4>Detections Over Time</h4>
                </div>
                <div class="card-body">
                    <canvas id="detections-chart" style="height:250px;"></canvas>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h4>Top Detected Applications</h4>
                </div>
                <div class="card-body">
                    <canvas id="apps-chart" style="height:250px;"></canvas>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Details Modal -->
<div id="app-details-modal" class="modal fade">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Detection Details</h4>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>App Name</label>
                            <div id="modal-app-name" class="form-control-static"></div>
                        </div>
                        <div class="form-group">
                            <label>User</label>
                            <div id="modal-user-name" class="form-control-static"></div>
                        </div>
                        <div class="form-group">
                            <label>Detection Time</label>
                            <div id="modal-detection-time" class="form-control-static"></div>
                        </div>
                        <div class="form-group">
                            <label>Suspicion Score</label>
                            <div id="modal-suspicion-score" class="form-control-static"></div>
                        </div>
                        <div class="form-group">
                            <label>Project</label>
                            <div id="modal-project" class="form-control-static"></div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Status</label>
                            <select id="modal-status" class="form-control">
                                <option value="0">Unresolved</option>
                                <option value="1">Resolved</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Action Taken</label>
                            <select id="modal-action" class="form-control">
                                <option value="none">None</option>
                                <option value="warning">Warning Issued</option>
                                <option value="monitoring">Increased Monitoring</option>
                                <option value="meeting">Meeting Scheduled</option>
                                <option value="disciplinary">Disciplinary Action</option>
                                <option value="permitted">Application Permitted</option>
                                <option value="other">Other</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Notes</label>
                            <textarea id="modal-notes" class="form-control" rows="4"></textarea>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <h5>App Details</h5>
                            </div>
                            <div class="card-body">
                                <pre id="modal-app-details" style="max-height: 200px; overflow-y: auto;"></pre>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <input type="hidden" id="modal-record-id">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-danger" id="btn-delete-record">Delete</button>
                <button type="button" class="btn btn-primary" id="btn-save-record">Save changes</button>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
    $(document).ready(function () {
        // Initialize DataTable
        var dataTable = $("#invalid-apps-table").DataTable({
            serverSide: true,
            processing: true,
            responsive: true,
            ajax: {
                url: "<?php echo get_uri('tracebit/invalid_app/admin_get_invalid_apps'); ?>",
                type: "POST",
                data: function (d) {
                    d.csrf_token = $('meta[name="csrf_token"]').attr('content');
                }
            },
            columns: [
                {title: "ID", data: "id"},
                {title: "App Name", data: "app_name"},
                {title: "User", data: null, render: function (data) {
                    return data.first_name + ' ' + data.last_name;
                }},
                {title: "Detection Time", data: "detection_time"},
                {title: "Suspicion Score", data: "suspicion_score", render: function (data) {
                    var scoreClass = "bg-success";
                    if (data > 5) scoreClass = "bg-warning";
                    if (data > 7) scoreClass = "bg-danger";

                    return '<span class="badge ' + scoreClass + '">' + data + '</span>';
                }},
                {title: "Project", data: "project_title"},
                {title: "Status", data: "resolved", render: function (data) {
                    return data == 1 ?
                        '<span class="badge bg-success">Resolved</span>' :
                        '<span class="badge bg-warning">Unresolved</span>';
                }},
                {title: "Action", data: "action_taken"},
                {title: "", data: "id", orderable: false, render: function (data) {
                    return '<button class="btn btn-default btn-sm view-details" data-id="' + data + '"><i class="fa fa-eye"></i> Details</button>';
                }}
            ],
            order: [[3, "desc"]]
        });

        // Refresh data button
        $("#btn-refresh-data").on("click", function (e) {
            e.preventDefault();
            dataTable.ajax.reload();
            loadStatistics();
        });

        // View details click
        $("#invalid-apps-table").on("click", ".view-details", function () {
            var id = $(this).data("id");

            // Find the record in the DataTable
            var data = dataTable.rows().data();
            var record = null;

            for (var i = 0; i < data.length; i++) {
                if (data[i].id == id) {
                    record = data[i];
                    break;
                }
            }

            if (record) {
                // Populate modal
                $("#modal-record-id").val(record.id);
                $("#modal-app-name").text(record.app_name);
                $("#modal-user-name").text(record.first_name + ' ' + record.last_name);
                $("#modal-detection-time").text(record.detection_time);
                $("#modal-suspicion-score").text(record.suspicion_score);
                $("#modal-project").text(record.project_title || 'N/A');
                $("#modal-status").val(record.resolved);
                $("#modal-action").val(record.action_taken || 'none');
                $("#modal-notes").val(record.notes || '');

                // Parse and display app details
                try {
                    var details = record.app_details;
                    if (typeof details === 'string') {
                        details = JSON.parse(details);
                    }
                    $("#modal-app-details").text(JSON.stringify(details, null, 2));
                } catch (e) {
                    $("#modal-app-details").text(record.app_details || 'No details available');
                }

                // Show modal
                $("#app-details-modal").modal("show");
            }
        });

        // Save record changes
        $("#btn-save-record").on("click", function () {
            var id = $("#modal-record-id").val();
            var resolved = $("#modal-status").val();
            var action = $("#modal-action").val();
            var notes = $("#modal-notes").val();

            $.ajax({
                url: "<?php echo get_uri('tracebit/invalid_app/update_invalid_app_status'); ?>",
                type: "POST",
                data: {
                    id: id,
                    resolved: resolved,
                    action_taken: action,
                    notes: notes,
                    csrf_token: $('meta[name="csrf_token"]').attr('content')
                },
                success: function (response) {
                    if (response.success) {
                        $("#app-details-modal").modal("hide");
                        dataTable.ajax.reload();
                        appAlert.success("Record updated successfully", {duration: 3000});
                        loadStatistics();
                    } else {
                        appAlert.error("Error updating record: " + response.message, {duration: 5000});
                    }
                },
                error: function () {
                    appAlert.error("An error occurred while updating the record", {duration: 5000});
                }
            });
        });

        // Delete record
        $("#btn-delete-record").on("click", function () {
            var id = $("#modal-record-id").val();

            if (confirm("Are you sure you want to delete this record? This cannot be undone.")) {
                $.ajax({
                    url: "<?php echo get_uri('tracebit/invalid_app/delete_invalid_app'); ?>",
                    type: "POST",
                    data: {
                        id: id,
                        csrf_token: $('meta[name="csrf_token"]').attr('content')
                    },
                    success: function (response) {
                        if (response.success) {
                            $("#app-details-modal").modal("hide");
                            dataTable.ajax.reload();
                            appAlert.success("Record deleted successfully", {duration: 3000});
                            loadStatistics();
                        } else {
                            appAlert.error("Error deleting record: " + response.message, {duration: 5000});
                        }
                    },
                    error: function () {
                        appAlert.error("An error occurred while deleting the record", {duration: 5000});
                    }
                });
            }
        });

        // Load statistics and charts
        function loadStatistics() {
            $.ajax({
                url: "<?php echo get_uri('tracebit/invalid_app/get_statistics'); ?>",
                type: "GET",
                data: {
                    days: 30,
                    csrf_token: $('meta[name="csrf_token"]').attr('content')
                },
                success: function (response) {
                    if (response.success) {
                        var stats = response.data;

                        // Update counters
                        $("#total-detections").text(stats.total);
                        $("#affected-users").text(stats.by_user.length);
                        $("#unique-apps").text(stats.by_app.length);
                        $("#resolved-issues").text(stats.resolved_count || 0);

                        // Update charts
                        updateDetectionsChart(stats.by_day);
                        updateAppsChart(stats.by_app);
                    }
                }
            });
        }

        // Initialize charts
        var detectionsChart, appsChart;

        function updateDetectionsChart(data) {
            var labels = [];
            var values = [];

            // Sort by date ascending
            data.sort(function(a, b) {
                return new Date(a.date) - new Date(b.date);
            });

            // Extract data
            for (var i = 0; i < data.length; i++) {
                labels.push(data[i].date);
                values.push(data[i].count);
            }

            // Create or update chart
            if (detectionsChart) {
                detectionsChart.data.labels = labels;
                detectionsChart.data.datasets[0].data = values;
                detectionsChart.update();
            } else {
                var ctx = document.getElementById("detections-chart").getContext("2d");
                detectionsChart = new Chart(ctx, {
                    type: 'line',
                    data: {
                        labels: labels,
                        datasets: [{
                            label: 'Detections',
                            data: values,
                            borderColor: '#007bff',
                            backgroundColor: 'rgba(0, 123, 255, 0.1)',
                            borderWidth: 2,
                            fill: true
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        scales: {
                            y: {
                                beginAtZero: true,
                                ticks: {
                                    precision: 0
                                }
                            }
                        }
                    }
                });
            }
        }

        function updateAppsChart(data) {
            var labels = [];
            var values = [];
            var backgroundColors = [
                '#007bff', '#28a745', '#ffc107', '#dc3545', '#17a2b8',
                '#6610f2', '#fd7e14', '#20c997', '#6c757d', '#343a40'
            ];

            // Sort by count descending
            data.sort(function(a, b) {
                return b.count - a.count;
            });

            // Extract data (top 10)
            var maxItems = Math.min(data.length, 10);
            for (var i = 0; i < maxItems; i++) {
                labels.push(data[i].app_name);
                values.push(data[i].count);
            }

            // Create or update chart
            if (appsChart) {
                appsChart.data.labels = labels;
                appsChart.data.datasets[0].data = values;
                appsChart.update();
            } else {
                var ctx = document.getElementById("apps-chart").getContext("2d");
                appsChart = new Chart(ctx, {
                    type: 'bar',
                    data: {
                        labels: labels,
                        datasets: [{
                            label: 'Detections',
                            data: values,
                            backgroundColor: backgroundColors
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        scales: {
                            y: {
                                beginAtZero: true,
                                ticks: {
                                    precision: 0
                                }
                            }
                        }
                    }
                });
            }
        }

        // Function to view detection details
        function viewDetails(id) {
            $.ajax({
                url: '<?= base_url('tracebit/invalid_app/admin_get_invalid_apps') ?>',
                type: 'POST',
                data: { id: id },
                dataType: 'json',
                success: function(response) {
                    if (response.success && response.data.length > 0) {
                        const record = response.data[0];

                        // Parse app details to show more information
                        let appDetailsHtml = '';
                        try {
                            const appDetails = JSON.parse(record.app_details || '{}');

                            // Show matched terms if available
                            if (appDetails.matchedTerms && appDetails.matchedTerms.length > 0) {
                                appDetailsHtml += '<div class="p-2 mb-2 bg-light"><strong>Matched Terms:</strong><br>';
                                appDetails.matchedTerms.forEach(match => {
                                    appDetailsHtml += `• ${match.term} (${match.category})<br>`;
                                });
                                appDetailsHtml += '</div>';
                            }

                            // Show system info if available
                            if (appDetails.system_info) {
                                appDetailsHtml += '<div class="p-2 mb-2 bg-light"><strong>System Information:</strong><br>';
                                const sysInfo = appDetails.system_info;
                                appDetailsHtml += `Platform: ${sysInfo.platform || 'N/A'}<br>`;
                                appDetailsHtml += `User Agent: ${sysInfo.userAgent || 'N/A'}<br>`;
                                appDetailsHtml += '</div>';
                            }

                            // Add formatted raw data
                            appDetailsHtml += '<div class="p-2 mb-2 bg-light small"><strong>Raw Detection Data:</strong><br>';
                            appDetailsHtml += '<pre>' + JSON.stringify(appDetails, null, 2) + '</pre></div>';
                        } catch (e) {
                            appDetailsHtml = '<div class="alert alert-warning">Could not parse app details: ' + e.message + '</div>';
                            appDetailsHtml += '<pre>' + record.app_details + '</pre>';
                        }

                        // Show enhanced modal
                        $("#app-details-content").html(appDetailsHtml);
                        $("#detection-details-modal").modal("show");
                        $("#detection-id").val(id);
                        $("#app-name").text(record.app_name);
                        $("#detection-time").text(record.detection_time);
                        $("#user-name").text(record.user_name);
                        $("#notes-field").val(record.notes || '');

                        // Set button states
                        $("#btn-resolve").text(record.resolved == 1 ? 'Mark as Active' : 'Mark as Resolved');
                        $("#btn-resolve").data('status', record.resolved);
                    } else {
                        appAlert.error("Failed to load detection details.");
                    }
                },
                error: function() {
                    appAlert.error("Error loading detection details. Please try again.");
                }
            });
        }

        // Load initial statistics
        loadStatistics();
    });
</script>
