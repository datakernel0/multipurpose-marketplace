<?php

namespace Tracebit;

use App\Libraries\BasePluginServiceProvider;
use CodeIgniter\Events\Events;

/**
 * Tracebit Plugin Service Provider
 *
 * This class handles the registration of Tracebit plugin services,
 * routes, and other components.
 */
class TracebitServiceProvider extends BasePluginServiceProvider {

    /**
     * Register the plugin's services
     *
     * @return void
     */
    public function register() {
        // Register plugin configuration
        // This is a good place to register config classes, models, libraries, etc.
    }

    /**
     * Boot the plugin's services
     *
     * @return void
     */
    public function boot() {
        $this->registerHelpers();
        $this->registerEvents();
    }

    /**
     * Register plugin events
     *
     * @return void
     */
    public function registerEvents() {
        // Register plugin-specific events
        Events::on('app_init', function() {
            // Initialize plugin components
        });
    }

    /**
     * Register plugin helpers
     *
     * @return void
     */
    public function registerHelpers() {
        // Load tracker helper
        helper('tracker_general');
    }

    /**
     * Register plugin routes
     *
     * @param \CodeIgniter\Router\RouteCollection $routes
     * @return void
     */
    public function registerRoutes($routes) {
        // Load plugin routes
        if (file_exists($this->getPluginPath() . 'Config/Routes.php')) {
            require_once $this->getPluginPath() . 'Config/Routes.php';
        }
    }
}
