<?php

namespace Tracebit\Models;

/**
 * Optimized Native App Model
 * Secure authentication, performance monitoring, and proper caching
 */
class Native_app_model extends Tracker_base_model {

    protected $table = 'users';
    protected $cache_ttl = 900; // 15 minutes for user data

    public function __construct() {
        parent::__construct('users');
    }

    /**
     * Secure authentication for native app
     * Rate limiting and proper password verification
     */
    public function authenticate_for_native($email, $password) {
        $start_time = microtime(true);

        try {
            // Input validation
            if (empty($email) || empty($password)) {
                throw new \InvalidArgumentException('Email and password are required');
            }

            // Rate limiting check (implement with cache)
            $rate_limit_key = "auth_attempts_" . md5($email);
            $attempts = $this->cache->get($rate_limit_key) ?? 0;

            if ($attempts >= 5) {
                throw new \RuntimeException('Too many authentication attempts. Please try again later.');
            }

            // Secure query with prepared statement
            $sql = "SELECT id, user_type, client_id, password, first_name, last_name, email
                    FROM " . $this->db->prefixTable('users') . "
                    WHERE email = ?
                    AND status = 'active'
                    AND deleted = 0
                    AND disable_login = 0";

            $query = $this->db->query($sql, [$email]);

            if (!$query) {
                return $this->handle_db_error('Authentication query failed');
            }

            $users = $query->getResult();

            if (empty($users)) {
                // Increment failed attempts
                $this->cache->save($rate_limit_key, $attempts + 1, 900); // 15 min lockout
                return false;
            }

            // Verify password for each user (handle multiple users with same email)
            foreach ($users as $user_info) {
                if ($this->verify_password($user_info, $password)) {
                    // Clear failed attempts on successful login
                    $this->cache->delete($rate_limit_key);

                    // Update last login
                    $this->update_last_login($user_info->id);

                    $this->monitor_query_performance('authenticate_for_native', $start_time);

                    // Return user info without password
                    unset($user_info->password);
                    return $user_info;
                }
            }

            // Increment failed attempts
            $this->cache->save($rate_limit_key, $attempts + 1, 900);
            return false;

        } catch (\Exception $e) {
            return false;
        }
    }

    /**
     * Enhanced user_info function with comprehensive user data for profile modal
     * Returns detailed user information including profile fields, employment details, and settings
     */
    public function user_info($user_id) {
        $start_time = microtime(true);

        try {
            // Validate user ID
            if (!is_numeric($user_id) || $user_id <= 0) {
                throw new \InvalidArgumentException('Invalid user ID');
            }

            // Check cache first
            $cache_key = $this->cache_prefix . "user_info_{$user_id}";
            if ($this->enable_query_cache) {
                $cached_result = $this->cache->get($cache_key);
                if ($cached_result !== null) {
                    return $cached_result;
                }
            }

            // Enhanced query to get comprehensive user information
            $sql = "SELECT
                        u.id,
                        u.first_name,
                        u.last_name,
                        CONCAT(u.first_name, ' ', u.last_name) as name,
                        u.email,
                        u.job_title,
                        u.job_title as designation,
                        u.job_title as position,
                        u.job_title as role,
                        u.phone,
                        u.phone as mobile,
                        u.phone as contact,
                        u.address,
                        u.created_at,
                        u.created_at as join_date,
                        u.created_at as joining_date,
                        u.user_type,
                        u.status,
                        u.note,
                        u.image,
                        u.gender,
                        u.alternative_address,

                        -- Try to get client/company information
                        c.company_name,
                        c.company_name as company,
                        c.company_name as organization,

                        -- Try to get team/department information
                        t.title as team_name,
                        t.title as department,
                        t.title as dept,
                        t.title as division,

                        -- Get employment details
                        CASE
                            WHEN u.user_type = 'staff' THEN 'Employee'
                            WHEN u.user_type = 'client' THEN 'Client'
                            WHEN u.job_title IS NOT NULL AND u.job_title != '' THEN u.job_title
                            ELSE 'Employee'
                        END as calculated_designation

                    FROM " . $this->db->prefixTable('users') . " u
                    LEFT JOIN " . $this->db->prefixTable('clients') . " c ON u.client_id = c.id
                    LEFT JOIN " . $this->db->prefixTable('project_members') . " pm ON pm.user_id = u.id
                    LEFT JOIN " . $this->db->prefixTable('projects') . " t ON t.id = pm.project_id
                    WHERE u.id = ?
                    AND u.deleted = 0
                    LIMIT 1";

            $query = $this->db->query($sql, [$user_id]);

            if (!$query) {
                throw new \RuntimeException('Database query failed: ' . $this->db->error()['message']);
            }

            $user_data = $query->getRow();

            if (!$user_data) {
                return false;
            }

            // Enhance user data with calculated fields and formatting
            $enhanced_user_data = $this->enhance_user_data($user_data);

            // Get additional user statistics and activity data
            $user_stats = $this->get_user_activity_stats($user_id);

            // Merge stats with user data
            $final_user_data = array_merge((array)$enhanced_user_data, $user_stats);

            // Convert back to object for consistency
            $result = [(object)$final_user_data];

            // Cache the result
            if ($this->enable_query_cache) {
                $this->cache->save($cache_key, $result, $this->cache_ttl);
            }

            $this->monitor_query_performance('user_info', $start_time);

            return $result;

        } catch (\Exception $e) {
            return [];
        }
    }

    /**
     * Secure password verification
     */
    private function verify_password($user_info, $password) {
        try {
            // Modern password verification (bcrypt) or legacy MD5
            $is_valid = (strlen($user_info->password) === 60 && password_verify($password, $user_info->password))
                       || $user_info->password === md5($password);

            if ($is_valid) {
                // Execute post-signin hooks
                try {
                    app_hooks()->do_action('app_hook_after_signin');
                } catch (\Exception $ex) {
                    // Post-signin hook error handled silently
                }

                // If using legacy MD5, recommend password update
                if ($user_info->password === md5($password)) {
                    // User is using legacy MD5 password
                }
            }

            return $is_valid;

        } catch (\Exception $e) {
            return false;
        }
    }

    /**
     * Optimized sync function with better upsert logic for desktop app and API
     */
    public function synced($attendance, $performance, $user_id) {
        $start_time = microtime(true);

        try {
            // Enhanced validation
            if (!is_numeric($user_id) || $user_id <= 0) {
                throw new \InvalidArgumentException('Invalid user ID');
            }

            // Debug: Log first few items of attendance data
            if (is_array($attendance) && !empty($attendance)) {
                // First attendance item logged
                if (count($attendance) > 1) {
                    // Second attendance item logged
                }
            }

            // Validate arrays
            $attendance = is_array($attendance) ? $attendance : [];
            $performance = is_array($performance) ? $performance : [];



            $this->db->transStart();

            $sync_stats = [
                'attendance_inserted' => 0,
                'attendance_updated' => 0,
                'performance_inserted' => 0,
                'performance_updated' => 0
            ];

            // Process attendance with improved upsert logic
            if (!empty($attendance)) {
                log_message('info', "[TRACKER] About to call sync_attendance_improved with " . count($attendance) . " records");
                $sync_stats = array_merge($sync_stats, $this->sync_attendance_improved($attendance, $user_id));
            } else {
                log_message('warning', "[TRACKER] No attendance data to process");
            }

            // Process performance with improved upsert logic
            if (!empty($performance)) {
                // Debug: Log first few items of performance data
                if (count($performance) > 0) {
                    // First performance item logged
                    if (count($performance) > 1) {
                        // Second performance item logged
                    }
                }

                $perf_stats = $this->sync_performance_improved($performance, $user_id);
                $sync_stats['performance_inserted'] += $perf_stats['inserted'];
                $sync_stats['performance_updated'] += $perf_stats['updated'];

                // sync_performance_improved completed
            } else {
                // No performance data to process
            }

            $this->db->transComplete();

            if (!$this->db->transStatus()) {
                throw new \RuntimeException('Transaction failed');
            }

            // Clear relevant cache
            $this->clear_cache_pattern("attendance_user_{$user_id}");
            $this->clear_cache_pattern("performance_user_{$user_id}");

            // Get current day attendance for response
            $attendance_data = $this->get_current_day_attendance($user_id);

            $this->monitor_query_performance('synced', $start_time);

            return [
                'success' => true,
                'attendanceData' => $attendance_data,
                'syncStats' => $sync_stats,
                'message' => 'Data synced successfully'
            ];

        } catch (\Exception $e) {
            $this->db->transRollback();

            return [
                'success' => false,
                'error' => 'Sync failed: ' . $e->getMessage(),
                'attendanceData' => []
            ];
        }
    }

    /**
     * Improved attendance sync with proper upsert logic
     */
    private function sync_attendance_improved($attendance, $user_id) {
        $attendance_table = $this->db->prefixTable('tracker_attendance');
        $inserted = 0;
        $updated = 0;



        // Group by unique key (user_id, inTime, project) for efficient processing
        $grouped_data = [];
        $skipped_count = 0;
        $processed_count = 0;

        foreach ($attendance as $index => $row) {
            // Debug: Log each row being processed

            // Check if $row is an object or array
            if (is_array($row)) {
                $row = (object)$row; // Convert array to object for consistency
            }

            // Debug: Check what type $row is

            // More detailed validation with debugging
            $inTime_empty = empty($row->inTime ?? null);
            $user_id_empty = empty($row->user_id ?? null);

            

            // Validate required fields
            if ($inTime_empty || $user_id_empty) {
                $skipped_count++;
                continue;
            }

            // Security check with detailed logging
            $row_user_id = (int)($row->user_id ?? 0);
            $expected_user_id = (int)$user_id;

            if ($row_user_id !== $expected_user_id) {
                $skipped_count++;
                continue;
            }

            $project = $row->project ?? '';
            $key = $user_id . '_' . $row->inTime . '_' . $project;



            // Keep the latest record if there are duplicates
            $grouped_data[$key] = [
                'user_id' => (int)$row->user_id,
                'inTime' => (int)$row->inTime,
                'outTime' => isset($row->outTime) ? (int)$row->outTime : null,
                'project' => $project,
                'note' => $row->note ?? '0',
                'timezone' => (int)($row->timezone ?? 0),
                'sign' => in_array($row->sign ?? '+', ['+', '-']) ? $row->sign : '+',
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s')
            ];

            $processed_count++;
        }

        // Attendance processing summary

        if (empty($grouped_data)) {
            return ['attendance_inserted' => 0, 'attendance_updated' => 0];
        }

        // Use MySQL's INSERT ... ON DUPLICATE KEY UPDATE for efficient upsert
        $batch_data = array_values($grouped_data);
        $chunk_size = 50;
        $chunks = array_chunk($batch_data, $chunk_size);

        foreach ($chunks as $chunk) {
            $fields = array_keys($chunk[0]);
            $placeholders = '(' . str_repeat('?,', count($fields) - 1) . '?)';
            $values_clause = str_repeat($placeholders . ',', count($chunk) - 1) . $placeholders;

            // Construct ON DUPLICATE KEY UPDATE clause
            $update_fields = ['outTime', 'note', 'timezone', 'sign', 'updated_at'];
            $update_clause = implode(', ', array_map(function($field) {
                return "`$field` = VALUES(`$field`)";

            }, $update_fields));

            $sql = "INSERT INTO $attendance_table
                    (`" . implode('`, `', $fields) . "`)
                    VALUES $values_clause
                    ON DUPLICATE KEY UPDATE
                    $update_clause,
                    `id` = LAST_INSERT_ID(`id`)";


            $binds = [];
            foreach ($chunk as $row) {
                foreach ($fields as $field) {
                    $binds[] = $row[$field] ?? null;
                }
            }

            $result = $this->db->query($sql, $binds);

            if (!$result) {
                $error = $this->db->error();
                error_log( print_r( "db error from model - $error", true ) );
                throw new \RuntimeException('Attendance upsert failed: ' . $error['message']);
            }

            // Track insert/update counts (approximate)
            $affected_rows = $this->db->affectedRows();
            $inserted += $affected_rows; // This is approximate for upsert operations
        }

        return ['attendance_inserted' => $inserted, 'attendance_updated' => 0];
    }

    /**
     * Improved performance sync with proper upsert logic
     */
    private function sync_performance_improved($performance, $user_id) {
        $performance_table = $this->db->prefixTable('tracker_performance');
        $inserted = 0;
        $updated = 0;

        // Group by unique key (user_id, timestamp) for efficient processing
        $grouped_data = [];
        $skipped_count = 0;
        $processed_count = 0;

        foreach ($performance as $index => $row) {
           
            // Check if $row is an object or array
            if (is_array($row)) {
                $row = (object)$row; // Convert array to object for consistency
            }

            // More detailed validation with debugging
            $timestamp_empty = empty($row->timestamp ?? null);
            $user_id_empty = empty($row->user_id ?? null);

            // Validate required fields
            if ($timestamp_empty || $user_id_empty) {                
                $skipped_count++;
                continue;
            }

            // Security check with detailed logging
            $row_user_id = (int)($row->user_id ?? 0);
            $expected_user_id = (int)$user_id;

            if ($row_user_id !== $expected_user_id) { 
                $skipped_count++;
                continue;
            }

            $key = $user_id . '_' . $row->timestamp;

            // Keep the latest record if there are duplicates
            $grouped_data[$key] = [
                'user_id' => (int)$row->user_id,
                'timestamp' => (int)$row->timestamp,
                'takenTime' => $row->takenTime ?? date('Y-m-d H:i:s'),
                'performance' => (int)($row->performance ?? 0),
                'project' => $row->project ?? '',
                'timezone' => (int)($row->timezone ?? 0),
                'sign' => in_array($row->sign ?? '+', ['+', '-']) ? $row->sign : '+',
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s')
            ];

            $processed_count++;

        }

        if (empty($grouped_data)) {            
            return ['inserted' => 0, 'updated' => 0];
        }

        // Use MySQL's INSERT ... ON DUPLICATE KEY UPDATE for efficient upsert
        $batch_data = array_values($grouped_data);
        $chunk_size = 50;
        $chunks = array_chunk($batch_data, $chunk_size);

        foreach ($chunks as $chunk) {
            $fields = array_keys($chunk[0]);
            $placeholders = '(' . str_repeat('?,', count($fields) - 1) . '?)';
            $values_clause = str_repeat($placeholders . ',', count($chunk) - 1) . $placeholders;

            // Construct ON DUPLICATE KEY UPDATE clause
            $update_fields = ['takenTime', 'performance', 'project', 'timezone', 'sign', 'updated_at'];
            $update_clause = implode(', ', array_map(function($field) {
                return "`$field` = VALUES(`$field`)";

            }, $update_fields));

            $sql = "INSERT INTO $performance_table
                    (`" . implode('`, `', $fields) . "`)
                    VALUES $values_clause
                    ON DUPLICATE KEY UPDATE
                    $update_clause,
                    `id` = LAST_INSERT_ID(`id`)";


            $binds = [];
            foreach ($chunk as $row) {
                foreach ($fields as $field) {
                    $binds[] = $row[$field] ?? null;
                }
            }

            $result = $this->db->query($sql, $binds);

            if (!$result) {
                $error = $this->db->error();
                throw new \RuntimeException('Performance upsert failed: ' . $error['message']);
            }

            // Track insert/update counts (approximate)
            $affected_rows = $this->db->affectedRows();
            $inserted += $affected_rows; // This is approximate for upsert operations
        }

        return ['inserted' => $inserted, 'updated' => 0];
    }

    /**
     * Get current day attendance data
     */
    private function get_current_day_attendance($user_id) {
        $sql = "SELECT inTime, outTime, project, note, user_id
                FROM " . $this->db->prefixTable('tracker_attendance') . "
                WHERE user_id = ?
                AND DATE(FROM_UNIXTIME(inTime / 1000)) = CURDATE()
                AND deleted = 0
                ORDER BY inTime DESC";

        $query = $this->db->query($sql, [$user_id]);
        return $query ? $query->getResult() : [];
    }

    /**
     * Create screenshot with validation
     */
    public function createScreenshot($data) {
        $start_time = microtime(true);

        try {
            $rules = [
                'project_id' => 'permit_empty|integer',
                'user_id' => 'required|integer',
                'path' => 'required|max_length[500]'
            ];

            $validated_data = $this->validate_input($data, $rules);

            // Additional validation
            if (!$this->is_valid_screenshot_path($validated_data['path'])) {
                throw new \InvalidArgumentException('Invalid screenshot path');
            }

            $insert_data = [
                'project_id' => $validated_data['project_id'] ?? null,
                'user_id' => $validated_data['user_id'],
                'path' => $validated_data['path'],
                'title' => $validated_data['title'] ?? null,
                'created_at' => date('Y-m-d H:i:s')
            ];

            $table = $this->db->table($this->db->prefixTable('tracker_screenshots'));
            $result = $table->insert($insert_data);

            if ($result) {
                // Clear relevant cache
                $this->clear_cache_pattern("screenshots_user_{$validated_data['user_id']}");

                $this->monitor_query_performance('createScreenshot', $start_time);
                return $this->db->insertID();
            }

            return $this->handle_db_error('Screenshot creation failed');

        } catch (\Exception $e) {
            return false;
        }
    }

    /**
     * Get settings data with caching
     */
    public function getSettingsData() {
        $cache_key = $this->cache_prefix . 'settings_all';


        $sql = "SELECT setting_name, setting_value, type
                FROM " . $this->db->prefixTable('tracker_settings') . "
                WHERE deleted = 0
                ORDER BY setting_name";

        $query = $this->db->query($sql);


        if ($query) {
            $result = $query->getResult();
            if ($this->enable_query_cache) {
                $this->cache->save($cache_key, $result, 3600); // 1 hour cache
            }

            return $result;
        }

        return $this->handle_db_error('Failed to retrieve settings');
    }

    /**
     * Update tracker settings for desktop app
     */
    public function updateTrackerSettings($user_id, $settings_data) {
        $start_time = microtime(true);

        try {
            // Validate user ID
            if (!is_numeric($user_id) || $user_id <= 0) {
                throw new \InvalidArgumentException('Invalid user ID');
            }

            // Validate settings data
            if (empty($settings_data) || !is_array($settings_data)) {
                throw new \InvalidArgumentException('Invalid settings data');
            }

            // Load the Tracker_settings_model
            $tracker_settings_model = model("Tracebit\Models\Tracker_settings_model");

            $this->db->transStart();

            $updated_settings = [];
            $allowed_settings = [
                // Core tracking settings
                'screenshot_interval',
                'idle_timeout',
                'working_hours_start',
                'working_hours_end',
                'timezone_offset',

                // Feature toggles
                'enable_screenshots',
                'enable_activity_tracking',
                'enable_idle_detection',
                'productivity_tracking',

                // Screenshot settings
                'screenshot_quality',
                'max_screenshot_size',

                // Performance settings
                'performance_threshold',

                // Break and reminder settings
                'break_reminder_interval',
                'auto_break_duration',

                // Desktop app specific settings
                'enable_notifications',
                'minimize_to_tray',
                'start_with_system',
                'auto_sync_interval',

                // Security settings
                'force_screenshot_encryption',
                'max_idle_before_logout',
                'require_checkout_confirmation'
            ];

            foreach ($settings_data as $setting_name => $setting_value) {
                // Validate setting name
                if (!in_array($setting_name, $allowed_settings)) {
                    
                    continue;
                }

                // Validate and sanitize setting value
                $sanitized_value = $this->validateSettingValue($setting_name, $setting_value);

                if ($sanitized_value !== false) {
                    $result = $tracker_settings_model->save_setting($setting_name, $sanitized_value, 'app');

                    if ($result) {
                        $updated_settings[$setting_name] = $sanitized_value;                        
                    }
                }
            }

            $this->db->transComplete();

            if (!$this->db->transStatus()) {
                throw new \RuntimeException('Transaction failed during settings update');
            }

            // Clear settings cache
            $this->clear_cache_pattern('settings_');

            $this->monitor_query_performance('updateTrackerSettings', $start_time);

            return [
                'updated_settings' => $updated_settings,
                'total_updated' => count($updated_settings),
                'user_id' => $user_id
            ];

        } catch (\Exception $e) {
            $this->db->transRollback();
            
            return false;
        }
    }

    /**
     * Get tracker settings optimized for desktop app
     */
    public function getTrackerSettings($user_id) {
        $start_time = microtime(true);

        try {
            // Validate user ID
            if (!is_numeric($user_id) || $user_id <= 0) {
                throw new \InvalidArgumentException('Invalid user ID');
            }


            // Load the Tracker_settings_model
            $tracker_settings_model = model("Tracebit\Models\Tracker_settings_model");

            // Get all app-type settings
            $settings_result = $tracker_settings_model->get_settings_by_type('app_settings');

            // Convert to key-value format for easier consumption by the desktop app
            $settings_array = [];

            if (is_array($settings_result)) {
                foreach ($settings_result as $setting) {
                    $settings_array[$setting->setting_name] = $setting->setting_value;
                }
            }

            // Add default values for missing settings
            $default_settings = [
                // Core tracking settings
                'screenshot_interval' => '300',
                'idle_timeout' => '100',  // Changed from 600 to 100 to match expected value
                'working_hours_start' => '09:00',
                'working_hours_end' => '17:00',
                'timezone_offset' => '0',

                // Feature toggles
                'enable_screenshots' => '1',
                'enable_activity_tracking' => '1',
                'enable_idle_detection' => '1',
                'productivity_tracking' => '1',

                // Screenshot settings
                'screenshot_quality' => '80',
                'max_screenshot_size' => '5242880',

                // Performance settings
                'performance_threshold' => '50',

                // Break and reminder settings
                'break_reminder_interval' => '3600',
                'auto_break_duration' => '900',

                // Desktop app specific settings
                'enable_notifications' => '1',
                'minimize_to_tray' => '1',
                'start_with_system' => '0',
                'auto_sync_interval' => '300',

                // Security settings
                'force_screenshot_encryption' => '0',
                'max_idle_before_logout' => '7200',
                'require_checkout_confirmation' => '1'
            ];

            // Special handling for idle_timeout to ensure it's correctly set
            if (isset($settings_array['idle_timeout'])) {
                log_message('debug', "[TRACKER] Using database value for idle_timeout: {$settings_array['idle_timeout']}");
            } else {                
                $settings_array['idle_timeout'] = $default_settings['idle_timeout'];
            }

            // Apply defaults for other missing settings
            foreach ($default_settings as $key => $default_value) {
                if (!isset($settings_array[$key]) && $key !== 'idle_timeout') { // Skip idle_timeout as it's handled above
                    $settings_array[$key] = $default_value;
                    
                }
            }

            // Temporarily disable caching
            /*
            if ($this->enable_query_cache) {
                $this->cache->save($cache_key, $settings_array, $this->cache_ttl);
            }
            */

            $this->monitor_query_performance('getTrackerSettings', $start_time);
            return $settings_array;

        } catch (\Exception $e) {
            
            return false;
        }
    }

    /**
     * Validate and sanitize setting values
     */
    private function validateSettingValue($setting_name, $setting_value) {
        try {
            switch ($setting_name) {
                case 'screenshot_interval':
                case 'idle_timeout':
                case 'break_reminder_interval':
                case 'auto_break_duration':
                case 'auto_sync_interval':
                case 'max_idle_before_logout':
                    // Must be positive integer (seconds)
                    $value = (int)$setting_value;
                    return ($value > 0 && $value <= 86400) ? (string)$value : false; // Max 24 hours

                case 'timezone_offset':
                    // Must be integer between -12 and +14 (timezone hours)
                    $value = (int)$setting_value;
                    return ($value >= -12 && $value <= 14) ? (string)$value : false;

                case 'screenshot_quality':
                case 'performance_threshold':
                    // Must be integer between 1 and 100
                    $value = (int)$setting_value;
                    return ($value >= 1 && $value <= 100) ? (string)$value : false;

                case 'max_screenshot_size':
                    // Must be positive integer (bytes)
                    $value = (int)$setting_value;
                    return ($value > 0 && $value <= 52428800) ? (string)$value : false; // Max 50MB

                case 'working_hours_start':
                case 'working_hours_end':
                    // Must be valid time format HH:MM
                    if (preg_match('/^([01]?[0-9]|2[0-3]):[0-5][0-9]$/', $setting_value)) {
                        return $setting_value;
                    }
                    return false;

                case 'enable_screenshots':
                case 'enable_activity_tracking':
                case 'enable_idle_detection':
                case 'productivity_tracking':
                case 'enable_notifications':
                case 'minimize_to_tray':
                case 'start_with_system':
                case 'force_screenshot_encryption':
                case 'require_checkout_confirmation':
                    // Must be boolean (convert to 1 or 0)
                    $value = filter_var($setting_value, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);
                    return ($value !== null) ? ($value ? '1' : '0') : false;

                default:
                    // Unknown setting name
                    return false;
            }
        } catch (\Exception $e) {
            // Setting validation error
            return false;
        }
    }

    /**
     * Update last login timestamp
     */
    private function update_last_login($user_id) {
        try {
            $sql = "UPDATE " . $this->db->prefixTable('users') . "
                    SET last_online = NOW()
                    WHERE id = ?";

            $this->db->query($sql, [$user_id]);

            // Clear user cache
            $this->cache->delete($this->cache_prefix . "user_info_{$user_id}");

        } catch (\Exception $e) {
            // Failed to update last login
        }
    }

    /**
     * Validate screenshot path
     */
    private function is_valid_screenshot_path($path) {
        // Basic security checks
        if (empty($path) || strlen($path) > 500) {
            return false;
        }

        // Check for directory traversal
        if (strpos($path, '../') !== false || strpos($path, '..\\') !== false) {
            return false;
        }

        // Check for null bytes
        if (strpos($path, "\0") !== false) {
            return false;
        }

        return true;
    }

    /**
     * Get projects for user with caching
     */
    public function getProjects($user_id) {
        $start_time = microtime(true);

        try {
            $cache_key = $this->cache_prefix . "projects_user_{$user_id}";

            if ($this->enable_query_cache) {
                $cached_result = $this->cache->get($cache_key);
                if ($cached_result !== null) {
                    return $cached_result;
                }
            }

            // Get projects based on user assignments or all projects if admin
            $sql = "SELECT p.id, p.title, p.description, p.start_date, p.deadline, p.status
                    FROM " . $this->db->prefixTable('projects') . " p
                    LEFT JOIN " . $this->db->prefixTable('project_members') . " pm ON p.id = pm.project_id
                    WHERE (pm.user_id = ? OR p.created_by = ?)
                    AND p.deleted = 0
                    AND p.status != 'canceled'
                    ORDER BY p.title ASC";

            $query = $this->db->query($sql, [$user_id, $user_id]);

            if ($query) {
                $result = $query->getResult();

                if ($this->enable_query_cache && !empty($result)) {
                    $this->cache->save($cache_key, $result, $this->cache_ttl);
                }

                $this->monitor_query_performance('getProjects', $start_time);
                return $result;
            }

            return $this->handle_db_error('Failed to retrieve projects');

        } catch (\Exception $e) {
            log_message('error', '[TRACKER] getProjects error: ' . $e->getMessage());
            return [];
        }
    }

    /**
     * Add a new project for the user
     */
    public function addProject($project_data) {
        $start_time = microtime(true);

        try {
            // Validate required fields
            if (empty($project_data['title']) || empty($project_data['user_id'])) {
                throw new \InvalidArgumentException('Project title and user_id are required');
            }

            // Prepare project data with defaults
            $data = [
                'title' => trim($project_data['title']),
                'description' => $project_data['description'] ?? '',
                'created_by' => $project_data['user_id'],
                'start_date' => $project_data['start_date'] ?? date('Y-m-d'),
                'created_date' => $project_data['created_date'] ?? date('Y-m-d'),
                'status' => $project_data['status'] ?? 'open',
                'client_id' => 0, // Default to 0 for internal projects
                'project_type' => 'internal_project'
            ];

            // Insert the project
            $sql = "INSERT INTO " . $this->db->prefixTable('projects') . "
                    (title, description, created_by, start_date, created_date, status, client_id, project_type)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

            $result = $this->db->query($sql, [
                $data['title'],
                $data['description'],
                $data['created_by'],
                $data['start_date'],
                $data['created_date'],
                $data['status'],
                $data['client_id'],
                $data['project_type']
            ]);

            if ($result) {
                $project_id = $this->db->insertID();

                // Add the creator as a project member
                $member_sql = "INSERT INTO " . $this->db->prefixTable('project_members') . "
                               (user_id, project_id, is_leader)
                               VALUES (?, ?, 1)";

                $this->db->query($member_sql, [$data['created_by'], $project_id]);

                // Clear user projects cache
                $cache_key = $this->cache_prefix . "projects_user_{$data['created_by']}";
                $this->cache->delete($cache_key);

                $this->monitor_query_performance('addProject', $start_time);

                log_message('info', "[TRACKER] Project created successfully - ID: {$project_id}, Title: {$data['title']}, User: {$data['created_by']}");

                return $project_id;
            }

            return $this->handle_db_error('Failed to create project');

        } catch (\Exception $e) {
            log_message('error', '[TRACKER] addProject error: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Enhance user data with calculated fields and proper formatting
     */
    private function enhance_user_data($user_data) {
        try {
            $enhanced = (array)$user_data;

            // Format dates properly
            if (!empty($user_data->created_at)) {
                try {
                    $created_date = new \DateTime($user_data->created_at);
                    $enhanced['join_date'] = $created_date->format('Y-m-d');
                    $enhanced['joining_date'] = $created_date->format('Y-m-d');
                    $enhanced['formatted_join_date'] = $created_date->format('F j, Y');
                    $enhanced['join_date_iso'] = $created_date->format('c');
                } catch (\Exception $e) {
                    log_message('warning', "[TRACKER] Date formatting error: " . $e->getMessage());
                }
            }

            // Ensure name fields are properly set
            if (empty($enhanced['name']) && !empty($user_data->first_name)) {
                $enhanced['name'] = trim($user_data->first_name . ' ' . ($user_data->last_name ?? ''));
            }

            // Set username fallback
            if (empty($enhanced['username'])) {
                $enhanced['username'] = $user_data->email ? explode('@', $user_data->email)[0] : 'user' . $user_data->id;
            }

            // Ensure all expected profile fields exist
            $default_fields = [
                'employee_id' => $user_data->id,
                'emp_id' => $user_data->id,
                'department' => $enhanced['department'] ?? 'Development',
                'dept' => $enhanced['department'] ?? 'Development',
                'designation' => $enhanced['calculated_designation'] ?? 'Employee',
                'position' => $enhanced['calculated_designation'] ?? 'Employee',
                'role' => $enhanced['calculated_designation'] ?? 'Employee',
                'job_title' => $enhanced['calculated_designation'] ?? 'Employee',
                'phone' => $user_data->phone ?? '',
                'mobile' => $user_data->phone ?? '',
                'contact' => $user_data->phone ?? '',
                'company' => $enhanced['company_name'] ?? 'Company',
                'organization' => $enhanced['company_name'] ?? 'Company',
                'status' => $user_data->status ?? 'active',
                'user_type' => $user_data->user_type ?? 'staff'
            ];

            foreach ($default_fields as $field => $default_value) {
                if (empty($enhanced[$field])) {
                    $enhanced[$field] = $default_value;
                }
            }

            return $enhanced;

        } catch (\Exception $e) {
            log_message('error', '[TRACKER] enhance_user_data error: ' . $e->getMessage());
            return (array)$user_data;
        }
    }

    /**
     * Get user activity statistics for profile modal
     */
    private function get_user_activity_stats($user_id) {
        try {
            $stats = [
                'total_projects' => 0,
                'active_projects' => 0,
                'total_hours_logged' => '0:00:00',
                'avg_daily_hours' => '0:00:00',
                'last_activity' => null,
                'total_screenshots' => 0,
                'productivity_score' => 0
            ];

            // Get project count
            $project_sql = "SELECT COUNT(*) as total_projects,
                                  COUNT(CASE WHEN p.status = 'open' THEN 1 END) as active_projects
                           FROM " . $this->db->prefixTable('project_members') . " pm
                           JOIN " . $this->db->prefixTable('projects') . " p ON p.id = pm.project_id
                           WHERE pm.user_id = ? AND p.deleted = 0";

            $project_query = $this->db->query($project_sql, [$user_id]);
            if ($project_query) {
                $project_data = $project_query->getRow();
                $stats['total_projects'] = (int)$project_data->total_projects;
                $stats['active_projects'] = (int)$project_data->active_projects;
            }

            // Get total logged hours from attendance
            $hours_sql = "SELECT
                            COUNT(*) as total_sessions,
                            SUM(CASE WHEN outTime > inTime THEN (outTime - inTime) / 3600000 ELSE 0 END) as total_hours
                          FROM " . $this->db->prefixTable('tracker_attendance') . "
                          WHERE user_id = ? AND deleted = 0 AND inTime IS NOT NULL";

            $hours_query = $this->db->query($hours_sql, [$user_id]);
            if ($hours_query) {
                $hours_data = $hours_query->getRow();
                $total_hours = (float)$hours_data->total_hours;
                if ($total_hours > 0) {
                    $hours = floor($total_hours);
                    $minutes = floor(($total_hours - $hours) * 60);
                    $stats['total_hours_logged'] = sprintf('%d:%02d:00', $hours, $minutes);
                }
            }

            // Get last activity
            $activity_sql = "SELECT MAX(GREATEST(
                                COALESCE(inTime, 0),
                                COALESCE(outTime, 0)
                             )) as last_timestamp
                            FROM " . $this->db->prefixTable('tracker_attendance') . "
                            WHERE user_id = ? AND deleted = 0";

            $activity_query = $this->db->query($activity_sql, [$user_id]);
            if ($activity_query) {
                $activity_data = $activity_query->getRow();
                if ($activity_data->last_timestamp) {
                    $stats['last_activity'] = date('Y-m-d H:i:s', $activity_data->last_timestamp / 1000);
                }
            }

            // Get screenshot count - using fallback table name check
            $screenshot_tables = ['tracker_screenshots', 'screenshots', 'user_screenshots'];
            foreach ($screenshot_tables as $table_name) {
                try {
                    $screenshot_sql = "SELECT COUNT(*) as total_screenshots
                                      FROM " . $this->db->prefixTable($table_name) . "
                                      WHERE user_id = ?";

                    $screenshot_query = $this->db->query($screenshot_sql, [$user_id]);
                    if ($screenshot_query) {
                        $screenshot_data = $screenshot_query->getRow();
                        $stats['total_screenshots'] = (int)$screenshot_data->total_screenshots;
                        break; // Found working table, exit loop
                    }
                } catch (\Exception $e) {
                    // Table doesn't exist, try next one
                    continue;
                }
            }

            return $stats;

        } catch (\Exception $e) {
            log_message('error', '[TRACKER] get_user_activity_stats error: ' . $e->getMessage());
            return [
                'total_projects' => 0,
                'active_projects' => 0,
                'total_hours_logged' => '0:00:00',
                'last_activity' => null,
                'total_screenshots' => 0
            ];
        }
    }

    /**
     * Get user by ID with caching
     *
     * @param int $user_id User ID
     * @return array|null User data or null if not found
     */
    public function getUserById($user_id) {
        // Validate input
        if (!is_numeric($user_id) || $user_id <= 0) {
            return null;
        }

        // If not in cache, get from database
        $db = $this->db;
        $user = $db->table($this->table)
                   ->select('id, first_name, last_name, email, is_admin, status')
                   ->where('id', $user_id)
                   ->get()
                   ->getRowArray();

        return $user;
    }

    /**
     * Helper method to check idle_timeout directly from the database
     * This bypasses cache and other settings layers to get the raw value
     */
    private function check_db_idle_timeout_directly() {
        try {
            $sql = "SELECT setting_value
                    FROM " . $this->db->prefixTable('tracker_settings') . "
                    WHERE setting_name = 'idle_timeout' AND deleted = 0
                    LIMIT 1";

            $query = $this->db->query($sql);

            if ($query && $result = $query->getRow()) {
                return $result->setting_value;
            }

            return null;
        } catch (\Exception $e) {
            log_message('error', '[TRACKER] check_db_idle_timeout_directly error: ' . $e->getMessage());
            return null;
        }
    }

    /**
     * Public method to check idle_timeout directly from the database
     * For diagnostic purposes only
     */
    public function diagnose_idle_timeout() {
        try {
            $sql = "SELECT setting_value, updated_at
                    FROM " . $this->db->prefixTable('tracker_settings') . "
                    WHERE setting_name = 'idle_timeout' AND deleted = 0
                    LIMIT 1";

            $query = $this->db->query($sql);

            if ($query && $result = $query->getRow()) {
                return [
                    'db_value' => $result->setting_value,
                    'updated_at' => $result->updated_at,
                    'source' => 'direct_db_query'
                ];
            }

            return [
                'db_value' => null,
                'error' => 'Setting not found in database',
                'source' => 'direct_db_query'
            ];
        } catch (\Exception $e) {
            log_message('error', '[TRACKER] diagnose_idle_timeout error: ' . $e->getMessage());
            return [
                'db_value' => null,
                'error' => $e->getMessage(),
                'source' => 'direct_db_query'
            ];
        }
    }

    /**
     * Update user status in tracker_status table
     * 
     * @param int $user_id User ID
     * @param string $status Status (check-in/check-out)
     * @return bool Success or failure
     */
    public function updateUserStatus($user_id, $status) {
        try {
            // Get the correct table name with prefix
            $table_name = $this->db->prefixTable('tracker_status');

            // Check if tracker_status table exists
            if (!$this->tableExists('tracker_status')) {
                $table_created = $this->createTrackerStatusTable();
                if (!$table_created) {
                    log_message('error', '[TRACKER] Failed to create tracker_status table');
                    return false;
                }
            }

            // Current timestamp in user's timezone (Asia/Dhaka)
            $originalTimezone = date_default_timezone_get();
            date_default_timezone_set('Asia/Dhaka');
            $timestamp = date('Y-m-d H:i:s');
            date_default_timezone_set($originalTimezone);

            // Prepare data for insertion/update
            $data = [
                'user_id' => $user_id,
                'status' => $status,
                'last_activity' => $timestamp,
                'updated_at' => $timestamp
            ];

            // Check if a record exists for this user
            $existing = $this->db->table($table_name)
                                ->where('user_id', $user_id)
                                ->get()
                                ->getRowArray();

            if ($existing) {
                // Update existing record
                $update_result = $this->db->table($table_name)
                                         ->where('user_id', $user_id)
                                         ->update($data);

                if (!$update_result) {
                    log_message('error', '[TRACKER] Update operation failed for user_id: ' . $user_id);
                    return false;
                }
            } else {
                // Insert new record
                $data['created_at'] = $timestamp;
                $insert_result = $this->db->table($table_name)->insert($data);

                if (!$insert_result) {
                    log_message('error', '[TRACKER] Insert operation failed for user_id: ' . $user_id);
                    return false;
                }
            }

            // Verify the data was actually saved
            $saved_record = $this->db->table($table_name)
                                    ->where('user_id', $user_id)
                                    ->get()
                                    ->getRowArray();

            if (empty($saved_record)) {
                log_message('error', '[TRACKER] Data verification failed for user_id: ' . $user_id);
                return false;
            }

            // Log the status change
            $this->logStatusChange($user_id, $status, $timestamp);

            return true;
        } catch (\Exception $e) {
            log_message('error', '[TRACKER] Database error in updateUserStatus: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Check if a table exists in the database
     *
     * @param string $table_name Table name (can be with or without prefix)
     * @return bool
     */
    public function tableExists($unprefixed_table_name) {
        $table_name = $this->db->prefixTable($unprefixed_table_name);
        try {
            // Get table list
            $tables = $this->db->listTables();

            // First check if the table exists with the exact name provided
            $table_exists = in_array($table_name, $tables);

            if (!$table_exists) {
                // If not found, try with prefix added (for cases where base name is provided)
                $db_prefix = $this->db->getPrefix();
                if (!empty($db_prefix) && strpos($table_name, $db_prefix) !== 0) {
                    $prefixed_table_name = $table_name;
                    $table_exists = in_array($prefixed_table_name, $tables);
                }
            }

            if ($table_exists) {
                return true;
            }

            // Method 2: Try to query the table directly as fallback
            try {
                $query = $this->db->query("SELECT 1 FROM `{$table_name}` LIMIT 1");
                return true;
            } catch (\Exception $e) {
                // Try with prefix if not already prefixed
                if (!empty($this->db->getPrefix()) && strpos($table_name, $this->db->getPrefix()) !== 0) {
                    $prefixed_name = $table_name;
                    try {
                        $query = $this->db->query("SELECT 1 FROM `{$prefixed_name}` LIMIT 1");
                        return true;
                    } catch (\Exception $e2) {
                        return false;
                    }
                } else {
                    return false;
                }
            }

        } catch (\Exception $e) {
            log_message('error', '[TRACKER] Error checking table existence: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Create the tracker_status table if it doesn't exist
     *
     * @return bool
     */
    public function createTrackerStatusTable() {
        try {
            $forge = \Config\Database::forge();

            $fields = [
                'id' => [
                    'type' => 'INT',
                    'constraint' => 11,
                    'unsigned' => true,
                    'auto_increment' => true
                ],
                'user_id' => [
                    'type' => 'INT',
                    'constraint' => 11
                ],
                'status' => [
                    'type' => 'VARCHAR',
                    'constraint' => 50
                ],
                'last_activity' => [
                    'type' => 'DATETIME'
                ],
                'created_at' => [
                    'type' => 'DATETIME'
                ],
                'updated_at' => [
                    'type' => 'DATETIME'
                ]
            ];

            $forge->addField($fields);
            $forge->addKey('id', true);
            $forge->addKey('user_id');

            $table_created = $forge->createTable('tracker_status', true);

            // Verify table was actually created
            if ($table_created && $this->tableExists('tracker_status')) {
                log_message('info', '[TRACKER] tracker_status table created successfully');
                return true;
            } else {
                log_message('error', '[TRACKER] tracker_status table creation failed');
                return false;
            }

        } catch (\Exception $e) {
            log_message('error', '[TRACKER] Exception during table creation: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Log status changes for auditing
     *
     * @param int $user_id User ID
     * @param string $status New status
     * @param string $timestamp Timestamp
     */
    public function logStatusChange($user_id, $status, $timestamp) {
        try {
            // Use the full table name (forge creates table with exact name provided)
            $log_table_name = $this->db->prefixTable('tracker_status_log');

            // Check if the log table exists using full name
            if (!$this->tableExists('tracker_status_log')) {
                try {
                    $table_created = $this->createTrackerStatusLogTable();
                    if (!$table_created) {
                        log_message('error', '[TRACKER] Failed to create tracker_status_log table, skipping status logging');
                        return; // Don't fail the main operation, just skip logging
                    }
                } catch (\Exception $create_e) {
                    log_message('error', '[TRACKER] Exception while creating tracker_status_log table: ' . $create_e->getMessage());
                    return; // Don't fail the main operation, just skip logging
                }
            }

            // Insert log entry using raw SQL to avoid double prefixing
            $log_data = [
                'user_id' => $user_id,
                'status' => $status,
                'timestamp' => $timestamp,
                'ip_address' => service('request')->getIPAddress(),
                'user_agent' => service('request')->getUserAgent()->__toString()
            ];

            // Use raw query to avoid double prefixing
            $sql = "INSERT INTO `{$log_table_name}` (user_id, status, timestamp, ip_address, user_agent) VALUES (?, ?, ?, ?, ?)";
            $insert_result = $this->db->query($sql, [
                $log_data['user_id'],
                $log_data['status'],
                $log_data['timestamp'],
                $log_data['ip_address'],
                $log_data['user_agent']
            ]);

            if ($insert_result) {
                log_message('info', '[TRACKER] Status change logged successfully for user_id: ' . $user_id);
            } else {
                log_message('error', '[TRACKER] Failed to log status change for user_id: ' . $user_id);
            }

        } catch (\Exception $e) {
            log_message('error', '[TRACKER] Exception in logStatusChange: ' . $e->getMessage());
        }
    }

    /**
     * Create the tracker_status_log table if it doesn't exist
     *
     * @return bool
     */
    public function createTrackerStatusLogTable() {
        try {
            $forge = \Config\Database::forge();

            $fields = [
                'id' => [
                    'type' => 'INT',
                    'constraint' => 11,
                    'unsigned' => true,
                    'auto_increment' => true
                ],
                'user_id' => [
                    'type' => 'INT',
                    'constraint' => 11
                ],
                'status' => [
                    'type' => 'VARCHAR',
                    'constraint' => 50
                ],
                'timestamp' => [
                    'type' => 'DATETIME'
                ],
                'ip_address' => [
                    'type' => 'VARCHAR',
                    'constraint' => 45
                ],
                'user_agent' => [
                    'type' => 'TEXT'
                ]
            ];

            $forge->addField($fields);
            $forge->addKey('id', true);
            $forge->addKey('user_id');
            $forge->addKey('timestamp');

            $table_created = $forge->createTable('tracker_status_log', true);

            if ($table_created && $this->tableExists('tracker_status_log')) {
                log_message('info', '[TRACKER] tracker_status_log table created successfully');
                return true;
            } else {
                log_message('error', '[TRACKER] tracker_status_log table creation failed');
                return false;
            }

        } catch (\Exception $e) {
            log_message('error', '[TRACKER] Exception during log table creation: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Get user status from tracker_status table
     *
     * @param int $user_id User ID
     * @return array|null User status data or null if not found
     */
    public function getUserStatus($user_id) {
        try {
            $table_name = $this->db->prefixTable('tracker_status');
            
            return $this->db->table($table_name)
                           ->where('user_id', $user_id)
                           ->get()
                           ->getRowArray();
        } catch (\Exception $e) {
            log_message('error', '[TRACKER] Error getting user status: ' . $e->getMessage());
            return null;
        }
    }

    /**
     * Get all user statuses
     *
     * @return array All user statuses
     */
    public function getAllUserStatuses() {
        try {
            $table_name = $this->db->prefixTable('tracker_status');
            
            return $this->db->table($table_name)
                           ->get()
                           ->getResultArray();
        } catch (\Exception $e) {
            log_message('error', '[TRACKER] Error getting all user statuses: ' . $e->getMessage());
            return [];
        }
    }

    /**
     * Delete user status
     *
     * @param int $user_id User ID
     * @return bool Success or failure
     */
    public function deleteUserStatus($user_id) {
        try {
            $table_name = $this->db->prefixTable('tracker_status');
            
            $result = $this->db->table($table_name)
                              ->where('user_id', $user_id)
                              ->delete();
            
            return $result !== false;
        } catch (\Exception $e) {
            log_message('error', '[TRACKER] Error deleting user status: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Get status log entries for a user
     *
     * @param int $user_id User ID
     * @param int $limit Limit number of entries
     * @return array Status log entries
     */
    public function getUserStatusLog($user_id, $limit = 100) {
        try {
            $log_table_name = $this->db->prefixTable('tracker_status_log');
            
            return $this->db->table($log_table_name)
                           ->where('user_id', $user_id)
                           ->orderBy('timestamp', 'DESC')
                           ->limit($limit)
                           ->get()
                           ->getResultArray();
        } catch (\Exception $e) {
            log_message('error', '[TRACKER] Error getting user status log: ' . $e->getMessage());
            return [];
        }
    }

    /**
     * Clean up old status log entries
     *
     * @param int $days_old Delete entries older than this many days
     * @return int Number of deleted entries
     */
    public function cleanupOldStatusLogs($days_old = 30) {
        try {
            $log_table_name = $this->db->prefixTable('tracker_status_log');
            $cutoff_date = date('Y-m-d H:i:s', strtotime("-{$days_old} days"));
            
            $result = $this->db->table($log_table_name)
                              ->where('timestamp <', $cutoff_date)
                              ->delete();
            
            return $result !== false ? $result : 0;
        } catch (\Exception $e) {
            log_message('error', '[TRACKER] Error cleaning up old status logs: ' . $e->getMessage());
            return 0;
        }
    }
}
