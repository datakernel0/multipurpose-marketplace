<?php

namespace Tracebit\Models;

/**
 * Optimized Tracker Settings Model
 * Includes caching, validation, and security improvements
 */
class Tracker_settings_model extends Tracker_base_model {

    protected $table = 'tracker_settings';
    protected $cache_ttl = 3600; // 1 hour cache for settings
    private static $initializing_defaults = false; // Recursion guard

    public function __construct() {
        // Set table before calling parent constructor
        $this->table = 'tracker_settings';

        // Call parent constructor with table name to prevent the table() error
        parent::__construct('tracker_settings');

        // DO NOT auto-initialize defaults in constructor to prevent recursion
        // Settings will be initialized on-demand when needed
    }

    /**
     * Check if this is a background/API request that shouldn't trigger full initialization
     */
    private function is_background_request() {
        $uri = $_SERVER['REQUEST_URI'] ?? '';
        return (
            strpos($uri, '/api/') !== false ||
            strpos($uri, 'ajax') !== false ||
            (php_sapi_name() === 'cli')
        );
    }

    /**
     * Get setting with caching
     */
    public function get_setting($setting_name) {
        $start_time = microtime(true);

        try {
            // Validate setting name
            if (empty($setting_name) || !is_string($setting_name)) {
                throw new \InvalidArgumentException('Invalid setting name');
            }



            // Use secure query
            $sql = "SELECT setting_value
                    FROM " . $this->db->prefixTable('tracker_settings') . "
                    WHERE setting_name = ? AND deleted = 0
                    LIMIT 1";

            $query = $this->db->query($sql, [$setting_name]);

            if ($query) {
                $result = $query->getResult();
                $value = !empty($result) ? $result[0]->setting_value : null;

                $this->monitor_query_performance('get_setting', $start_time);
                return $value;
            }

            return $this->handle_db_error('Failed to retrieve setting');

        } catch (\Exception $e) {
            return null;
        }
    }

    /**
     * Save setting with validation and caching
     */
    public function save_setting($setting_name, $setting_value, $type = "app_settings") {
        $start_time = microtime(true);

        try {
            // Validate inputs
            $rules = [
                'setting_name' => 'required|max_length[100]|regex_match[/^[a-zA-Z0-9_-]+$/]',
                'setting_value' => 'permit_empty',
                'type' => 'required|in_list[app_settings,web_settings,holidays_settings,break_settings,weekend_settings,system,user]'
            ];

            $data = [
                'setting_name' => $setting_name,
                'setting_value' => $setting_value,
                'type' => $type
            ];

            try {
                $validated_data = $this->validate_input($data, $rules);               
            } catch (\Exception $validation_error) {                
                return false;
            }

            // Check if setting exists for this specific type
            $existing = $this->get_setting_record($validated_data['setting_name'], $validated_data['type']);
            $table = $this->db->prefixTable('tracker_settings');
            
            if ($existing) {
               
                $builder = $this->db->table($table);
                $update_data = [
                    'setting_value' => $validated_data['setting_value'],
                    'updated_at'    => date('Y-m-d H:i:s'),
                ];

                $builder->where([
                    'setting_name' => $validated_data['setting_name'],
                    'type'         => $validated_data['type'],
                    'deleted'      => 0,
                ]);

                $result = $builder->update($update_data);
                
                if (!$result) {
                    
                    return false;
                }
            } else {
               
                $sql = "INSERT INTO " . $this->db->prefixTable('tracker_settings') . "
                        (setting_name, setting_value, type, created_at)
                        VALUES (?, ?, ?, NOW())
                        ON DUPLICATE KEY UPDATE 
                        setting_value = VALUES(setting_value),
                        updated_at = NOW()";

                $result = $this->db->query($sql, [
                    $validated_data['setting_name'],
                    $validated_data['setting_value'],
                    $validated_data['type']
                ]);
                
                if (!$result) {
                    $db_error = $this->db->error();
                   
                    // If it's still a duplicate key error, try to update the existing record
                    if (strpos($db_error['message'], 'Duplicate entry') !== false) {
                        
                        $update_sql = "UPDATE " . $this->db->prefixTable('tracker_settings') . "
                                      SET setting_value = ?, updated_at = NOW()
                                      WHERE setting_name = ? AND deleted = 0";
                        
                        $result = $this->db->query($update_sql, [
                            $validated_data['setting_value'],
                            $validated_data['setting_name']
                        ]);
                        
                        if (!$result) {
                           
                            return false;
                        }
                    } else {
                        return false;
                    }
                }
            }

            if ($result) {
                // Clear cache for this setting
                $cache_key = $this->cache_prefix . "setting_{$validated_data['setting_name']}";
                $this->cache->delete($cache_key);

                // Clear all settings cache
                $this->cache->delete($this->cache_prefix . 'settings_all');                
                $this->monitor_query_performance('save_setting', $start_time);
                return true;
            }

            return $this->handle_db_error('Failed to save setting');

        } catch (\Exception $e) {            
            return false;
        }
    }

    /**
     * Get all settings with caching
     */
    public function get_all_settings() {
        $start_time = microtime(true);

        try {
            $cache_key = $this->cache_prefix . 'settings_all';

            if ($this->enable_query_cache) {
                $cached_result = $this->cache->get($cache_key);
                if ($cached_result !== null) {
                    return $cached_result;
                }
            }

            $sql = "SELECT setting_name, setting_value, type, updated_at
                    FROM " . $this->db->prefixTable('tracker_settings') . "
                    WHERE deleted = 0
                    ORDER BY setting_name";

            $query = $this->db->query($sql);

            if ($query) {
                $result = $query->getResult();

                if ($this->enable_query_cache) {
                    $this->cache->save($cache_key, $result, $this->cache_ttl);
                }

                $this->monitor_query_performance('get_all_settings', $start_time);
                return $result;
            }

            return $this->handle_db_error('Failed to retrieve all settings');

        } catch (\Exception $e) {            
            return [];
        }
    }

    /**
     * Get settings as key-value array
     */
    public function get_settings_array() {
        $settings = $this->get_all_settings();
        $settings_array = [];

        if (is_array($settings)) {
            foreach ($settings as $setting) {
                $settings_array[$setting->setting_name] = $setting->setting_value;
            }
        }

        return $settings_array;
    }

    /**
     * Get settings by type as key-value array for easier access
     */
    public function get_settings_array_by_type($type = 'app_settings') {
        $settings = $this->get_settings_by_type($type);
        $settings_array = [];

        if (is_array($settings)) {
            foreach ($settings as $setting) {
                $settings_array[$setting->setting_name] = $setting->setting_value;
            }
        }

        return $settings_array;
    }

    /**
     * Bulk save settings (for configuration pages)
     */
    public function save_settings_batch($settings_array) {
        if (empty($settings_array) || !is_array($settings_array)) {
            return false;
        }

        try {
            $this->db->transStart();

            foreach ($settings_array as $setting_name => $setting_value) {
                $this->save_setting($setting_name, $setting_value);
            }

            $this->db->transComplete();

            if ($this->db->transStatus()) {
                // Clear all settings cache
                $this->clear_cache_pattern('setting_');
                return true;
            }

            return false;

        } catch (\Exception $e) {
            $this->db->transRollback();            
            return false;
        }
    }

    /**
     * Bulk save settings for a specific type (for configuration pages)
     */
    public function save_settings_batch_by_type($settings_array, $type = 'app_settings') {
        
        if (empty($settings_array) || !is_array($settings_array)) {            
            return false;
        }

        try {
            // Don't use transactions for individual setting saves since save_setting might already handle them
            $success_count = 0;
            $total_count = count($settings_array);
            $failed_settings = [];

            foreach ($settings_array as $setting_name => $setting_value) {
                
                $result = $this->save_setting($setting_name, $setting_value, $type);
                if ($result) {
                    $success_count++;
                } else {
                    $failed_settings[] = $setting_name;
                }
            }


            // Clear cache regardless of some failures
            $this->clear_cache_pattern('setting_');

            // Consider it successful if at least some settings were saved
            if ($success_count > 0) {
                return true;
            }
            
            return false;

        } catch (\Exception $e) {           
            return false;
        }
    }

    /**
     * Delete setting
     */
    public function delete_setting($setting_name) {
        try {
            if (empty($setting_name)) {
                throw new \InvalidArgumentException('Setting name is required');
            }

            $sql = "UPDATE " . $this->db->prefixTable('tracker_settings') . "
                    SET deleted = 1, updated_at = NOW()
                    WHERE setting_name = ?";

            $result = $this->db->query($sql, [$setting_name]);

            if ($result) {
                // Clear cache
                $cache_key = $this->cache_prefix . "setting_{$setting_name}";
                $this->cache->delete($cache_key);
                $this->cache->delete($this->cache_prefix . 'settings_all');

                return true;
            }

            return $this->handle_db_error('Failed to delete setting');

        } catch (\Exception $e) {            
            return false;
        }
    }

    /**
     * Get setting record (for internal use)
     */
    private function get_setting_record($setting_name, $type = null) {
        $sql = "SELECT * FROM " . $this->db->prefixTable('tracker_settings') . "
                WHERE setting_name = ? AND deleted = 0";

        $params = [$setting_name];

        if ($type !== null) {
            $sql .= " AND type = ?";
            $params[] = $type;
        }

        $sql .= " LIMIT 1";

        $query = $this->db->query($sql, $params);

        if ($query) {
            $result = $query->getResult();
            return !empty($result) ? $result[0] : null;
        }

        return null;
    }

    /**
     * Get setting value directly from database (used during initialization to avoid recursion)
     */
    private function get_setting_direct($setting_name) {
        try {
            $sql = "SELECT setting_value
                    FROM " . $this->db->prefixTable('tracker_settings') . "
                    WHERE setting_name = ? AND deleted = 0
                    LIMIT 1";

            $query = $this->db->query($sql, [$setting_name]);

            if ($query) {
                $result = $query->getResult();
                return !empty($result) ? $result[0]->setting_value : null;
            }

            return null;
        } catch (\Exception $e) {            
            return null;
        }
    }

    /**
     * Get settings by type with improved resilience to common issues
     */
    public function get_settings_by_type($type = 'app_settings') {
        $start_time = microtime(true);

        try {
           
            // Validate the type parameter
            $allowed_types = ['app_settings', 'web_settings', 'holidays_settings', 'break_settings', 'weekend_settings', 'system', 'user', 'app'];
            if (empty($type)) {
                $type = 'app_settings'; // Default to 'app_settings' if type is empty
            } elseif (!in_array($type, $allowed_types)) {
                $type = 'app_settings';
            }

            // Create a cache key for this type of settings
            $cache_key = $this->cache_prefix . "settings_type_{$type}";

            // Check if table exists
            if (!$this->tableExists()) {               
                return []; // Return empty array as fallback
            }

            // Check if 'type' column exists in the table schema
            $has_type_column = $this->checkColumnExists('type');

            // Build the query based on whether the type column exists
            if ($has_type_column) {
                $sql = "SELECT setting_name, setting_value,
                        " . ($this->checkColumnExists('updated_at') ? "updated_at" : "created_at as updated_at") . "
                        FROM " . $this->db->prefixTable('tracker_settings') . "
                        WHERE type = ? AND deleted = 0
                        ORDER BY setting_name";
                $params = [$type];
            } else {
               
                $sql = "SELECT setting_name, setting_value,
                        " . ($this->checkColumnExists('updated_at') ? "updated_at" : "created_at as updated_at") . "
                        FROM " . $this->db->prefixTable('tracker_settings') . "
                        WHERE deleted = 0
                        ORDER BY setting_name";
                $params = [];
            }

            // Execute the query
            $query = $this->db->query($sql, $params);

            if ($query) {
                $result = $query->getResult();

                $count = count($result);
               
                $this->monitor_query_performance('get_settings_by_type', $start_time);

                // If no settings found and type is 'app_settings', return empty instead of initializing (prevents recursion)
                if (empty($result) && in_array($type, ['app_settings', 'app'])) {                    
                    return []; // Return empty array instead of trying to initialize
                }

                return $result;
            }

            return $this->handle_db_error('Failed to retrieve settings by type');

        } catch (\Exception $e) {
             
            // Return empty array as fallback
            return [];
        }
    }

    /**
     * Check if the tracker_settings table exists
     */
    private function tableExists() {
        try {
            $tables = $this->db->listTables();
            $table_name = $this->db->prefixTable('tracker_settings');
            return in_array($table_name, $tables);
        } catch (\Exception $e) {
            
            return false;
        }
    }

    /**
     * Check if a column exists in the tracker_settings table
     */
    private function checkColumnExists($column_name) {
        try {
            $fields = $this->db->getFieldData($this->db->prefixTable('tracker_settings'));
            foreach ($fields as $field) {
                if ($field->name === $column_name) {
                    return true;
                }
            }
            return false;
        } catch (\Exception $e) {
            
            return false;
        }
    }

    /**
     * Initialize default settings if they don't exist
     * Enhanced with table creation and more detailed logging
     */
    public function initialize_default_settings() {
        // Prevent infinite recursion
        if (self::$initializing_defaults) {
            
            return true;
        }

        self::$initializing_defaults = true;

        try {
            
            // Ensure the table exists
            if (!$this->tableExists()) {
               
                if (!$this->createSettingsTable()) {
                    
                    self::$initializing_defaults = false;
                    return false;
                }
            } else {
                // Fix table constraints if needed
                $this->fixTableConstraints();
            }

            // Default settings organized by type
            $defaults_by_type = [
                'app_settings' => [
                    // Core tracking settings
                    'screenshot_interval' => ['value' => '300', 'desc' => 'Screenshot capture interval in seconds'],
                    'idle_timeout' => ['value' => '150', 'desc' => 'Idle detection timeout in seconds'],
                    'working_hours_start' => ['value' => '09:00', 'desc' => 'Work day start time'],
                    'working_hours_end' => ['value' => '17:00', 'desc' => 'Work day end time'],
                    'timezone_offset' => ['value' => '0', 'desc' => 'User timezone offset'],

                    // Feature toggles
                    'enable_screenshots' => ['value' => '1', 'desc' => 'Enable screenshot capture'],
                    'enable_activity_tracking' => ['value' => '1', 'desc' => 'Enable activity tracking'],
                    'enable_idle_detection' => ['value' => '1', 'desc' => 'Enable idle detection'],
                    'productivity_tracking' => ['value' => '1', 'desc' => 'Enable productivity tracking'],

                    // Screenshot settings
                    'screenshot_quality' => ['value' => '80', 'desc' => 'Screenshot quality (1-100)'],
                    'max_screenshot_size' => ['value' => '5242880', 'desc' => 'Maximum screenshot size in bytes (5MB)'],

                    // Performance and monitoring
                    'performance_threshold' => ['value' => '50', 'desc' => 'Performance threshold percentage'],
                    'query_cache_enabled' => ['value' => '1', 'desc' => 'Enable query caching'],
                    'max_query_cache_time' => ['value' => '3600', 'desc' => 'Maximum query cache time in seconds'],

                    // Security settings
                    'force_screenshot_encryption' => ['value' => '0', 'desc' => 'Force screenshot encryption'],
                    'max_idle_before_logout' => ['value' => '7200', 'desc' => 'Maximum idle time before auto logout (2 hours)'],
                    'require_checkout_confirmation' => ['value' => '1', 'desc' => 'Require confirmation on checkout'],

                    // Dashboard features
                    'dashboard_checkin_active' => ['value' => '1', 'desc' => 'Enable dashboard check-in feature']
                ],

                'web_settings' => [
                    // Desktop app specific settings
                    'enable_notifications' => ['value' => '1', 'desc' => 'Enable desktop notifications'],
                    'minimize_to_tray' => ['value' => '1', 'desc' => 'Minimize to system tray'],
                    'start_with_system' => ['value' => '0', 'desc' => 'Start app with system boot'],
                    'auto_sync_interval' => ['value' => '300', 'desc' => 'Auto sync interval in seconds (5 minutes)'],
                    'theme_preference' => ['value' => 'auto', 'desc' => 'UI theme preference (light/dark/auto)'],
                    'language' => ['value' => 'en', 'desc' => 'Interface language'],
                    'show_detailed_stats' => ['value' => '1', 'desc' => 'Show detailed statistics on dashboard'],
                    'dashboard_checkin' => ['value' => '1', 'desc' => 'Enable dashboard check-in feature'],
                    'compact_view' => ['value' => '0', 'desc' => 'Enable compact view mode']
                ],

                'break_settings' => [
                    // Break and reminder settings
                    'break_reminder_interval' => ['value' => '3600', 'desc' => 'Break reminder interval in seconds (1 hour)'],
                    'auto_break_duration' => ['value' => '900', 'desc' => 'Auto break duration in seconds (15 minutes)'],
                    'break_reminder_enabled' => ['value' => '1', 'desc' => 'Enable break reminders'],
                    'break_sound_enabled' => ['value' => '1', 'desc' => 'Enable break reminder sounds'],
                    'mandatory_break_enabled' => ['value' => '0', 'desc' => 'Force mandatory breaks'],
                    'break_message' => ['value' => 'Time for a break! Step away from your desk.', 'desc' => 'Break reminder message'],
                    'short_break_duration' => ['value' => '300', 'desc' => 'Short break duration in seconds (5 minutes)'],
                    'long_break_duration' => ['value' => '900', 'desc' => 'Long break duration in seconds (15 minutes)'],
                    'long_break_interval' => ['value' => '14400', 'desc' => 'Long break interval in seconds (4 hours)']
                ],

                'weekend_settings' => [
                    // Weekend configuration
                    'weekend_days' => ['value' => '0,6', 'desc' => 'Weekend days (0=Sunday, 1=Monday, etc.) comma-separated'],
                    'weekend_tracking_enabled' => ['value' => '0', 'desc' => 'Enable tracking on weekends'],
                    'weekend_notification_enabled' => ['value' => '0', 'desc' => 'Enable notifications on weekends'],
                    'weekend_start_day' => ['value' => '6', 'desc' => 'Weekend start day (6=Saturday)'],
                    'weekend_end_day' => ['value' => '0', 'desc' => 'Weekend end day (0=Sunday)'],
                    'weekend_working_hours_enabled' => ['value' => '0', 'desc' => 'Apply working hours on weekends']
                ],

                'holidays_settings' => [
                    // Holiday configuration
                    'holidays_tracking_enabled' => ['value' => '0', 'desc' => 'Enable tracking on holidays'],
                    'holiday_notification_enabled' => ['value' => '0', 'desc' => 'Enable notifications on holidays'],
                    'auto_detect_holidays' => ['value' => '1', 'desc' => 'Automatically detect regional holidays'],
                    'holiday_country_code' => ['value' => 'US', 'desc' => 'Country code for holiday detection'],
                    'custom_holidays' => ['value' => '[]', 'desc' => 'Custom holidays in JSON format'],
                    'holiday_reminder_days' => ['value' => '3', 'desc' => 'Days before holiday to show reminder'],
                    'holiday_message' => ['value' => 'Today is a holiday. Enjoy your day off!', 'desc' => 'Holiday notification message']
                ]
            ];

            $initialized_count = 0;
            $existed_count = 0;
            $errors = [];

            // Use transaction for better atomicity
            $this->db->transStart();

            // Process settings by type
            foreach ($defaults_by_type as $type => $defaults) {
                foreach ($defaults as $setting_name => $setting_info) {
                    $setting_value = $setting_info['value'];

                    // Check if setting already exists using direct database query to avoid recursion
                    $existing = $this->get_setting_direct($setting_name);

                    if ($existing === null) {
                        // Create the setting with the appropriate type
                        $result = $this->save_setting($setting_name, $setting_value, $type);

                        if ($result) {
                            $initialized_count++;
                           
                        } else {
                            $errors[] = "Failed to initialize setting: {$setting_name}";                           
                        }
                    } else {
                        $existed_count++;
                    }
                }
            }

            $this->db->transComplete();

            if (!$this->db->transStatus()) {               
                return false;
            }

            // Clear all settings cache
            $this->clear_cache_pattern('setting_');
            $this->clear_cache_pattern('settings_');

            $success = empty($errors);

            self::$initializing_defaults = false; // Reset the guard
            return $success;
        } catch (\Exception $e) {            
            self::$initializing_defaults = false; // Reset the guard
            return false;
        }
    }

    /**
     * Create the tracker_settings table
     */
    private function createSettingsTable() {
        try {
           
            // Set shorter timeout for table creation
            if (function_exists('set_time_limit')) {
                set_time_limit(60);
            }

            $forge = \Config\Database::forge();

            $fields = [
                'id' => [
                    'type' => 'INT',
                    'constraint' => 11,
                    'unsigned' => true,
                    'auto_increment' => true
                ],
                'setting_name' => [
                    'type' => 'VARCHAR',
                    'constraint' => 100,
                    'null' => false
                ],
                'setting_value' => [
                    'type' => 'TEXT',
                    'null' => true
                ],
                'type' => [
                    'type' => 'VARCHAR',
                    'constraint' => 20,
                    'default' => 'app_settings',
                    'null' => false
                ],
                'created_at' => [
                    'type' => 'DATETIME',
                    'null' => false
                ],
                'updated_at' => [
                    'type' => 'DATETIME',
                    'null' => true
                ],
                'deleted' => [
                    'type' => 'TINYINT',
                    'constraint' => 1,
                    'default' => 0,
                    'null' => false
                ]
            ];

            $forge->addField($fields);
            $forge->addKey('id', true);
            $forge->addUniqueKey(['setting_name', 'type', 'deleted'], 'unique_setting_type');
            $forge->addKey(['setting_name']);
            $forge->addKey(['type']);

            $table_name = $this->db->prefixTable('tracker_settings');
            $result = $forge->createTable($table_name, true);

            if ($result) {
                return true;
            } else {
                return false;
            }
        } catch (\Exception $e) {
            
            return false;
        }
    }

    /**
     * Fix existing table constraints if needed
     */
    public function fixTableConstraints() {
        try {
            $table_name = $this->db->prefixTable('tracker_settings');
            
            // Check if table exists
            if (!$this->tableExists()) {
                return true; // Nothing to fix
            }
            
            // Try to add the new constraint
            try {
                $this->db->query("ALTER TABLE {$table_name} ADD UNIQUE KEY unique_setting_type (setting_name, type, deleted)");
                
            } catch (\Exception $e) {
               
            }
            
            return true;
            
        } catch (\Exception $e) {
            
            return false;
        }
    }
}
