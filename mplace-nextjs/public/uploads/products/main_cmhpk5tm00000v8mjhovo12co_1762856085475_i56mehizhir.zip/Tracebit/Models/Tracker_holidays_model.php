<?php

namespace Tracebit\Models;

use CodeIgniter\Model;

class Tracker_holidays_model extends Model {
    protected $table = 'tracker_holidays';
    protected $primaryKey = 'id';
    protected $allowedFields = ['name', 'start_date', 'end_date', 'duration', 'type', 'created_by', 'created_at', 'deleted'];

    protected $useSoftDeletes = true;
    protected $useTimestamps = false;
    protected $deletedField = 'deleted';

    public function __construct() {
        parent::__construct();
        $this->db = db_connect();

        // Get the table prefix and apply it to the table name
        $prefix = $this->db->getPrefix();
        $this->table = $prefix . 'tracker_holidays';

        $this->builder = $this->db->table($this->table);
    }

    /**
     * Get all holidays
     *
     * @param array $options Optional filters
     * @return array
     */
    public function get_all($options = []) {
        $this->builder->where('deleted', 0);

        if (isset($options['type'])) {
            $this->builder->where('type', $options['type']);
        }

        if (isset($options['start_date']) && isset($options['end_date'])) {
            // Find any holidays that overlap with the specified range
            $this->builder->where('(
                (start_date >= "' . $options['start_date'] . '" AND start_date <= "' . $options['end_date'] . '") OR
                (end_date >= "' . $options['start_date'] . '" AND end_date <= "' . $options['end_date'] . '") OR
                (start_date <= "' . $options['start_date'] . '" AND end_date >= "' . $options['end_date'] . '")
            )');
        } else if (isset($options['start_date'])) {
            $this->builder->where('start_date >=', $options['start_date']);
        } else if (isset($options['end_date'])) {
            $this->builder->where('end_date <=', $options['end_date']);
        }

        if (isset($options['order_by'])) {
            $this->builder->orderBy($options['order_by']);
        } else {
            $this->builder->orderBy('start_date', 'ASC');
        }

        $query = $this->builder->get();
        return $query->getResultArray();
    }

    /**
     * Get a single holiday by ID
     *
     * @param int $id
     * @return array
     */
    public function get_one($id) {
        return $this->builder->where('id', $id)
            ->where('deleted', 0)
            ->get()
            ->getRowArray();
    }

    /**
     * Insert a new holiday
     *
     * @param array $data
     * @return int|false
     */
    public function insert_holiday($data) {
        $data['created_at'] = date('Y-m-d H:i:s');
        $data['created_by'] = isset($this->login_user->id) ? $this->login_user->id : 1;

        $this->builder->insert($data);
        return $this->db->insertID();
    }

    /**
     * Update a holiday
     *
     * @param int $id
     * @param array $data
     * @return bool
     */
    public function update_holiday($id, $data) {
        return $this->builder->where('id', $id)
            ->update($data);
    }

    /**
     * Delete a holiday
     *
     * @param int $id
     * @return bool
     */
    public function delete_holiday($id) {
        return $this->builder->where('id', $id)
            ->update(['deleted' => 1]);
    }

    /**
     * Calculate the number of holidays within a date range
     *
     * @param string $start_date
     * @param string $end_date
     * @return int
     */
    public function count_holidays_in_range($start_date, $end_date) {
        $holidays = $this->get_all([
            'start_date' => $start_date,
            'end_date' => $end_date
        ]);

        $holiday_days = [];
        foreach ($holidays as $holiday) {
            $current_date = $holiday['start_date'];
            $end_date = $holiday['end_date'];

            while (strtotime($current_date) <= strtotime($end_date)) {
                $holiday_days[$current_date] = true;
                $current_date = date('Y-m-d', strtotime($current_date . ' +1 day'));
            }
        }

        return count($holiday_days);
    }

    /**
     * Get holidays as a formatted array for settings
     *
     * @return array
     */
    public function get_holidays_for_settings() {
        $holidays = $this->get_all();
        $formatted_holidays = [];

        foreach ($holidays as $holiday) {
            $formatted_holidays[] = [
                'name' => $holiday['name'],
                'start_date' => $holiday['start_date'],
                'end_date' => $holiday['end_date'],
                'duration' => $holiday['duration'],
                'type' => $holiday['type']
            ];
        }

        return $formatted_holidays;
    }

    /**
     * Save holidays from settings array
     *
     * @param array $holidays_data
     * @return bool
     */
    public function save_holidays_from_settings($holidays_data) {
        // First, mark all holidays as deleted
        $this->builder->update(['deleted' => 1]);

        // Then insert or update the holidays from settings
        if (!empty($holidays_data) && is_array($holidays_data)) {
            foreach ($holidays_data as $holiday) {
                // Check if this is an existing holiday by name and date
                $existing = $this->builder->where('name', $holiday['name'])
                    ->where('start_date', $holiday['start_date'])
                    ->get()
                    ->getRowArray();

                if ($existing) {
                    // Update
                    $this->update_holiday($existing['id'], [
                        'end_date' => $holiday['end_date'],
                        'duration' => $holiday['duration'],
                        'type' => $holiday['type'],
                        'deleted' => 0
                    ]);
                } else {
                    // Insert
                    $this->insert_holiday([
                        'name' => $holiday['name'],
                        'start_date' => $holiday['start_date'],
                        'end_date' => $holiday['end_date'],
                        'duration' => $holiday['duration'],
                        'type' => $holiday['type']
                    ]);
                }
            }
        }

        return true;
    }
}
