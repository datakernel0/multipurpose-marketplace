<?php

namespace Tracebit\Models;

use DateTime;

/**
 * Optimized Employee Status Model
 * Addresses N+1 queries, complex query optimization, and proper indexing
 */
class Employee_status_model extends Tracker_base_model {
    
    protected $table = 'tracker_attendance';
    protected $cache_ttl = 1800; // 30 minutes for attendance data

    public function __construct() {
        parent::__construct($this->table);
        parent::init_activity_log($this->db->prefixTable($this->table), "file_name", "project", "project_id");
    }

    /**
     * Get attendance report with pagination support
     * Reduces complex CTEs and improves performance
     */
    public function getAttendance($data = []) {
        $start_time = microtime(true);

        try {
            $rules = [
                'start_date' => 'required|valid_date',
                'end_date' => 'required|valid_date',
                'user_ids' => 'permit_empty|array',
                'department' => 'permit_empty|string',
                'length' => 'permit_empty|integer',
                'start' => 'permit_empty|integer',
                'search' => 'permit_empty|string',
                'order_column' => 'permit_empty|integer',
                'order_dir' => 'permit_empty|string'
            ];

            $validated_data = $this->validate_input($data, $rules);
            $start_date = $validated_data['start_date'];
            $end_date = $validated_data['end_date'];
            $user_ids = $validated_data['user_ids'] ?? [];

            // Pagination parameters
            $length = $validated_data['length'] ?? 10;
            $start = $validated_data['start'] ?? 0;
            $search = $validated_data['search'] ?? '';
            $order_column = $validated_data['order_column'] ?? 1;
            $order_dir = $validated_data['order_dir'] ?? 'asc';

            // Generate cache key
            $cache_key = $this->cache_prefix . "attendance_report_" .
                        md5($start_date . $end_date . serialize($user_ids) . $length . $start . $search);

            if ($this->enable_query_cache && empty($search)) {
                $cached_result = $this->cache->get($cache_key);
                if ($cached_result !== null) {
                    return $cached_result;
                }
            }

            // Optimized query with pagination support
            $sql = $this->build_attendance_query_optimized($start_date, $end_date, $user_ids, $search, $order_column, $order_dir, $length, $start);

            // Build parameter array for optimized query - 5 BETWEEN clauses + LIMIT/OFFSET
            $start_timestamp = strtotime($start_date) * 1000;
            $end_timestamp = strtotime($end_date . ' 23:59:59') * 1000;
            
            $params = [
                $start_timestamp, $end_timestamp, // att_summary: inTime BETWEEN
                $start_date, $end_date,           // leave_summary: start_date BETWEEN  
                $start_date, $end_date,           // perf_summary: takenTime BETWEEN
                $start_timestamp, $end_timestamp, // idle_summary: inTime BETWEEN
                $start_timestamp, $end_timestamp  // away_summary: inTime BETWEEN
            ];

            // Add search parameters if provided
            if (!empty($search)) {
                $params[] = "%$search%"; // For employee name search
            }

            // Add user_ids to params if provided
            if (!empty($user_ids)) {
                $params = array_merge($params, $user_ids);
            }

            // Add pagination parameters
            $params[] = (int)$length;
            $params[] = (int)$start;

            $query = $this->db->query($sql, $params);

            if ($query && method_exists($query, 'getResult')) {
                $result = $query->getResult();

                // Process and enhance results
                $processed_result = $this->process_attendance_results($result, $start_date, $end_date);

                if ($this->enable_query_cache && empty($search)) {
                    $this->cache->save($cache_key, $processed_result, $this->cache_ttl);
                }

                $this->monitor_query_performance('getAttendance', $start_time);
                return $processed_result;
            }

            return $this->handle_db_error('Failed to retrieve attendance data');

        } catch (\Exception $e) {
            return [];
        }
    }

    /**
     * Get total count of attendance records for pagination
     */
    public function getAttendanceCount($data = []) {
        try {
            $start_date = $data['start_date'];
            $end_date = $data['end_date'];
            $user_ids = $data['user_ids'] ?? [];
            $search = $data['search'] ?? '';

            $userTable = $this->db->prefixTable('users');

            $user_filter = '';
            if (!empty($user_ids)) {
                $placeholders = str_repeat('?,', count($user_ids) - 1) . '?';
                $user_filter = " AND u.id IN ($placeholders)";
            }

            $search_filter = '';
            if (!empty($search)) {
                $search_filter = " AND CONCAT(u.first_name, ' ', u.last_name) LIKE ?";
            }

            $sql = "SELECT COUNT(DISTINCT u.id) as total
                    FROM $userTable u
                    WHERE u.deleted = 0 AND u.user_type = 'staff' $user_filter $search_filter";

            $params = [];
            if (!empty($search)) {
                $params[] = "%$search%";
            }
            if (!empty($user_ids)) {
                $params = array_merge($params, $user_ids);
            }

            $query = $this->db->query($sql, $params);
            $result = $query->getRow();

            return $result ? $result->total : 0;

        } catch (\Exception $e) {
            return 0;
        }
    }

    /**
     * OPTIMIZED: Build attendance query with JOINs instead of subqueries
     * Fixes N+1 problem and performance issues
     */
    private function build_attendance_query_optimized($start_date, $end_date, $user_ids = [], $search = '', $order_column = 1, $order_dir = 'asc', $length = 10, $start = 0) {
        $userTable = $this->db->prefixTable('users');
        $attendanceTable = $this->db->prefixTable('tracker_attendance');
        $leaveTable = $this->db->prefixTable('leave_applications');
        $performanceTable = $this->db->prefixTable('tracker_performance');

        // Pre-calculate date range for better performance
        $start_timestamp = strtotime($start_date) * 1000;
        $end_timestamp = strtotime($end_date . ' 23:59:59') * 1000;

        // Build filters
        $user_filter = '';
        if (!empty($user_ids)) {
            $placeholders = str_repeat('?,', count($user_ids) - 1) . '?';
            $user_filter = "AND u.id IN ($placeholders)";
        }

        $search_filter = '';
        if (!empty($search)) {
            $search_filter = "AND CONCAT(u.first_name, ' ', u.last_name) LIKE ?";
        }

        // Order by mapping
        $order_columns = [
            0 => 'u.image',
            1 => 'employee_name',
            2 => 'total_worked_seconds',
            3 => 'first_in_time',
            4 => 'last_out_time',
            5 => 'present_days',
            6 => 'late_days',
            7 => 'total_leave_days',
            8 => 'avg_activity'
        ];

        $order_by_column = $order_columns[$order_column] ?? 'employee_name';
        $order_direction = (strtolower($order_dir) === 'desc') ? 'DESC' : 'ASC';

        return "
        SELECT 
            u.id,
            CONCAT(u.first_name, ' ', u.last_name) AS employee_name,
            u.image AS employee_image,
            u.id AS user_id,
            
            -- Worked hours calculation
            COALESCE(att_summary.total_worked_seconds, 0) AS total_worked_seconds,
            SEC_TO_TIME(COALESCE(att_summary.total_worked_seconds, 0)) AS worked_hours,
            
            -- First in time and last out time  
            att_summary.first_in_time AS inTime,
            att_summary.last_out_time AS outTime,
            
            -- Attendance counts
            COALESCE(att_summary.present_days, 0) AS present,
            COALESCE(att_summary.late_days, 0) AS late,
            
            -- Leave days
            COALESCE(leave_summary.total_leave_days, 0) AS total_leave,
            
            -- Performance/Activity
            COALESCE(perf_summary.avg_performance, 0) AS activity,
            
            -- Idle and away time
            COALESCE(idle_summary.idle_seconds, 0) AS idle_seconds,
            COALESCE(away_summary.away_seconds, 0) AS away_seconds

        FROM $userTable u

        -- LEFT JOIN for attendance summary
        LEFT JOIN (
            SELECT 
                user_id,
                COUNT(DISTINCT DATE(FROM_UNIXTIME(inTime / 1000))) AS present_days,
                SUM(CASE WHEN late = 1 THEN 1 ELSE 0 END) AS late_days,
                SUM(CASE 
                    WHEN outTime IS NOT NULL AND outTime > inTime 
                    THEN (outTime - inTime) / 1000 
                    ELSE 0 
                END) AS total_worked_seconds,
                MIN(inTime) AS first_in_time,
                MAX(outTime) AS last_out_time
            FROM $attendanceTable 
            WHERE inTime BETWEEN ? AND ?
              AND deleted = 0
            GROUP BY user_id
        ) att_summary ON u.id = att_summary.user_id

        -- LEFT JOIN for leave summary  
        LEFT JOIN (
            SELECT 
                applicant_id,
                SUM(CAST(total_days AS DECIMAL(10,2))) AS total_leave_days
            FROM $leaveTable 
            WHERE status = 'approved' 
              AND start_date BETWEEN ? AND ?
              AND deleted = 0
            GROUP BY applicant_id
        ) leave_summary ON u.id = leave_summary.applicant_id

        -- LEFT JOIN for performance summary
        LEFT JOIN (
            SELECT 
                user_id,
                AVG(performance) AS avg_performance
            FROM $performanceTable 
            WHERE takenTime BETWEEN ? AND ?
              AND deleted = 0 
              AND performance > 0
            GROUP BY user_id
        ) perf_summary ON u.id = perf_summary.user_id

        -- LEFT JOIN for idle time
        LEFT JOIN (
            SELECT 
                user_id,
                SUM(CASE 
                    WHEN outTime IS NOT NULL AND outTime > inTime 
                    THEN (outTime - inTime) / 1000 
                    ELSE 0 
                END) AS idle_seconds
            FROM $attendanceTable 
            WHERE inTime BETWEEN ? AND ?
              AND deleted = 0 
              AND project LIKE 'idle-%'
            GROUP BY user_id
        ) idle_summary ON u.id = idle_summary.user_id

        -- LEFT JOIN for away time
        LEFT JOIN (
            SELECT 
                user_id,
                SUM(CASE 
                    WHEN outTime IS NOT NULL AND outTime > inTime 
                    THEN (outTime - inTime) / 1000 
                    ELSE 0 
                END) AS away_seconds
            FROM $attendanceTable 
            WHERE inTime BETWEEN ? AND ?
              AND deleted = 0 
              AND project LIKE 'b-%' 
              AND (isMinusBreak IS NULL OR isMinusBreak = 0)
            GROUP BY user_id
        ) away_summary ON u.id = away_summary.user_id

        WHERE u.deleted = 0 
          AND u.user_type = 'staff' 
          $user_filter 
          $search_filter
        
        GROUP BY u.id, u.first_name, u.last_name, u.image
        ORDER BY $order_by_column $order_direction
        LIMIT ? OFFSET ?
        ";
    }

    /**
     * BACKUP: Original attendance query (kept for reference)
     * ⚠️ WARNING: This has N+1 performance issues - use build_attendance_query_optimized instead
     */
    private function build_attendance_query_original($start_date, $end_date, $user_ids = [], $search = '', $order_column = 1, $order_dir = 'asc', $length = 10, $start = 0) {
        $userTable = $this->db->prefixTable('users');
        $attendanceTable = $this->db->prefixTable('tracker_attendance');
        $leaveTable = $this->db->prefixTable('leave_applications');
        $performanceTable = $this->db->prefixTable('tracker_performance');

        $user_filter = '';
        if (!empty($user_ids)) {
            $placeholders = str_repeat('?,', count($user_ids) - 1) . '?';
            $user_filter = " AND u.id IN ($placeholders)";
        }

        $search_filter = '';
        if (!empty($search)) {
            $search_filter = " AND CONCAT(u.first_name, ' ', u.last_name) LIKE ?";
        }

        $order_columns = [
            0 => 'u.first_name',
            1 => 'employee_name',
            2 => 'inTime',
            3 => 'outTime',
            4 => 'present',
            5 => 'worked_hours',
            6 => 'overtime',
            7 => 'due_time',
            8 => 'idle',
            9 => 'activity'
        ];

        $order_by_column = $order_columns[$order_column] ?? 'u.first_name';
        $order_direction = strtoupper($order_dir) === 'DESC' ? 'DESC' : 'ASC';

        return "SELECT " .
            "u.id, " .
            "CONCAT(u.first_name, ' ', u.last_name) AS employee_name, " .
            "u.image AS employee_image, " .
            "u.id AS user_id, " .
            "SEC_TO_TIME(COALESCE(SUM(CASE WHEN a.outTime IS NOT NULL AND a.outTime > a.inTime THEN (a.outTime - a.inTime) / 1000 ELSE 0 END), 0)) AS worked_hours, " .
            "(SELECT att.inTime FROM $attendanceTable att WHERE att.user_id = u.id AND DATE(FROM_UNIXTIME(att.inTime / 1000)) BETWEEN ? AND ? AND att.deleted = 0 ORDER BY att.inTime ASC LIMIT 1) AS inTime, " .
            "(SELECT att.outTime FROM $attendanceTable att WHERE att.user_id = u.id AND DATE(FROM_UNIXTIME(att.outTime / 1000)) BETWEEN ? AND ? AND att.deleted = 0 AND att.outTime IS NOT NULL ORDER BY att.outTime DESC LIMIT 1) AS outTime, " .
            "(SELECT COUNT(DISTINCT DATE(FROM_UNIXTIME(att.inTime / 1000))) FROM $attendanceTable att WHERE att.user_id = u.id AND DATE(FROM_UNIXTIME(att.inTime / 1000)) BETWEEN ? AND ? AND att.deleted = 0) AS present, " .
            "(SELECT COUNT(DISTINCT DATE(FROM_UNIXTIME(att.inTime / 1000))) FROM $attendanceTable att WHERE att.user_id = u.id AND DATE(FROM_UNIXTIME(att.inTime / 1000)) BETWEEN ? AND ? AND att.note != '0' AND att.deleted = 0) AS late, " .
            "COALESCE((SELECT SUM(CAST(l.total_days AS DECIMAL(10,2))) FROM $leaveTable l WHERE l.applicant_id = u.id AND l.status = 'approved' AND DATE(l.start_date) BETWEEN ? AND ?), 0) AS total_leave, " .
            "COALESCE((SELECT AVG(p.performance) " .
                "FROM $performanceTable p " .
                "WHERE p.user_id = u.id " .
                "AND DATE(p.takenTime) BETWEEN ? AND ? " .
                "AND p.deleted = 0 " .
                "AND p.performance > 0" .
            "), 0) AS activity, " .
            "COALESCE((SELECT SUM(CASE WHEN idle_att.outTime IS NOT NULL AND idle_att.outTime > idle_att.inTime THEN (idle_att.outTime - idle_att.inTime) / 1000 ELSE 0 END) FROM $attendanceTable idle_att WHERE idle_att.user_id = u.id AND DATE(FROM_UNIXTIME(idle_att.inTime / 1000)) BETWEEN ? AND ? AND idle_att.deleted = 0 AND idle_att.project LIKE 'idle-%'), 0) AS idle_seconds, " .
            "COALESCE((SELECT SUM(CASE WHEN away_att.outTime IS NOT NULL AND away_att.outTime > away_att.inTime THEN (away_att.outTime - away_att.inTime) / 1000 ELSE 0 END) FROM $attendanceTable away_att WHERE away_att.user_id = u.id AND DATE(FROM_UNIXTIME(away_att.inTime / 1000)) BETWEEN ? AND ? AND away_att.deleted = 0 AND away_att.project LIKE 'b-%' AND (away_att.isMinusBreak IS NULL OR away_att.isMinusBreak = 0)), 0) AS away_seconds " .
            "FROM $userTable u " .
            "LEFT JOIN $attendanceTable a ON u.id = a.user_id AND DATE(FROM_UNIXTIME(a.inTime / 1000)) BETWEEN ? AND ? AND a.deleted = 0 " .
            "WHERE u.deleted = 0 AND u.user_type = 'staff' $user_filter $search_filter " .
            "GROUP BY u.id, u.first_name, u.last_name, u.image " .
            "ORDER BY $order_by_column $order_direction " .
            "LIMIT ? OFFSET ?";
    }

    /**
     * 📊 RECOMMENDED DATABASE INDEXES for Performance
     * 
     * Run these CREATE INDEX statements to optimize query performance:
     * 
     * -- For tracker_attendance table
     * CREATE INDEX idx_attendance_user_intime ON tracker_attendance(user_id, inTime, deleted);
     * CREATE INDEX idx_attendance_user_date ON tracker_attendance(user_id, deleted, inTime);
     * CREATE INDEX idx_attendance_project ON tracker_attendance(project, deleted);
     * CREATE INDEX idx_attendance_late ON tracker_attendance(user_id, late, deleted);
     * 
     * -- For leave_applications table  
     * CREATE INDEX idx_leave_applicant_dates ON leave_applications(applicant_id, start_date, end_date, status, deleted);
     * 
     * -- For tracker_performance table
     * CREATE INDEX idx_performance_user_time ON tracker_performance(user_id, takenTime, deleted);
     * 
     * -- For users table
     * CREATE INDEX idx_users_type_deleted ON users(user_type, deleted);
     * 
     * These indexes will significantly improve query performance!
     */
    private function getDatabaseIndexRecommendations() {
        return [
            'tracker_attendance' => [
                'idx_attendance_user_intime' => 'user_id, inTime, deleted',
                'idx_attendance_user_date' => 'user_id, deleted, inTime', 
                'idx_attendance_project' => 'project, deleted',
                'idx_attendance_late' => 'user_id, late, deleted'
            ],
            'leave_applications' => [
                'idx_leave_applicant_dates' => 'applicant_id, start_date, end_date, status, deleted'
            ],
            'tracker_performance' => [
                'idx_performance_user_time' => 'user_id, takenTime, deleted'
            ],
            'users' => [
                'idx_users_type_deleted' => 'user_type, deleted'
            ]
        ];
    }

    /**
     * Process attendance results to add calculated fields
     */
    private function process_attendance_results($results, $start_date, $end_date) {
        $working_days = $this->get_working_days_count($start_date, $end_date);
        $daily_hours = 8; // Standard working hours

        foreach ($results as $result) {
            // Calculate absent days
            $result->absent = max(0, $working_days - $result->present - $result->total_leave);

            // Calculate estimated hours
            $result->est_hours = ($working_days - $result->total_leave) * $daily_hours;

            // Calculate due time and overtime
            $worked_seconds = $this->time_to_seconds($result->worked_hours);
            $expected_seconds = $result->est_hours * 3600;

            if ($worked_seconds < $expected_seconds) {
                $result->due_time = $this->seconds_to_time($expected_seconds - $worked_seconds);
                $result->over_time = '00:00:00';
            } else {
                $result->due_time = '00:00:00';
                $result->over_time = $this->seconds_to_time($worked_seconds - $expected_seconds);
            }

            // Format activity percentage
            $result->activity = round($result->activity, 1);
        }

        return $results;
    }

    /**
     * Get timesheet data with pagination and optimization
     */
    public function timeSheet($data = []) {
        $start_time = microtime(true);
       
        try {
            $rules = [
                'user_id' => 'required|integer',
                'start_date' => 'permit_empty|valid_date',
                'end_date' => 'permit_empty|valid_date',
                'page' => 'permit_empty|integer',
                'per_page' => 'permit_empty|integer'
            ];

            $validated_data = $this->validate_input($data, $rules);
            
            $user_id = $validated_data['user_id'];
            $start_date = $validated_data['start_date'] ?? date('Y-m-01'); // First day of current month
            $end_date = $validated_data['end_date'] ?? date('Y-m-t'); // Last day of current month
            $page = max(1, $validated_data['page'] ?? 1);
            $per_page = min(100, $validated_data['per_page'] ?? 31);
            $offset = ($page - 1) * $per_page;

            // Generate cache key
            $cache_key = $this->cache_prefix . "timesheet_user_{$user_id}_" .
                        md5($start_date . $end_date . $page . $per_page);
           
            // Optimized timesheet query
            $sql = $this->build_timesheet_query($user_id, $start_date, $end_date, $per_page, $offset);
            // Build parameter array for timesheet query
            $params = [
                $user_id,       // First check-in user_id
                $user_id,       // Last check-out user_id
                $user_id,       // Activity user_id
                $start_date,    // Date range start for date generation
                $start_date,    // Date range start for date comparison
                $end_date,      // Date range end
                $user_id,       // Attendance join user_id
                $user_id        // Leave join user_id
            ];

            $query = $this->db->query($sql, $params);
            if ($query && method_exists($query, 'getResult')) {
                $result = $query->getResult();
               
                $processed_result = [
                    'data' => $result,
                    'pagination' => [
                        'page' => $page,
                        'per_page' => $per_page,
                        'total' => $this->get_timesheet_count($user_id, $start_date, $end_date)
                    ]
                ];
                
                $this->monitor_query_performance('timeSheet', $start_time);
                
                return $processed_result;
            }

            return $this->handle_db_error('Failed to retrieve timesheet data');

        } catch (\Exception $e) {
            return ['data' => [], 'pagination' => ['page' => 1, 'per_page' => 31, 'total' => 0]];
        }
    }

    /**
     * Build optimized timesheet query
     */
    private function build_timesheet_query($user_id, $start_date, $end_date, $limit, $offset) {
        $attendanceTable = $this->db->prefixTable('tracker_attendance');
        $performanceTable = $this->db->prefixTable('tracker_performance');
        $leaveTable = $this->db->prefixTable('leave_applications');

        return "SELECT " .
            "d.date, " .
            "SEC_TO_TIME(COALESCE(SUM(CASE WHEN a.outTime IS NOT NULL AND a.outTime > a.inTime THEN (a.outTime - a.inTime) / 1000 ELSE 0 END), 0)) AS worked_hours, " .
            "(SELECT MIN(att.inTime) FROM $attendanceTable att WHERE att.user_id = ? AND DATE(FROM_UNIXTIME(att.inTime / 1000)) = d.date AND att.deleted = 0) AS inTime, " .
            "(SELECT MAX(att.outTime) FROM $attendanceTable att WHERE att.user_id = ? AND DATE(FROM_UNIXTIME(att.outTime / 1000)) = d.date AND att.deleted = 0 AND att.outTime IS NOT NULL) AS outTime, " .
            "CASE WHEN l.id IS NOT NULL THEN 'On Leave' WHEN a.user_id IS NOT NULL THEN 'Present' WHEN DAYOFWEEK(d.date) IN (1, 7) THEN 'Weekend' ELSE 'Absent' END AS status, " .
            "COALESCE((SELECT AVG(p.performance) FROM $performanceTable p WHERE p.user_id = ? AND DATE(p.takenTime) = d.date AND p.deleted = 0), 0) AS activity, " .
            "'00:00:00' AS idle, " .
            "'00:00:00' AS group_discussion " .
            "FROM (SELECT DATE_ADD(?, INTERVAL seq.seq DAY) as date FROM (SELECT a.i + b.i * 10 + c.i * 100 as seq FROM (SELECT 0 i UNION SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 UNION SELECT 5 UNION SELECT 6 UNION SELECT 7 UNION SELECT 8 UNION SELECT 9) a CROSS JOIN (SELECT 0 i UNION SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 UNION SELECT 5 UNION SELECT 6 UNION SELECT 7 UNION SELECT 8 UNION SELECT 9) b CROSS JOIN (SELECT 0 i UNION SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 UNION SELECT 5 UNION SELECT 6 UNION SELECT 7 UNION SELECT 8 UNION SELECT 9) c) seq WHERE DATE_ADD(?, INTERVAL seq.seq DAY) <= ?) d " .
            "LEFT JOIN $attendanceTable a ON DATE(FROM_UNIXTIME(a.inTime / 1000)) = d.date AND a.user_id = ? AND a.deleted = 0 " .
            "LEFT JOIN $leaveTable l ON DATE(l.start_date) <= d.date AND DATE(l.end_date) >= d.date AND l.applicant_id = ? AND l.status = 'approved' " .
            "GROUP BY d.date " .
            "ORDER BY d.date ASC";
    }

    /**
     * Get working days count between dates
     */
    private function get_working_days_count($start_date, $end_date) {
        $sql = "SELECT COUNT(*) as count
                FROM (
                    SELECT DATE_ADD(?, INTERVAL seq.seq DAY) as date
                    FROM (
                        SELECT a.i + b.i * 10 + c.i * 100 as seq
                        FROM (SELECT 0 i UNION SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4
                              UNION SELECT 5 UNION SELECT 6 UNION SELECT 7 UNION SELECT 8 UNION SELECT 9) a
                        CROSS JOIN (SELECT 0 i UNION SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4
                                   UNION SELECT 5 UNION SELECT 6 UNION SELECT 7 UNION SELECT 8 UNION SELECT 9) b
                        CROSS JOIN (SELECT 0 i UNION SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4
                                   UNION SELECT 5 UNION SELECT 6 UNION SELECT 7 UNION SELECT 8 UNION SELECT 9) c
                    ) seq
                    WHERE DATE_ADD(?, INTERVAL seq.seq DAY) <= ?
                    AND DAYOFWEEK(DATE_ADD(?, INTERVAL seq.seq DAY)) NOT IN (1, 7)
                ) working_days";

        $query = $this->cached_query($sql, [$start_date, $start_date, $end_date, $start_date], 3600);

        if ($query) {
            $result = $query->getResult();
            return $result[0]->count ?? 0;
        }

        return 0;
    }

    /**
     * Get timesheet count for pagination
     */
    private function get_timesheet_count($user_id, $start_date, $end_date) {
        $sql = "SELECT DATEDIFF(?, ?) + 1 as count";

        $query = $this->cached_query($sql, [$end_date, $start_date], 3600);

        if ($query) {
            $result = $query->getResult();
            return $result[0]->count ?? 0;
        }

        return 0;
    }

    /**
     * Activity log with optimization
     */
    public function activityLog($data = []) {
        $start_time = microtime(true);

        try {
            $rules = [
                'user_id' => 'permit_empty|integer',
                'start_date' => 'required|valid_date',
                'end_date' => 'required|valid_date',
                'project_id' => 'permit_empty|integer',
                'activity_threshold' => 'permit_empty|integer'
            ];

            $validated_data = $this->validate_input($data, $rules);
            $user_id = $validated_data['user_id'] ?? null;
            $start_date = $validated_data['start_date'];
            $end_date = $validated_data['end_date'];
            $project_id = $validated_data['project_id'] ?? null;
            $threshold = $validated_data['activity_threshold'] ?? 0;

            // Build activity log query
            $sql = $this->build_activity_log_query($user_id, $start_date, $end_date, $project_id, $threshold);

            $binds = [$start_date, $end_date];
            if ($user_id) $binds[] = $user_id;
            if ($project_id) $binds[] = $project_id;
            if ($threshold > 0) $binds[] = $threshold;

            $query = $this->cached_query($sql, $binds, 900); // 15 min cache

            if ($query) {
                $this->monitor_query_performance('activityLog', $start_time);
                return $query->getResult();
            }

            return $this->handle_db_error('Failed to retrieve activity log');

        } catch (\Exception $e) {
            return [];
        }
    }

    /**
     * Build activity log query
     */
    private function build_activity_log_query($user_id, $start_date, $end_date, $project_id, $threshold) {
        $performanceTable = $this->db->prefixTable('tracker_performance');
        $userTable = $this->db->prefixTable('users');
        $projectTable = $this->db->prefixTable('projects');

        $where_clauses = ["DATE(p.takenTime) BETWEEN ? AND ?"];

        if ($user_id) {
            $where_clauses[] = "p.user_id = ?";
        }

        if ($project_id) {
            $where_clauses[] = "p.project = (SELECT title FROM $projectTable WHERE id = ?)";
        }

        if ($threshold > 0) {
            $where_clauses[] = "p.performance >= ?";
        }

        $where_clause = implode(' AND ', $where_clauses);

        return "SELECT " .
            "p.id, " .
            "p.user_id, " .
            "CONCAT(u.first_name, ' ', u.last_name) as user_name, " .
            "p.project, " .
            "p.performance, " .
            "p.takenTime, " .
            "DATE(p.takenTime) as activity_date, " .
            "TIME(p.takenTime) as activity_time " .
            "FROM $performanceTable p " .
            "INNER JOIN $userTable u ON p.user_id = u.id AND u.deleted = 0 " .
            "WHERE $where_clause " .
            "AND p.deleted = 0 " .
            "ORDER BY p.takenTime DESC " .
            "LIMIT 500";
    }

    /**
     * Helper function to convert time string to seconds
     */
    private function time_to_seconds($time_str) {
        if (empty($time_str) || $time_str === '00:00:00') {
            return 0;
        }

        $parts = explode(':', $time_str);
        return ($parts[0] * 3600) + ($parts[1] * 60) + ($parts[2] ?? 0);
    }

    /**
     * Helper function to convert seconds to time string
     */
    private function seconds_to_time($seconds) {
        if ($seconds <= 0) {
            return '00:00:00';
        }

        $hours = floor($seconds / 3600);
        $minutes = floor(($seconds % 3600) / 60);
        $seconds = $seconds % 60;

        return sprintf('%02d:%02d:%02d', $hours, $minutes, $seconds);
    }

    /**
     * Create or populate Calendar table for date range operations
     * This method ensures calendar dates exist for the given date range
     */
    function createCalender ($data = array()) {

      $this->db->query("DROP TABLE IF EXISTS Calendar");
      $start_date = $data['start_date'];
      $end_date = $data['end_date'];
    
      // Create the Calendar table
      $create_calender = "CREATE TABLE IF NOT EXISTS Calendar (
          date DATE PRIMARY KEY
      )";
      $ccd = $this->db->query($create_calender);

      // Insert data into the Calendar table
      $insert_data = "INSERT INTO Calendar (date)
      SELECT CURDATE() - INTERVAL (a.a + (10 * b.a) + (100 * c.a)) DAY
      FROM (SELECT 0 as a UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4
          UNION ALL SELECT 5 UNION ALL SELECT 6 UNION ALL SELECT 7 UNION ALL SELECT 8 UNION ALL SELECT 9) a
      CROSS JOIN (SELECT 0 as a UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4
          UNION ALL SELECT 5 UNION ALL SELECT 6 UNION ALL SELECT 7 UNION ALL SELECT 8 UNION ALL SELECT 9) b
      CROSS JOIN (SELECT 0 as a UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4
          UNION ALL SELECT 5 UNION ALL SELECT 6 UNION ALL SELECT 7 UNION ALL SELECT 8 UNION ALL SELECT 9) c
      WHERE CURDATE() - INTERVAL (a.a + (10 * b.a) + (100 * c.a)) DAY BETWEEN '$start_date' AND '$end_date'";
      $ccd = $this->db->query($insert_data);

      if($ccd) {
         error_log( print_r( "Table Successfully Created", true ) );
      } else {
          $error = $this->db->error();
          error_log( print_r( "No it is not update- ". $error['message'], true ) );
      }
  }

    /**
     * Validate if a string is a valid date
     */
    private function isValidDate($date) {
        $d = DateTime::createFromFormat('Y-m-d', $date);
        return $d && $d->format('Y-m-d') === $date;
    }

    /**
     * Get screenshots for a specific date and user
     */
    public function getScreenshots($view_data = []) {
        $start_time = microtime(true);

        try {
            $rules = [
                'date' => 'permit_empty|valid_date',
                'user_id' => 'permit_empty|integer'
            ];

            $validated_data = $this->validate_input($view_data, $rules);
            $date = $validated_data['date'] ?? date('Y-m-d');
            $user_id = $validated_data['user_id'] ?? null;

            // Generate cache key
            $cache_key = $this->cache_prefix . "screenshots_" .
                        md5($date . ($user_id ?? 'all'));

            if ($this->enable_query_cache) {
                $cached_result = $this->cache->get($cache_key);
                if ($cached_result !== null) {
                    return $cached_result;
                }
            }

            // Build screenshots query
            $sql = $this->build_screenshots_query($date, $user_id);

            $binds = [$date . '%'];
            if ($user_id) {
                $binds[] = $user_id;
            }

            $query = $this->db->query($sql, $binds);

            if ($query && method_exists($query, 'getResult')) {
                $result = $query->getResult();

                if ($this->enable_query_cache) {
                    $this->cache->save($cache_key, $result, 1800); // 30 min cache
                }

                $this->monitor_query_performance('getScreenshots', $start_time);
                return $result;
            }

            return $this->handle_db_error('Failed to retrieve screenshots');

        } catch (\Exception $e) {
            return [];
        }
    }

    /**
     * Build screenshots query
     */
    private function build_screenshots_query($date, $user_id = null) {
        $screenshotsTable = $this->db->prefixTable('tracker_screenshots');
        $userTable = $this->db->prefixTable('users');

        $user_filter = '';
        if ($user_id) {
            $user_filter = " AND s.user_id = ?";
        }

        return "SELECT " .
            "s.id, " .
            "s.user_id, " .
            "CONCAT(u.first_name, ' ', u.last_name) AS user_name, " .
            "s.file_name, " .
            "s.project, " .
            "s.taken_time, " .
            "s.activity_percentage, " .
            "DATE_FORMAT(s.taken_time, '%H:%i:%s') as time_taken, " .
            "DATE_FORMAT(s.taken_time, '%Y-%m-%d') as date_taken " .
            "FROM $screenshotsTable s " .
            "INNER JOIN $userTable u ON s.user_id = u.id " .
            "WHERE s.taken_time LIKE ? " .
            "$user_filter " .
            "AND s.deleted = 0 " .
            "AND u.deleted = 0 " .
            "ORDER BY s.taken_time DESC " .
            "LIMIT 100";
    }

    /**
     * Get all attendance data for status counting
     */
    public function get_all_attendance_data() {
        try {
            // Get today's date in user's timezone (consistent with dashboard helpers)
            $today = $this->getDateInUserTimezone('Y-m-d');

            // Get proper table names with prefix
            $usersTable = $this->db->prefixTable('users');
            $attendanceTable = $this->db->prefixTable('tracker_attendance');
            $performanceTable = $this->db->prefixTable('tracker_performance');
            $leaveTable = $this->db->prefixTable('leave_applications');

            $sql = "SELECT
                        u.id as user_id,
                        att.inTime,
                        att.outTime,
                        COALESCE(perf.activity, 0) as activity,
                        CASE WHEN att.inTime IS NOT NULL THEN 1 ELSE 0 END as present,
                        COALESCE(leave_info.total_leave, 0.00) as total_leave,
                        u.first_name,
                        u.last_name,
                        u.image as employee_image
                    FROM {$usersTable} u
                    LEFT JOIN {$attendanceTable} att ON u.id = att.user_id
                        AND DATE(FROM_UNIXTIME(att.inTime / 1000)) = ?
                    LEFT JOIN (
                        SELECT user_id, AVG(performance) as activity
                        FROM {$performanceTable}
                        WHERE DATE(takenTime) = ?
                        AND deleted = 0
                        AND performance > 0
                        GROUP BY user_id
                    ) perf ON u.id = perf.user_id
                    LEFT JOIN (
                        SELECT applicant_id as user_id, SUM(total_days) as total_leave
                        FROM {$leaveTable}
                        WHERE status = 'approved'
                        AND ? BETWEEN start_date AND end_date
                        GROUP BY applicant_id
                    ) leave_info ON u.id = leave_info.user_id
                    WHERE u.user_type = 'staff'
                    AND u.deleted = 0

                    GROUP BY u.id
                    ORDER BY u.first_name, u.last_name";

            $query = $this->db->query($sql, [$today, $today, $today]);
            $result = $query->getResult();

            return $result;

        } catch (\Exception $e) {
            return [];
        }
    }

    /**
     * Get date in user's timezone (consistent with dashboard helpers)
     * @param string $format Date format (default: 'Y-m-d')
     * @return string Formatted date in user timezone
     */
    private function getDateInUserTimezone($format = 'Y-m-d') {
        $originalTimezone = date_default_timezone_get();
        date_default_timezone_set('Asia/Dhaka'); // Set to local timezone
        $date = date($format);
        date_default_timezone_set($originalTimezone); // Reset to original
        return $date;
    }

    /**
     * Get session data for a specific date and user
     * @param string $date Date in Y-m-d format
     * @param int $user_id User ID
     * @return array|false Session data or false on error
     */
    public function get_session_data($date, $user_id) {
        try {
            if (!$date || !$user_id) {
                return [];
            }

            // First try to get data from tracker_attendance table
            $attendanceTable = $this->db->prefixTable('tracker_attendance');
            $attendance_sql = "
                SELECT
                    id,
                    inTime,
                    outTime,
                    project,
                    note,
                    CASE
                        WHEN outTime IS NOT NULL AND outTime > inTime THEN
                            CONCAT(
                                FLOOR((outTime - inTime) / 1000 / 3600), 'h ',
                                FLOOR(((outTime - inTime) / 1000 % 3600) / 60), 'm'
                            )
                        ELSE 'Active'
                    END as duration,
                    CASE
                        WHEN outTime IS NULL THEN 'Active'
                        ELSE 'Completed'
                    END as status,
                    FROM_UNIXTIME(inTime / 1000) as created_at
                FROM {$attendanceTable}
                WHERE user_id = ?
                AND DATE(FROM_UNIXTIME(inTime / 1000)) = ?
                AND deleted = 0
                ORDER BY inTime ASC
            ";

            $query = $this->db->query($attendance_sql, [$user_id, $date]);
            $attendance_data = $query->getResult();

            // Get productivity data for the same date
            $performanceTable = $this->db->prefixTable('tracker_performance');
            $productivity_sql = "
                SELECT AVG(performance) as avg_productivity
                FROM {$performanceTable}
                WHERE user_id = ?
                AND DATE(FROM_UNIXTIME(takenTime / 1000)) = ?
                AND deleted = 0
                AND performance > 0
            ";

            $productivity_query = $this->db->query($productivity_sql, [$user_id, $date]);
            $productivity_result = $productivity_query->getRow();
            $avg_productivity = $productivity_result ? round($productivity_result->avg_productivity, 1) : 0;

            // Get projects for name resolution
            $projectsTable = $this->db->prefixTable('projects');
            $projects_sql = "SELECT id, title FROM {$projectsTable} WHERE deleted = 0";
            $projects_query = $this->db->query($projects_sql);
            $projects_data = $projects_query->getResult();

            // Create projects lookup array
            $projects_lookup = [];
            foreach ($projects_data as $project) {
                $projects_lookup[$project->id] = $project->title;
            }

            // Get tracker breaks for break name resolution
            $breaksTable = $this->db->prefixTable('tracker_breaks');
            $breaks_sql = "SELECT id, name FROM {$breaksTable} WHERE deleted_at IS NULL";
            $breaks_query = $this->db->query($breaks_sql);
            $breaks_data = $breaks_query->getResult();

            // Create breaks lookup array
            $breaks_lookup = [];
            foreach ($breaks_data as $break_item) {
                $breaks_lookup[$break_item->id] = $break_item->name;
            }

            // Format the data for the modal
            $formatted_sessions = [];
            foreach ($attendance_data as $session) {
                // Convert timestamps to Asia/Dhaka timezone (matching dashboard_helpers.php)
                $start_time = '';
                $end_time = '';

                if ($session->inTime) {
                    $originalTimezone = date_default_timezone_get();
                    date_default_timezone_set('Asia/Dhaka');
                    $start_time = date('h:i A', $session->inTime / 1000);
                    date_default_timezone_set($originalTimezone);
                }

                if ($session->outTime) {
                    $originalTimezone = date_default_timezone_get();
                    date_default_timezone_set('Asia/Dhaka');
                    $end_time = date('h:i A', $session->outTime / 1000);
                    date_default_timezone_set($originalTimezone);
                }

                // Create session time range
                $session_time = $start_time;
                if ($end_time && $session->status === 'Completed') {
                    $session_time .= ' - ' . $end_time;
                }

                // Resolve project name based on project code
                $project_name = 'Other';
                $description = 'Other';

                if ($session->project) {
                    if (strpos($session->project, 'b-') === 0) {
                        // Break project - extract break ID and get name from tracker_breaks
                        $break_id = substr($session->project, 2); // Remove 'b-' prefix
                        if (isset($breaks_lookup[$break_id])) {
                            $project_name = $breaks_lookup[$break_id];
                            $description = $breaks_lookup[$break_id];
                        } else {
                            $project_name = 'Break';
                            $description = 'Break';
                        }
                    } elseif (strpos($session->project, 'idle-') === 0) {
                        // Idle time - static
                        $project_name = 'Idle Time';
                        $description = 'Idle Time';
                    } elseif (strpos($session->project, 'manual-') === 0) {
                        // Manual time - static
                        $project_name = 'Manual Time';
                        $description = 'Manual Time';
                    } else {
                        // Regular project - get from projects table
                        if (isset($projects_lookup[$session->project])) {
                            $project_name = $projects_lookup[$session->project];
                            $description = $projects_lookup[$session->project];
                        } else {
                            // Fallback to smart description based on project string
                            if (stripos($session->project, 'formgent') !== false) {
                                $description = 'FormGent';
                            } elseif (stripos($session->project, 'study') !== false || stripos($session->project, 'islamic') !== false) {
                                $description = 'Islamic Study and Lecture';
                            } elseif (stripos($session->project, 'meeting') !== false) {
                                $description = 'Meeting';
                            } elseif (stripos($session->project, 'development') !== false || stripos($session->project, 'dev') !== false) {
                                $description = 'Development';
                            } elseif (stripos($session->project, 'testing') !== false || stripos($session->project, 'test') !== false) {
                                $description = 'Testing';
                            } elseif (stripos($session->project, 'review') !== false) {
                                $description = 'Code Review';
                            }
                            $project_name = $description;
                        }
                    }
                }

                // Use note if available, otherwise use project-based description
                if (!empty($session->note) && $session->note !== '0') {
                    $description = $session->note;
                }

                $formatted_sessions[] = (object)[
                    'id' => $session->id,
                    'session_time' => $session_time,
                    'start_time' => $start_time,
                    'end_time' => $end_time,
                    'description' => $description,
                    'project_name' => $project_name,
                    'duration' => $session->duration,
                    'status' => $session->status,
                    'project' => $session->project,
                    'created_at' => $session->created_at,
                    'productivity' => $avg_productivity // Add productivity to each session
                ];
            }

            return [
                'sessions' => $formatted_sessions,
                'avg_productivity' => $avg_productivity
            ];

        } catch (\Exception $e) {
            return [];
        }
    }

    /**
     * Delete a tracker attendance session
     */
    public function delete_session($session_id, $user_id = null) {
        try {
            $attendanceTable = $this->db->prefixTable('tracker_attendance');

            // Build the WHERE clause
            $where_conditions = ["id = ?"];
            $params = [$session_id];

            // Add user_id check if provided for security
            if ($user_id) {
                $where_conditions[] = "user_id = ?";
                $params[] = $user_id;
            }

            $where_clause = implode(" AND ", $where_conditions);

            // Soft delete by setting deleted = 1
            $sql = "UPDATE {$attendanceTable} SET deleted = 1 WHERE {$where_clause}";

            $query = $this->db->query($sql, $params);

            if ($query) {
                return true;
            } else {
                return false;
            }

        } catch (\Exception $e) {
            return false;
        }
    }

    /**
     * Get all active staff users with their basic information
     */
    public function getActiveStaffUsers() {
        $usersTable = $this->db->prefixTable('users');
        try {
            $query = $this->db->query("
                SELECT id, first_name, last_name, email, image 
                FROM $usersTable 
                WHERE user_type = 'staff' AND status = 'active' AND deleted = 0
                ORDER BY first_name, last_name
            ");
            
            return $query->getResult();
        } catch (\Exception $e) {
            return [];
        }
    }

    /**
     * Get tracker settings by setting names
     */
    public function getTrackerSettings($setting_names = []) {
        $settingsTable = $this->db->prefixTable('tracker_settings');
        try {
            if (empty($setting_names)) {
                return [];
            }

            $placeholders = str_repeat('?,', count($setting_names) - 1) . '?';
            
            $query = $this->db->query("
                SELECT setting_name, setting_value 
                FROM $settingsTable 
                WHERE setting_name IN ($placeholders) AND deleted = 0
            ", $setting_names);
            
            $settings = [];
            foreach ($query->getResult() as $setting) {
                $settings[$setting->setting_name] = $setting->setting_value;
            }
            
            return $settings;
        } catch (\Exception $e) {
            return [];
        }
    }

    /**
     * Get user attendance statistics for date range
     */
    public function getUserAttendanceStats($user_id, $start_date, $end_date) {
        $attendanceTable = $this->db->prefixTable('tracker_attendance');
        $leaveTable = $this->db->prefixTable('leave_applications');
        $tracker_holidays_table = $this->db->prefixTable('tracker_holidays');
        
        try {
            // Get working hours start and weekend days from settings
            $settings = $this->getTrackerSettings(['working_hours_start', 'weekend_days']);
            $working_hours_start = $settings['working_hours_start'] ?? '09:00';
            $weekend_days_setting = $settings['weekend_days'] ?? 'Friday,Saturday';
            
            $query = $this->db->query("
                SELECT 
                    COUNT(DISTINCT DATE(FROM_UNIXTIME(inTime/1000))) as present_days,
                    COUNT(DISTINCT CASE 
                        WHEN TIME(FROM_UNIXTIME(inTime/1000)) > ? 
                        AND DAYNAME(DATE(FROM_UNIXTIME(inTime/1000))) NOT IN (?) -- Not weekend based on settings
                        AND NOT EXISTS (
                            SELECT 1 FROM $tracker_holidays_table h 
                            WHERE h.start_date <= DATE(FROM_UNIXTIME(inTime/1000)) 
                            AND h.end_date >= DATE(FROM_UNIXTIME(inTime/1000)) 
                            AND h.deleted = 0
                        )
                        AND NOT EXISTS (
                            SELECT 1 FROM $leaveTable l 
                            WHERE l.applicant_id = ? 
                            AND l.start_date <= DATE(FROM_UNIXTIME(inTime/1000)) 
                            AND l.end_date >= DATE(FROM_UNIXTIME(inTime/1000)) 
                            AND l.status = 'approved' 
                            AND l.deleted = 0
                        )
                        THEN DATE(FROM_UNIXTIME(inTime/1000))
                    END) as late_days,
                    
                    -- Worked hours calculation (excluding breaks)
                    COALESCE(SUM(
                        CASE 
                            WHEN outTime IS NOT NULL AND inTime IS NOT NULL 
                                 AND (project IS NULL OR project NOT LIKE 'b-%' OR project = '') 
                            THEN (outTime - inTime) / (1000 * 60) -- Convert to minutes
                            ELSE 0 
                        END
                    ), 0) as total_worked_minutes,
                    
                    -- Group discussion time (break sessions)
                    COALESCE(SUM(
                        CASE 
                            WHEN outTime IS NOT NULL AND inTime IS NOT NULL 
                                 AND project LIKE 'b-%' AND isMinusBreak = 0
                            THEN (outTime - inTime) / (1000 * 60) -- Convert to minutes
                            ELSE 0 
                        END
                    ), 0) as group_discussion_minutes
                    
                FROM $attendanceTable 
                WHERE user_id = ? 
                AND DATE(FROM_UNIXTIME(inTime/1000)) BETWEEN ? AND ?
                AND deleted = 0
            ", [$working_hours_start, $weekend_days_setting, $user_id, $user_id, $start_date, $end_date]);
            
            return $query->getRow();
        } catch (\Exception $e) {
            return null;
        }
    }

    /**
     * Get user leave days for date range
     */
    public function getUserLeaveDays($user_id, $start_date, $end_date) {
        $leaveTable = $this->db->prefixTable('leave_applications');
        try {
            // Simplified and corrected query to calculate overlapping leave days
            $query = $this->db->query("
                SELECT 
                    COALESCE(SUM(
                        CASE 
                            WHEN start_date <= ? AND end_date >= ? THEN
                                DATEDIFF(LEAST(end_date, ?), GREATEST(start_date, ?)) + 1
                            ELSE 0
                        END
                    ), 0) as total_leave_days
                FROM $leaveTable 
                WHERE applicant_id = ? 
                AND status = 'approved'
                AND deleted = 0
                AND NOT (end_date < ? OR start_date > ?)
            ", [
                $end_date, $start_date, $end_date, $start_date,  // For CASE calculation
                $user_id,                                        // For WHERE applicant_id
                $start_date, $end_date                          // For NOT condition
            ]);
            
            $result = $query->getRow();
            return $result && $result->total_leave_days ? (float)$result->total_leave_days : 0;
        } catch (\Exception $e) {
            return 0;
        }
    }

    /**
     * Get user performance average for date range
     */
    public function getUserPerformanceAverage($user_id, $start_date, $end_date) {
        $performanceTable = $this->db->prefixTable('tracker_performance');
        try {
            $query = $this->db->query("
                SELECT AVG(performance) as avg_performance 
                FROM $performanceTable 
                WHERE user_id = ? 
                AND DATE(takenTime) BETWEEN ? AND ?
                AND deleted = 0
            ", [$user_id, $start_date, $end_date]);
            
            $result = $query->getRow();
            return $result && $result->avg_performance !== null ? round($result->avg_performance) : 0;
        } catch (\Exception $e) {
            return 0;
        }
    }

    /**
     * Get holiday days for date range
     */
    public function getHolidayDays($start_date, $end_date) {
        $holidaysTable = $this->db->prefixTable('tracker_holidays');
        try {
            // Simplified and corrected query to calculate overlapping holiday days
            $query = $this->db->query("
                SELECT 
                    COALESCE(SUM(
                        DATEDIFF(
                            LEAST(end_date, ?), 
                            GREATEST(start_date, ?)
                        ) + 1
                    ), 0) as total_holiday_days
                FROM $holidaysTable 
                WHERE start_date <= ? 
                  AND end_date >= ?
                  AND deleted = 0
            ", [$end_date, $start_date, $end_date, $start_date]);
            
            $result = $query->getRow();
            return $result && $result->total_holiday_days ? (int)$result->total_holiday_days : 0;
        } catch (\Exception $e) {
            return 0;
        }
    }

    /**
     * Get comprehensive employee summary data using optimized model methods
     */
    public function getEmployeeSummaryData($start_date, $end_date) {
        
            // Get all active staff users
            $users = $this->getActiveStaffUsers();
            if (empty($users)) {
                return [];
            }
            
            // Get tracker settings
            $settings = $this->getTrackerSettings(['working_hours_start', 'daily_worked_time', 'working_hours_end']);
            $working_hours_start = $settings['working_hours_start'] ?? '09:00';
            $daily_worked_hours = (float)($settings['daily_worked_time'] ?? 8);
        
           
            // Calculate date range info
            $date_info = $this->calculateDateRangeInfo($start_date, $end_date);
            
            $employees_data = [];
            
            foreach ($users as $user) {
                // Get attendance statistics
                $attendance_stats = $this->getUserAttendanceStats($user->id, $start_date, $end_date);
                if (!$attendance_stats) {
                    $attendance_stats = (object)[
                        'present_days' => 0,
                        'late_days' => 0,
                        'total_worked_minutes' => 0,
                        'group_discussion_minutes' => 0
                    ];
                }
                
                // Get leave days
                $total_leave_days = $this->getUserLeaveDays($user->id, $start_date, $end_date);
                
                // Get performance average
                $avg_performance = $this->getUserPerformanceAverage($user->id, $start_date, $end_date);
                
                // Calculate workable days
                $workable_days = $date_info['total_days'] - $date_info['weekend_days'] - $date_info['holiday_days'] - $total_leave_days;
                $workable_days = max(0, $workable_days);
                
                // Calculate hours
                $worked_hours = $attendance_stats->total_worked_minutes / 60;
                $estimated_hours = $workable_days * $daily_worked_hours;

                // Calculate due hours and overtime
                $due_hours = max(0, $estimated_hours - $worked_hours);
                $overtime_hours = max(0, $worked_hours - $estimated_hours);
                
                // Calculate absent days
                $absent_days = max(0, $workable_days - $attendance_stats->present_days);
                
                $employees_data[] = [
                    'first_name' => $user->first_name,
                    'last_name' => $user->last_name,
                    'image' => $user->image,
                    'user_id' => $user->id,
                    'work_days' => $workable_days,
                    'present' => $attendance_stats->present_days,
                    'leave' => round($total_leave_days, 1),
                    'absent' => $absent_days,
                    'late' => $attendance_stats->late_days,
                    'estimated_hours' => $estimated_hours,
                    'worked_hours' => $worked_hours,
                    'due_hours' => $due_hours,
                    'overtime_hours' => $overtime_hours,
                    'group_discussion_hours' => $attendance_stats->group_discussion_minutes / 60,
                    'avg_performance' => $avg_performance
                ];
            }
            
            return $employees_data;
    }
    
    /**
     * Calculate date range information (total, weekend, holiday days)
     */
    private function calculateDateRangeInfo($start_date, $end_date) {
        // Calculate basic date info
        $start_dt = new \DateTime($start_date);
        $end_dt = new \DateTime($end_date);
        $interval = $start_dt->diff($end_dt);
        $total_days = $interval->days + 1;
        
        // Calculate weekend days
        $weekend_days = 0;
        $current = clone $start_dt;
        while ($current <= $end_dt) {
            $day_of_week = $current->format('w');
            if ($day_of_week == 0 || $day_of_week == 6) { // Sunday or Saturday
                $weekend_days++;
            }
            $current->add(new \DateInterval('P1D'));
        }
        
        // Get holiday days from model
        $holiday_days = $this->getHolidayDays($start_date, $end_date);
        
        return [
            'total_days' => $total_days,
            'weekend_days' => $weekend_days,
            'holiday_days' => $holiday_days
        ];
    }

    /**
     * Get tracker settings for calculations with proper defaults
     */
    public function getTrackerSettingsForCalculations($setting_names = []) {
        if (empty($setting_names)) {
            $setting_names = ['daily_work_hours', 'work_start_time', 'working_hours_start', 'daily_worked_time'];
        }
        
        $settings = $this->getTrackerSettings($setting_names);
        
        // Map daily_worked_time to daily_work_hours for backward compatibility
        if (isset($settings['daily_worked_time']) && !isset($settings['daily_work_hours'])) {
            $settings['daily_work_hours'] = $settings['daily_worked_time'];
        }
        
        // Map working_hours_start to work_start_time for backward compatibility
        if (isset($settings['working_hours_start']) && !isset($settings['work_start_time'])) {
            $settings['work_start_time'] = $settings['working_hours_start'];
        }
        
        return $settings;
    }

    /**
     * Enhanced getEmployeeSummaryData with explicit database queries for fallback
     */
    public function getEmployeeSummaryDataWithQueries($start_date, $end_date) {
        $usersTable = $this->db->prefixTable('users');
        $settingsTable = $this->db->prefixTable('tracker_settings');
        $tracker_holidays_table = $this->db->prefixTable('tracker_holidays');
        $leaveTable = $this->db->prefixTable('leave_applications');
        $attendanceTable = $this->db->prefixTable('tracker_attendance');
        $performanceTable = $this->db->prefixTable('tracker_performance');

        try {
            // Get all staff users
            $users_query = $this->db->query("
                SELECT id, first_name, last_name, email, image 
                FROM $usersTable 
                WHERE user_type = 'staff' AND status = 'active' AND deleted = 0
                ORDER BY first_name, last_name
            ");
            $users = $users_query->getResult();
            
            if (empty($users)) {
                return []; // No users found
            }
            
            // Get tracker settings
            $settings_query = $this->db->query("
                SELECT setting_name, setting_value 
                FROM $settingsTable 
                WHERE setting_name IN ('working_hours_start', 'daily_worked_time') 
                AND deleted = 0
            ");
            $settings_result = $settings_query->getResult();
            
            $working_hours_start = '09:00';
            $daily_worked_hours = 8;
            
            foreach ($settings_result as $setting) {
                if ($setting->setting_name === 'working_hours_start') {
                    $working_hours_start = $setting->setting_value;
                } elseif ($setting->setting_name === 'daily_worked_time') {
                    $daily_worked_hours = (float) $setting->setting_value;
                }
            }
            
            // Calculate date range details
            $date_info = $this->calculateDateRangeInfo($start_date, $end_date);
            
            $employees_data = [];
            
            foreach ($users as $user) {
                // Get user's leave applications in date range
                $total_leave_days = $this->getUserLeaveDays($user->id, $start_date, $end_date);
                
                // Calculate workable days
                $workable_days = $date_info['total_days'] - $date_info['weekend_days'] - $date_info['holiday_days'] - $total_leave_days;
                $workable_days = max(0, $workable_days); // Ensure non-negative
                
                // Get attendance data
                $attendance_stats = $this->getUserAttendanceStats($user->id, $start_date, $end_date);
                if (!$attendance_stats) {
                    $attendance_stats = (object)[
                        'present_days' => 0,
                        'late_days' => 0,
                        'total_worked_minutes' => 0,
                        'group_discussion_minutes' => 0
                    ];
                }
                
                $worked_hours = $attendance_stats->total_worked_minutes / 60;
                
                // Calculate estimated hours
                $estimated_hours = $workable_days * $daily_worked_hours;
                
                // Calculate due hours and overtime
                $due_hours = max(0, $estimated_hours - $worked_hours);
                $overtime_hours = max(0, $worked_hours - $estimated_hours);
                
                // Get activity percentage from tracker_performance
                $avg_performance = $this->getUserPerformanceAverage($user->id, $start_date, $end_date);
                
                // Calculate absent days
                $absent_days = max(0, $workable_days - $attendance_stats->present_days);
                
                $employees_data[] = [
                    'first_name' => $user->first_name,
                    'last_name' => $user->last_name,
                    'image' => $user->image,
                    'user_id' => $user->id,
                    'work_days' => $workable_days,
                    'present' => $attendance_stats->present_days,
                    'leave' => round($total_leave_days, 1),
                    'absent' => $absent_days,
                    'late' => $attendance_stats->late_days,
                    'estimated_hours' => $estimated_hours,
                    'worked_hours' => $worked_hours,
                    'due_hours' => $due_hours,
                    'overtime_hours' => $overtime_hours,
                    'group_discussion_hours' => $attendance_stats->group_discussion_minutes / 60,
                    'avg_performance' => $avg_performance
                ];
            }
            
            return $employees_data;
            
        } catch (\Exception $e) {
            return [];
        }
    }

    /**
     * Check if a date is a holiday
     */
    public function isHoliday($date) {
        $tracker_holidays_table = $this->db->prefixTable('tracker_holidays');
        try {
            $query = $this->db->query("
                SELECT COUNT(*) as count 
                FROM $tracker_holidays_table 
                WHERE ? BETWEEN start_date AND end_date 
                AND deleted = 0
            ", [$date]);
            
            $result = $query->getRow();
            $is_database_holiday = $result && $result->count > 0;
            
            // Check for special configured holidays
            $is_special_holiday = $this->isSpecialHoliday($date);
            
            return $is_database_holiday || $is_special_holiday;
        } catch (\Exception $e) {
            return false;
        }
    }

    /**
     * Check if a date is a special holiday (configurable through settings)
     * This replaces hardcoded date conditions with a proper configurable system
     */
    private function isSpecialHoliday($date) {
        try {
            // Get special holidays from tracker settings
            $settings = $this->getTrackerSettings(['special_holidays']);
            $special_holidays_setting = $settings['special_holidays'] ?? '';
            
            if (empty($special_holidays_setting)) {
                return false;
            }
            
            // Parse special holidays (comma-separated dates in YYYY-MM-DD format)
            $special_dates = array_map('trim', explode(',', $special_holidays_setting));
            
            return in_array($date, $special_dates);
            
        } catch (\Exception $e) {
            return false;
        }
    }

    /**
     * Add a special holiday to the configuration
     * This provides a proper way to add one-off holidays without hardcoding
     */
    public function addSpecialHoliday($date, $reason = '') {
        try {
            // Validate date format
            if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
                throw new \InvalidArgumentException('Date must be in YYYY-MM-DD format');
            }
            
            // Get current special holidays
            $settings = $this->getTrackerSettings(['special_holidays']);
            $current_holidays = $settings['special_holidays'] ?? '';
            
            // Parse existing holidays
            $holidays_array = empty($current_holidays) ? [] : array_map('trim', explode(',', $current_holidays));
            
            // Add new holiday if not already exists
            if (!in_array($date, $holidays_array)) {
                $holidays_array[] = $date;
                $new_holidays_setting = implode(',', $holidays_array);
                
                // Update the setting
                $tracker_settings_model = model("Tracebit\Models\Tracker_settings_model");
                $result = $tracker_settings_model->save_setting('special_holidays', $new_holidays_setting);
                
                if ($result) {
                    return true;
                } else {
                    return false;
                }
            }
            
            return true; // Already exists
            
        } catch (\Exception $e) {
            return false;
        }
    }

    /**
     * Remove a special holiday from the configuration
     */
    public function removeSpecialHoliday($date) {
        try {
            // Get current special holidays
            $settings = $this->getTrackerSettings(['special_holidays']);
            $current_holidays = $settings['special_holidays'] ?? '';
            
            if (empty($current_holidays)) {
                return true; // Nothing to remove
            }
            
            // Parse existing holidays
            $holidays_array = array_map('trim', explode(',', $current_holidays));
            
            // Remove the date
            $holidays_array = array_filter($holidays_array, function($holiday) use ($date) {
                return $holiday !== $date;
            });
            
            // Update the setting
            $new_holidays_setting = implode(',', $holidays_array);
            
            $tracker_settings_model = model("Tracebit\Models\Tracker_settings_model");
            $result = $tracker_settings_model->save_setting('special_holidays', $new_holidays_setting);
            
            if ($result) {
                return true;
            } else {
                return false;
            }
            
        } catch (\Exception $e) {
            return false;
        }
    }

    /**
     * Get user leave information for a specific date
     */
    public function getUserLeaveInfo($user_id, $date) {
        $leaveTable = $this->db->prefixTable('leave_applications');
        try {
            $query = $this->db->query("
                SELECT total_days, start_date, end_date 
                FROM $leaveTable 
                WHERE applicant_id = ? 
                AND ? BETWEEN start_date AND end_date 
                AND status = 'approved' 
                AND deleted = 0
            ", [$user_id, $date]);
            
            return $query->getRow();
        } catch (\Exception $e) {
            return null;
        }
    }

     /**
     * Format timestamp to local time in 12-hour format (consistent with dashboard_helpers.php)
     */
    private function formatTimestampToLocalTime($timestamp) {
      if (!$timestamp) return '--:--';
      
      // Ensure timestamp is numeric
      if (!is_numeric($timestamp)) {
          return '--:--';
      }

      $originalTimezone = date_default_timezone_get();
      date_default_timezone_set('Asia/Dhaka'); // Same as dashboard_helpers.php
      $formatted_time = date('h:i', $timestamp / 1000);
      date_default_timezone_set($originalTimezone);

      return $formatted_time;
  }

    /**
     * Check late status for user on specific date
     */
    public function checkLateStatus($user_id, $currentDate) {
        try {
            // Get working hours start and weekend days from tracker_settings
            $settings = $this->getTrackerSettings(['working_hours_start', 'weekend_days']);
            $working_hours_start = $settings['working_hours_start'] ?? '09:00';
            $weekend_days_setting = $settings['weekend_days'] ?? 'Friday,Saturday';
            
            // Check if it's a workable day (not weekend, holiday, or leave)
            $day_of_week = date('w', strtotime($currentDate));
            $day_name = date('l', strtotime($currentDate)); // Full day name (Friday, Saturday, etc.)
            
            // Check if current day is in weekend days setting
            $weekend_days_array = array_map('trim', explode(',', $weekend_days_setting));
            $is_weekend = in_array($day_name, $weekend_days_array);
            
            if ($is_weekend) {
                return ['is_late' => false, 'late_by_minutes' => 0];
            }
            
            // Check if it's a holiday
            if ($this->isHoliday($currentDate)) {
                return ['is_late' => false, 'late_by_minutes' => 0];
            }
            
            // Check if user is on leave
            $leave_info = $this->getUserLeaveInfo($user_id, $currentDate);
            if ($leave_info) {
                return ['is_late' => false, 'late_by_minutes' => 0];
            }
            
            // Get attendance data for the date
            $attendanceTable = $this->db->prefixTable('tracker_attendance');
            $query = $this->db->query("
                SELECT inTime, late
                FROM $attendanceTable 
                WHERE user_id = ? 
                AND DATE(FROM_UNIXTIME(inTime/1000)) = ?
                AND deleted = 0
                ORDER BY inTime ASC
                LIMIT 1
            ", [$user_id, $currentDate]);
            
            $attendance = $query->getRow();
           
            if (!$attendance || !$attendance->inTime) {
                return ['is_late' => false, 'late_by_minutes' => 0];
            }
            
            // Calculate late status from inTime
            $checkin_time = $this->formatTimestampToLocalTime($attendance->inTime);
           
            // Compare times
            $start_time_obj = \DateTime::createFromFormat('H:i', $working_hours_start);
            $checkin_time_obj = \DateTime::createFromFormat('H:i', $checkin_time);
            
            if (!$start_time_obj || !$checkin_time_obj) {
                return ['is_late' => false, 'late_by_minutes' => 0];
            }
            // Calculate if late (only for workable days)
            if ($checkin_time_obj > $start_time_obj) {
                $diff = $checkin_time_obj->diff($start_time_obj);
                $late_minutes = ($diff->h * 60) + $diff->i;
                
                return ['is_late' => true, 'late_by_minutes' => $late_minutes];
            }
            
            return ['is_late' => false, 'late_by_minutes' => 0];
            
        } catch (\Exception $e) {
            return ['is_late' => false, 'late_by_minutes' => 0];
        }
    }

    /**
     * Save manual time entry with proper timezone handling
     */
    public function saveManualTime($data) {
        try {
            $date = $data['date'];
            $in_time = $data['in_time'];
            $out_time = $data['out_time'];
            $description = $data['description'] ?? '';
            $user_id = $data['user_id'];
            
            // Get timezone from Rise settings instead of hardcoded value
            $timezone_offset = $this->getRiseTimezoneOffset();
            $timezone_sign = $timezone_offset >= 0 ? '+' : '-';
            $timezone_minutes = abs($timezone_offset);
            
            // Create DateTime objects using the proper timezone
            $timezone_name = get_setting('timezone') ?: 'Asia/Dhaka';
            $local_timezone = new \DateTimeZone($timezone_name);
            
            $start_datetime = \DateTime::createFromFormat('Y-m-d H:i', $date . ' ' . $in_time, $local_timezone);
            $end_datetime = \DateTime::createFromFormat('Y-m-d H:i', $date . ' ' . $out_time, $local_timezone);
            
            if (!$start_datetime || !$end_datetime) {
                throw new \Exception('Invalid date or time format');
            }
            
            if ($end_datetime <= $start_datetime) {
                throw new \Exception('Out time must be after in time');
            }
            
            // Convert to timestamp in milliseconds (matching existing timesheet format)
            $in_timestamp = $start_datetime->getTimestamp() * 1000;
            $out_timestamp = $end_datetime->getTimestamp() * 1000;
            
            // Prepare data for tracker_attendance table
            $attendance_data = [
                'user_id' => $user_id,
                'inTime' => $in_timestamp,
                'outTime' => $out_timestamp,
                'note' => $description,
                'timezone' => $timezone_minutes,
                'sign' => $timezone_sign,
                'project' => 'manual-10', // As specified
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
                'isMinusBreak' => 0,
                'deleted' => 0,                
                'late' => 0 // Manual entries are not considered late
            ];
            
            // Insert into tracker_attendance table
            $attendance_table = $this->db->prefixTable('tracker_attendance');
            $result = $this->db->table($attendance_table)->insert($attendance_data);
            $insert_id = $this->db->insertID();
            
            if (!$result || !$insert_id) {
                throw new \Exception('Failed to save manual time entry');
            }
            
            // Calculate duration for response
            $duration = $end_datetime->diff($start_datetime);
            $duration_text = $duration->format('%h hours %i minutes');
            
            return [
                'success' => true,
                'message' => 'Manual time entry saved successfully',
                'data' => [
                    'id' => $insert_id,
                    'date' => $date,
                    'in_time' => $in_time,
                    'out_time' => $out_time,
                    'duration' => $duration_text,
                    'description' => $description
                ]
            ];
            
        } catch (\Exception $e) {
            return [
                'success' => false,
                'message' => 'Database error: ' . $e->getMessage()
            ];
        }
    }

    /**
     * Get Rise CRM timezone offset in minutes
     */
    public function getRiseTimezoneOffset() {
        try {
            // Get timezone from Rise settings
            $timezone_name = get_setting('timezone');
            if (!$timezone_name) {
                return 360; // Default to +6 hours if no timezone set
            }
            
            // Calculate offset in minutes
            $timezone = new \DateTimeZone($timezone_name);
            $datetime = new \DateTime('now', $timezone);
            $offset_seconds = $timezone->getOffset($datetime);
            $offset_minutes = $offset_seconds / 60;
            
            return $offset_minutes;
        } catch (\Exception $e) {
            return 360; // Default to +6 hours on error
        }
    }



    /**
     * Get holidays and leave data for date range optimization
     */
    public function getHolidaysAndLeaveData($start_date, $end_date) {
        $tracker_holidays_table = $this->db->prefixTable('tracker_holidays');
        $leaveTable = $this->db->prefixTable('leave_applications');
        
        try {
            // Get holidays in date range
            $holidays_query = $this->db->query("
                SELECT start_date, end_date 
                FROM $tracker_holidays_table 
                WHERE (start_date BETWEEN ? AND ?) 
                   OR (end_date BETWEEN ? AND ?) 
                   OR (start_date <= ? AND end_date >= ?)
                AND deleted = 0
            ", [$start_date, $end_date, $start_date, $end_date, $start_date, $end_date]);
            
            $holidays = $holidays_query->getResult();
            
            // Get all leave applications in date range
            $leave_query = $this->db->query("
                SELECT applicant_id, start_date, end_date, total_days 
                FROM $leaveTable 
                WHERE status = 'approved'
                AND ((start_date BETWEEN ? AND ?) 
                     OR (end_date BETWEEN ? AND ?) 
                     OR (start_date <= ? AND end_date >= ?))
                AND deleted = 0
            ", [$start_date, $end_date, $start_date, $end_date, $start_date, $end_date]);
            
            $leaves = $leave_query->getResult();
            
            return [
                'holidays' => $holidays,
                'leaves' => $leaves
            ];
            
        } catch (\Exception $e) {
            return [
                'holidays' => [],
                'leaves' => []
            ];
        }
    }

    /**
     * Get daily work hours setting
     */
    public function getDailyWorkHoursSetting() {
        try {
            $settings = $this->getTrackerSettings(['daily_work_hours', 'daily_worked_time']);
            return (float)($settings['daily_work_hours'] ?? $settings['daily_worked_time'] ?? 8);
        } catch (\Exception $e) {
            return 8.0; // Default
        }
    }
}
