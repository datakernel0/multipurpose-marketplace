<?php

namespace Tracebit\Models;

use App\Models\Crud_model;
use CodeIgniter\Cache\CacheInterface;

/**
 * Optimized Base Model for Tracker Plugin
 * Provides caching, security, and performance optimizations
 */
abstract class Tracker_base_model extends Crud_model {

    protected $cache;
    protected $cache_prefix = 'tracker_';
    protected $cache_ttl = 3600; // 1 hour default
    protected $enable_query_cache = true;
    private $cache_settings_initialized = false;

    public function __construct($table = null) {
        parent::__construct($table);
        $this->cache = \Config\Services::cache();
        // Removed init_cache_settings() call to prevent recursion
        // Settings will be loaded on-demand when needed
    }

    /**
     * Initialize cache settings from database (called on-demand)
     */
    private function init_cache_settings() {
        // Return early if already initialized or if this is the settings model itself
        if ($this->cache_settings_initialized || get_class($this) === 'Tracebit\Models\Tracker_settings_model') {
            return;
        }

        try {
            // Only try to get settings if we're not in a settings model and table exists
            $db = \Config\Database::connect();

            // Check if table exists first to avoid errors
            $tables = $db->listTables();
            if (!in_array($db->prefixTable('tracker_settings'), $tables)) {
                // Table doesn't exist, use defaults
                $this->enable_query_cache = true;
                $this->cache_ttl = 3600;
                $this->cache_settings_initialized = true;
                return;
            }

            $query = $db->query("SELECT setting_name, setting_value FROM " .
                               $db->prefixTable('tracker_settings') .
                               " WHERE setting_name IN ('query_cache_enabled', 'max_query_cache_time') AND deleted = 0");

            $settings = [];
            if ($query && method_exists($query, 'getResult')) {
                foreach ($query->getResult() as $row) {
                    $settings[$row->setting_name] = $row->setting_value;
                }
            }

            $this->enable_query_cache = ($settings['query_cache_enabled'] ?? '1') === '1';
            $this->cache_ttl = (int) ($settings['max_query_cache_time'] ?? 3600);
            $this->cache_settings_initialized = true;
        } catch (\Exception $e) {
            log_message('error', '[TRACKER] Cache settings init failed: ' . $e->getMessage());
            // Use defaults on error
            $this->enable_query_cache = true;
            $this->cache_ttl = 3600;
            $this->cache_settings_initialized = true;
        }
    }

    /**
     * Cached query execution with automatic cache key generation
     *
     * @param string $sql SQL query
     * @param array $binds Query bindings
     * @param int $cache_ttl Cache time to live (optional)
     * @return mixed Query result
     */
    protected function cached_query($sql, $binds = [], $cache_ttl = null) {
        // Initialize cache settings on first use
        if (!$this->cache_settings_initialized) {
            $this->init_cache_settings();
        }

        if (!$this->enable_query_cache) {
            return $this->db->query($sql, $binds);
        }

        $cache_key = $this->generate_cache_key($sql, $binds);
        $result = $this->cache->get($cache_key);

        if ($result === null) {
            $query = $this->db->query($sql, $binds);
            if ($query) {
                $result = $query->getResult();
                $ttl = $cache_ttl ?? $this->cache_ttl;
                $this->cache->save($cache_key, $result, $ttl);

                // Log cache miss for monitoring
                log_message('debug', '[TRACKER] Cache MISS: ' . $cache_key);
            } else {
                return false;
            }
        } else {
            log_message('debug', '[TRACKER] Cache HIT: ' . $cache_key);
        }

        return new class($result) {
            private $result;

            public function __construct($result) {
                $this->result = $result;
            }

            public function getResult() {
                return $this->result;
            }

            public function getRow() {
                return $this->result[0] ?? null;
            }
        };
    }

    /**
     * Generate cache key from SQL and bindings
     */
    private function generate_cache_key($sql, $binds = []) {
        $key_data = $sql . serialize($binds);
        return $this->cache_prefix . md5($key_data);
    }

    /**
     * Clear cache by pattern
     */
    protected function clear_cache_pattern($pattern = '') {
        if (method_exists($this->cache, 'deleteMatching')) {
            $this->cache->deleteMatching($this->cache_prefix . $pattern . '*');
        } else {
            // Fallback: clear all tracker cache
            $this->cache->delete($this->cache_prefix . '*');
        }
    }

    /**
     * Secure query builder with automatic escaping
     * Prevents SQL injection by using proper parameter binding
     */
    protected function secure_query($sql, $binds = []) {
        // Validate that no direct concatenation is used
        if (preg_match('/\$\w+/', $sql)) {
            log_message('error', '[TRACKER] Potential SQL injection in query: ' . $sql);
            throw new \InvalidArgumentException('Direct variable concatenation detected in SQL query');
        }

        return $this->db->query($sql, $binds);
    }

    /**
     * Get projects for user with caching and proper security
     */
    protected function get_user_projects_cached($user_id, $cache_ttl = null) {
        $sql = "SELECT p.*
                FROM " . $this->db->prefixTable('projects') . " p
                INNER JOIN " . $this->db->prefixTable('project_members') . " pm
                    ON p.id = pm.project_id
                WHERE pm.user_id = ?
                AND pm.deleted = 0
                AND p.deleted = 0
                ORDER BY p.title";

        $query = $this->cached_query($sql, [$user_id], $cache_ttl);
        return $query ? $query->getResult() : [];
    }

    /**
     * Get project IDs for user (optimized for IN clauses)
     */
    protected function get_user_project_ids($user_id) {
        $sql = "SELECT GROUP_CONCAT(DISTINCT pm.project_id) as project_ids
                FROM " . $this->db->prefixTable('project_members') . " pm
                WHERE pm.user_id = ? AND pm.deleted = 0";

        $query = $this->cached_query($sql, [$user_id], 300); // 5 min cache
        $result = $query ? $query->getResult() : [];

        if (!empty($result) && !empty($result[0]->project_ids)) {
            return explode(',', $result[0]->project_ids);
        }

        return [0]; // Return [0] to prevent SQL errors in IN clauses
    }

    /**
     * Batch insert with duplicate key handling
     */
    protected function safe_batch_insert($table, $data, $on_duplicate_update = []) {
        if (empty($data)) {
            return true;
        }

        try {
            $this->db->transStart();

            // Split large batches into smaller chunks to avoid SQL size limits
            $chunk_size = 50; // Process 50 records at a time
            $chunks = array_chunk($data, $chunk_size);

            log_message('debug', "[TRACKER] Processing " . count($data) . " records in " . count($chunks) . " chunks for table: $table");

            foreach ($chunks as $chunk_index => $chunk) {
                log_message('debug', "[TRACKER] Processing chunk " . ($chunk_index + 1) . "/" . count($chunks) . " with " . count($chunk) . " records");

                if (!empty($on_duplicate_update)) {
                    // Custom batch insert with ON DUPLICATE KEY UPDATE
                    $fields = array_keys($chunk[0]);
                    $placeholders = '(' . str_repeat('?,', count($fields) - 1) . '?)';
                    $values_clause = str_repeat($placeholders . ',', count($chunk) - 1) . $placeholders;

                    $update_clause = implode(', ', array_map(function($field) {
                        return "`$field` = VALUES(`$field`)";
                    }, $on_duplicate_update));

                    $sql = "INSERT INTO " . $this->db->prefixTable($table) . "
                            (`" . implode('`, `', $fields) . "`)
                            VALUES $values_clause
                            ON DUPLICATE KEY UPDATE $update_clause";

                    $binds = [];
                    foreach ($chunk as $row) {
                        foreach ($fields as $field) {
                            $binds[] = $row[$field] ?? null;
                        }
                    }

                    log_message('debug', "[TRACKER] Executing custom batch insert with " . count($binds) . " binds");
                    $result = $this->db->query($sql, $binds);

                    if (!$result) {
                        $error = $this->db->error();
                        log_message('error', "[TRACKER] Custom batch insert failed: " . json_encode($error));
                        throw new \RuntimeException('Custom batch insert failed: ' . $error['message']);
                    }
                } else {
                    // Standard batch insert
                    log_message('debug', "[TRACKER] Executing standard batch insert");
                    $result = $this->db->table($this->db->prefixTable($table))->insertBatch($chunk);

                    if (!$result) {
                        $error = $this->db->error();
                        log_message('error', "[TRACKER] Standard batch insert failed: " . json_encode($error));
                        throw new \RuntimeException('Standard batch insert failed: ' . $error['message']);
                    }
                }

                log_message('debug', "[TRACKER] Chunk " . ($chunk_index + 1) . " processed successfully");
            }

            $this->db->transComplete();
            $status = $this->db->transStatus();

            log_message('debug', "[TRACKER] Transaction status: " . ($status ? 'SUCCESS' : 'FAILED'));

            return $status;
        } catch (\Exception $e) {
            $this->db->transRollback();
            log_message('error', '[TRACKER] Batch insert failed: ' . $e->getMessage());
            log_message('error', '[TRACKER] Batch insert error trace: ' . $e->getTraceAsString());
            log_message('error', '[TRACKER] Failed table: ' . $table);
            log_message('error', '[TRACKER] Data count: ' . count($data));
            return false;
        }
    }

    /**
     * Performance monitoring helper
     */
    protected function monitor_query_performance($query_name, $start_time) {
        $execution_time = microtime(true) - $start_time;

        if ($execution_time > 1.0) { // Log slow queries (> 1 second)
            log_message('warning', "[TRACKER] Slow query detected - $query_name: {$execution_time}s");
        }

        return $execution_time;
    }

    /**
     * Get timezone-adjusted datetime
     */
    protected function get_timezone_adjusted_time($timestamp, $timezone_offset = 0, $sign = '+') {
        if ($sign === '+') {
            return "DATE_ADD(FROM_UNIXTIME(? / 1000), INTERVAL ? MINUTE)";
        } else {
            return "DATE_SUB(FROM_UNIXTIME(? / 1000), INTERVAL ? MINUTE)";
        }
    }

    /**
     * Validate and sanitize input data
     */
    protected function validate_input($data, $rules) {
        $validation = \Config\Services::validation();
        $validation->setRules($rules);

        if (!$validation->run($data)) {
            throw new \InvalidArgumentException('Validation failed: ' . implode(', ', $validation->getErrors()));
        }

        // Support older CI versions without getValidated()
        if (method_exists($validation, 'getValidated')) {
            return $validation->getValidated();
        }

        // Fallback: return only fields defined in rules
        $validated = [];
        foreach (array_keys((array) $rules) as $field) {
            if (array_key_exists($field, $data)) {
                $validated[$field] = $data[$field];
            }
        }
        return $validated;
    }

    /**
     * Error handling with logging
     */
    protected function handle_db_error($context = '') {
        $error = $this->db->error();
        $error_msg = $context ? "$context - " . $error['message'] : $error['message'];

        log_message('error', '[TRACKER] Database error: ' . $error_msg);

        if (ENVIRONMENT === 'development') {
            throw new \RuntimeException($error_msg);
        }

        return false;
    }
}
