<?php

namespace Tracebit\Models;

class Tracker_performance extends Tracker_base_model {

    protected $table = 'tracker_performance';

    function __construct() {
        parent::__construct('tracker_performance');
    }

    function createScreenshot($data) {

        $table = $this->db->table($this->db->prefixTable('tracker_screenshots'));

        if($table->insert($data)) {
            return true;
        } else {
            $error = $this->db->error();
            error_log( print_r( "No it is not update- ". $error['message'], true ) );
            return false;
        }
    }

    function getProjects($data) {

        $pm = $this->db->prefixTable('project_members');
        $ps = $this->db->prefixTable('projects');

        $pmQuery = "SELECT GROUP_CONCAT(DISTINCT $pm.project_id) as project_id FROM $pm WHERE $pm.user_id = $data AND $pm.deleted= 0";
        $pmResult = $this->db->query($pmQuery)->getResult();
        $project_ids = !empty($pmResult[0]) ? $pmResult[0]->project_id : null;
        $project_ids = $project_ids ? $project_ids : '0';

        $psQuery = "SELECT $ps.* FROM $ps WHERE $ps.id IN($project_ids) AND $ps.deleted= 0";
        $query = $this->db->query($psQuery)->getResult();

        if($query) {
            return $query;
        } else {
            $error = $this->db->error();
            error_log( print_r( "No it is not update- ". $error['message'], true ) );
            return false;
        }

    }

    function refresh($attendance) {

        $tableAttendance = $this->db->table($this->db->prefixTable('attendance2'));
        if($tableAttendance->insertBatch($attendance)) {
            return true;
        } else {
            $error = $this->db->error();
            error_log( print_r( "No it is not update- ". $error['message'], true ) );
            return false;
        }
    }

    function forceRefresh($attendance) {
        $tableAttendance = $this->db->table($this->db->prefixTable('attendance2'));

        // Process attendance records
        foreach ($attendance as $row) {
            $inPhpTime = new \DateTime($row->inTime);  // Assuming $row->inTime is a valid datetime string or object

            // Format the inTime as 'Y-m-d H:i:s' if it's a DateTime object

            $inTime = $inPhpTime->format('Y-m-d H:i:s');

            $modifyTime = $inPhpTime->modify('+1 second');
            $modifyTime = $modifyTime->format('Y-m-d H:i:s');
            $exists = $tableAttendance->where('inTime', $inTime)->orWhere('inTime', $modifyTime)->where('user_id', $row->user_id)->get()->getRow();
            if (!$exists) {
                // Insert new record
                $tableAttendance->insert($row);
            } else {
                $tableAttendance->where('inTime', $exists->inTime)
                ->set('outTime', $row->outTime)
                ->update();
            }
        }

        return true;
    }

    function getAttendance($data) {

        $at = $this->db->prefixTable('attendance2');

        $atQuery = "SELECT $at.* FROM $at WHERE $at.id=$data AND $at.deleted= 0 AND DATE($at.inTime) = CURDATE()";
        $query = $this->db->query($atQuery)->getResult();

        if($query) {
            return $query;
        } else {
            $error = $this->db->error();
            error_log( print_r( "No it is not update- ". $error['message'], true ) );
            return false;
        }

    }

    function getCpanelData() {

        $sp = $this->db->prefixTable('sv_cpanel');

        $psQuery = "SELECT $sp.* FROM $sp";
        $query = $this->db->query($psQuery)->getResult();

        if($query) {
            return $query;
        } else {
            $error = $this->db->error();
            error_log( print_r( "No it is not update- ". $error['message'], true ) );
            return false;
        }

    }



}
