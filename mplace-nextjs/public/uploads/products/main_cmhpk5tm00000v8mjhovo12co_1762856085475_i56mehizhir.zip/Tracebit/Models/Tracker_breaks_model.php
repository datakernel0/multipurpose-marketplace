<?php

namespace Tracebit\Models;

use CodeIgniter\Model;

class Tracker_breaks_model extends Model {
    protected $table = 'tracker_breaks';
    protected $primaryKey = 'id';

    public function __construct()
    {
        parent::__construct();
        $this->table = $this->db->prefixTable('tracker_breaks');
        $this->builder = $this->db->table($this->table);
    }
    protected $allowedFields = [ 'name', 'value', 'icon', 'description', 'is_minus_break', 'max_time' ];
    protected $useTimestamps = true;
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';
    protected $deletedField = 'deleted_at';
    protected $returnType = 'object';

    public function get_details() {
         $this->builder->where('deleted_at', NULL);
       $query = $this->builder->get();

        return $query->getResult();
    }

    /**
     * Get active breaks (not deleted)
     *
     * @return array
     */
    public function get_active_breaks() {
        $this->builder->where('deleted_at', NULL);
        $query = $this->builder->get();
        
        return $query->getResult();
    }

    public function get_one($id = 0) {
        return $this->find($id);
    }

     /**
     * Delete a break by ID
     *
     * @param int $id
     * @return bool
     */
    public function delete_break($id) {
        return $this->builder->where('id', $id)
            ->update(['deleted_at' => get_current_utc_time()]);
    }
}
