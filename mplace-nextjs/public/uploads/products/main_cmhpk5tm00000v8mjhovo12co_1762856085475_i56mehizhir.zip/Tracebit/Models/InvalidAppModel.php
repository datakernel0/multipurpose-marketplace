<?php

namespace Tracebit\Models;

use Exception;

/**
 * InvalidAppModel - Model for handling invalid app detection data
 *
 * This model is used to interact with the tracker_invalid_apps table
 * for recording and retrieving invalid app detection data.
 */
class InvalidAppModel {
    private $db;
    private $dbprefix;
    private $table;

    /**
     * Constructor
     */
    public function __construct() {
        $this->db = db_connect('default');
        $this->dbprefix = get_db_prefix();
        $this->table = $this->dbprefix . 'tracker_invalid_apps';

        // Ensure table exists
        $this->ensure_table_exists();
    }

    /**
     * Make sure the table exists, create it if it doesn't
     */
    private function ensure_table_exists() {
        try {
            // Check if table exists
            $table_exists = $this->db->query("SHOW TABLES LIKE '{$this->table}'")->getNumRows() > 0;

            if (!$table_exists) {
                // Create table with optimized structure
                $create_table = "CREATE TABLE `{$this->table}` (
                    `id` int(11) NOT NULL AUTO_INCREMENT,
                    `user_id` int(11) NOT NULL,
                    `app_name` varchar(255) NOT NULL,
                    `suspicion_score` int(3) DEFAULT 5,
                    `project_id` int(11) DEFAULT NULL,
                    `app_details` text DEFAULT NULL,
                    `detection_time` datetime NOT NULL,
                    `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
                    `action_taken` varchar(50) DEFAULT 'none',
                    `notes` text DEFAULT NULL,
                    `resolved` tinyint(1) NOT NULL DEFAULT 0,
                    `deleted` tinyint(1) NOT NULL DEFAULT 0,
                    PRIMARY KEY (`id`),
                    KEY `idx_user_app` (`user_id`, `app_name`),
                    KEY `idx_detection_time` (`detection_time`),
                    KEY `idx_suspicion_score` (`suspicion_score`),
                    KEY `idx_resolved_deleted` (`resolved`, `deleted`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";

                $this->db->query($create_table);

                // Log table creation
                error_log("Created tracker_invalid_apps table");
            }
        } catch (Exception $e) {
            error_log("Error creating tracker_invalid_apps table: " . $e->getMessage());
        }
    }

    /**
     * Insert a new invalid app record
     *
     * @param array $data Record data
     * @return int|bool Inserted ID or false on failure
     */
    public function insert($data) {
        try {
            // Ensure required fields
            if (!isset($data['user_id']) || !isset($data['app_name'])) {
                return false;
            }

            // Set defaults
            if (!isset($data['detection_time'])) {
                $data['detection_time'] = date('Y-m-d H:i:s');
            }

            if (!isset($data['suspicion_score'])) {
                $data['suspicion_score'] = 5;
            }

            // Handle app details
            if (isset($data['app_details']) && is_array($data['app_details'])) {
                $data['app_details'] = json_encode($data['app_details']);
            }

            // Build query
            $fields = array_keys($data);
            $placeholders = array_fill(0, count($fields), '?');

            $query = "INSERT INTO `{$this->table}`
                     (`" . implode("`, `", $fields) . "`)
                     VALUES (" . implode(", ", $placeholders) . ")";

            $this->db->query($query, array_values($data));

            return $this->db->insertID();
        } catch (Exception $e) {
            error_log("Error inserting invalid app: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Get invalid apps for a specific user
     *
     * @param int $user_id User ID
     * @param int $limit Results limit
     * @param int $offset Results offset
     * @return array Records
     */
    public function get_by_user($user_id, $limit = 100, $offset = 0) {
        try {
            $query = "SELECT * FROM `{$this->table}`
                     WHERE `user_id` = ? AND `deleted` = 0
                     ORDER BY `detection_time` DESC
                     LIMIT ? OFFSET ?";

            return $this->db->query($query, [$user_id, $limit, $offset])->getResult();
        } catch (Exception $e) {
            error_log("Error getting invalid apps by user: " . $e->getMessage());
            return [];
        }
    }

    /**
     * Get all invalid apps with pagination and filtering
     *
     * @param array $options Query options
     * @return array Records and pagination info
     */
    public function get_all($options = []) {
        try {
            // Set defaults
            $limit = isset($options['limit']) ? intval($options['limit']) : 100;
            $offset = isset($options['offset']) ? intval($options['offset']) : 0;
            $search = isset($options['search']) ? $options['search'] : '';
            $sort_by = isset($options['sort_by']) ? $options['sort_by'] : 'detection_time';
            $sort_dir = isset($options['sort_dir']) ? strtoupper($options['sort_dir']) : 'DESC';
            $include_resolved = isset($options['include_resolved']) ? (bool)$options['include_resolved'] : false;

            // Validate sort parameters
            $allowed_sort_columns = ['id', 'user_id', 'app_name', 'suspicion_score', 'detection_time', 'resolved'];
            if (!in_array($sort_by, $allowed_sort_columns)) {
                $sort_by = 'detection_time';
            }

            $sort_dir = ($sort_dir === 'ASC') ? 'ASC' : 'DESC';

            // Build where clause
            $where = ["`deleted` = 0"];
            $params = [];

            if (!$include_resolved) {
                $where[] = "`resolved` = 0";
            }

            if ($search) {
                $where[] = "(`app_name` LIKE ? OR `app_details` LIKE ?)";
                $params[] = "%{$search}%";
                $params[] = "%{$search}%";
            }

            $where_clause = implode(" AND ", $where);

            // Get total count
            $count_query = "SELECT COUNT(*) as total FROM `{$this->table}` WHERE {$where_clause}";
            $count_result = $this->db->query($count_query, $params)->getRow();
            $total = $count_result->total;

            // Get data
            $query = "SELECT ia.*, u.first_name, u.last_name, p.title as project_title
                     FROM `{$this->table}` ia
                     LEFT JOIN `" . $this->dbprefix . "users` u ON ia.user_id = u.id
                     LEFT JOIN `" . $this->dbprefix . "projects` p ON ia.project_id = p.id
                     WHERE {$where_clause}
                     ORDER BY {$sort_by} {$sort_dir}
                     LIMIT ? OFFSET ?";

            $params[] = $limit;
            $params[] = $offset;

            $records = $this->db->query($query, $params)->getResult();

            // Process records (decode JSON, etc.)
            foreach ($records as &$record) {
                if (isset($record->app_details) && is_string($record->app_details)) {
                    $record->app_details = json_decode($record->app_details);
                }
            }

            return [
                'records' => $records,
                'total' => $total,
                'page' => floor($offset / $limit) + 1,
                'limit' => $limit,
                'pages' => ceil($total / $limit)
            ];
        } catch (Exception $e) {
            error_log("Error getting all invalid apps: " . $e->getMessage());
            return [
                'records' => [],
                'total' => 0,
                'page' => 1,
                'limit' => $limit,
                'pages' => 0
            ];
        }
    }

    /**
     * Update an invalid app record
     *
     * @param int $id Record ID
     * @param array $data Update data
     * @return bool Success
     */
    public function update($id, $data) {
        try {
            if (empty($data) || !$id) {
                return false;
            }

            // Handle app details
            if (isset($data['app_details']) && is_array($data['app_details'])) {
                $data['app_details'] = json_encode($data['app_details']);
            }

            // Build update clause
            $updates = [];
            $params = [];

            foreach ($data as $field => $value) {
                $updates[] = "`{$field}` = ?";
                $params[] = $value;
            }

            // Add updated_at
            $updates[] = "`updated_at` = NOW()";

            $update_clause = implode(", ", $updates);

            // Execute update
            $query = "UPDATE `{$this->table}` SET {$update_clause} WHERE `id` = ?";
            $params[] = $id;

            $this->db->query($query, $params);

            return true;
        } catch (Exception $e) {
            error_log("Error updating invalid app: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Soft delete an invalid app record
     *
     * @param int $id Record ID
     * @return bool Success
     */
    public function delete($id) {
        try {
            $query = "UPDATE `{$this->table}` SET `deleted` = 1, `updated_at` = NOW() WHERE `id` = ?";
            $this->db->query($query, [$id]);

            return true;
        } catch (Exception $e) {
            error_log("Error deleting invalid app: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Get statistics about invalid app detections
     *
     * @param array $options Query options
     * @return array Statistics
     */
    public function get_statistics($options = []) {
        try {
            // Set defaults
            $days = isset($options['days']) ? intval($options['days']) : 30;
            $user_id = isset($options['user_id']) ? intval($options['user_id']) : null;

            // Build where clause
            $where = ["`deleted` = 0"];
            $params = [];

            if ($user_id) {
                $where[] = "`user_id` = ?";
                $params[] = $user_id;
            }

            if ($days > 0) {
                $where[] = "`detection_time` >= DATE_SUB(NOW(), INTERVAL ? DAY)";
                $params[] = $days;
            }

            $where_clause = implode(" AND ", $where);

            // Total detections
            $total_query = "SELECT COUNT(*) as total FROM `{$this->table}` WHERE {$where_clause}";
            $total_result = $this->db->query($total_query, $params)->getRow();

            // Detections by app name
            $app_query = "SELECT `app_name`, COUNT(*) as count
                         FROM `{$this->table}`
                         WHERE {$where_clause}
                         GROUP BY `app_name`
                         ORDER BY count DESC
                         LIMIT 10";
            $app_result = $this->db->query($app_query, $params)->getResult();

            // Detections by user (if not filtered by user)
            $user_stats = [];
            if (!$user_id) {
                $user_query = "SELECT ia.`user_id`, u.first_name, u.last_name, COUNT(*) as count
                              FROM `{$this->table}` ia
                              LEFT JOIN `" . $this->dbprefix . "users` u ON ia.user_id = u.id
                              WHERE {$where_clause}
                              GROUP BY ia.`user_id`
                              ORDER BY count DESC
                              LIMIT 10";
                $user_stats = $this->db->query($user_query, $params)->getResult();
            }

            // Detections by day
            $day_query = "SELECT DATE(detection_time) as date, COUNT(*) as count
                         FROM `{$this->table}`
                         WHERE {$where_clause}
                         GROUP BY DATE(detection_time)
                         ORDER BY date DESC
                         LIMIT 30";
            $day_result = $this->db->query($day_query, $params)->getResult();

            return [
                'total' => $total_result->total,
                'by_app' => $app_result,
                'by_user' => $user_stats,
                'by_day' => $day_result
            ];
        } catch (Exception $e) {
            error_log("Error getting invalid app statistics: " . $e->getMessage());
            return [
                'total' => 0,
                'by_app' => [],
                'by_user' => [],
                'by_day' => []
            ];
        }
    }

    /**
     * Get user information by ID
     *
     * @param int $user_id User ID
     * @return object|null User data or null if not found
     */
    public function getUserById($user_id) {
        try {
            $user_query = "SELECT id, first_name, last_name, email, user_type FROM " . $this->db->prefixTable('users') . " WHERE id = ? AND deleted = 0";
            $user = $this->db->query($user_query, [$user_id])->getRow();
            return $user;
        } catch (Exception $e) {
            error_log("Error getting user by ID: " . $e->getMessage());
            return null;
        }
    }

    /**
     * Get all admin users
     *
     * @return array Admin users
     */
    public function getAdminUsers() {
        try {
            $admin_query = "SELECT id, first_name, last_name, email FROM " . $this->db->prefixTable('users') . " WHERE is_admin = 1 AND status = 'active' AND deleted = 0";
            $admins = $this->db->query($admin_query)->getResult();
            return $admins;
        } catch (Exception $e) {
            error_log("Error getting admin users: " . $e->getMessage());
            return [];
        }
    }

    /**
     * Get invalid app statistics for a user
     *
     * @param int $user_id User ID
     * @return object|null Statistics data or null if not found
     */
    public function getUserInvalidAppStats($user_id) {
        try {
            $query = "SELECT 
                        COUNT(*) as total_detections,
                        AVG(suspicion_score) as avg_suspicion_score,
                        MAX(detection_time) as last_detection
                      FROM {$this->table} 
                      WHERE user_id = ? AND deleted = 0";
            $result = $this->db->query($query, [$user_id])->getRow();
            return $result;
        } catch (Exception $e) {
            error_log("Error getting user invalid app stats: " . $e->getMessage());
            return null;
        }
    }

    /**
     * Report invalid app with enhanced data handling
     *
     * @param array $data App data
     * @return int|bool Inserted ID or false on failure
     */
    public function reportInvalidApp($data) {
        try {
            // Get request data with improved handling
            $user_id = $data['user_id'] ?? null;
            $app_name = $data['app_name'] ?? null;
            $suspicion_score = $data['suspicion_score'] ?? 5;
            $project_id = $data['project_id'] ?? null;
            $detection_time = $data['detection_time'] ?? date('Y-m-d H:i:s');
            $system_info = $data['system_info'] ?? null;

            // Get app details if provided
            $app_details = $data['app_details'] ?? null;

            // Process app_details with better handling for different formats
            if ($app_details) {
                // Decode if it's already a JSON string
                $decoded = json_decode($app_details, true);

                if (is_array($decoded)) {
                    // Valid JSON, add system_info if available
                    if ($system_info) {
                        $system_data = json_decode($system_info, true);
                        if (is_array($system_data)) {
                            $decoded['system_info'] = $system_data;
                        }
                    }

                    // Re-encode the enriched data
                    $app_details = json_encode($decoded);
                } else {
                    // Not valid JSON, encode as raw text
                    $app_details = json_encode([
                        'raw' => $app_details,
                        'system_info' => $system_info ? json_decode($system_info, true) : null
                    ]);
                }
            }

            // Validate required fields
            if (!$user_id || !$app_name) {
                return false;
            }

            // Prepare insert data
            $insert_data = [
                'user_id' => $user_id,
                'app_name' => $app_name,
                'suspicion_score' => $suspicion_score,
                'project_id' => $project_id,
                'app_details' => $app_details,
                'detection_time' => $detection_time,
                'created_at' => date('Y-m-d H:i:s')
            ];

            // Insert the record
            $result = $this->insert($insert_data);

            if ($result) {
                // Log successful insertion
                error_log("Invalid app reported successfully: User ID {$user_id}, App: {$app_name}");
                return $result;
            }

            return false;
        } catch (Exception $e) {
            error_log("Error reporting invalid app: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Send message about invalid app detection
     *
     * @param array $data Message data
     * @return bool Success or failure
     */
    public function sendInvalidAppMessage($data) {
        try {
            $user_id = $data['user_id'] ?? null;
            $app_name = $data['app_name'] ?? null;

            if (!$user_id || !$app_name) {
                return false;
            }

            // Insert a simple record for messaging
            $insert_query = "INSERT INTO {$this->table} (user_id, app_name, suspicion_score, detection_time, created_at) VALUES (?, ?, 5, NOW(), NOW())";
            $this->db->query($insert_query, [$user_id, $app_name]);

            return true;
        } catch (Exception $e) {
            error_log("Error sending invalid app message: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Notify admin about invalid app detection
     *
     * @param array $data Detection data
     * @return bool Success or failure
     */
    public function notifyAdmin($data) {
        try {
            // Get admin users
            $admins = $this->getAdminUsers();
            
            if (empty($admins)) {
                error_log("No admin users found for notification");
                return false;
            }

            // Log the notification attempt
            error_log("Notifying " . count($admins) . " admin users about invalid app detection: " . ($data['app_name'] ?? 'Unknown'));

            // In a real implementation, you would send emails or notifications here
            // For now, we'll just log the notification
            foreach ($admins as $admin) {
                error_log("Admin notification sent to: {$admin->email} for app: " . ($data['app_name'] ?? 'Unknown'));
            }

            return true;
        } catch (Exception $e) {
            error_log("Error notifying admin: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Check admin access
     *
     * @return bool True if user has admin access
     */
    public function checkAdminAccess() {
        try {
            // This would typically check the current user's session
            // For now, we'll return true as a placeholder
            // In a real implementation, you would check the user's role/permissions
            return true;
        } catch (Exception $e) {
            error_log("Error checking admin access: " . $e->getMessage());
            return false;
        }
    }
}
