<?php

namespace Tracebit\Models;

use Exception;
use InvalidArgumentException;

/**
 * Optimized Screenshots Model
 * Includes proper security, caching, and performance optimizations
 */
class Screenshots_model extends Tracker_base_model {

    protected $table = 'tracker_screenshots';
    protected $cache_ttl = 1800; // 30 minutes for screenshots

    public function __construct() {
        parent::__construct('tracker_screenshots');
        parent::init_activity_log("tracker_screenshots", "title", "project", "project_id");
    }

    /**
     * Create screenshot with validation and security
     */
    public function createScreenshot($data) {
        $start_time = microtime(true);

        try {
            // Validate input
            $rules = [
                'user_id' => 'required|integer',
                'project_id' => 'permit_empty|integer',
                'path' => 'required|max_length[500]',
                'title' => 'permit_empty|max_length[255]',
                'description' => 'permit_empty'
            ];

            $validated_data = $this->validate_input($data, $rules);

            // Additional security: validate file path
            if (!$this->is_valid_file_path($validated_data['path'])) {
                throw new InvalidArgumentException('Invalid file path provided');
            }

            // Use table builder for security
            $table = $this->db->table($this->table);
            $result = $table->insert($validated_data);

            if ($result) {
                // Clear relevant cache
                $this->clear_cache_pattern("screenshots_user_{$validated_data['user_id']}");

                $this->monitor_query_performance('createScreenshot', $start_time);
                return $this->db->insertID();
            }

            return $this->handle_db_error('Screenshot creation failed');

        } catch (Exception $e) {
            log_message('error', '[TRACKER] Screenshot creation error: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Get screenshots with optimized query and caching
     */
    public function getScreenshots($data = []) {
        $start_time = microtime(true);

        // Validate input
        $rules = [
            'date' => 'required|valid_date',
            'user_id' => 'required|integer',
            'project_id' => 'permit_empty|integer',
            'limit' => 'permit_empty|integer'
        ];

        try {
            $validated_data = $this->validate_input($data, $rules);
            $user_id = $validated_data['user_id'];
            $date = $validated_data['date'];
            $project_id = $validated_data['project_id'] ?? null;
            $limit = $validated_data['limit'] ?? 50;

            // Generate cache key
            $cache_key = $this->cache_prefix . "screenshots_user_{$user_id}_date_{$date}" .
                        ($project_id ? "_project_{$project_id}" : '') . "_limit_{$limit}";

            // Try to get from cache first
            if ($this->enable_query_cache) {
                $cached_result = $this->cache->get($cache_key);
                if ($cached_result !== null) {
                    log_message('debug', '[TRACKER] Cache HIT: ' . $cache_key);
                    return $cached_result;
                }
            }

            // Build optimized query
            $sql = "SELECT
                        ts.id,
                        ts.path,
                        ts.title,
                        ts.description,
                        ts.created_at as date,
                        p.title as project_title,
                        p.id as project_id
                    FROM " . $this->db->prefixTable('tracker_screenshots') . " ts
                    LEFT JOIN " . $this->db->prefixTable('projects') . " p
                        ON ts.project_id = p.id AND p.deleted = 0
                    WHERE ts.user_id = ?
                    AND DATE(ts.created_at) = ?
                    AND ts.deleted = 0";

            $binds = [$user_id, $date];

            if ($project_id) {
                $sql .= " AND ts.project_id = ?";
                $binds[] = $project_id;
            }

            $sql .= " ORDER BY ts.created_at DESC LIMIT ?";
            $binds[] = $limit;

            $query = $this->db->query($sql, $binds);

            if ($query) {
                $result = $query->getResult();

                // Cache the result
                if ($this->enable_query_cache) {
                    $this->cache->save($cache_key, $result, $this->cache_ttl);
                    log_message('debug', '[TRACKER] Cache MISS: ' . $cache_key);
                }

                $this->monitor_query_performance('getScreenshots', $start_time);
                return $result;
            }

            return $this->handle_db_error('Failed to retrieve screenshots');

        } catch (Exception $e) {
            log_message('error', '[TRACKER] getScreenshots error: ' . $e->getMessage());
            return [];
        }
    }

    /**
     * Get latest screenshots with optimized query
     */
    public function getLatestScreenshots($data) {
        $start_time = microtime(true);

        try {
            $rules = [
                'user_id' => 'required|integer',
                'limit' => 'permit_empty|integer'
            ];

            $validated_data = $this->validate_input($data, $rules);
            $user_id = $validated_data['user_id'];
            $limit = $validated_data['limit'] ?? 10;

            // Use index-optimized query
            $sql = "SELECT
                        ts.id,
                        ts.path,
                        ts.title,
                        ts.description,
                        ts.created_at,
                        p.title as project_title
                    FROM " . $this->db->prefixTable('tracker_screenshots') . " ts
                    LEFT JOIN " . $this->db->prefixTable('projects') . " p
                        ON ts.project_id = p.id AND p.deleted = 0
                    WHERE ts.user_id = ?
                    AND ts.deleted = 0
                    ORDER BY ts.created_at DESC
                    LIMIT ?";

            $query = $this->cached_query($sql, [$user_id, $limit], 300); // 5 min cache

            if ($query) {
                $this->monitor_query_performance('getLatestScreenshots', $start_time);
                return $query->getResult();
            }

            return $this->handle_db_error('Failed to retrieve latest screenshots');

        } catch (Exception $e) {
            log_message('error', '[TRACKER] getLatestScreenshots error: ' . $e->getMessage());
            return [];
        }
    }

    /**
     * Get screenshots by date range with pagination
     */
    public function getScreenshotsByDateRange($data) {
        $start_time = microtime(true);

        try {
            $rules = [
                'user_id' => 'required|integer',
                'start_date' => 'required|valid_date',
                'end_date' => 'required|valid_date',
                'page' => 'permit_empty|integer',
                'per_page' => 'permit_empty|integer'
            ];

            $validated_data = $this->validate_input($data, $rules);
            $user_id = $validated_data['user_id'];
            $start_date = $validated_data['start_date'];
            $end_date = $validated_data['end_date'];
            $page = max(1, $validated_data['page'] ?? 1);
            $per_page = min(100, $validated_data['per_page'] ?? 20);
            $offset = ($page - 1) * $per_page;

            // Optimized query with proper indexing
            $sql = "SELECT
                        ts.id,
                        ts.path,
                        ts.title,
                        ts.description,
                        ts.created_at,
                        p.title as project_title,
                        p.id as project_id
                    FROM " . $this->db->prefixTable('tracker_screenshots') . " ts
                    LEFT JOIN " . $this->db->prefixTable('projects') . " p
                        ON ts.project_id = p.id AND p.deleted = 0
                    WHERE ts.user_id = ?
                    AND DATE(ts.created_at) BETWEEN ? AND ?
                    AND ts.deleted = 0
                    ORDER BY ts.created_at DESC
                    LIMIT ? OFFSET ?";

            $query = $this->cached_query($sql, [$user_id, $start_date, $end_date, $per_page, $offset], 900); // 15 min cache

            if ($query) {
                $this->monitor_query_performance('getScreenshotsByDateRange', $start_time);
                return [
                    'data' => $query->getResult(),
                    'pagination' => [
                        'page' => $page,
                        'per_page' => $per_page,
                        'total' => $this->getScreenshotsCount($user_id, $start_date, $end_date)
                    ]
                ];
            }

            return $this->handle_db_error('Failed to retrieve screenshots by date range');

        } catch (Exception $e) {
            log_message('error', '[TRACKER] getScreenshotsByDateRange error: ' . $e->getMessage());
            return ['data' => [], 'pagination' => ['page' => 1, 'per_page' => 20, 'total' => 0]];
        }
    }

    /**
     * Get screenshots count for pagination
     */
    private function getScreenshotsCount($user_id, $start_date, $end_date) {
        $sql = "SELECT COUNT(*) as total
                FROM " . $this->db->prefixTable('tracker_screenshots') . "
                WHERE user_id = ?
                AND DATE(created_at) BETWEEN ? AND ?
                AND deleted = 0";

        $query = $this->cached_query($sql, [$user_id, $start_date, $end_date], 900);

        if ($query) {
            $result = $query->getResult();
            return $result[0]->total ?? 0;
        }

        return 0;
    }

    /**
     * Delete screenshot with proper cleanup
     */
    public function deleteScreenshot($screenshot_id, $user_id) {
        try {
            // Verify ownership
            $sql = "SELECT id, path, user_id FROM " . $this->db->prefixTable('tracker_screenshots') . "
                    WHERE id = ? AND user_id = ? AND deleted = 0";

            $query = $this->db->query($sql, [$screenshot_id, $user_id]);

            if (!$query || !$query->getRow()) {
                throw new InvalidArgumentException('Screenshot not found or access denied');
            }

            $screenshot = $query->getRow();

            // Soft delete
            $update_sql = "UPDATE " . $this->db->prefixTable('tracker_screenshots') . "
                          SET deleted = 1, updated_at = NOW()
                          WHERE id = ? AND user_id = ?";

            $result = $this->db->query($update_sql, [$screenshot_id, $user_id]);

            if ($result) {
                // Clear cache
                $this->clear_cache_pattern("screenshots_user_{$user_id}");

                // Log the deletion
                log_message('info', "[TRACKER] Screenshot deleted - ID: {$screenshot_id}, User: {$user_id}, Path: {$screenshot->path}");

                return true;
            }

            return $this->handle_db_error('Failed to delete screenshot');

        } catch (Exception $e) {
            log_message('error', '[TRACKER] deleteScreenshot error: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Validate file path for security
     */
    private function is_valid_file_path($path) {
        // Basic security checks
        if (empty($path)) {
            return false;
        }

        // Check for directory traversal attempts
        if (strpos($path, '../') !== false || strpos($path, '..\\') !== false) {
            return false;
        }

        // Check for null bytes
        if (strpos($path, "\0") !== false) {
            return false;
        }

        // Must be within allowed directory (you can customize this)
        $allowed_prefixes = [
            'files/tracker_screenshots/',
            'uploads/screenshots/',
            '/var/www/uploads/screenshots/'
        ];

        foreach ($allowed_prefixes as $prefix) {
            if (strpos($path, $prefix) === 0) {
                return true;
            }
        }

        return false;
    }

    /**
     * Get screenshots statistics for dashboard
     */
    public function getScreenshotsStats($user_id, $date_range = 30) {
        $start_time = microtime(true);

        try {
            $sql = "SELECT
                        COUNT(*) as total_screenshots,
                        COUNT(DISTINCT DATE(created_at)) as active_days,
                        COUNT(DISTINCT project_id) as projects_with_screenshots,
                        MAX(created_at) as last_screenshot_date
                    FROM " . $this->db->prefixTable('tracker_screenshots') . "
                    WHERE user_id = ?
                    AND created_at >= DATE_SUB(NOW(), INTERVAL ? DAY)
                    AND deleted = 0";

            $query = $this->cached_query($sql, [$user_id, $date_range], 1800); // 30 min cache

            if ($query) {
                $this->monitor_query_performance('getScreenshotsStats', $start_time);
                return $query->getResult()[0] ?? null;
            }

            return $this->handle_db_error('Failed to retrieve screenshots stats');

        } catch (Exception $e) {
            log_message('error', '[TRACKER] getScreenshotsStats error: ' . $e->getMessage());
            return null;
        }
    }
}
