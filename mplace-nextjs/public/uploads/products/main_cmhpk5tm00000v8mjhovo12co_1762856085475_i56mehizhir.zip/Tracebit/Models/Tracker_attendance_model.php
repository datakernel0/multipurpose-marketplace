<?php

namespace Tracebit\Models;

use App\Models\Crud_model;

/**
 * Tracker Attendance Model
 * Handles check-in/check-out functionality for the dashboard
 */
class Tracker_attendance_model extends Crud_model {

    protected $table = 'tracker_attendance';

    public function __construct() {
        $this->table = 'tracker_attendance';
        parent::__construct($this->table);
    }

    /**
     * Check in a user
     */
    public function clock_in($user_id, $note = '') {
        try {
            // Check if user is already checked in
            $current_status = $this->get_current_status($user_id);
            if ($current_status) {
                return false; // Already checked in
            }

            // Calculate if user is late based on working_hours_start setting
            $late_status = $this->calculate_late_status();

            $data = array(
                'user_id' => $user_id,
                'inTime' => time() * 1000, // Store as milliseconds
                'outTime' => null,
                'note' => $note,
                'status' => $late_status['status'],
                'late' => $late_status['is_late'],
                'timezone' => function_exists('get_timezone_offset') ? get_timezone_offset() : 0,
                'sign' => '+',
                'created_at' => function_exists('get_current_utc_time') ? get_current_utc_time() : date('Y-m-d H:i:s'),
                'deleted' => 0
            );

            $result = $this->ci_save($data);
            if ($result) {
                return $result;
            }

            return false;

        } catch (\Exception $e) {
            return false;
        }
    }

    /**
     * Check out a user
     */
    public function clock_out($user_id, $attendance_id = null, $note = '') {
        try {
            // Get current check-in record
            $current_status = $this->get_current_status($user_id);
            if (!$current_status) {
                return false; // Not checked in
            }

            $update_data = array(
                'outTime' => time() * 1000, // Store as milliseconds
                'updated_at' => function_exists('get_current_utc_time') ? get_current_utc_time() : date('Y-m-d H:i:s')
            );

            // Append note if provided
            if (!empty($note)) {
                $existing_note = $current_status->note ?: '';
                $update_data['note'] = $existing_note . ($existing_note ? ' | ' : '') . $note;
            }

            $result = $this->ci_save($update_data, $current_status->id);
            if ($result) {
                return true;
            }

            return false;

        } catch (\Exception $e) {
            return false;
        }
    }

    /**
     * Get current attendance status for a user (only considers today's records)
     */
    public function get_current_status($user_id) {
        try {
            $tracker_attendance_table = $this->db->prefixTable('tracker_attendance');

            // Calculate today's timestamp range (00:00:00 to 23:59:59 in milliseconds)
            $today_start = strtotime(date('Y-m-d 00:00:00')) * 1000;
            $today_end = strtotime(date('Y-m-d 23:59:59')) * 1000;

            $sql = "SELECT * FROM {$tracker_attendance_table}
                    WHERE user_id = ? 
                    AND outTime IS NULL 
                    AND deleted = 0
                    AND inTime >= ? 
                    AND inTime <= ?
                    ORDER BY created_at DESC
                    LIMIT 1";

            $query = $this->db->query($sql, [$user_id, $today_start, $today_end]);

            if ($query) {
                $result = $query->getResult();
                $status = !empty($result) ? $result[0] : null;
                
                return $status;
            }

            return null;

        } catch (\Exception $e) {
            return null;
        }
    }

    /**
     * Get attendance records for a date range
     */
    public function get_attendance_by_date_range($user_id, $start_date, $end_date) {
        try {
            $start_timestamp = strtotime($start_date . ' 00:00:00') * 1000;
            $end_timestamp = strtotime($end_date . ' 23:59:59') * 1000;

            $tracker_attendance_table = $this->db->prefixTable('tracker_attendance');

            $sql = "SELECT * FROM {$tracker_attendance_table}
                    WHERE user_id = ?
                    AND inTime >= ?
                    AND inTime <= ?
                    AND deleted = 0
                    ORDER BY inTime DESC";

            $query = $this->db->query($sql, [$user_id, $start_timestamp, $end_timestamp]);

            if ($query) {
                return $query->getResult();
            }

            return [];

        } catch (\Exception $e) {
            return [];
        }
    }

    /**
     * Get total worked time for a user on a specific date
     */
    public function get_total_worked_time($user_id, $date) {
        try {
            $records = $this->get_attendance_by_date_range($user_id, $date, $date);
            $total_seconds = 0;

            foreach ($records as $record) {
                if ($record->outTime) {
                    $in_time = $record->inTime / 1000; // Convert from milliseconds
                    $out_time = $record->outTime / 1000; // Convert from milliseconds
                    $total_seconds += ($out_time - $in_time);
                }
            }

            return $total_seconds;

        } catch (\Exception $e) {
            return 0;
        }
    }

    /**
     * Check if user is currently checked in
     */
    public function is_checked_in($user_id) {
        $status = $this->get_current_status($user_id);
        return $status ? true : false;
    }

    /**
     * Get attendance summary for dashboard
     */
    public function get_dashboard_summary($user_id, $date = null) {
        try {
            if (!$date) {
                $date = date('Y-m-d');
            }

            $current_status = $this->get_current_status($user_id);
            $total_time = $this->get_total_worked_time($user_id, $date);
            $records = $this->get_attendance_by_date_range($user_id, $date, $date);

            return array(
                'is_checked_in' => $current_status ? true : false,
                'current_session' => $current_status,
                'total_worked_seconds' => $total_time,
                'total_worked_formatted' => convert_seconds_to_time_format($total_time),
                'total_sessions' => count($records),
                'records' => $records
            );

        } catch (\Exception $e) {
            return array(
                'is_checked_in' => false,
                'current_session' => null,
                'total_worked_seconds' => 0,
                'total_worked_formatted' => '00:00:00',
                'total_sessions' => 0,
                'records' => []
            );
        }
    }

    /**
     * Calculate if the current check-in time is late based on working_hours_start setting
     */
    public function calculate_late_status() {
        try {
            // Get the working hours start time from tracker_settings
            $tracker_settings_table = $this->db->prefixTable('tracker_settings');
            $sql = "SELECT setting_value FROM {$tracker_settings_table} 
                    WHERE setting_name = 'working_hours_start' AND deleted = 0 LIMIT 1";
            
            $query = $this->db->query($sql);
            $working_hours_start = '09:00'; // Default fallback
            
            if ($query) {
                $result = $query->getResult();
                if (!empty($result)) {
                    $working_hours_start = $result[0]->setting_value;
                }
            }

            // Get current time in local timezone
            $current_time = date('H:i');
            $current_date = date('Y-m-d');
            
            // Convert working hours start to comparable format
            $start_time_obj = DateTime::createFromFormat('H:i', $working_hours_start);
            $current_time_obj = DateTime::createFromFormat('H:i', $current_time);
            
            if (!$start_time_obj || !$current_time_obj) {
                return array('status' => 'present', 'is_late' => 0);
            }

            // Check if current time is after working hours start
            $is_late = $current_time_obj > $start_time_obj;
            
            // Determine status
            $status = $is_late ? 'late' : 'on_time';
            
            return array(
                'status' => $status,
                'is_late' => $is_late ? 1 : 0,
                'working_hours_start' => $working_hours_start,
                'check_in_time' => $current_time
            );

        } catch (\Exception $e) {
            return array('status' => 'present', 'is_late' => 0);
        }
    }

    /**
     * Get attendance records with status information
     */
    public function get_attendance_with_status($user_id, $start_date, $end_date) {
        try {
            $start_timestamp = strtotime($start_date . ' 00:00:00') * 1000;
            $end_timestamp = strtotime($end_date . ' 23:59:59') * 1000;

            $tracker_attendance_table = $this->db->prefixTable('tracker_attendance');

            $sql = "SELECT *, 
                           CASE 
                               WHEN status = 'late' THEN 'Late'
                               WHEN status = 'on_time' THEN 'On Time'
                               ELSE 'Present'
                           END as status_display
                    FROM {$tracker_attendance_table}
                    WHERE user_id = ?
                    AND inTime >= ?
                    AND inTime <= ?
                    AND deleted = 0
                    ORDER BY inTime DESC";

            $query = $this->db->query($sql, [$user_id, $start_timestamp, $end_timestamp]);

            if ($query) {
                return $query->getResult();
            }

            return [];

        } catch (\Exception $e) {
            return [];
        }
    }
}
