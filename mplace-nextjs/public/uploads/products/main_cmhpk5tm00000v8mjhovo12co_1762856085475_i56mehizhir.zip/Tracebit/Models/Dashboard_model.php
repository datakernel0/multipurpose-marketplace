<?php

namespace Tracebit\Models;

use CodeIgniter\Model;

class Dashboard_model extends \Tracebit\Models\Tracker_base_model
{
    public function __construct()
    {
        parent::__construct('tracker_attendance');
    }

    /**
     * Get team members status
     */
    public function getTeamMembersStatus()
    {
        try {
            if (!$this->db) {
                return $this->getDemoTeamMembers();
            }

            $users_table = $this->db->prefixTable('users');
            $tracker_attendance_table = $this->db->prefixTable('tracker_attendance');
            $today = date('Y-m-d');

            $sql = "SELECT
                        u.id,
                        u.first_name,
                        u.last_name,
                        u.email,
                        u.job_title,
                        u.status,
                        u.image as employee_image,
                        CASE 
                            WHEN ta.inTime IS NOT NULL AND ta.outTime IS NULL THEN 'online'
                            WHEN ta.inTime IS NOT NULL AND ta.outTime IS NOT NULL THEN 'offline'
                            ELSE 'offline'
                        END as attendance_status,
                        ta.inTime as last_checkin,
                        DATE(FROM_UNIXTIME(ta.inTime / 1000)) as attendance_date
                    FROM {$users_table} u
                    LEFT JOIN (
                        SELECT user_id, inTime, outTime
                        FROM {$tracker_attendance_table}
                        WHERE DATE(FROM_UNIXTIME(inTime / 1000)) = ?
                        AND deleted = 0
                        ORDER BY inTime DESC
                    ) ta ON u.id = ta.user_id
                    WHERE u.status = 'active'
                    AND u.deleted = 0
                    AND u.disable_login = 0
                    ORDER BY u.first_name, u.last_name";

            $query = $this->db->query($sql, [$today]);

            if ($query) {
                $team_members = $query->getResult();
                
                if (!empty($team_members)) {
                    return $team_members;
                }
            }

            return $this->getDemoTeamMembers();

        } catch (\Exception $e) {
            return $this->getDemoTeamMembers();
        }
    }

    /**
     * Get attendance status for user
     */
    public function getAttendanceStatus($user_id)
    {
        try {
            if (!$this->db) {
                return [
                    'status' => 'absent',
                    'checkin_time' => null,
                    'checkout_time' => null,
                    'working_hours' => '0h 0m',
                    'total_seconds' => 0
                ];
            }

            $tracker_attendance_table = $this->db->prefixTable('tracker_attendance');
            $today = date('Y-m-d');

            $sql = "SELECT
                        inTime,
                        outTime,
                        CASE 
                            WHEN inTime IS NOT NULL AND outTime IS NULL THEN 'online'
                            WHEN inTime IS NOT NULL AND outTime IS NOT NULL THEN 'offline'
                            ELSE 'absent'
                        END as status
                    FROM {$tracker_attendance_table}
                    WHERE user_id = ?
                    AND DATE(FROM_UNIXTIME(inTime / 1000)) = ?
                    AND deleted = 0
                    ORDER BY inTime DESC
                    LIMIT 1";

            $query = $this->db->query($sql, [$user_id, $today]);

            if ($query && $result = $query->getRow()) {
                $checkin_time = $result->inTime ? date('H:i', $result->inTime / 1000) : null;
                $checkout_time = $result->outTime ? date('H:i', $result->outTime / 1000) : null;
                
                $total_seconds = 0;
                if ($result->inTime && $result->outTime) {
                    $total_seconds = ($result->outTime - $result->inTime) / 1000;
                } elseif ($result->inTime && !$result->outTime) {
                    $total_seconds = (time() * 1000 - $result->inTime) / 1000;
                }

                return [
                    'status' => $result->status,
                    'checkin_time' => $checkin_time,
                    'checkout_time' => $checkout_time,
                    'working_hours' => $this->formatTime($total_seconds),
                    'total_seconds' => $total_seconds
                ];
            }

            return [
                'status' => 'absent',
                'checkin_time' => null,
                'checkout_time' => null,
                'working_hours' => '0h 0m',
                'total_seconds' => 0
            ];

        } catch (\Exception $e) {
            return [
                'status' => 'absent',
                'checkin_time' => null,
                'checkout_time' => null,
                'working_hours' => '0h 0m',
                'total_seconds' => 0
            ];
        }
    }

    /**
     * Calculate working hours for user
     */
    public function calculateWorkingHours($user_id)
    {
        try {
            if (!$this->db) {
                return [
                    'working_hours' => '0h 0m',
                    'total_working_seconds' => 0,
                    'target_hours' => 8.0,
                    'target_seconds' => 28800,
                    'percentage' => 0,
                    'chart_labels' => ['Worked', 'Remaining'],
                    'chart_values' => [0, 100],
                    'chart_colors' => ['#10b981', '#e5e7eb']
                ];
            }

            $tracker_attendance_table = $this->db->prefixTable('tracker_attendance');
            $today = date('Y-m-d');
            $target_hours = $this->getDailyTargetHours();
            $target_seconds = $target_hours * 3600;

            $sql = "SELECT
                        SUM(CASE
                            WHEN inTime IS NOT NULL AND outTime IS NOT NULL
                            THEN (outTime - inTime) / 1000
                            WHEN inTime IS NOT NULL AND outTime IS NULL
                            THEN (UNIX_TIMESTAMP() * 1000 - inTime) / 1000
                            ELSE 0
                        END) as total_seconds
                    FROM {$tracker_attendance_table}
                    WHERE user_id = ?
                    AND DATE(FROM_UNIXTIME(inTime / 1000)) = ?
                    AND deleted = 0";

            $query = $this->db->query($sql, [$user_id, $today]);

            if ($query && $result = $query->getRow()) {
                $total_seconds = $result->total_seconds ?? 0;
                $percentage = $target_seconds > 0 ? ($total_seconds / $target_seconds) * 100 : 0;
                $remaining_percentage = 100 - $percentage;

                return [
                    'working_hours' => $this->formatTime($total_seconds),
                    'total_working_seconds' => $total_seconds,
                    'target_hours' => $target_hours,
                    'target_seconds' => $target_seconds,
                    'percentage' => round($percentage, 1),
                    'chart_labels' => ['Worked', 'Remaining'],
                    'chart_values' => [$percentage, $remaining_percentage],
                    'chart_colors' => ['#10b981', '#e5e7eb']
                ];
            }

            return [
                'working_hours' => '0h 0m',
                'total_working_seconds' => 0,
                'target_hours' => $target_hours,
                'target_seconds' => $target_seconds,
                'percentage' => 0,
                'chart_labels' => ['Worked', 'Remaining'],
                'chart_values' => [0, 100],
                'chart_colors' => ['#10b981', '#e5e7eb']
            ];

        } catch (\Exception $e) {
            return [
                'working_hours' => '0h 0m',
                'total_working_seconds' => 0,
                'target_hours' => 8.0,
                'target_seconds' => 28800,
                'percentage' => 0,
                'chart_labels' => ['Worked', 'Remaining'],
                'chart_values' => [0, 100],
                'chart_colors' => ['#10b981', '#e5e7eb']
            ];
        }
    }

    /**
     * Calculate productivity for user
     */
    public function calculateProductivity($user_id)
    {
        try {
            if (!$this->db) {
                return [
                    'productivity_score' => 0,
                    'productive_time' => '0h 0m',
                    'productive_seconds' => 0,
                    'chart_labels' => ['Productive', 'Non-Productive'],
                    'chart_values' => [0, 100],
                    'chart_colors' => ['#10b981', '#f59e0b']
                ];
            }

            $tracker_attendance_table = $this->db->prefixTable('tracker_attendance');
            $today = date('Y-m-d');

            $sql = "SELECT
                        SUM(CASE
                            WHEN inTime IS NOT NULL AND outTime IS NOT NULL
                            THEN (outTime - inTime) / 1000
                            WHEN inTime IS NOT NULL AND outTime IS NULL
                            THEN (UNIX_TIMESTAMP() * 1000 - inTime) / 1000
                            ELSE 0
                        END) as total_seconds,
                        SUM(CASE
                            WHEN project IS NOT NULL AND project != '' AND project NOT LIKE 'idle-%' AND project NOT LIKE 'break-%'
                            THEN CASE
                                WHEN inTime IS NOT NULL AND outTime IS NOT NULL
                                THEN (outTime - inTime) / 1000
                                WHEN inTime IS NOT NULL AND outTime IS NULL
                                THEN (UNIX_TIMESTAMP() * 1000 - inTime) / 1000
                                ELSE 0
                            END
                            ELSE 0
                        END) as productive_seconds
                    FROM {$tracker_attendance_table}
                    WHERE user_id = ?
                    AND DATE(FROM_UNIXTIME(inTime / 1000)) = ?
                    AND deleted = 0";

            $query = $this->db->query($sql, [$user_id, $today]);

            if ($query && $result = $query->getRow()) {
                $total_seconds = $result->total_seconds ?? 0;
                $productive_seconds = $result->productive_seconds ?? 0;
                
                $productivity_score = $total_seconds > 0 ? ($productive_seconds / $total_seconds) * 100 : 0;
                $non_productive_percentage = 100 - $productivity_score;

                return [
                    'productivity_score' => round($productivity_score, 1),
                    'productive_time' => $this->formatTime($productive_seconds),
                    'productive_seconds' => $productive_seconds,
                    'chart_labels' => ['Productive', 'Non-Productive'],
                    'chart_values' => [$productivity_score, $non_productive_percentage],
                    'chart_colors' => ['#10b981', '#f59e0b']
                ];
            }

            return [
                'productivity_score' => 0,
                'productive_time' => '0h 0m',
                'productive_seconds' => 0,
                'chart_labels' => ['Productive', 'Non-Productive'],
                'chart_values' => [0, 100],
                'chart_colors' => ['#10b981', '#f59e0b']
            ];

        } catch (\Exception $e) {
            return [
                'productivity_score' => 0,
                'productive_time' => '0h 0m',
                'productive_seconds' => 0,
                'chart_labels' => ['Productive', 'Non-Productive'],
                'chart_values' => [0, 100],
                'chart_colors' => ['#10b981', '#f59e0b']
            ];
        }
    }

    /**
     * Calculate project time for user
     */
    public function calculateProjectTime($user_id)
    {
        try {
            if (!$this->db) {
                return [
                    'projects' => [],
                    'total_projects' => 0,
                    'total_time' => '0h 0m',
                    'chart_labels' => [],
                    'chart_values' => [],
                    'chart_colors' => []
                ];
            }

            $tracker_attendance_table = $this->db->prefixTable('tracker_attendance');
            $today = date('Y-m-d');
            $exclusion_conditions = implode(' ', $this->getProjectExclusionConditions());

            $sql = "SELECT
                        project,
                        SUM(CASE
                            WHEN inTime IS NOT NULL AND outTime IS NOT NULL
                            THEN (outTime - inTime) / 1000
                            WHEN inTime IS NOT NULL AND outTime IS NULL
                            THEN (UNIX_TIMESTAMP() * 1000 - inTime) / 1000
                            ELSE 0
                        END) as total_seconds
                    FROM {$tracker_attendance_table}
                    WHERE user_id = ?
                    AND DATE(FROM_UNIXTIME(inTime / 1000)) = ?
                    AND deleted = 0
                    AND project IS NOT NULL
                    AND project != ''
                    {$exclusion_conditions}
                    GROUP BY project
                    ORDER BY total_seconds DESC
                    LIMIT 5";

            $query = $this->db->query($sql, [$user_id, $today]);

            if ($query) {
                $projects = [];
                $total_seconds = 0;
                $chart_labels = [];
                $chart_values = [];

                foreach ($query->getResult() as $project) {
                    $projects[] = [
                        'title' => $project->project,
                        'formatted_time' => $this->formatTime($project->total_seconds),
                        'seconds' => $project->total_seconds,
                        'name' => $project->project, // Keep for backward compatibility
                        'time' => $this->formatTime($project->total_seconds) // Keep for backward compatibility
                    ];
                    $total_seconds += $project->total_seconds;
                    $chart_labels[] = $project->project;
                    $chart_values[] = round(($project->total_seconds / ($total_seconds ?: 1)) * 100, 1);
                }

                return [
                    'projects' => $projects,
                    'total_projects' => count($projects),
                    'total_time' => $this->formatTime($total_seconds),
                    'chart_labels' => $chart_labels,
                    'chart_values' => $chart_values,
                    'chart_colors' => ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6']
                ];
            }

            return [
                'projects' => [],
                'total_projects' => 0,
                'total_time' => '0h 0m',
                'chart_labels' => [],
                'chart_values' => [],
                'chart_colors' => []
            ];

        } catch (\Exception $e) {
            return [
                'projects' => [],
                'total_projects' => 0,
                'total_time' => '0h 0m',
                'chart_labels' => [],
                'chart_values' => [],
                'chart_colors' => []
            ];
        }
    }

    /**
     * Calculate project recap for user
     */
    public function calculateProjectRecap($user_id, $filter = 'weekly')
    {
        try {
            if (!$this->db) {
                return [
                    'total_projects' => 0,
                    'total_time' => '0h 0m',
                    'total_seconds' => 0,
                    'days_worked' => 0,
                    'projects' => [],
                    'chart_labels' => [],
                    'chart_values' => [],
                    'chart_colors' => []
                ];
            }

            $tracker_attendance_table = $this->db->prefixTable('tracker_attendance');
            $exclusion_conditions = implode(' ', $this->getProjectExclusionConditions());
            
            $params = [$user_id];
            $date_condition = "";

            switch ($filter) {
                case 'weekly':
                    $date_condition = "AND YEARWEEK(DATE(FROM_UNIXTIME(inTime / 1000)), 1) = YEARWEEK(CURDATE(), 1)";
                    break;
                case 'monthly':
                    $date_condition = "AND YEAR(DATE(FROM_UNIXTIME(inTime / 1000))) = YEAR(CURDATE()) AND MONTH(DATE(FROM_UNIXTIME(inTime / 1000))) = MONTH(CURDATE())";
                    break;
                default: // daily
                    $today = date('Y-m-d');
                    $date_condition = "AND DATE(FROM_UNIXTIME(inTime / 1000)) = ?";
                    $params[] = $today;
                    break;
            }

            $sql = "SELECT
                        project,
                        SUM(CASE
                            WHEN inTime IS NOT NULL AND outTime IS NOT NULL
                            THEN (outTime - inTime) / 1000
                            WHEN inTime IS NOT NULL AND outTime IS NULL
                            THEN (UNIX_TIMESTAMP() * 1000 - inTime) / 1000
                            ELSE 0
                        END) as total_seconds,
                        COUNT(DISTINCT DATE(FROM_UNIXTIME(inTime / 1000))) as days_worked
                    FROM {$tracker_attendance_table}
                    WHERE user_id = ?
                    AND deleted = 0
                    AND project IS NOT NULL
                    AND project != ''
                    {$exclusion_conditions}
                    {$date_condition}
                    GROUP BY project
                    ORDER BY total_seconds DESC
                    LIMIT 10";

            $query = $this->db->query($sql, $params);

            if ($query) {
                $projects = [];
                $total_seconds = 0;
                $chart_labels = [];
                $chart_values = [];
                $total_days_worked = 0;

                foreach ($query->getResult() as $project) {
                    $projects[] = [
                        'name' => $project->project,
                        'time' => $this->formatTime($project->total_seconds),
                        'seconds' => $project->total_seconds,
                        'days_worked' => $project->days_worked
                    ];
                    $total_seconds += $project->total_seconds;
                    $total_days_worked = max($total_days_worked, $project->days_worked);
                    $chart_labels[] = $project->project;
                    $chart_values[] = round(($project->total_seconds / ($total_seconds ?: 1)) * 100, 1);
                }

                return [
                    'total_projects' => count($projects),
                    'total_time' => $this->formatTime($total_seconds),
                    'total_seconds' => $total_seconds,
                    'days_worked' => $total_days_worked,
                    'projects' => $projects,
                    'chart_labels' => $chart_labels,
                    'chart_values' => $chart_values,
                    'chart_colors' => ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#06b6d4', '#84cc16', '#f97316', '#ec4899', '#6366f1']
                ];
            }

            return [
                'total_projects' => 0,
                'total_time' => '0h 0m',
                'total_seconds' => 0,
                'days_worked' => 0,
                'projects' => [],
                'chart_labels' => [],
                'chart_values' => [],
                'chart_colors' => []
            ];

        } catch (\Exception $e) {
            return [
                'total_projects' => 0,
                'total_time' => '0h 0m',
                'total_seconds' => 0,
                'days_worked' => 0,
                'projects' => [],
                'chart_labels' => [],
                'chart_values' => [],
                'chart_colors' => []
            ];
        }
    }

    /**
     * Get latest screenshots for user
     */
    public function getLatestScreenshots($user_id, $limit = 4)
    {
        try {
            if (!$this->db) {
                return $this->getDemoScreenshots($limit);
            }

            $tracker_screenshots_table = $this->db->prefixTable('tracker_screenshots');

            $sql = "SELECT * FROM {$tracker_screenshots_table}
                    WHERE user_id = ? AND deleted = 0
                    ORDER BY created_at DESC
                    LIMIT ?";

            $query = $this->db->query($sql, [$user_id, $limit]);

            if ($query) {
                return $query->getResult();
            }
        } catch (\Exception $e) {
            // Failed to get screenshots
        }

        return $this->getDemoScreenshots($limit);
    }

    /**
     * Check if dashboard checkin is enabled
     */
    public function isDashboardCheckinEnabled()
    {
        try {
            if (!$this->db) { 
                return true; 
            }
            
            $tracker_settings_table = $this->db->prefixTable('tracker_settings');
            $sql = "SELECT setting_value FROM {$tracker_settings_table} WHERE setting_name = 'dashboard_checkin' AND deleted = 0 LIMIT 1";
            $query = $this->db->query($sql);
            
            if ($query && $result = $query->getRow()) {
                $setting_value = trim(strtolower($result->setting_value));
                if ($setting_value === '0' || $setting_value === 'false' || $setting_value === 'off' || $setting_value === 'no') { 
                    return false; 
                }
                if ($setting_value === '1' || $setting_value === 'true' || $setting_value === 'on' || $setting_value === 'yes') { 
                    return true; 
                }
                return false; // Default to false for any other value
            }
            return true; // Default to enabled if setting not found
            
        } catch (\Exception $e) { 
            return true; 
        }
    }

    /**
     * Get daily target hours
     */
    public function getDailyTargetHours()
    {
        try {
            if (!$this->db) { 
                return 8.0; 
            }
            
            $tracker_settings_table = $this->db->prefixTable('tracker_settings');
            $sql = "SELECT setting_value FROM {$tracker_settings_table} WHERE setting_name = 'daily_worked_time' AND deleted = 0 LIMIT 1";
            $query = $this->db->query($sql);
            
            if ($query && $result = $query->getRow()) {
                $target_hours = floatval($result->setting_value);
                return $target_hours > 0 ? $target_hours : 8.0;
            }
            return 8.0; // Default to 8 hours if setting not found
            
        } catch (\Exception $e) { 
            return 8.0; 
        }
    }

    /**
     * Check if project is excluded
     */
    public function isProjectExcluded($project_name)
    {
        if (empty($project_name)) { 
            return true; 
        }
        
        $excluded_prefixes = [
            'manual-', 'idle-', 'b-', 'break-', 'lunch-', 'meeting-', 'away-', 
            'offline-', 'off-', 'pause-', 'rest-', 'coffee-', 'tea-', 'smoke-', 
            'bathroom-', 'toilet-', 'wc-'
        ];
        
        foreach ($excluded_prefixes as $prefix) {
            if (stripos($project_name, $prefix) === 0) { 
                return true; 
            }
        }
        return false;
    }

    /**
     * Get project exclusion conditions for SQL
     */
    private function getProjectExclusionConditions()
    {
        return [
            "AND project NOT LIKE 'manual-%'",
            "AND project NOT LIKE 'idle-%'",
            "AND project NOT LIKE 'b-%'",
            "AND project NOT LIKE 'break-%'",
            "AND project NOT LIKE 'lunch-%'",
            "AND project NOT LIKE 'meeting-%'",
            "AND project NOT LIKE 'away-%'",
            "AND project NOT LIKE 'offline-%'",
            "AND project NOT LIKE 'off-%'",
            "AND project NOT LIKE 'pause-%'",
            "AND project NOT LIKE 'rest-%'",
            "AND project NOT LIKE 'coffee-%'",
            "AND project NOT LIKE 'tea-%'",
            "AND project NOT LIKE 'smoke-%'",
            "AND project NOT LIKE 'bathroom-%'",
            "AND project NOT LIKE 'toilet-%'",
            "AND project NOT LIKE 'wc-%'"
        ];
    }

    /**
     * Format seconds into human readable time
     */
    public function formatTime($seconds)
    {
        if ($seconds < 60) {
            return round($seconds) . 's';
        } elseif ($seconds < 3600) {
            return round($seconds / 60) . 'm';
        } else {
            $hours = floor($seconds / 3600);
            $minutes = floor(($seconds % 3600) / 60);
            return $hours . 'h ' . $minutes . 'm';
        }
    }

    /**
     * Get demo team members data
     */
    private function getDemoTeamMembers()
    {
        return [
            (object)[
                'id' => 1,
                'first_name' => 'John',
                'last_name' => 'Doe',
                'email' => 'john.doe@example.com',
                'job_title' => 'Software Developer',
                'status' => 'active',
                'employee_image' => '',
                'attendance_status' => 'online',
                'last_checkin' => time() * 1000,
                'attendance_date' => date('Y-m-d')
            ],
            (object)[
                'id' => 2,
                'first_name' => 'Jane',
                'last_name' => 'Smith',
                'email' => 'jane.smith@example.com',
                'job_title' => 'Project Manager',
                'status' => 'active',
                'employee_image' => '',
                'attendance_status' => 'offline',
                'last_checkin' => null,
                'attendance_date' => null
            ]
        ];
    }

    /**
     * Get demo screenshots data
     */
    private function getDemoScreenshots($limit = 4)
    {
        $screenshots = [];
        for ($i = 1; $i <= $limit; $i++) {
            $screenshots[] = (object)[
                'id' => $i,
                'user_id' => 1,
                'project_id' => null,
                'path' => 'plugins/Tracebit/assets/demo/screenshot-placeholder.svg',
                'title' => 'Demo Screenshot ' . $i,
                'created_at' => date('Y-m-d H:i:s', time() - ($i * 3600))
            ];
        }
        return $screenshots;
    }
} 
