<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["away"] = "Μακριά";
$lang["weekend"] = "Σαββατοκύριακο";
$lang["half_leave"] = "Μισή άδεια";
$lang["workedTime"] = "Χρόνος εργασίας";
$lang["available"] = "Διαθέσιμος";
$lang["active"] = "Ενεργός";
$lang["in_active"] = "Ανενεργός";
$lang["not_available"] = "Μη διαθέσιμος";
$lang["on_leave"] = "Σε άδεια";
$lang["idleTime"] = "Χρόνος αδράνειας";
$lang["outTime"] = "Χρόνος εξόδου";
$lang["activities"] = "Δραστηριότητες";
$lang["screen_shoots"] = "Στιγμιότυπο δραστηριότητας";
$lang["gd"] = "Ομαδική εργασία";
$lang["overtime"] = "Υπερωρίες";
$lang["due_time"] = "Απαιτούμενος χρόνος";
$lang["worked"] = "Χρόνος εργασίας";
$lang["hrs"] = "ώρες";
$lang["est"] = "Εκτιμώμενες ώρες";
$lang["employee_status"] = "Κατάσταση εργαζομένου";
$lang["activity_log"] = "Καταγραφή δραστηριοτήτων";
$lang["inTime"] = "Χρόνος εισόδου";
$lang["inAt"] = "Καρτέλα εισόδου";
$lang["present"] = "Παρών";
$lang["activity"] = "Δραστηριότητα";
$lang["absent"] = "Απών";
$lang["last_out"] = "Καρτέλα εξόδου";
$lang["online"] = "Συνδεδεμένος";
$lang["offline"] = "Αποσυνδεδεμένος";
$lang["tracker"] = "Παρακολουθητής";
$lang["tracebit"] = "Tracebit";
$lang["attendance_title"] = "Χρονοδιάγραμμα";
$lang["screenshot_title"] = "Στιγμιότυπο";
$lang["demo_hello_world"] = "Γεια σου κόσμε!";
$lang["storage_management"] = "Διαχείριση αποθήκευσης";
$lang["settings"] = "Ρυθμίσεις";

// Activity Log related language keys
$lang["activity_type"] = "Τύπος δραστηριότητας";
$lang["description"] = "Περιγραφή";
$lang["ip_address"] = "Διεύθυνση IP";
$lang["status"] = "Κατάσταση";
$lang["date_range"] = "Εύρος ημερομηνιών";
$lang["search_activities"] = "Αναζήτηση δραστηριοτήτων...";
$lang["user"] = "Χρήστης";
$lang["date"] = "Ημερομηνία";
$lang["time"] = "Ώρα";
$lang["login"] = "Σύνδεση";
$lang["logout"] = "Αποσύνδεση";
$lang["task_create"] = "Εργασία δημιουργήθηκε";
$lang["task_update"] = "Εργασία ενημερώθηκε";
$lang["file_upload"] = "Ανέβασμα αρχείου";
$lang["message_send"] = "Μήνυμα αποστάλθηκε";
$lang["report_generate"] = "Αναφορά δημιουργήθηκε";
$lang["settings_change"] = "Ρυθμίσεις άλλαξαν";
$lang["profile_update"] = "Προφίλ ενημερώθηκε";
$lang["password_change"] = "Κωδικός άλλαξε";
$lang["data_export"] = "Εξαγωγή δεδομένων";
$lang["search_perform"] = "Αναζήτηση εκτελέστηκε";
$lang["select_team_member"] = "Επιλέξτε μέλος ομάδας";
$lang["all_team_members"] = "Όλα τα μέλη ομάδας";

// Additional keys for Activity Log format
$lang["search"] = "Αναζήτηση";
$lang["work_days"] = "Εργάσιμες μέρες";
$lang["late"] = "Αργά";
$lang["est_hours"] = "Εκτιμώμενες ώρες";
$lang["worked_hours"] = "Ώρες εργασίας";
$lang["due_hours"] = "Απαιτούμενες ώρες";
$lang["group_discussion"] = "Ομαδική συζήτηση";

// Timesheet format keys
$lang["day"] = "Ημέρα";
$lang["clock_in"] = "Καρτέλα εισόδου";
$lang["clock_out"] = "Καρτέλα εξόδου";
$lang["hours"] = "Ώρες";
$lang["sessions"] = "Συνεδρίες";
$lang["manual_time"] = "Χειροκίνητος χρόνος";

// Dashboard specific keys
$lang["team_activity"] = "Δραστηριότητα ομάδας";
$lang["real_time_status"] = "Κατάσταση σε πραγματικό χρόνο";
$lang["currently_working"] = "Εργάζεται τώρα";
$lang["on_leave"] = "Σε άδεια";
$lang["not_checked_in"] = "Δεν έχει κάνει καρτέλα";
$lang["inactive"] = "Ανενεργός";
$lang["attendance_recap"] = "Σύνοψη παρουσίας";
$lang["current_month"] = "Τρέχων μήνας";
$lang["workable_days"] = "Εργάσιμες μέρες";
$lang["present_days"] = "Μέρες παρουσίας";
$lang["absent_days"] = "Μέρες απουσίας";
$lang["late_arrivals"] = "Αργές αφίξεις";
$lang["leave_days"] = "Μέρες άδειας";
$lang["project_recap"] = "Σύνοψη έργων";
$lang["weekly"] = "Εβδομαδιαία";
$lang["monthly"] = "Μηνιαία";
$lang["no_project_activity"] = "Δεν υπάρχει δραστηριότητα έργου";
$lang["more_projects"] = "περισσότερα έργα";
$lang["project_leader"] = "Ηγέτης έργου";
$lang["all_snapshots"] = "Όλα τα στιγμιότυπα";
$lang["snapshot_at"] = "Στιγμιότυπο στις";

// Attendance specific keys
$lang["total_employees"] = "Συνολικοί εργαζόμενοι";
$lang["active_now"] = "Ενεργός τώρα";
$lang["on_break_idle"] = "Σε διάλειμμα/Αδρανής";
$lang["offline"] = "Αποσυνδεδεμένος";
$lang["avg_productivity"] = "Μέση παραγωγικότητα";
$lang["last_updated"] = "Τελευταία ενημέρωση";

return $lang;
