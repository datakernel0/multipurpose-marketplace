<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["away"] = "Ausente";
$lang["weekend"] = "Fim de semana";
$lang["half_leave"] = "Meia folga";
$lang["workedTime"] = "Tempo trabalhado";
$lang["available"] = "Disponível";
$lang["active"] = "Ativo";
$lang["in_active"] = "Inativo";
$lang["not_available"] = "Não disponível";
$lang["on_leave"] = "Em férias";
$lang["idleTime"] = "Tempo ocioso";
$lang["outTime"] = "Hora de saída";
$lang["activities"] = "Atividades";
$lang["screen_shoots"] = "Captura de tela de atividade";
$lang["gd"] = "Trabalho em grupo";
$lang["overtime"] = "Horas extras";
$lang["due_time"] = "Tempo devido";
$lang["worked"] = "Tempo trabalhado";
$lang["hrs"] = "h";
$lang["est"] = "Horas estimadas";
$lang["employee_status"] = "Status do funcionário";
$lang["activity_log"] = "Registro de atividades";
$lang["inTime"] = "Hora de entrada";
$lang["inAt"] = "Ponto de entrada";
$lang["present"] = "Presente";
$lang["activity"] = "Atividade";
$lang["absent"] = "Ausente";
$lang["last_out"] = "Ponto de saída";
$lang["online"] = "Online";
$lang["offline"] = "Offline";
$lang["tracker"] = "Rastreador";
$lang["tracebit"] = "Tracebit";
$lang["attendance_title"] = "Cartão de ponto";
$lang["screenshot_title"] = "Captura de tela";
$lang["demo_hello_world"] = "Olá mundo!";
$lang["storage_management"] = "Gerenciamento de armazenamento";
$lang["settings"] = "Configurações";

// Activity Log related language keys
$lang["activity_type"] = "Tipo de atividade";
$lang["description"] = "Descrição";
$lang["ip_address"] = "Endereço IP";
$lang["status"] = "Status";
$lang["date_range"] = "Intervalo de datas";
$lang["search_activities"] = "Pesquisar atividades...";
$lang["user"] = "Usuário";
$lang["date"] = "Data";
$lang["time"] = "Hora";
$lang["login"] = "Login";
$lang["logout"] = "Logout";
$lang["task_create"] = "Tarefa criada";
$lang["task_update"] = "Tarefa atualizada";
$lang["file_upload"] = "Upload de arquivo";
$lang["message_send"] = "Mensagem enviada";
$lang["report_generate"] = "Relatório gerado";
$lang["settings_change"] = "Configurações alteradas";
$lang["profile_update"] = "Perfil atualizado";
$lang["password_change"] = "Senha alterada";
$lang["data_export"] = "Exportação de dados";
$lang["search_perform"] = "Pesquisa realizada";
$lang["select_team_member"] = "Selecionar membro da equipe";
$lang["all_team_members"] = "Todos os membros da equipe";

// Additional keys for Activity Log format
$lang["search"] = "Pesquisar";
$lang["work_days"] = "Dias úteis";
$lang["late"] = "Atrasado";
$lang["est_hours"] = "Horas estimadas";
$lang["worked_hours"] = "Horas trabalhadas";
$lang["due_hours"] = "Horas devidas";
$lang["group_discussion"] = "Discussão em grupo";

// Timesheet format keys
$lang["day"] = "Dia";
$lang["clock_in"] = "Ponto de entrada";
$lang["clock_out"] = "Ponto de saída";
$lang["hours"] = "Horas";
$lang["sessions"] = "Sessões";
$lang["manual_time"] = "Tempo manual";

// Dashboard specific keys
$lang["team_activity"] = "Atividade da equipe";
$lang["real_time_status"] = "Status em tempo real";
$lang["currently_working"] = "Trabalhando agora";
$lang["on_leave"] = "Em férias";
$lang["not_checked_in"] = "Não registrou entrada";
$lang["inactive"] = "Inativo";
$lang["attendance_recap"] = "Resumo de presença";
$lang["current_month"] = "Mês atual";
$lang["workable_days"] = "Dias úteis";
$lang["present_days"] = "Dias de presença";
$lang["absent_days"] = "Dias de ausência";
$lang["late_arrivals"] = "Chegadas atrasadas";
$lang["leave_days"] = "Dias de férias";
$lang["project_recap"] = "Resumo de projetos";
$lang["weekly"] = "Semanal";
$lang["monthly"] = "Mensal";
$lang["no_project_activity"] = "Nenhuma atividade de projeto";
$lang["more_projects"] = "mais projetos";
$lang["project_leader"] = "Líder do projeto";
$lang["all_snapshots"] = "Todas as capturas de tela";
$lang["snapshot_at"] = "Captura de tela às";

// Attendance specific keys
$lang["total_employees"] = "Total de funcionários";
$lang["active_now"] = "Ativo agora";
$lang["on_break_idle"] = "Em pausa/Ocioso";
$lang["offline"] = "Offline";
$lang["avg_productivity"] = "Produtividade média";
$lang["last_updated"] = "Última atualização";

return $lang;
