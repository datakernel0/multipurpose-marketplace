<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["away"] = "Nieobecny";
$lang["weekend"] = "Weekend";
$lang["half_leave"] = "Pół dnia urlopu";
$lang["workedTime"] = "Przepracowany czas";
$lang["available"] = "Dostępny";
$lang["active"] = "Aktywny";
$lang["in_active"] = "Nieaktywny";
$lang["not_available"] = "Niedostępny";
$lang["on_leave"] = "Na urlopie";
$lang["idleTime"] = "Czas bezczynności";
$lang["outTime"] = "Czas wyjścia";
$lang["activities"] = "Aktywności";
$lang["screen_shoots"] = "Zrzut ekranu aktywności";
$lang["gd"] = "Praca grupowa";
$lang["overtime"] = "Nadgodziny";
$lang["due_time"] = "Wymagany czas";
$lang["worked"] = "Przepracowany czas";
$lang["hrs"] = "godz";
$lang["est"] = "Szacowane godziny";
$lang["employee_status"] = "Status pracownika";
$lang["activity_log"] = "Dziennik aktywności";
$lang["inTime"] = "Czas wejścia";
$lang["inAt"] = "Wejście";
$lang["present"] = "Obecny";
$lang["activity"] = "Aktywność";
$lang["absent"] = "Nieobecny";
$lang["last_out"] = "Wyjście";
$lang["online"] = "Online";
$lang["offline"] = "Offline";
$lang["tracker"] = "Ślednik";
$lang["tracebit"] = "Tracebit";
$lang["attendance_title"] = "Karta czasu pracy";
$lang["screenshot_title"] = "Zrzut ekranu";
$lang["demo_hello_world"] = "Witaj świecie!";
$lang["storage_management"] = "Zarządzanie magazynem";
$lang["settings"] = "Ustawienia";

// Activity Log related language keys
$lang["activity_type"] = "Typ aktywności";
$lang["description"] = "Opis";
$lang["ip_address"] = "Adres IP";
$lang["status"] = "Status";
$lang["date_range"] = "Zakres dat";
$lang["search_activities"] = "Szukaj aktywności...";
$lang["user"] = "Użytkownik";
$lang["date"] = "Data";
$lang["time"] = "Czas";
$lang["login"] = "Logowanie";
$lang["logout"] = "Wylogowanie";
$lang["task_create"] = "Zadanie utworzone";
$lang["task_update"] = "Zadanie zaktualizowane";
$lang["file_upload"] = "Przesłanie pliku";
$lang["message_send"] = "Wiadomość wysłana";
$lang["report_generate"] = "Raport wygenerowany";
$lang["settings_change"] = "Ustawienia zmienione";
$lang["profile_update"] = "Profil zaktualizowany";
$lang["password_change"] = "Hasło zmienione";
$lang["data_export"] = "Eksport danych";
$lang["search_perform"] = "Wyszukiwanie wykonane";
$lang["select_team_member"] = "Wybierz członka zespołu";
$lang["all_team_members"] = "Wszyscy członkowie zespołu";

// Additional keys for Activity Log format
$lang["search"] = "Szukaj";
$lang["work_days"] = "Dni robocze";
$lang["late"] = "Późno";
$lang["est_hours"] = "Szacowane godziny";
$lang["worked_hours"] = "Przepracowane godziny";
$lang["due_hours"] = "Wymagane godziny";
$lang["group_discussion"] = "Dyskusja grupowa";

// Timesheet format keys
$lang["day"] = "Dzień";
$lang["clock_in"] = "Wejście";
$lang["clock_out"] = "Wyjście";
$lang["hours"] = "Godziny";
$lang["sessions"] = "Sesje";
$lang["manual_time"] = "Czas ręczny";

// Dashboard specific keys
$lang["team_activity"] = "Aktywność zespołu";
$lang["real_time_status"] = "Status w czasie rzeczywistym";
$lang["currently_working"] = "Obecnie pracuje";
$lang["on_leave"] = "Na urlopie";
$lang["not_checked_in"] = "Nie zalogowany";
$lang["inactive"] = "Nieaktywny";
$lang["attendance_recap"] = "Podsumowanie obecności";
$lang["current_month"] = "Bieżący miesiąc";
$lang["workable_days"] = "Dni robocze";
$lang["present_days"] = "Dni obecności";
$lang["absent_days"] = "Dni nieobecności";
$lang["late_arrivals"] = "Późne przybycia";
$lang["leave_days"] = "Dni urlopu";
$lang["project_recap"] = "Podsumowanie projektów";
$lang["weekly"] = "Tygodniowo";
$lang["monthly"] = "Miesięcznie";
$lang["no_project_activity"] = "Brak aktywności projektu";
$lang["more_projects"] = "więcej projektów";
$lang["project_leader"] = "Lider projektu";
$lang["all_snapshots"] = "Wszystkie zrzuty ekranu";
$lang["snapshot_at"] = "Zrzut ekranu o";

// Attendance specific keys
$lang["total_employees"] = "Łącznie pracowników";
$lang["active_now"] = "Aktywny teraz";
$lang["on_break_idle"] = "Na przerwie/Bezczynny";
$lang["offline"] = "Offline";
$lang["avg_productivity"] = "Średnia produktywność";
$lang["last_updated"] = "Ostatnia aktualizacja";

return $lang;
