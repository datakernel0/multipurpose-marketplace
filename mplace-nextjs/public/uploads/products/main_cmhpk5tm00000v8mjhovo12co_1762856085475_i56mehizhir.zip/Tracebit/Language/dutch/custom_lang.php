<?php //copy from default_lang.php file and update

$lang["demo_example"] = "Voorbeeld";

return $lang;
