<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["away"] = "Weg";
$lang["weekend"] = "Weekend";
$lang["half_leave"] = "Halve dag verlof";
$lang["workedTime"] = "Gewerkte tijd";
$lang["available"] = "Beschikbaar";
$lang["active"] = "Actief";
$lang["in_active"] = "Inactief";
$lang["not_available"] = "Niet beschikbaar";
$lang["on_leave"] = "Met verlof";
$lang["idleTime"] = "Inactieve tijd";
$lang["outTime"] = "Uitkloktijd";
$lang["activities"] = "Activiteiten";
$lang["screen_shoots"] = "Screenshot activiteit";
$lang["gd"] = "Groepswerk";
$lang["overtime"] = "Overuren";
$lang["due_time"] = "Vereiste tijd";
$lang["worked"] = "Gewerkte tijd";
$lang["hrs"] = "uur";
$lang["est"] = "Geschatte uren";
$lang["employee_status"] = "Medewerker status";
$lang["activity_log"] = "Activiteitenlogboek";
$lang["inTime"] = "Inkloktijd";
$lang["inAt"] = "Inklokken";
$lang["present"] = "Tilstede";
$lang["activity"] = "Activiteit";
$lang["absent"] = "Fraværende";
$lang["last_out"] = "Uitklokken";
$lang["online"] = "Online";
$lang["offline"] = "Offline";
$lang["tracker"] = "Sporer";
$lang["tracebit"] = "Tracebit";
$lang["attendance_title"] = "Tidsrapport";
$lang["screenshot_title"] = "Screenshot";
$lang["demo_hello_world"] = "Hallo wereld!";
$lang["storage_management"] = "Lagringsadministrasjon";
$lang["settings"] = "Innstillinger";

// Activity Log related language keys
$lang["activity_type"] = "Aktivitetstype";
$lang["description"] = "Beskrivelse";
$lang["ip_address"] = "IP-adresse";
$lang["status"] = "Status";
$lang["date_range"] = "Datoområde";
$lang["search_activities"] = "Søk etter aktiviteter...";
$lang["user"] = "Bruker";
$lang["date"] = "Dato";
$lang["time"] = "Tid";
$lang["login"] = "Innlogging";
$lang["logout"] = "Utlogging";
$lang["task_create"] = "Oppgave opprettet";
$lang["task_update"] = "Oppgave oppdatert";
$lang["file_upload"] = "Filopplasting";
$lang["message_send"] = "Melding sendt";
$lang["report_generate"] = "Rapport generert";
$lang["settings_change"] = "Innstillinger endret";
$lang["profile_update"] = "Profil oppdatert";
$lang["password_change"] = "Passord endret";
$lang["data_export"] = "Dataeksport";
$lang["search_perform"] = "Søk utført";
$lang["select_team_member"] = "Velg teammedlem";
$lang["all_team_members"] = "Alle teammedlemmer";

// Additional keys for Activity Log format
$lang["search"] = "Søk";
$lang["work_days"] = "Arbeidsdager";
$lang["late"] = "Sen";
$lang["est_hours"] = "Geschatte uren";
$lang["worked_hours"] = "Arbeidede uren";
$lang["due_hours"] = "Påkrevde uren";
$lang["group_discussion"] = "Gruppediskusjon";

// Timesheet format keys
$lang["day"] = "Dag";
$lang["clock_in"] = "Innstempling";
$lang["clock_out"] = "Utstempling";
$lang["hours"] = "Timer";
$lang["sessions"] = "Økter";
$lang["manual_time"] = "Manuell tid";

// Dashboard specific keys
$lang["team_activity"] = "Team aktivitet";
$lang["real_time_status"] = "Sanntids status";
$lang["currently_working"] = "Arbeider nå";
$lang["on_leave"] = "På permisjon";
$lang["not_checked_in"] = "Ikke innstemplet";
$lang["inactive"] = "Inaktiv";
$lang["attendance_recap"] = "Nærværs oversikt";
$lang["current_month"] = "Gjeldende måned";
$lang["workable_days"] = "Arbeidsdager";
$lang["present_days"] = "Nærværsdager";
$lang["absent_days"] = "Fraværsdager";
$lang["late_arrivals"] = "Sene ankomster";
$lang["leave_days"] = "Permisjonsdager";
$lang["project_recap"] = "Prosjekt oversikt";
$lang["weekly"] = "Ukentlig";
$lang["monthly"] = "Månedlig";
$lang["no_project_activity"] = "Ingen prosjektaktivitet";
$lang["more_projects"] = "flere prosjekter";
$lang["project_leader"] = "Prosjektleder";
$lang["all_snapshots"] = "Alle screenshots";
$lang["snapshot_at"] = "Screenshot kl";

// Attendance specific keys
$lang["total_employees"] = "Totalt ansatte";
$lang["active_now"] = "Aktiv nå";
$lang["on_break_idle"] = "På pause/Inaktiv";
$lang["offline"] = "Offline";
$lang["avg_productivity"] = "Gjennomsnittlig produktivitet";
$lang["last_updated"] = "Sist oppdatert";

// Dashboard Overview Cards
$lang["dashboard"] = "Dashboard";
$lang["total_time_tracked"] = "Total tid sporet";
$lang["productivity"] = "Produktivitet";
$lang["project_time"] = "Prosjekttid";
$lang["idle_times"] = "Inaktive tider";
$lang["manual_time"] = "Manuell tid";
$lang["away_time"] = "Borte tid";
$lang["recent_snapshots"] = "Nylige screenshots";
$lang["database_setup_required"] = "Databaseoppsett påkrevd";
$lang["run_tracker_schema"] = "Vennligst kjør tracker database-skjemaet for å aktivere innstemplingsfunksjonalitet.";
$lang["saving"] = "Lagrer...";
$lang["save_app_settings"] = "Lagre app-innstillinger";
$lang["save_interface_settings"] = "Lagre grensesnitt-innstillinger";

// Settings Tabs
$lang["app_settings"] = "App-innstillinger";
$lang["web_settings"] = "Web-innstillinger";
$lang["break_settings"] = "Pause-innstillinger";
$lang["weekend_settings"] = "Helge-innstillinger";
$lang["holidays_settings"] = "Ferie-innstillinger";
$lang["desktop_app_interface_settings"] = "Skrivebordsapp og grensesnitt-innstillinger";

// App Settings
$lang["application_settings"] = "Applikasjonsinnstillinger";
$lang["idle_timeout"] = "Inaktiv timeout (sekunder)";
$lang["idle_detection_timeout_seconds"] = "Inaktiv deteksjon timeout i sekunder";
$lang["auto_update_time"] = "Auto-oppdateringstid (sekunder)";
$lang["work_day_start_time"] = "Arbeidsdag starttid";
$lang["work_day_end_time"] = "Arbeidsdag sluttid";
$lang["feature_toggles"] = "Funksjonsbrytere";
$lang["enable_screenshot_capture"] = "Aktiver screenshot-opptak";
$lang["enable_screenshot_on_break"] = "Aktiver screenshot på pause";
$lang["enable_activity_tracking"] = "Aktiver aktivitetssporing";
$lang["enable_idle_detection"] = "Aktiver inaktiv deteksjon";
$lang["enable_productivity_tracking"] = "Aktiver produktivitets-sporing";
$lang["screenshot_performance_settings"] = "Screenshot og ytelsesinnstillinger";
$lang["screenshot_interval"] = "Screenshot-intervall (sekunder)";
$lang["screenshot_capture_interval_seconds"] = "Screenshot-opptaksintervall i sekunder";
$lang["screenshot_quality"] = "Screenshot-kvalitet (1-100)";
$lang["screenshot_width_size"] = "Screenshot bredde-størrelse";
$lang["screenshot_height"] = "Screenshot høyde";
$lang["max_screenshot_size"] = "Maks screenshot-størrelse (bytes)";
$lang["maximum_screenshot_size_default_5mb"] = "Maksimal screenshot-størrelse (standard: 5MB)";
$lang["performance_monitoring"] = "Ytelse og overvåking";
$lang["performance_threshold"] = "Ytelses terskel (%)";

// Web Settings
$lang["display_settings"] = "Visningsinnstillinger";
$lang["dashboard_checkin_on_off"] = "Dashboard innstempling ON-OFF";

// Break Settings
$lang["break_list"] = "Pauseliste";
$lang["refresh"] = "Oppdater";
$lang["add_break"] = "Legg til pause";
$lang["break_name"] = "Pausenavn";
$lang["value"] = "Verdi";
$lang["icon"] = "Ikon";
$lang["is_minus_break"] = "Er minus pause";
$lang["max_time"] = "Maks tid";
$lang["actions"] = "Handlinger";

// Timesheet specific keys
$lang["timesheet"] = "Tidsrapport";
$lang["current_period"] = "Gjeldende periode";
$lang["workable_days"] = "Arbeidsdager";
$lang["present_days"] = "Nærværsdager";
$lang["absent_days"] = "Fraværsdager";
$lang["weekend_days"] = "Helgedager";
$lang["leave_holiday"] = "Permisjon/Ferie";
$lang["worked_hours"] = "Arbeidede timer";
$lang["estimate_hours"] = "Estimerte timer";
$lang["overtime"] = "Overurer";
$lang["due_hours"] = "Påkrevde timer";
$lang["select_user"] = "Velg bruker";
$lang["all_users"] = "Alle brukere";
$lang["select_month"] = "Velg måned";
$lang["apply_filter"] = "Bruk filter";
$lang["reset"] = "Tilbakestill";

// Status messages
$lang["settings_saved_successfully"] = "Innstillinger lagret vellykket!";
$lang["failed_to_save_settings"] = "Kunne ikke lagre innstillinger";
$lang["an_error_occurred_while_saving"] = "En feil oppstod under lagring av innstillinger";
$lang["web_settings_saved_successfully"] = "Web-innstillinger lagret vellykket!";
$lang["failed_to_save_web_settings"] = "Kunne ikke lagre web-innstillinger";
$lang["an_error_occurred_while_saving_web_settings"] = "En feil oppstod under lagring av web-innstillinger";
$lang["app_settings_saved_successfully"] = "App-innstillinger lagret vellykket!";
$lang["failed_to_save_app_settings"] = "Kunne ikke lagre app-innstillinger";
$lang["an_error_occurred_while_saving_app_settings"] = "En feil oppstod under lagring av app-innstillinger";

// Confirmation messages
$lang["initialize_defaults_confirmation"] = "Dette vil initialisere alle standardinnstillinger. Er du sikker?";
$lang["an_error_occurred_while_initializing"] = "En feil oppstod under initialisering av innstillinger";

// Debug information
$lang["debug_current_colors"] = "Debug - Gjeldende farger";
$lang["present"] = "Tilstede";
$lang["late"] = "Sen";
$lang["absent"] = "Fraværende";
$lang["leave"] = "Permisjon";

return $lang;
