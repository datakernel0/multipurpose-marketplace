<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["away"] = "Abwesend";
$lang["weekend"] = "Wochenende";
$lang["half_leave"] = "Halber Urlaub";
$lang["workedTime"] = "Gearbeitete Zeit";
$lang["available"] = "Verfügbar";
$lang["active"] = "Aktiv";
$lang["in_active"] = "Inaktiv";
$lang["not_available"] = "Nicht verfügbar";
$lang["on_leave"] = "Im Urlaub";
$lang["idleTime"] = "Leerlaufzeit";
$lang["outTime"] = "Ausstempelzeit";
$lang["activities"] = "Aktivitäten";
$lang["screen_shoots"] = "Bildschirmfoto-Aktivität";
$lang["gd"] = "Gruppenarbeit";
$lang["overtime"] = "Überstunden";
$lang["due_time"] = "Fällige Zeit";
$lang["worked"] = "Gearbeitete Zeit";
$lang["hrs"] = "Std";
$lang["est"] = "Geschätzte Stunden";
$lang["employee_status"] = "Mitarbeiterstatus";
$lang["activity_log"] = "Aktivitätsprotokoll";
$lang["inTime"] = "Einstempelzeit";
$lang["inAt"] = "Einstempeln";
$lang["present"] = "Anwesend";
$lang["activity"] = "Aktivität";
$lang["absent"] = "Abwesend";
$lang["last_out"] = "Ausstempeln";
$lang["online"] = "Online";
$lang["offline"] = "Offline";
$lang["tracker"] = "Tracker";
$lang["tracebit"] = "Tracebit";
$lang["attendance_title"] = "Zeiterfassung";
$lang["screenshot_title"] = "Bildschirmfoto";
$lang["demo_hello_world"] = "Hallo Welt!";
$lang["storage_management"] = "Speicherverwaltung";
$lang["settings"] = "Einstellungen";

// Activity Log related language keys
$lang["activity_type"] = "Aktivitätstyp";
$lang["description"] = "Beschreibung";
$lang["ip_address"] = "IP-Adresse";
$lang["status"] = "Status";
$lang["date_range"] = "Datumsbereich";
$lang["search_activities"] = "Aktivitäten suchen...";
$lang["user"] = "Benutzer";
$lang["date"] = "Datum";
$lang["time"] = "Zeit";
$lang["login"] = "Anmeldung";
$lang["logout"] = "Abmeldung";
$lang["task_create"] = "Aufgabe erstellt";
$lang["task_update"] = "Aufgabe aktualisiert";
$lang["file_upload"] = "Datei-Upload";
$lang["message_send"] = "Nachricht gesendet";
$lang["report_generate"] = "Bericht generiert";
$lang["settings_change"] = "Einstellungen geändert";
$lang["profile_update"] = "Profil aktualisiert";
$lang["password_change"] = "Passwort geändert";
$lang["data_export"] = "Datenexport";
$lang["search_perform"] = "Suche durchgeführt";
$lang["select_team_member"] = "Teammitglied auswählen";
$lang["all_team_members"] = "Alle Teammitglieder";

// Additional keys for Activity Log format
$lang["search"] = "Suchen";
$lang["work_days"] = "Arbeitstage";
$lang["late"] = "Spät";
$lang["est_hours"] = "Geschätzte Stunden";
$lang["worked_hours"] = "Gearbeitete Stunden";
$lang["due_hours"] = "Fällige Stunden";
$lang["group_discussion"] = "Gruppendiskussion";

// Timesheet format keys
$lang["day"] = "Tag";
$lang["clock_in"] = "Einstempeln";
$lang["clock_out"] = "Ausstempeln";
$lang["hours"] = "Stunden";
$lang["sessions"] = "Sitzungen";
$lang["manual_time"] = "Manuelle Zeit";

// Dashboard specific keys
$lang["team_activity"] = "Team-Aktivität";
$lang["real_time_status"] = "Echtzeit-Status";
$lang["currently_working"] = "Arbeitet derzeit";
$lang["on_leave"] = "Im Urlaub";
$lang["not_checked_in"] = "Nicht eingestempelt";
$lang["inactive"] = "Inaktiv";
$lang["attendance_recap"] = "Anwesenheitsübersicht";
$lang["current_month"] = "Aktueller Monat";
$lang["workable_days"] = "Arbeitstage";
$lang["present_days"] = "Anwesenheitstage";
$lang["absent_days"] = "Abwesenheitstage";
$lang["late_arrivals"] = "Verspätete Ankünfte";
$lang["leave_days"] = "Urlaubstage";
$lang["project_recap"] = "Projektübersicht";
$lang["weekly"] = "Wöchentlich";
$lang["monthly"] = "Monatlich";
$lang["no_project_activity"] = "Keine Projektaktivität";
$lang["more_projects"] = "weitere Projekte";
$lang["project_leader"] = "Projektleiter";
$lang["all_snapshots"] = "Alle Bildschirmfotos";
$lang["snapshot_at"] = "Bildschirmfoto um";

// Attendance specific keys
$lang["total_employees"] = "Gesamtmitarbeiter";
$lang["active_now"] = "Jetzt aktiv";
$lang["on_break_idle"] = "In Pause/Leerlauf";
$lang["offline"] = "Offline";
$lang["avg_productivity"] = "Durchschnittliche Produktivität";
$lang["last_updated"] = "Zuletzt aktualisiert";

return $lang;
