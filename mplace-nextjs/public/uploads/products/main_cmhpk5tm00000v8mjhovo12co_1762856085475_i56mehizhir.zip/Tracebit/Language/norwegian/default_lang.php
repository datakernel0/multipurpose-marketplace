<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["away"] = "Borte";
$lang["weekend"] = "Helg";
$lang["half_leave"] = "Halv permisjon";
$lang["workedTime"] = "Arbeidet tid";
$lang["available"] = "Tilgjengelig";
$lang["active"] = "Aktiv";
$lang["in_active"] = "Inaktiv";
$lang["not_available"] = "Ikke tilgjengelig";
$lang["on_leave"] = "På permisjon";
$lang["idleTime"] = "Inaktiv tid";
$lang["outTime"] = "Utstemplingstid";
$lang["activities"] = "Aktiviteter";
$lang["screen_shoots"] = "Skjermbilde aktivitet";
$lang["gd"] = "Gruppearbeid";
$lang["overtime"] = "Overtid";
$lang["due_time"] = "Påkrevd tid";
$lang["worked"] = "Arbeidet tid";
$lang["hrs"] = "timer";
$lang["est"] = "Estimerte timer";
$lang["employee_status"] = "Ansatt status";
$lang["activity_log"] = "Aktivitetslogg";
$lang["inTime"] = "Innstemplingstid";
$lang["inAt"] = "Innstempling";
$lang["present"] = "Tilstede";
$lang["activity"] = "Aktivitet";
$lang["absent"] = "Fraværende";
$lang["last_out"] = "Utstempling";
$lang["online"] = "Online";
$lang["offline"] = "Offline";
$lang["tracker"] = "Sporer";
$lang["tracebit"] = "Tracebit";
$lang["attendance_title"] = "Tidsrapport";
$lang["screenshot_title"] = "Skjermbilde";
$lang["demo_hello_world"] = "Hallo verden!";
$lang["storage_management"] = "Lagringsadministrasjon";
$lang["settings"] = "Innstillinger";

// Activity Log related language keys
$lang["activity_type"] = "Aktivitetstype";
$lang["description"] = "Beskrivelse";
$lang["ip_address"] = "IP-adresse";
$lang["status"] = "Status";
$lang["date_range"] = "Datoområde";
$lang["search_activities"] = "Søk etter aktiviteter...";
$lang["user"] = "Bruker";
$lang["date"] = "Dato";
$lang["time"] = "Tid";
$lang["login"] = "Innlogging";
$lang["logout"] = "Utlogging";
$lang["task_create"] = "Oppgave opprettet";
$lang["task_update"] = "Oppgave oppdatert";
$lang["file_upload"] = "Filopplasting";
$lang["message_send"] = "Melding sendt";
$lang["report_generate"] = "Rapport generert";
$lang["settings_change"] = "Innstillinger endret";
$lang["profile_update"] = "Profil oppdatert";
$lang["password_change"] = "Passord endret";
$lang["data_export"] = "Dataeksport";
$lang["search_perform"] = "Søk utført";
$lang["select_team_member"] = "Velg teammedlem";
$lang["all_team_members"] = "Alle teammedlemmer";

// Additional keys for Activity Log format
$lang["search"] = "Søk";
$lang["work_days"] = "Arbeidsdager";
$lang["late"] = "Sen";
$lang["est_hours"] = "Estimerte timer";
$lang["worked_hours"] = "Arbeidede timer";
$lang["due_hours"] = "Påkrevde timer";
$lang["group_discussion"] = "Gruppediskusjon";

// Timesheet format keys
$lang["day"] = "Dag";
$lang["clock_in"] = "Innstempling";
$lang["clock_out"] = "Utstempling";
$lang["hours"] = "Timer";
$lang["sessions"] = "Økter";
$lang["manual_time"] = "Manuell tid";

// Dashboard specific keys
$lang["team_activity"] = "Team aktivitet";
$lang["real_time_status"] = "Sanntids status";
$lang["currently_working"] = "Arbeider nå";
$lang["on_leave"] = "På permisjon";
$lang["not_checked_in"] = "Ikke innstemplet";
$lang["inactive"] = "Inaktiv";
$lang["attendance_recap"] = "Nærværs oversikt";
$lang["current_month"] = "Gjeldende måned";
$lang["workable_days"] = "Arbeidsdager";
$lang["present_days"] = "Nærværsdager";
$lang["absent_days"] = "Fraværsdager";
$lang["late_arrivals"] = "Sene ankomster";
$lang["leave_days"] = "Permisjonsdager";
$lang["project_recap"] = "Prosjekt oversikt";
$lang["weekly"] = "Ukentlig";
$lang["monthly"] = "Månedlig";
$lang["no_project_activity"] = "Ingen prosjektaktivitet";
$lang["more_projects"] = "flere prosjekter";
$lang["project_leader"] = "Prosjektleder";
$lang["all_snapshots"] = "Alle skjermbilder";
$lang["snapshot_at"] = "Skjermbilde kl";

// Attendance specific keys
$lang["total_employees"] = "Totalt ansatte";
$lang["active_now"] = "Aktiv nå";
$lang["on_break_idle"] = "På pause/Inaktiv";
$lang["offline"] = "Offline";
$lang["avg_productivity"] = "Gjennomsnittlig produktivitet";
$lang["last_updated"] = "Sist oppdatert";

return $lang;
