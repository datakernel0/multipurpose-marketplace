<?php //copy from default_lang.php file and update

$lang["demo_example"] = "Example";

// Activity Log related language keys
$lang["activity_type"] = "Activity Type";
$lang["description"] = "Description";
$lang["ip_address"] = "IP Address";
$lang["status"] = "Status";
$lang["date_range"] = "Date Range";
$lang["search_activities"] = "Search activities...";
$lang["user"] = "User";
$lang["date"] = "Date";
$lang["time"] = "Time";
$lang["login"] = "Login";
$lang["logout"] = "Logout";
$lang["task_create"] = "Task Created";
$lang["task_update"] = "Task Updated";
$lang["file_upload"] = "File Upload";
$lang["message_send"] = "Message Sent";
$lang["report_generate"] = "Report Generated";
$lang["settings_change"] = "Settings Changed";
$lang["profile_update"] = "Profile Updated";
$lang["password_change"] = "Password Changed";
$lang["data_export"] = "Data Export";
$lang["search_perform"] = "Search Performed";
$lang["select_team_member"] = "Select team member";
$lang["all_team_members"] = "All team members";

// Additional keys for Activity Log format
$lang["search"] = "Search";
$lang["work_days"] = "Work Days";
$lang["late"] = "Late";
$lang["est_hours"] = "Est.hours";
$lang["worked_hours"] = "Worked Hours";
$lang["due_hours"] = "Due Hours";
$lang["group_discussion"] = "Group Discussion";

// Timesheet format keys
$lang["day"] = "Day";
$lang["clock_in"] = "Clock In";
$lang["clock_out"] = "Clock Out";
$lang["hours"] = "Hours";
$lang["sessions"] = "Sessions";
$lang["manual_time"] = "Manual Time";

return $lang;