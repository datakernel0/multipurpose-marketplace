<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["away"] = "Away";
$lang["weekend"] = "Weekend";
$lang["half_leave"] = "Half leave";
$lang["workedTime"] = "Worked Time";
$lang["available"] = "Available";
$lang["active"] = "Active";
$lang["in_active"] = "Inactive";
$lang["not_available"] = "Not Available";
$lang["on_leave"] = "On Leave";
$lang["idleTime"] = "Idle Time";
$lang["outTime"] = "Out Time";
$lang["activities"] = "Activities";
$lang["screen_shoots"] = "Snapshot Activity";
$lang["gd"] = "Group Work";
$lang["overtime"] = "Overtime";
$lang["due_time"] = "Due Time";
$lang["worked"] = "Worked Time";
$lang["hrs"] = "hrs";
$lang["est"] = "Est.hours";
$lang["employee_status"] = "Employee Status";
$lang["activity_log"] = "Activity Log";
$lang["inTime"] = "In Time";
$lang["inAt"] = "Clock In";
$lang["present"] = "Present";
$lang["activity"] = "Activity";
$lang["absent"] = "Absent";
$lang["last_out"] = "Clock Out";
$lang["online"] = "Online";
$lang["offline"] = "Offline";
$lang["tracker"] = "Tracker";
$lang["tracebit"] = "Tracebit";
$lang["attendance_title"] = "Timesheet";
$lang["screenshot_title"] = "Snapshot";
$lang["demo_hello_world"] = "Hello World!";
$lang["storage_management"] = "Storage Management";
$lang["settings"] = "Settings";

// Activity Log related language keys
$lang["activity_type"] = "Activity Type";
$lang["description"] = "Description";
$lang["ip_address"] = "IP Address";
$lang["status"] = "Status";
$lang["date_range"] = "Date Range";
$lang["search_activities"] = "Search activities...";
$lang["user"] = "User";
$lang["date"] = "Date";
$lang["time"] = "Time";
$lang["login"] = "Login";
$lang["logout"] = "Logout";
$lang["task_create"] = "Task Created";
$lang["task_update"] = "Task Updated";
$lang["file_upload"] = "File Upload";
$lang["message_send"] = "Message Sent";
$lang["report_generate"] = "Report Generated";
$lang["settings_change"] = "Settings Changed";
$lang["profile_update"] = "Profile Updated";
$lang["password_change"] = "Password Changed";
$lang["data_export"] = "Data Export";
$lang["search_perform"] = "Search Performed";
$lang["select_team_member"] = "Select team member";
$lang["all_team_members"] = "All team members";

// Additional keys for Activity Log format
$lang["search"] = "Search";
$lang["work_days"] = "Work Days";
$lang["late"] = "Late";
$lang["est_hours"] = "Est.hours";
$lang["worked_hours"] = "Worked Hours";
$lang["due_hours"] = "Due Hours";
$lang["group_discussion"] = "Group Discussion";

// Timesheet format keys
$lang["day"] = "Day";
$lang["clock_in"] = "Clock In";
$lang["clock_out"] = "Clock Out";
$lang["hours"] = "Hours";
$lang["sessions"] = "Sessions";
$lang["manual_time"] = "Manual Time";

// Dashboard specific keys
$lang["team_activity"] = "Team Activity";
$lang["real_time_status"] = "Real-time status";
$lang["currently_working"] = "Currently working";
$lang["on_leave"] = "On leave";
$lang["not_checked_in"] = "Not checked in";
$lang["inactive"] = "Inactive";
$lang["attendance_recap"] = "Attendance Recap";
$lang["current_month"] = "Current Month";
$lang["workable_days"] = "Workable Days";
$lang["present_days"] = "Present Days";
$lang["absent_days"] = "Absent Days";
$lang["late_arrivals"] = "Late Arrivals";
$lang["leave_days"] = "Leave Days";
$lang["project_recap"] = "Project Recap";
$lang["weekly"] = "Weekly";
$lang["monthly"] = "Monthly";
$lang["no_project_activity"] = "No project activity";
$lang["more_projects"] = "more projects";
$lang["project_leader"] = "Leader";
$lang["all_snapshots"] = "All snapshots";
$lang["snapshot_at"] = "Snapshot at";

// Attendance specific keys
$lang["total_employees"] = "Total Employees";
$lang["active_now"] = "Active Now";
$lang["on_break_idle"] = "On Break/Idle";
$lang["offline"] = "Offline";
$lang["avg_productivity"] = "Avg Productivity";
$lang["last_updated"] = "Last updated";

// Dashboard Overview Cards
$lang["dashboard"] = "Dashboard";
$lang["total_time_tracked"] = "Total time tracked";
$lang["productivity"] = "Productivity";
$lang["project_time"] = "Project Time";
$lang["idle_times"] = "Idle Times";
$lang["manual_time"] = "Manual Time";
$lang["away_time"] = "Away Time";
$lang["recent_snapshots"] = "Recent snapshots";
$lang["database_setup_required"] = "Database Setup Required";
$lang["run_tracker_schema"] = "Please run the tracker database schema to enable check-in functionality.";
$lang["saving"] = "Saving...";
$lang["save_app_settings"] = "Save App Settings";
$lang["save_interface_settings"] = "Save Interface Settings";

// Settings Tabs
$lang["app_settings"] = "App Settings";
$lang["web_settings"] = "Web Settings";
$lang["break_settings"] = "Break Settings";
$lang["weekend_settings"] = "Weekend Settings";
$lang["holidays_settings"] = "Holiday Settings";
$lang["desktop_app_interface_settings"] = "Desktop App & Interface Settings";

// App Settings
$lang["application_settings"] = "Application Settings";
$lang["idle_timeout"] = "Idle Timeout (seconds)";
$lang["idle_detection_timeout_seconds"] = "Idle detection timeout in seconds";
$lang["auto_update_time"] = "Auto Update Time (seconds)";
$lang["work_day_start_time"] = "Work Day Start Time";
$lang["work_day_end_time"] = "Work Day End Time";
$lang["feature_toggles"] = "Feature Toggles";
$lang["enable_screenshot_capture"] = "Enable Screenshot Capture";
$lang["enable_screenshot_on_break"] = "Enable Screenshot on Break";
$lang["enable_activity_tracking"] = "Enable Activity Tracking";
$lang["enable_idle_detection"] = "Enable Idle Detection";
$lang["enable_productivity_tracking"] = "Enable Productivity Tracking";
$lang["screenshot_performance_settings"] = "Screenshot & Performance Settings";
$lang["screenshot_interval"] = "Screenshot Interval (seconds)";
$lang["screenshot_capture_interval_seconds"] = "Screenshot capture interval in seconds";
$lang["screenshot_quality"] = "Screenshot Quality (1-100)";
$lang["screenshot_width_size"] = "Screenshot width size";
$lang["screenshot_height"] = "Screenshot height";
$lang["max_screenshot_size"] = "Max Screenshot Size (bytes)";
$lang["maximum_screenshot_size_default_5mb"] = "Maximum screenshot size (default: 5MB)";
$lang["performance_monitoring"] = "Performance & Monitoring";
$lang["performance_threshold"] = "Performance Threshold (%)";

// Web Settings
$lang["display_settings"] = "Display Settings";
$lang["dashboard_checkin_on_off"] = "Dashboard CheckIn ON-Off";

// Break Settings
$lang["break_list"] = "Break List";
$lang["refresh"] = "Refresh";
$lang["add_break"] = "Add Break";
$lang["break_name"] = "Break Name";
$lang["value"] = "Value";
$lang["icon"] = "Icon";
$lang["is_minus_break"] = "Is Minus Break";
$lang["max_time"] = "Max Time";
$lang["actions"] = "Actions";

// Timesheet specific keys
$lang["timesheet"] = "Timesheet";
$lang["current_period"] = "Current Period";
$lang["workable_days"] = "Workable Days";
$lang["present_days"] = "Present Days";
$lang["absent_days"] = "Absent Days";
$lang["weekend_days"] = "Weekend Days";
$lang["leave_holiday"] = "Leave/Holiday";
$lang["worked_hours"] = "Worked Hours";
$lang["estimate_hours"] = "Estimate Hours";
$lang["overtime"] = "Overtime";
$lang["due_hours"] = "Due Hours";
$lang["select_user"] = "Select User";
$lang["all_users"] = "All Users";
$lang["select_month"] = "Select Month";
$lang["apply_filter"] = "Apply Filter";
$lang["reset"] = "Reset";

// Status messages
$lang["settings_saved_successfully"] = "Settings saved successfully!";
$lang["failed_to_save_settings"] = "Failed to save settings";
$lang["an_error_occurred_while_saving"] = "An error occurred while saving settings";
$lang["web_settings_saved_successfully"] = "Web settings saved successfully!";
$lang["failed_to_save_web_settings"] = "Failed to save web settings";
$lang["an_error_occurred_while_saving_web_settings"] = "An error occurred while saving web settings";
$lang["app_settings_saved_successfully"] = "App settings saved successfully!";
$lang["failed_to_save_app_settings"] = "Failed to save app settings";
$lang["an_error_occurred_while_saving_app_settings"] = "An error occurred while saving app settings";

// Confirmation messages
$lang["initialize_defaults_confirmation"] = "This will initialize all default settings. Are you sure?";
$lang["an_error_occurred_while_initializing"] = "An error occurred while initializing settings";

// Debug information
$lang["debug_current_colors"] = "Debug - Current Colors";
$lang["present"] = "Present";
$lang["late"] = "Late";
$lang["absent"] = "Absent";
$lang["leave"] = "Leave";

return $lang;
