# Tracebit Plugin Multi-Language Support

This directory contains language files for the Tracebit plugin, providing multi-language support for all user-facing text content.

## Supported Languages

The Tracebit plugin now supports the following languages:

1. **English** (en) - Default language
2. **Dutch** (nl) - Nederlandse
3. **Czech** (cs) - Čeština
4. **French** (fr) - Français
5. **German** (de) - Deutsch
6. **Greek** (el) - Ελληνικά
7. **Italian** (it) - Italiano
8. **Norwegian** (no) - Norsk
9. **Polish** (pl) - Polski
10. **Portuguese** (pt) - Português
11. **Russian** (ru) - Русский
12. **Spanish** (es) - Español

## Language File Structure

Each language has its own directory containing:

- `default_lang.php` - Default language definitions (DO NOT MODIFY)
- `custom_lang.php` - Custom language overrides (safe to modify)
- `index.html` - Security file to prevent directory listing

## Language Keys

The plugin includes comprehensive translations for:

### Core Functionality
- Employee status (active, inactive, absent, on leave, etc.)
- Time tracking (clock in/out, worked time, overtime, etc.)
- Activity logging (login, logout, task creation, etc.)

### Dashboard Elements
- Team activity status
- Attendance summaries
- Project recaps
- Productivity metrics

### User Interface
- Navigation labels
- Button text
- Form labels
- Status messages
- Error messages

## How to Use

### For Users

1. **Language Selection**: Users can select their preferred language through the main application's language settings
2. **Automatic Detection**: The plugin will automatically use the selected language
3. **Fallback**: If a translation is missing, the system falls back to English

### For Developers

#### Adding New Language Keys

1. **Add to English default**: First add the key to `english/default_lang.php`
2. **Translate to all languages**: Add translations to all language files
3. **Use in views**: Use `app_lang("key_name")` in your view files

#### Example Usage in Views

```php
<!-- Instead of hardcoded text -->
<h1>Employee Status</h1>

<!-- Use language function -->
<h1><?php echo app_lang("employee_status"); ?></h1>
```

#### Adding New Languages

1. Create a new language directory (e.g., `swedish/`)
2. Copy `english/default_lang.php` to `swedish/default_lang.php`
3. Translate all values to Swedish
4. Create `swedish/custom_lang.php` for customizations
5. Add `swedish/index.html` for security

## Language File Format

Each language file follows this structure:

```php
<?php
/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["key_name"] = "Translated Text";
$lang["another_key"] = "Another Translation";

return $lang;
```

## Customization

### Modifying Translations

**IMPORTANT**: Never modify `default_lang.php` files directly. Instead:

1. Copy the key from `default_lang.php` to `custom_lang.php`
2. Modify the value in `custom_lang.php`
3. The custom value will override the default

### Example Customization

```php
// In custom_lang.php
$lang["employee_status"] = "My Custom Translation";
```

## Best Practices

1. **Consistency**: Use consistent terminology across all languages
2. **Context**: Provide context for translators when keys are ambiguous
3. **Testing**: Test all languages after adding new keys
4. **Updates**: Keep all language files synchronized when adding new features
5. **Cultural Sensitivity**: Consider cultural differences in translations

## Troubleshooting

### Missing Translations

If you see English text instead of translated text:

1. Check if the language key exists in the language file
2. Verify the language is properly selected in the application
3. Clear any language caches
4. Check for syntax errors in language files

### Language Not Loading

1. Verify the language directory exists
2. Check file permissions
3. Ensure language files return the `$lang` array
4. Check for PHP syntax errors

## Contributing

When contributing translations:

1. Maintain the same structure as existing language files
2. Use appropriate cultural context for the target language
3. Test translations with native speakers when possible
4. Keep translations concise and clear
5. Follow the existing naming conventions for language keys

## Support

For issues with translations or adding new languages:

1. Check the main application's language system documentation
2. Review existing language files for examples
3. Test with a simple language key first
4. Ensure proper file encoding (UTF-8 recommended)

## File Encoding

All language files should be saved in **UTF-8** encoding to properly support special characters and diacritics used in various languages.

## Security Notes

- `index.html` files prevent directory listing
- Language files are PHP files that return arrays
- No executable code should be placed in language files
- Custom language files can be safely modified by users
