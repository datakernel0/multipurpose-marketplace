<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["away"] = "Assente";
$lang["weekend"] = "Fine settimana";
$lang["half_leave"] = "Mezza giornata";
$lang["workedTime"] = "Tempo lavorato";
$lang["available"] = "Disponibile";
$lang["active"] = "Attivo";
$lang["in_active"] = "Inattivo";
$lang["not_available"] = "Non disponibile";
$lang["on_leave"] = "In ferie";
$lang["idleTime"] = "Tempo di inattività";
$lang["outTime"] = "Ora di uscita";
$lang["activities"] = "Attività";
$lang["screen_shoots"] = "Screenshot attività";
$lang["gd"] = "Lavoro di gruppo";
$lang["overtime"] = "Straordinari";
$lang["due_time"] = "Tempo dovuto";
$lang["worked"] = "Tempo lavorato";
$lang["hrs"] = "ore";
$lang["est"] = "Ore stimate";
$lang["employee_status"] = "Stato dipendente";
$lang["activity_log"] = "Registro attività";
$lang["inTime"] = "Ora di entrata";
$lang["inAt"] = "Timbratura entrata";
$lang["present"] = "Presente";
$lang["activity"] = "Attività";
$lang["absent"] = "Assente";
$lang["last_out"] = "Timbratura uscita";
$lang["online"] = "Online";
$lang["offline"] = "Offline";
$lang["tracker"] = "Tracciatore";
$lang["tracebit"] = "Tracebit";
$lang["attendance_title"] = "Foglio presenze";
$lang["screenshot_title"] = "Screenshot";
$lang["demo_hello_world"] = "Ciao mondo!";
$lang["storage_management"] = "Gestione archiviazione";
$lang["settings"] = "Impostazioni";

// Activity Log related language keys
$lang["activity_type"] = "Tipo di attività";
$lang["description"] = "Descrizione";
$lang["ip_address"] = "Indirizzo IP";
$lang["status"] = "Stato";
$lang["date_range"] = "Intervallo date";
$lang["search_activities"] = "Cerca attività...";
$lang["user"] = "Utente";
$lang["date"] = "Data";
$lang["time"] = "Ora";
$lang["login"] = "Accesso";
$lang["logout"] = "Disconnessione";
$lang["task_create"] = "Attività creata";
$lang["task_update"] = "Attività aggiornata";
$lang["file_upload"] = "Caricamento file";
$lang["message_send"] = "Messaggio inviato";
$lang["report_generate"] = "Report generato";
$lang["settings_change"] = "Impostazioni modificate";
$lang["profile_update"] = "Profilo aggiornato";
$lang["password_change"] = "Password modificata";
$lang["data_export"] = "Esportazione dati";
$lang["search_perform"] = "Ricerca eseguita";
$lang["select_team_member"] = "Seleziona membro del team";
$lang["all_team_members"] = "Tutti i membri del team";

// Additional keys for Activity Log format
$lang["search"] = "Cerca";
$lang["work_days"] = "Giorni lavorativi";
$lang["late"] = "In ritardo";
$lang["est_hours"] = "Ore stimate";
$lang["worked_hours"] = "Ore lavorate";
$lang["due_hours"] = "Ore dovute";
$lang["group_discussion"] = "Discussione di gruppo";

// Timesheet format keys
$lang["day"] = "Giorno";
$lang["clock_in"] = "Timbratura entrata";
$lang["clock_out"] = "Timbratura uscita";
$lang["hours"] = "Ore";
$lang["sessions"] = "Sessioni";
$lang["manual_time"] = "Tempo manuale";

// Dashboard specific keys
$lang["team_activity"] = "Attività del team";
$lang["real_time_status"] = "Stato in tempo reale";
$lang["currently_working"] = "Sta lavorando ora";
$lang["on_leave"] = "In ferie";
$lang["not_checked_in"] = "Non timbrato";
$lang["inactive"] = "Inattivo";
$lang["attendance_recap"] = "Riepilogo presenze";
$lang["current_month"] = "Mese corrente";
$lang["workable_days"] = "Giorni lavorativi";
$lang["present_days"] = "Giorni di presenza";
$lang["absent_days"] = "Giorni di assenza";
$lang["late_arrivals"] = "Arrivi in ritardo";
$lang["leave_days"] = "Giorni di ferie";
$lang["project_recap"] = "Riepilogo progetti";
$lang["weekly"] = "Settimanale";
$lang["monthly"] = "Mensile";
$lang["no_project_activity"] = "Nessuna attività progetto";
$lang["more_projects"] = "altri progetti";
$lang["project_leader"] = "Capo progetto";
$lang["all_snapshots"] = "Tutti gli screenshot";
$lang["snapshot_at"] = "Screenshot alle";

// Attendance specific keys
$lang["total_employees"] = "Totale dipendenti";
$lang["active_now"] = "Attivo ora";
$lang["on_break_idle"] = "In pausa/Inattivo";
$lang["offline"] = "Offline";
$lang["avg_productivity"] = "Produttività media";
$lang["last_updated"] = "Ultimo aggiornamento";

return $lang;
