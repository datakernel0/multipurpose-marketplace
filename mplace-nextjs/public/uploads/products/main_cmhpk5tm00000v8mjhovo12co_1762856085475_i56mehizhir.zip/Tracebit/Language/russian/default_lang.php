<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["away"] = "Отсутствует";
$lang["weekend"] = "Выходные";
$lang["half_leave"] = "Половина дня";
$lang["workedTime"] = "Отработанное время";
$lang["available"] = "Доступен";
$lang["active"] = "Активен";
$lang["in_active"] = "Неактивен";
$lang["not_available"] = "Недоступен";
$lang["on_leave"] = "В отпуске";
$lang["idleTime"] = "Время простоя";
$lang["outTime"] = "Время выхода";
$lang["activities"] = "Активности";
$lang["screen_shoots"] = "Снимок экрана активности";
$lang["gd"] = "Групповая работа";
$lang["overtime"] = "Сверхурочные";
$lang["due_time"] = "Необходимое время";
$lang["worked"] = "Отработанное время";
$lang["hrs"] = "ч";
$lang["est"] = "Расчетные часы";
$lang["employee_status"] = "Статус сотрудника";
$lang["activity_log"] = "Журнал активности";
$lang["inTime"] = "Время входа";
$lang["inAt"] = "Вход";
$lang["present"] = "Присутствует";
$lang["activity"] = "Активность";
$lang["absent"] = "Отсутствует";
$lang["last_out"] = "Выход";
$lang["online"] = "Онлайн";
$lang["offline"] = "Офлайн";
$lang["tracker"] = "Трекер";
$lang["tracebit"] = "Tracebit";
$lang["attendance_title"] = "Табель учета времени";
$lang["screenshot_title"] = "Снимок экрана";
$lang["demo_hello_world"] = "Привет мир!";
$lang["storage_management"] = "Управление хранилищем";
$lang["settings"] = "Настройки";

// Activity Log related language keys
$lang["activity_type"] = "Тип активности";
$lang["description"] = "Описание";
$lang["ip_address"] = "IP адрес";
$lang["status"] = "Статус";
$lang["date_range"] = "Диапазон дат";
$lang["search_activities"] = "Поиск активностей...";
$lang["user"] = "Пользователь";
$lang["date"] = "Дата";
$lang["time"] = "Время";
$lang["login"] = "Вход";
$lang["logout"] = "Выход";
$lang["task_create"] = "Задача создана";
$lang["task_update"] = "Задача обновлена";
$lang["file_upload"] = "Загрузка файла";
$lang["message_send"] = "Сообщение отправлено";
$lang["report_generate"] = "Отчет сгенерирован";
$lang["settings_change"] = "Настройки изменены";
$lang["profile_update"] = "Профиль обновлен";
$lang["password_change"] = "Пароль изменен";
$lang["data_export"] = "Экспорт данных";
$lang["search_perform"] = "Поиск выполнен";
$lang["select_team_member"] = "Выберите участника команды";
$lang["all_team_members"] = "Все участники команды";

// Additional keys for Activity Log format
$lang["search"] = "Поиск";
$lang["work_days"] = "Рабочие дни";
$lang["late"] = "Опоздание";
$lang["est_hours"] = "Расчетные часы";
$lang["worked_hours"] = "Отработанные часы";
$lang["due_hours"] = "Необходимые часы";
$lang["group_discussion"] = "Групповое обсуждение";

// Timesheet format keys
$lang["day"] = "День";
$lang["clock_in"] = "Вход";
$lang["clock_out"] = "Выход";
$lang["hours"] = "Часы";
$lang["sessions"] = "Сессии";
$lang["manual_time"] = "Ручное время";

// Dashboard specific keys
$lang["team_activity"] = "Активность команды";
$lang["real_time_status"] = "Статус в реальном времени";
$lang["currently_working"] = "Сейчас работает";
$lang["on_leave"] = "В отпуске";
$lang["not_checked_in"] = "Не отметился";
$lang["inactive"] = "Неактивен";
$lang["attendance_recap"] = "Сводка посещаемости";
$lang["current_month"] = "Текущий месяц";
$lang["workable_days"] = "Рабочие дни";
$lang["present_days"] = "Дни присутствия";
$lang["absent_days"] = "Дни отсутствия";
$lang["late_arrivals"] = "Опоздания";
$lang["leave_days"] = "Дни отпуска";
$lang["project_recap"] = "Сводка проектов";
$lang["weekly"] = "Еженедельно";
$lang["monthly"] = "Ежемесячно";
$lang["no_project_activity"] = "Нет активности проекта";
$lang["more_projects"] = "больше проектов";
$lang["project_leader"] = "Руководитель проекта";
$lang["all_snapshots"] = "Все снимки экрана";
$lang["snapshot_at"] = "Снимок экрана в";

// Attendance specific keys
$lang["total_employees"] = "Всего сотрудников";
$lang["active_now"] = "Активен сейчас";
$lang["on_break_idle"] = "На перерыве/Простой";
$lang["offline"] = "Офлайн";
$lang["avg_productivity"] = "Средняя продуктивность";
$lang["last_updated"] = "Последнее обновление";

return $lang;
