<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["away"] = "Ausente";
$lang["weekend"] = "Fin de semana";
$lang["half_leave"] = "Media jornada";
$lang["workedTime"] = "Tiempo trabajado";
$lang["available"] = "Disponible";
$lang["active"] = "Activo";
$lang["in_active"] = "Inactivo";
$lang["not_available"] = "No disponible";
$lang["on_leave"] = "De vacaciones";
$lang["idleTime"] = "Tiempo inactivo";
$lang["outTime"] = "Hora de salida";
$lang["activities"] = "Actividades";
$lang["screen_shoots"] = "Captura de pantalla de actividad";
$lang["gd"] = "Trabajo en grupo";
$lang["overtime"] = "Horas extra";
$lang["due_time"] = "Tiempo debido";
$lang["worked"] = "Tiempo trabajado";
$lang["hrs"] = "h";
$lang["est"] = "Horas estimadas";
$lang["employee_status"] = "Estado del empleado";
$lang["activity_log"] = "Registro de actividades";
$lang["inTime"] = "Hora de entrada";
$lang["inAt"] = "Fichar entrada";
$lang["present"] = "Presente";
$lang["activity"] = "Actividad";
$lang["absent"] = "Ausente";
$lang["last_out"] = "Fichar salida";
$lang["online"] = "En línea";
$lang["offline"] = "Desconectado";
$lang["tracker"] = "Rastreador";
$lang["tracebit"] = "Tracebit";
$lang["attendance_title"] = "Hoja de tiempo";
$lang["screenshot_title"] = "Captura de pantalla";
$lang["demo_hello_world"] = "¡Hola mundo!";
$lang["storage_management"] = "Gestión de almacenamiento";
$lang["settings"] = "Configuración";

// Activity Log related language keys
$lang["activity_type"] = "Tipo de actividad";
$lang["description"] = "Descripción";
$lang["ip_address"] = "Dirección IP";
$lang["status"] = "Estado";
$lang["date_range"] = "Rango de fechas";
$lang["search_activities"] = "Buscar actividades...";
$lang["user"] = "Usuario";
$lang["date"] = "Fecha";
$lang["time"] = "Hora";
$lang["login"] = "Inicio de sesión";
$lang["logout"] = "Cerrar sesión";
$lang["task_create"] = "Tarea creada";
$lang["task_update"] = "Tarea actualizada";
$lang["file_upload"] = "Carga de archivo";
$lang["message_send"] = "Mensaje enviado";
$lang["report_generate"] = "Informe generado";
$lang["settings_change"] = "Configuración cambiada";
$lang["profile_update"] = "Perfil actualizado";
$lang["password_change"] = "Contraseña cambiada";
$lang["data_export"] = "Exportación de datos";
$lang["search_perform"] = "Búsqueda realizada";
$lang["select_team_member"] = "Seleccionar miembro del equipo";
$lang["all_team_members"] = "Todos los miembros del equipo";

// Additional keys for Activity Log format
$lang["search"] = "Buscar";
$lang["work_days"] = "Días laborables";
$lang["late"] = "Tarde";
$lang["est_hours"] = "Horas estimadas";
$lang["worked_hours"] = "Horas trabajadas";
$lang["due_hours"] = "Horas debidas";
$lang["group_discussion"] = "Discusión grupal";

// Timesheet format keys
$lang["day"] = "Día";
$lang["clock_in"] = "Fichar entrada";
$lang["clock_out"] = "Fichar salida";
$lang["hours"] = "Horas";
$lang["sessions"] = "Sesiones";
$lang["manual_time"] = "Tiempo manual";

// Dashboard specific keys
$lang["team_activity"] = "Actividad del equipo";
$lang["real_time_status"] = "Estado en tiempo real";
$lang["currently_working"] = "Trabajando ahora";
$lang["on_leave"] = "De vacaciones";
$lang["not_checked_in"] = "No ha fichado entrada";
$lang["inactive"] = "Inactivo";
$lang["attendance_recap"] = "Resumen de asistencia";
$lang["current_month"] = "Mes actual";
$lang["workable_days"] = "Días laborables";
$lang["present_days"] = "Días de asistencia";
$lang["absent_days"] = "Días de ausencia";
$lang["late_arrivals"] = "Llegadas tardías";
$lang["leave_days"] = "Días de vacaciones";
$lang["project_recap"] = "Resumen de proyectos";
$lang["weekly"] = "Semanal";
$lang["monthly"] = "Mensual";
$lang["no_project_activity"] = "Sin actividad de proyecto";
$lang["more_projects"] = "más proyectos";
$lang["project_leader"] = "Líder del proyecto";
$lang["all_snapshots"] = "Todas las capturas de pantalla";
$lang["snapshot_at"] = "Captura de pantalla a las";

// Attendance specific keys
$lang["total_employees"] = "Total de empleados";
$lang["active_now"] = "Activo ahora";
$lang["on_break_idle"] = "En pausa/Inactivo";
$lang["offline"] = "Desconectado";
$lang["avg_productivity"] = "Productividad promedio";
$lang["last_updated"] = "Última actualización";

return $lang;
