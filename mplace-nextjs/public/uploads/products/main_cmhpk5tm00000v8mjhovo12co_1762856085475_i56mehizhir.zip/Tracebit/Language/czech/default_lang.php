<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["away"] = "Pryč";
$lang["weekend"] = "Víkend";
$lang["half_leave"] = "Půldenní volno";
$lang["workedTime"] = "Odpracovaný čas";
$lang["available"] = "Dostupný";
$lang["active"] = "Aktivní";
$lang["in_active"] = "Neaktivní";
$lang["not_available"] = "Nedostupný";
$lang["on_leave"] = "Na dovolené";
$lang["idleTime"] = "Nečinný čas";
$lang["outTime"] = "Čas odchodu";
$lang["activities"] = "Aktivity";
$lang["screen_shoots"] = "Snímek aktivity";
$lang["gd"] = "Skupinová práce";
$lang["overtime"] = "Přesčasy";
$lang["due_time"] = "Povinný čas";
$lang["worked"] = "Odpracovaný čas";
$lang["hrs"] = "hod";
$lang["est"] = "Odhad hodin";
$lang["employee_status"] = "Status zaměstnance";
$lang["activity_log"] = "Záznam aktivit";
$lang["inTime"] = "Čas příchodu";
$lang["inAt"] = "Příchod";
$lang["present"] = "Přítomen";
$lang["activity"] = "Aktivita";
$lang["absent"] = "Nepřítomen";
$lang["last_out"] = "Odchod";
$lang["online"] = "Online";
$lang["offline"] = "Offline";
$lang["tracker"] = "Sledovač";
$lang["tracebit"] = "Tracebit";
$lang["attendance_title"] = "Výkaz práce";
$lang["screenshot_title"] = "Snímek";
$lang["demo_hello_world"] = "Ahoj světe!";
$lang["storage_management"] = "Správa úložiště";
$lang["settings"] = "Nastavení";

// Activity Log related language keys
$lang["activity_type"] = "Typ aktivity";
$lang["description"] = "Popis";
$lang["ip_address"] = "IP adresa";
$lang["status"] = "Status";
$lang["date_range"] = "Rozsah dat";
$lang["search_activities"] = "Hledat aktivity...";
$lang["user"] = "Uživatel";
$lang["date"] = "Datum";
$lang["time"] = "Čas";
$lang["login"] = "Přihlášení";
$lang["logout"] = "Odhlášení";
$lang["task_create"] = "Úkol vytvořen";
$lang["task_update"] = "Úkol aktualizován";
$lang["file_upload"] = "Nahrání souboru";
$lang["message_send"] = "Zpráva odeslána";
$lang["report_generate"] = "Report vygenerován";
$lang["settings_change"] = "Nastavení změněno";
$lang["profile_update"] = "Profil aktualizován";
$lang["password_change"] = "Heslo změněno";
$lang["data_export"] = "Export dat";
$lang["search_perform"] = "Vyhledávání provedeno";
$lang["select_team_member"] = "Vyberte člena týmu";
$lang["all_team_members"] = "Všichni členové týmu";

// Additional keys for Activity Log format
$lang["search"] = "Hledat";
$lang["work_days"] = "Pracovní dny";
$lang["late"] = "Pozdě";
$lang["est_hours"] = "Odhad hodin";
$lang["worked_hours"] = "Odpracované hodiny";
$lang["due_hours"] = "Povinné hodiny";
$lang["group_discussion"] = "Skupinová diskuse";

// Timesheet format keys
$lang["day"] = "Den";
$lang["clock_in"] = "Příchod";
$lang["clock_out"] = "Odchod";
$lang["hours"] = "Hodiny";
$lang["sessions"] = "Sezení";
$lang["manual_time"] = "Ruční čas";

// Dashboard specific keys
$lang["team_activity"] = "Aktivita týmu";
$lang["real_time_status"] = "Status v reálném čase";
$lang["currently_working"] = "Právě pracuje";
$lang["on_leave"] = "Na dovolené";
$lang["not_checked_in"] = "Nepřihlášen";
$lang["inactive"] = "Neaktivní";
$lang["attendance_recap"] = "Přehled docházky";
$lang["current_month"] = "Aktuální měsíc";
$lang["workable_days"] = "Pracovní dny";
$lang["present_days"] = "Přítomné dny";
$lang["absent_days"] = "Nepřítomné dny";
$lang["late_arrivals"] = "Pozdní příchody";
$lang["leave_days"] = "Dny dovolené";
$lang["project_recap"] = "Přehled projektů";
$lang["weekly"] = "Týdenní";
$lang["monthly"] = "Měsíční";
$lang["no_project_activity"] = "Žádná aktivita projektu";
$lang["more_projects"] = "více projektů";
$lang["project_leader"] = "Vedoucí";
$lang["all_snapshots"] = "Všechny snímky";
$lang["snapshot_at"] = "Snímek v";

// Attendance specific keys
$lang["total_employees"] = "Celkem zaměstnanců";
$lang["active_now"] = "Aktivní nyní";
$lang["on_break_idle"] = "Na přestávce/Nečinný";
$lang["offline"] = "Offline";
$lang["avg_productivity"] = "Průměrná produktivita";
$lang["last_updated"] = "Naposledy aktualizováno";

return $lang;
