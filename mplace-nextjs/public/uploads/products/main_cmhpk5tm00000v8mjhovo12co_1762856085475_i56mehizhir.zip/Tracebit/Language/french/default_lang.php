<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["away"] = "Absent";
$lang["weekend"] = "Week-end";
$lang["half_leave"] = "Demi-congé";
$lang["workedTime"] = "Temps travaillé";
$lang["available"] = "Disponible";
$lang["active"] = "Actif";
$lang["in_active"] = "Inactif";
$lang["not_available"] = "Non disponible";
$lang["on_leave"] = "En congé";
$lang["idleTime"] = "Temps d'inactivité";
$lang["outTime"] = "Heure de sortie";
$lang["activities"] = "Activités";
$lang["screen_shoots"] = "Capture d'écran d'activité";
$lang["gd"] = "Travail de groupe";
$lang["overtime"] = "Heures supplémentaires";
$lang["due_time"] = "Temps requis";
$lang["worked"] = "Temps travaillé";
$lang["hrs"] = "h";
$lang["est"] = "Heures estimées";
$lang["employee_status"] = "Statut de l'employé";
$lang["activity_log"] = "Journal d'activité";
$lang["inTime"] = "Heure d'entrée";
$lang["inAt"] = "Pointage d'entrée";
$lang["present"] = "Présent";
$lang["activity"] = "Activité";
$lang["absent"] = "Absent";
$lang["last_out"] = "Pointage de sortie";
$lang["online"] = "En ligne";
$lang["offline"] = "Hors ligne";
$lang["tracker"] = "Suiveur";
$lang["tracebit"] = "Tracebit";
$lang["attendance_title"] = "Feuille de temps";
$lang["screenshot_title"] = "Capture d'écran";
$lang["demo_hello_world"] = "Bonjour le monde !";
$lang["storage_management"] = "Gestion du stockage";
$lang["settings"] = "Paramètres";

// Activity Log related language keys
$lang["activity_type"] = "Type d'activité";
$lang["description"] = "Description";
$lang["ip_address"] = "Adresse IP";
$lang["status"] = "Statut";
$lang["date_range"] = "Plage de dates";
$lang["search_activities"] = "Rechercher des activités...";
$lang["user"] = "Utilisateur";
$lang["date"] = "Date";
$lang["time"] = "Heure";
$lang["login"] = "Connexion";
$lang["logout"] = "Déconnexion";
$lang["task_create"] = "Tâche créée";
$lang["task_update"] = "Tâche mise à jour";
$lang["file_upload"] = "Téléchargement de fichier";
$lang["message_send"] = "Message envoyé";
$lang["report_generate"] = "Rapport généré";
$lang["settings_change"] = "Paramètres modifiés";
$lang["profile_update"] = "Profil mis à jour";
$lang["password_change"] = "Mot de passe modifié";
$lang["data_export"] = "Export de données";
$lang["search_perform"] = "Recherche effectuée";
$lang["select_team_member"] = "Sélectionner un membre de l'équipe";
$lang["all_team_members"] = "Tous les membres de l'équipe";

// Additional keys for Activity Log format
$lang["search"] = "Rechercher";
$lang["work_days"] = "Jours de travail";
$lang["late"] = "En retard";
$lang["est_hours"] = "Heures estimées";
$lang["worked_hours"] = "Heures travaillées";
$lang["due_hours"] = "Heures requises";
$lang["group_discussion"] = "Discussion de groupe";

// Timesheet format keys
$lang["day"] = "Jour";
$lang["clock_in"] = "Pointage d'entrée";
$lang["clock_out"] = "Pointage de sortie";
$lang["hours"] = "Heures";
$lang["sessions"] = "Sessions";
$lang["manual_time"] = "Temps manuel";

// Dashboard specific keys
$lang["team_activity"] = "Activité de l'équipe";
$lang["real_time_status"] = "Statut en temps réel";
$lang["currently_working"] = "Travaille actuellement";
$lang["on_leave"] = "En congé";
$lang["not_checked_in"] = "Non pointé";
$lang["inactive"] = "Inactif";
$lang["attendance_recap"] = "Récapitulatif de présence";
$lang["current_month"] = "Mois en cours";
$lang["workable_days"] = "Jours de travail";
$lang["present_days"] = "Jours de présence";
$lang["absent_days"] = "Jours d'absence";
$lang["late_arrivals"] = "Arrivées en retard";
$lang["leave_days"] = "Jours de congé";
$lang["project_recap"] = "Récapitulatif des projets";
$lang["weekly"] = "Hebdomadaire";
$lang["monthly"] = "Mensuel";
$lang["no_project_activity"] = "Aucune activité de projet";
$lang["more_projects"] = "projets supplémentaires";
$lang["project_leader"] = "Chef de projet";
$lang["all_snapshots"] = "Toutes les captures d'écran";
$lang["snapshot_at"] = "Capture d'écran à";

// Attendance specific keys
$lang["total_employees"] = "Total des employés";
$lang["active_now"] = "Actif maintenant";
$lang["on_break_idle"] = "En pause/Inactif";
$lang["offline"] = "Hors ligne";
$lang["avg_productivity"] = "Productivité moyenne";
$lang["last_updated"] = "Dernière mise à jour";

return $lang;
