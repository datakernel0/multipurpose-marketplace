-- Tracker Plugin Optimized Database Schema
-- This file contains optimized database structure for the Tracker plugin with proper indexing

-- Enhanced tracker_screenshots table with better indexing
DROP TABLE IF EXISTS `tracker_screenshots_optimized`;
CREATE TABLE `tracker_screenshots_optimized` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `project_id` int(11) DEFAULT NULL,
  `path` varchar(500) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_user_project_date` (`user_id`, `project_id`, `created_at`),
  KEY `idx_user_date` (`user_id`, `created_at`),
  KEY `idx_project_date` (`project_id`, `created_at`),
  KEY `idx_deleted_created` (`deleted`, `created_at`),
  KEY `idx_path_hash` (`path`(100)) -- Index first 100 chars of path
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Enhanced tracker_attendance table with compound indexes
DROP TABLE IF EXISTS `tracker_attendance_optimized`;
CREATE TABLE `tracker_attendance_optimized` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `inTime` bigint(20) NOT NULL,
  `outTime` bigint(20) DEFAULT NULL,
  `note` varchar(255) DEFAULT '0',
  `timezone` int(11) DEFAULT 0,
  `sign` varchar(10) DEFAULT '+',
  `project` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_unique_attendance` (`user_id`, `inTime`, `project`),
  KEY `idx_user_intime` (`user_id`, `inTime`),
  KEY `idx_user_project_time` (`user_id`, `project`, `inTime`),
  KEY `idx_time_range` (`inTime`, `outTime`),
  KEY `idx_deleted_user_time` (`deleted`, `user_id`, `inTime`),
  KEY `idx_project_pattern` (`project`),
  KEY `idx_date_computed` ((DATE(FROM_UNIXTIME(inTime / 1000))))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Enhanced tracker_performance table with better indexing
DROP TABLE IF EXISTS `tracker_performance_optimized`;
CREATE TABLE `tracker_performance_optimized` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `project` varchar(255) NOT NULL,
  `performance` int(11) NOT NULL DEFAULT 0,
  `takenTime` datetime NOT NULL,
  `timestamp` bigint(20) DEFAULT NULL,
  `timezone` int(11) DEFAULT 0,
  `sign` varchar(10) DEFAULT '+',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_unique_performance` (`user_id`, `timestamp`),
  KEY `idx_user_project_time` (`user_id`, `project`, `takenTime`),
  KEY `idx_user_taken_time` (`user_id`, `takenTime`),
  KEY `idx_project_performance` (`project`, `performance`),
  KEY `idx_deleted_user_time` (`deleted`, `user_id`, `takenTime`),
  KEY `idx_date_computed` ((DATE(takenTime))),
  KEY `idx_performance_analysis` (`user_id`, `performance`, `takenTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Enhanced tracker_settings table (already well optimized)
CREATE TABLE IF NOT EXISTS `tracker_settings_optimized` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_name` varchar(100) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `type` varchar(50) DEFAULT 'app',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_setting_name` (`setting_name`, `deleted`),
  KEY `idx_type_deleted` (`type`, `deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Additional indexes for existing main tables (if they exist)
-- These should be added to the main CRM tables for better performance

-- For users table
ALTER TABLE `users`
ADD INDEX `idx_user_type_status` (`user_type`, `status`, `deleted`) IF NOT EXISTS,
ADD INDEX `idx_attendance_status` (`attendance_status`, `attendance_date`) IF NOT EXISTS;

-- For project_members table
ALTER TABLE `project_members`
ADD INDEX `idx_user_project_deleted` (`user_id`, `project_id`, `deleted`) IF NOT EXISTS;

-- For projects table
ALTER TABLE `projects`
ADD INDEX `idx_deleted_title` (`deleted`, `title`) IF NOT EXISTS;

-- Calendar table for date ranges (if not exists)
CREATE TABLE IF NOT EXISTS `Calendar` (
  `date` date NOT NULL,
  `day_of_week` tinyint(1) NOT NULL,
  `is_weekend` tinyint(1) NOT NULL DEFAULT 0,
  `is_holiday` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`date`),
  KEY `idx_date_range` (`date`, `is_weekend`),
  KEY `idx_workdays` (`is_weekend`, `is_holiday`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Pre-populate calendar for 5 years (2020-2025)
INSERT IGNORE INTO `Calendar` (`date`, `day_of_week`, `is_weekend`)
SELECT
  DATE_ADD('2020-01-01', INTERVAL seq.seq DAY) as date,
  DAYOFWEEK(DATE_ADD('2020-01-01', INTERVAL seq.seq DAY)) as day_of_week,
  CASE WHEN DAYOFWEEK(DATE_ADD('2020-01-01', INTERVAL seq.seq DAY)) IN (1,7) THEN 1 ELSE 0 END as is_weekend
FROM (
  SELECT a.i + b.i * 100 + c.i * 10000 as seq
  FROM (SELECT 0 i UNION SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 UNION SELECT 5 UNION SELECT 6 UNION SELECT 7 UNION SELECT 8 UNION SELECT 9) a
  CROSS JOIN (SELECT 0 i UNION SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 UNION SELECT 5 UNION SELECT 6 UNION SELECT 7 UNION SELECT 8 UNION SELECT 9) b
  CROSS JOIN (SELECT 0 i UNION SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 UNION SELECT 5 UNION SELECT 6 UNION SELECT 7 UNION SELECT 8 UNION SELECT 9) c
) seq
WHERE DATE_ADD('2020-01-01', INTERVAL seq.seq DAY) <= '2025-12-31';

-- Insert default optimized settings
INSERT IGNORE INTO `tracker_settings_optimized` (`setting_name`, `setting_value`, `type`) VALUES
('screenshot_interval', '300', 'app'),
('working_hours_start', '09:00', 'app'),
('working_hours_end', '17:00', 'app'),
('timezone_offset', '0', 'app'),
('enable_screenshots', '1', 'app'),
('enable_activity_tracking', '1', 'app'),
('query_cache_enabled', '1', 'system'),
('max_query_cache_time', '3600', 'system'),
('performance_threshold', '50', 'app');
