-- Tracker Plugin Database Schema
-- This file contains the database structure for the Tracker plugin

-- Table structure for tracker_screenshots
CREATE TABLE IF NOT EXISTS `tracker_screenshots` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `project_id` int(11) DEFAULT NULL,
  `path` varchar(500) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `project_id` (`project_id`),
  KEY `created_at` (`created_at`),
  KEY `deleted` (`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table structure for tracker_attendance
CREATE TABLE IF NOT EXISTS `tracker_attendance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `inTime` bigint(20) NOT NULL,
  `outTime` bigint(20) DEFAULT NULL,
  `note` varchar(255) DEFAULT '0',
  `status` VARCHAR(20) DEFAULT 'present' COMMENT 'Attendance status: present, absent, late, on_time, manual, etc.',
  `late` TINYINT(1) DEFAULT 0 COMMENT '1 if employee was late, 0 if on time',
  `timezone` int(11) DEFAULT 0,
  `sign` varchar(10) DEFAULT '+',
  `project` VARCHAR(50) DEFAULT NULL COMMENT 'Project identifier for tracking purposes',
  `isMinusBreak` TINYINT(1) DEFAULT 0 COMMENT 'Flag for break calculation',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `inTime` (`inTime`),
  KEY `deleted` (`deleted`),
  KEY `idx_status` (`status`),
  KEY `idx_late` (`late`),
  KEY `idx_project` (`project`),
  KEY `idx_user_status` (`user_id`, `status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table structure for tracker_performance
CREATE TABLE IF NOT EXISTS `tracker_performance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `project` varchar(255) NOT NULL,
  `performance` int(11) NOT NULL DEFAULT 0,
  `takenTime` datetime NOT NULL,
  `timezone` int(11) DEFAULT 0,
  `sign` varchar(10) DEFAULT '+',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `project` (`project`),
  KEY `takenTime` (`takenTime`),
  KEY `deleted` (`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table structure for tracker_settings
CREATE TABLE IF NOT EXISTS `tracker_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_name` varchar(100) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `type` varchar(50) DEFAULT 'app',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_setting_name` (`setting_name`, `deleted`),
  KEY `idx_type_deleted` (`type`, `deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert default settings
INSERT INTO `tracker_settings` (`setting_name`, `setting_value`, `type`) VALUES
('screenshot_interval', '300', 'app'),
('working_hours_start', '09:00', 'app'),
('working_hours_end', '17:00', 'app'),
('timezone_offset', '0', 'app'),
('enable_screenshots', '1', 'app'),
('enable_activity_tracking', '1', 'app'),
('enable_idle_detection', '1', 'app'),
('productivity_tracking', '1', 'app'),
('screenshot_quality', '80', 'app'),
('idle_timeout', '600', 'app'),
('enable_screenshot_notifications', '1', 'app'),
('query_cache_enabled', '1', 'system'),
('max_query_cache_time', '3600', 'system'),
('performance_threshold', '50', 'app'),
('max_screenshot_size', '5242880', 'app'),
('dashboard_checkin_active', '1', 'app')
ON DUPLICATE KEY UPDATE
`setting_value` = VALUES(`setting_value`),
`type` = VALUES(`type`),
`updated_at` = CURRENT_TIMESTAMP;
