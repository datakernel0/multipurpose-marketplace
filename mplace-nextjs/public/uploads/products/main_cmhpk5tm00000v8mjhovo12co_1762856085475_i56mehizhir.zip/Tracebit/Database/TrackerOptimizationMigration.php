<?php

namespace Tracker\Database\Migrations;

use CodeIgniter\Database\Migration;

/**
 * Database Optimization Migration for Tracker Plugin
 * Adds proper indexes, optimizes existing tables, and creates optimized structure
 */
class TrackerOptimizationMigration extends Migration {

    public function up() {
        $forge = \Config\Database::forge();

        // Add indexes to existing tracker_screenshots table
        $this->add_screenshots_indexes();

        // Add indexes to existing tracker_attendance table
        $this->add_attendance_indexes();

        // Add indexes to existing tracker_performance table
        $this->add_performance_indexes();

        // Add indexes to tracker_settings table
        $this->add_settings_indexes();

        // Create Calendar table if it doesn't exist
        $this->create_calendar_table();

        // Add indexes to main CRM tables for better join performance
        $this->add_main_table_indexes();

        // Add performance monitoring table
        $this->create_performance_monitoring_table();

        echo "Tracker database optimization completed successfully.\n";
    }

    public function down() {
        // Remove added indexes (keep this simple for now)
        echo "Tracker optimization rollback - manual index removal required.\n";
    }

    private function add_screenshots_indexes() {
        try {
            $sql_commands = [
                "ALTER TABLE `tracker_screenshots` ADD INDEX `idx_user_project_date` (`user_id`, `project_id`, `created_at`)",
                "ALTER TABLE `tracker_screenshots` ADD INDEX `idx_user_date` (`user_id`, `created_at`)",
                "ALTER TABLE `tracker_screenshots` ADD INDEX `idx_project_date` (`project_id`, `created_at`)",
                "ALTER TABLE `tracker_screenshots` ADD INDEX `idx_deleted_created` (`deleted`, `created_at`)",
                "ALTER TABLE `tracker_screenshots` ADD INDEX `idx_path_hash` (`path`(100))"
            ];

            foreach ($sql_commands as $sql) {
                try {
                    $this->db->query($sql);
                    echo "✓ Added screenshots index\n";
                } catch (\Exception $e) {
                    if (strpos($e->getMessage(), 'Duplicate key name') === false) {
                        echo "⚠ Screenshots index error: " . $e->getMessage() . "\n";
                    }
                }
            }
        } catch (\Exception $e) {
            echo "Error adding screenshots indexes: " . $e->getMessage() . "\n";
        }
    }

    private function add_attendance_indexes() {
        try {
            // Add project column if it doesn't exist
            $fields = $this->db->getFieldNames('tracker_attendance');
            if (!in_array('project', $fields)) {
                $this->db->query("ALTER TABLE `tracker_attendance` ADD COLUMN `project` VARCHAR(255) DEFAULT NULL AFTER `note`");
                echo "✓ Added project column to attendance table\n";
            }

            $sql_commands = [
                "ALTER TABLE `tracker_attendance` ADD UNIQUE INDEX `idx_unique_attendance` (`user_id`, `inTime`, `project`)",
                "ALTER TABLE `tracker_attendance` ADD INDEX `idx_user_intime` (`user_id`, `inTime`)",
                "ALTER TABLE `tracker_attendance` ADD INDEX `idx_user_project_time` (`user_id`, `project`, `inTime`)",
                "ALTER TABLE `tracker_attendance` ADD INDEX `idx_time_range` (`inTime`, `outTime`)",
                "ALTER TABLE `tracker_attendance` ADD INDEX `idx_deleted_user_time` (`deleted`, `user_id`, `inTime`)",
                "ALTER TABLE `tracker_attendance` ADD INDEX `idx_project_pattern` (`project`)",
                "ALTER TABLE `tracker_attendance` ADD INDEX `idx_date_computed` ((DATE(FROM_UNIXTIME(inTime / 1000))))"
            ];

            foreach ($sql_commands as $sql) {
                try {
                    $this->db->query($sql);
                    echo "✓ Added attendance index\n";
                } catch (\Exception $e) {
                    if (strpos($e->getMessage(), 'Duplicate key name') === false &&
                        strpos($e->getMessage(), 'Duplicate entry') === false) {
                        echo "⚠ Attendance index error: " . $e->getMessage() . "\n";
                    }
                }
            }
        } catch (\Exception $e) {
            echo "Error adding attendance indexes: " . $e->getMessage() . "\n";
        }
    }

    private function add_performance_indexes() {
        try {
            // Add timestamp column if it doesn't exist
            $fields = $this->db->getFieldNames('tracker_performance');
            if (!in_array('timestamp', $fields)) {
                $this->db->query("ALTER TABLE `tracker_performance` ADD COLUMN `timestamp` BIGINT(20) DEFAULT NULL AFTER `performance`");
                echo "✓ Added timestamp column to performance table\n";
            }

            $sql_commands = [
                "ALTER TABLE `tracker_performance` ADD UNIQUE INDEX `idx_unique_performance` (`user_id`, `timestamp`)",
                "ALTER TABLE `tracker_performance` ADD INDEX `idx_user_project_time` (`user_id`, `project`, `takenTime`)",
                "ALTER TABLE `tracker_performance` ADD INDEX `idx_user_taken_time` (`user_id`, `takenTime`)",
                "ALTER TABLE `tracker_performance` ADD INDEX `idx_project_performance` (`project`, `performance`)",
                "ALTER TABLE `tracker_performance` ADD INDEX `idx_deleted_user_time` (`deleted`, `user_id`, `takenTime`)",
                "ALTER TABLE `tracker_performance` ADD INDEX `idx_date_computed` ((DATE(takenTime)))",
                "ALTER TABLE `tracker_performance` ADD INDEX `idx_performance_analysis` (`user_id`, `performance`, `takenTime`)"
            ];

            foreach ($sql_commands as $sql) {
                try {
                    $this->db->query($sql);
                    echo "✓ Added performance index\n";
                } catch (\Exception $e) {
                    if (strpos($e->getMessage(), 'Duplicate key name') === false &&
                        strpos($e->getMessage(), 'Duplicate entry') === false) {
                        echo "⚠ Performance index error: " . $e->getMessage() . "\n";
                    }
                }
            }
        } catch (\Exception $e) {
            echo "Error adding performance indexes: " . $e->getMessage() . "\n";
        }
    }

    private function add_settings_indexes() {
        try {
            // Add type column if it doesn't exist
            $fields = $this->db->getFieldNames('tracker_settings');
            if (!in_array('type', $fields)) {
                $this->db->query("ALTER TABLE `tracker_settings` ADD COLUMN `type` VARCHAR(50) DEFAULT 'app' AFTER `setting_value`");
                echo "✓ Added type column to settings table\n";
            }

            $sql_commands = [
                "ALTER TABLE `tracker_settings` DROP INDEX `setting_name`",
                "ALTER TABLE `tracker_settings` ADD UNIQUE INDEX `idx_setting_name` (`setting_name`, `deleted`)",
                "ALTER TABLE `tracker_settings` ADD INDEX `idx_type_deleted` (`type`, `deleted`)"
            ];

            foreach ($sql_commands as $sql) {
                try {
                    $this->db->query($sql);
                    echo "✓ Added settings index\n";
                } catch (\Exception $e) {
                    if (strpos($e->getMessage(), 'Duplicate key name') === false &&
                        strpos($e->getMessage(), "Can't DROP") === false) {
                        echo "⚠ Settings index error: " . $e->getMessage() . "\n";
                    }
                }
            }
        } catch (\Exception $e) {
            echo "Error adding settings indexes: " . $e->getMessage() . "\n";
        }
    }

    private function create_calendar_table() {
        try {
            if (!$this->db->tableExists('Calendar')) {
                $forge = \Config\Database::forge();

                $forge->addField([
                    'date' => [
                        'type' => 'DATE',
                        'null' => false
                    ],
                    'day_of_week' => [
                        'type' => 'TINYINT',
                        'constraint' => 1,
                        'null' => false
                    ],
                    'is_weekend' => [
                        'type' => 'TINYINT',
                        'constraint' => 1,
                        'default' => 0,
                        'null' => false
                    ],
                    'is_holiday' => [
                        'type' => 'TINYINT',
                        'constraint' => 1,
                        'default' => 0,
                        'null' => false
                    ]
                ]);

                $forge->addPrimaryKey('date');
                $forge->addKey(['date', 'is_weekend'], false, false, 'idx_date_range');
                $forge->addKey(['is_weekend', 'is_holiday'], false, false, 'idx_workdays');

                $forge->createTable('Calendar', true);

                // Populate calendar
                $this->populate_calendar();

                echo "✓ Created Calendar table\n";
            }
        } catch (\Exception $e) {
            echo "Error creating Calendar table: " . $e->getMessage() . "\n";
        }
    }

    private function populate_calendar() {
        try {
            // Populate calendar for 5 years (2020-2025)
            $sql = "
                INSERT IGNORE INTO `Calendar` (`date`, `day_of_week`, `is_weekend`)
                SELECT
                  DATE_ADD('2020-01-01', INTERVAL seq.seq DAY) as date,
                  DAYOFWEEK(DATE_ADD('2020-01-01', INTERVAL seq.seq DAY)) as day_of_week,
                  CASE WHEN DAYOFWEEK(DATE_ADD('2020-01-01', INTERVAL seq.seq DAY)) IN (1,7) THEN 1 ELSE 0 END as is_weekend
                FROM (
                  SELECT a.i + b.i * 100 + c.i * 10000 as seq
                  FROM (SELECT 0 i UNION SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 UNION SELECT 5 UNION SELECT 6 UNION SELECT 7 UNION SELECT 8 UNION SELECT 9) a
                  CROSS JOIN (SELECT 0 i UNION SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 UNION SELECT 5 UNION SELECT 6 UNION SELECT 7 UNION SELECT 8 UNION SELECT 9) b
                  CROSS JOIN (SELECT 0 i UNION SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 UNION SELECT 5 UNION SELECT 6 UNION SELECT 7 UNION SELECT 8 UNION SELECT 9) c
                ) seq
                WHERE DATE_ADD('2020-01-01', INTERVAL seq.seq DAY) <= '2025-12-31'
            ";

            $this->db->query($sql);
            echo "✓ Populated Calendar table\n";
        } catch (\Exception $e) {
            echo "Error populating Calendar table: " . $e->getMessage() . "\n";
        }
    }

    private function add_main_table_indexes() {
        try {
            $sql_commands = [
                "ALTER TABLE `users` ADD INDEX `idx_user_type_status` (`user_type`, `status`, `deleted`)",
                "ALTER TABLE `users` ADD INDEX `idx_attendance_status` (`attendance_status`, `attendance_date`)",
                "ALTER TABLE `project_members` ADD INDEX `idx_user_project_deleted` (`user_id`, `project_id`, `deleted`)",
                "ALTER TABLE `projects` ADD INDEX `idx_deleted_title` (`deleted`, `title`)"
            ];

            foreach ($sql_commands as $sql) {
                try {
                    $this->db->query($sql);
                    echo "✓ Added main table index\n";
                } catch (\Exception $e) {
                    if (strpos($e->getMessage(), 'Duplicate key name') === false) {
                        echo "⚠ Main table index error: " . $e->getMessage() . "\n";
                    }
                }
            }
        } catch (\Exception $e) {
            echo "Error adding main table indexes: " . $e->getMessage() . "\n";
        }
    }

    private function create_performance_monitoring_table() {
        try {
            if (!$this->db->tableExists('tracker_query_performance')) {
                $forge = \Config\Database::forge();

                $forge->addField([
                    'id' => [
                        'type' => 'INT',
                        'constraint' => 11,
                        'unsigned' => true,
                        'auto_increment' => true
                    ],
                    'query_name' => [
                        'type' => 'VARCHAR',
                        'constraint' => 100,
                        'null' => false
                    ],
                    'execution_time' => [
                        'type' => 'DECIMAL',
                        'constraint' => '10,4',
                        'null' => false
                    ],
                    'memory_usage' => [
                        'type' => 'INT',
                        'constraint' => 11,
                        'null' => true
                    ],
                    'user_id' => [
                        'type' => 'INT',
                        'constraint' => 11,
                        'null' => true
                    ],
                    'created_at' => [
                        'type' => 'TIMESTAMP',
                        'default' => 'CURRENT_TIMESTAMP',
                        'null' => false
                    ]
                ]);

                $forge->addPrimaryKey('id');
                $forge->addKey(['query_name', 'execution_time'], false, false, 'idx_query_performance');
                $forge->addKey(['created_at'], false, false, 'idx_created_at');

                $forge->createTable('tracker_query_performance', true);

                echo "✓ Created query performance monitoring table\n";
            }
        } catch (\Exception $e) {
            echo "Error creating performance monitoring table: " . $e->getMessage() . "\n";
        }
    }
}
