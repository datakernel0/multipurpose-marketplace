-- Complete setup script for tracker attendance functionality
-- Run this script to set up the required database tables and settings

-- Create tracker_attendance table
CREATE TABLE IF NOT EXISTS `tracker_attendance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `inTime` bigint(20) NOT NULL,
  `outTime` bigint(20) DEFAULT NULL,
  `note` varchar(255) DEFAULT '0',
  `timezone` int(11) DEFAULT 0,
  `sign` varchar(10) DEFAULT '+',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `inTime` (`inTime`),
  KEY `deleted` (`deleted`),
  KEY `idx_user_checkin` (`user_id`, `outTime`, `deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create tracker_settings table
CREATE TABLE IF NOT EXISTS `tracker_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_name` varchar(100) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `type` varchar(50) DEFAULT 'app',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_setting_name` (`setting_name`, `deleted`),
  KEY `idx_type_deleted` (`type`, `deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert dashboard check-in setting
INSERT IGNORE INTO `tracker_settings` (`setting_name`, `setting_value`, `type`, `created_at`)
VALUES ('dashboard_checkin_active', '1', 'app', NOW());

-- Insert other default settings if they don't exist
INSERT IGNORE INTO `tracker_settings` (`setting_name`, `setting_value`, `type`) VALUES
('screenshot_interval', '300', 'app'),
('working_hours_start', '09:00', 'app'),
('working_hours_end', '17:00', 'app'),
('timezone_offset', '0', 'app'),
('enable_screenshots', '1', 'app'),
('enable_activity_tracking', '1', 'app'),
('enable_idle_detection', '1', 'app'),
('productivity_tracking', '1', 'app'),
('screenshot_quality', '80', 'app'),
('idle_timeout', '600', 'app'),
('enable_screenshot_notifications', '1', 'app'),
('query_cache_enabled', '1', 'system'),
('max_query_cache_time', '3600', 'system'),
('performance_threshold', '50', 'app'),
('max_screenshot_size', '5242880', 'app');

-- Show success message
SELECT 'Tracker attendance tables and settings created successfully!' as Status;
