-- Activity Log Performance Optimization - Database Indexes
-- Run these indexes to improve Activity Log query performance

-- ============================================================================
-- TRACKER_ATTENDANCE TABLE INDEXES
-- ============================================================================

-- Primary performance index for date-based attendance queries
CREATE INDEX idx_attendance_user_date_deleted 
ON tracker_attendance (user_id, inTime, deleted);

-- Index for late attendance filtering
CREATE INDEX idx_attendance_late_date 
ON tracker_attendance (late, inTime, deleted);

-- Index for project-based filtering (break vs work sessions)
CREATE INDEX idx_attendance_project_type 
ON tracker_attendance (user_id, project, deleted, inTime);

-- Composite index for time range queries
CREATE INDEX idx_attendance_time_range 
ON tracker_attendance (inTime, outTime, deleted);

-- ============================================================================
-- LEAVE_APPLICATIONS TABLE INDEXES
-- ============================================================================

-- Primary index for leave queries by user and date range
CREATE INDEX idx_leave_user_status_dates 
ON leave_applications (applicant_id, status, start_date, end_date, deleted);

-- Index for approved leave calculations
CREATE INDEX idx_leave_approved_dates 
ON leave_applications (status, start_date, end_date, deleted);

-- Index for leave period overlaps
CREATE INDEX idx_leave_date_overlap 
ON leave_applications (start_date, end_date, status, deleted);

-- ============================================================================
-- TRACKER_HOLIDAYS TABLE INDEXES
-- ============================================================================

-- Primary index for holiday date range queries
CREATE INDEX idx_holidays_date_range 
ON tracker_holidays (start_date, end_date, deleted);

-- Index for holiday period calculations
CREATE INDEX idx_holidays_period 
ON tracker_holidays (deleted, start_date, end_date);

-- ============================================================================
-- TRACKER_PERFORMANCE TABLE INDEXES
-- ============================================================================

-- Primary index for user performance queries
CREATE INDEX idx_performance_user_date 
ON tracker_performance (user_id, takenTime, deleted);

-- Index for performance aggregations
CREATE INDEX idx_performance_date_range 
ON tracker_performance (takenTime, deleted, performance);

-- ============================================================================
-- TRACKER_SETTINGS TABLE INDEXES
-- ============================================================================

-- Index for settings lookup
CREATE INDEX idx_settings_name_deleted 
ON tracker_settings (setting_name, deleted);

-- ============================================================================
-- USERS TABLE INDEXES (if not already present)
-- ============================================================================

-- Primary index for active staff members
CREATE INDEX idx_users_type_status_deleted 
ON users (user_type, status, deleted);

-- Index for user name sorting
CREATE INDEX idx_users_names 
ON users (first_name, last_name, deleted);

-- ============================================================================
-- PERFORMANCE ANALYSIS QUERIES
-- ============================================================================

-- Use these queries to analyze performance before and after index creation

-- Check query execution plan for main activity log query
EXPLAIN SELECT 
    u.id as user_id,
    u.first_name,
    u.last_name,
    COUNT(DISTINCT DATE(FROM_UNIXTIME(ta.inTime/1000))) as present_days
FROM users u
LEFT JOIN tracker_attendance ta ON u.id = ta.user_id 
    AND DATE(FROM_UNIXTIME(ta.inTime/1000)) BETWEEN '2024-01-01' AND '2024-01-31'
    AND ta.deleted = 0
WHERE u.user_type = 'staff' 
    AND u.status = 'active' 
    AND u.deleted = 0
GROUP BY u.id;

-- Check slow query log for Activity Log operations
-- Add to my.cnf:
-- slow_query_log = 1
-- slow_query_log_file = /var/log/mysql/slow.log
-- long_query_time = 1

-- Monitor index usage
SHOW INDEX FROM tracker_attendance;
SHOW INDEX FROM leave_applications;
SHOW INDEX FROM tracker_holidays;
SHOW INDEX FROM tracker_performance;
SHOW INDEX FROM tracker_settings;

-- ============================================================================
-- INDEX MAINTENANCE RECOMMENDATIONS
-- ============================================================================

-- 1. Monitor index effectiveness:
SELECT 
    TABLE_NAME,
    INDEX_NAME,
    CARDINALITY,
    SUB_PART,
    PACKED,
    NULL as COMMENT
FROM INFORMATION_SCHEMA.STATISTICS 
WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME IN ('tracker_attendance', 'leave_applications', 'tracker_holidays', 'tracker_performance', 'tracker_settings')
ORDER BY TABLE_NAME, INDEX_NAME;

-- 2. Analyze table statistics regularly:
ANALYZE TABLE tracker_attendance, leave_applications, tracker_holidays, tracker_performance, tracker_settings;

-- 3. Check for unused indexes periodically:
SELECT 
    s.TABLE_SCHEMA,
    s.TABLE_NAME,
    s.INDEX_NAME,
    s.CARDINALITY
FROM INFORMATION_SCHEMA.STATISTICS s
LEFT JOIN INFORMATION_SCHEMA.INDEX_STATISTICS i 
    ON s.TABLE_SCHEMA = i.TABLE_SCHEMA 
    AND s.TABLE_NAME = i.TABLE_NAME 
    AND s.INDEX_NAME = i.INDEX_NAME
WHERE s.TABLE_SCHEMA = DATABASE()
    AND s.TABLE_NAME IN ('tracker_attendance', 'leave_applications', 'tracker_holidays', 'tracker_performance', 'tracker_settings')
    AND i.INDEX_NAME IS NULL
    AND s.INDEX_NAME != 'PRIMARY';

-- ============================================================================
-- NOTES
-- ============================================================================
-- 
-- 1. Test these indexes in a staging environment first
-- 2. Monitor query performance before and after index creation
-- 3. Some indexes may need adjustment based on actual data patterns
-- 4. Consider partitioning for very large tables (tracker_attendance)
-- 5. Regular maintenance: OPTIMIZE TABLE monthly for MyISAM, ANALYZE TABLE for InnoDB
-- 
-- ============================================================================
