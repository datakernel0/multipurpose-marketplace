-- Add status and late tracking to tracker_attendance table
-- This script adds the required columns for status tracking and late detection

-- Add status column to track attendance status (present, absent, late, manual, etc.)
ALTER TABLE `tracker_attendance` 
ADD COLUMN `status` VARCHAR(20) DEFAULT 'present' COMMENT 'Attendance status: present, absent, late, on_time, manual, etc.' AFTER `note`;

-- Add late column to track if the employee was late
ALTER TABLE `tracker_attendance` 
ADD COLUMN `late` TINYINT(1) DEFAULT 0 COMMENT '1 if employee was late, 0 if on time' AFTER `status`;

-- Add project column if it doesn't exist (for manual entries like 'manual-10')
ALTER TABLE `tracker_attendance` 
ADD COLUMN `project` VARCHAR(50) DEFAULT NULL COMMENT 'Project identifier for tracking purposes' AFTER `sign`;

-- Add isMinusBreak column if it doesn't exist
ALTER TABLE `tracker_attendance` 
ADD COLUMN `isMinusBreak` TINYINT(1) DEFAULT 0 COMMENT 'Flag for break calculation' AFTER `project`;

-- Add indexes for better performance
ALTER TABLE `tracker_attendance` 
ADD INDEX `idx_status` (`status`);

ALTER TABLE `tracker_attendance` 
ADD INDEX `idx_late` (`late`);

ALTER TABLE `tracker_attendance` 
ADD INDEX `idx_project` (`project`);

-- Add composite index for user_id and status for faster queries
ALTER TABLE `tracker_attendance` 
ADD INDEX `idx_user_status` (`user_id`, `status`);
