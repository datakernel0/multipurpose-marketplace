-- Tracker status tables

-- Create tracker_status table
CREATE TABLE IF NOT EXISTS `tracker_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `status` enum('active','inactive','away','break','lunch','meeting','offline') NOT NULL DEFAULT 'offline',
  `status_message` varchar(255) DEFAULT NULL,
  `project_id` int(11) DEFAULT NULL,
  `current_task` varchar(500) DEFAULT NULL,
  `last_activity` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `session_start` datetime DEFAULT NULL,
  `total_active_time` int(11) DEFAULT 0,
  `performance_score` decimal(5,2) DEFAULT 0.00,
  `is_tracking` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_unique_user_status` (`user_id`, `deleted`),
  KEY `idx_user_activity` (`user_id`, `last_activity`),
  KEY `idx_status_recent` (`status`, `last_activity`, `deleted`),
  KEY `idx_active_users` (`status`, `is_tracking`, `deleted`),
  KEY `idx_project_users` (`project_id`, `status`),
  KEY `idx_performance_range` (`user_id`, `performance_score`),
  KEY `idx_session_tracking` (`user_id`, `session_start`),
  KEY `idx_deleted_status` (`deleted`, `status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create tracker_status_log table
CREATE TABLE IF NOT EXISTS `tracker_status_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `status` varchar(50) NOT NULL,
  `timestamp` datetime NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_timestamp` (`user_id`, `timestamp`),
  KEY `idx_timestamp` (`timestamp`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


