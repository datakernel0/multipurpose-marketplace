-- Insert dashboard check-in setting if it doesn't exist
INSERT IGNORE INTO `tracker_settings` (`setting_name`, `setting_value`, `type`, `created_at`)
VALUES ('dashboard_checkin_active', '1', 'app', NOW());
