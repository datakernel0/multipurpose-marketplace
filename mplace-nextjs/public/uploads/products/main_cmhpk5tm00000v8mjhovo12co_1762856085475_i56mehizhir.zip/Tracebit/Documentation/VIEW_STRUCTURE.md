# View Structure Documentation

## Overview

The view code has been reorganized to follow better separation of concerns. The storage management functionality has been moved from the topbar file to a dedicated view file, and the storage button is now consistent with other menu items.

## File Structure

### Before (Monolithic Structure)
```
plugins/Tracebit/Views/tracker/topbar.php
├── Navigation buttons
├── Storage management dropdown (complex)
├── Storage management modals (200+ lines)
└── Storage management JavaScript (150+ lines)
```

### After (Modular Structure)
```
plugins/Tracebit/Views/tracker/
├── topbar.php (Navigation only - consistent menu items)
└── storage_management.php (Storage functionality)
```

## Files

### 1. `topbar.php` (Cleaned & Consistent)
**Purpose:** Navigation and menu structure only
**Contains:**
- Navigation buttons (Timesheet, Activity Log, Screenshots, etc.)
- Storage management button (consistent with other menu items)
- Basic JavaScript for navigation state management
- Include statement for storage management view

**Key Changes:**
- Removed all modal HTML (200+ lines)
- Removed all storage management JavaScript (150+ lines)
- Added include statement: `include_once(__DIR__ . '/storage_management.php');`
- Storage button now uses `anchor()` function like other menu items
- Storage button has consistent CSS classes and structure
- Kept only navigation-related functionality

**Storage Button Implementation:**
```php
echo anchor("javascript:void(0)", "<i data-feather='hard-drive' class='icon-16 mr5'></i> " . (app_lang("storage_management") ?: "Storage Management"), array("class" => "btn btn-default round me-2 js-reports-link", "title" => "Storage Management", "onclick" => "openStorageModal('export', 'date_range')"));
```

### 2. `storage_management.php` (Self-Contained)
**Purpose:** Dedicated storage management functionality
**Contains:**
- Storage management modal (`#storageManagementModal`)
- Storage statistics modal (`#storageStatsModal`)
- All storage management JavaScript functions
- Form handling and AJAX calls
- Button click event handling

**Features:**
- Export functionality (ZIP, CSV, JSON)
- Delete functionality with confirmation
- Preview functionality
- Statistics display
- User selection dropdowns
- Date range selection
- Year/month selection
- Action selection within modal

## Benefits of This Structure

### 1. **Consistency with Existing Codebase**
- **Anchor Function:** Storage button uses `anchor()` like other menu items
- **CSS Classes:** Same classes as other navigation buttons
- **Structure:** Follows same patterns as existing menu items
- **Integration:** Seamlessly fits with existing navigation

### 2. **Separation of Concerns**
- **Navigation Logic:** Handled in `topbar.php`
- **Storage Logic:** Handled in `storage_management.php`
- **Clear Responsibilities:** Each file has a single purpose

### 3. **Maintainability**
- **Easier Debugging:** Issues can be isolated to specific files
- **Cleaner Code:** Smaller, focused files are easier to understand
- **Modular Updates:** Changes to storage functionality don't affect navigation

### 4. **Reusability**
- **Storage View:** Can be included in other pages if needed
- **Independent Testing:** Each component can be tested separately
- **Flexible Integration:** Easy to include/exclude storage functionality

### 5. **Performance**
- **Reduced File Size:** Topbar file is now much smaller
- **Faster Loading:** Only loads storage code when needed
- **Better Caching:** Components can be cached separately

## Code Organization

### Topbar.php Structure
```php
<?php
// Navigation buttons (consistent pattern)
echo anchor(get_uri("tracebit/timesheet"), "...");
echo anchor(get_uri("tracebit/activity-log"), "...");
echo anchor(get_uri("tracebit/screenshots"), "...");

// Storage management button (consistent with other menu items)
echo anchor("javascript:void(0)", "...", array("class" => "btn btn-default round me-2 js-reports-link", "onclick" => "openStorageModal('export', 'date_range')"));

echo anchor(get_uri("tracebit/tracker_settings"), "...");
?>

<?php
// Include storage management view
include_once(__DIR__ . '/storage_management.php');
?>

<script>
// Navigation-specific JavaScript only
$(document).ready(function () {
    // Active state logic
    // Cookie management
});
</script>
```

### Storage_management.php Structure
```php
<!-- Storage Management Modal -->
<div class="modal fade" id="storageManagementModal">
    <!-- Modal content with action selection -->
</div>

<!-- Storage Statistics Modal -->
<div class="modal fade" id="storageStatsModal">
    <!-- Statistics content -->
</div>

<script>
// Storage management functions
function openStorageModal(action, type) { ... }

// Button click handling
$(document).ready(function() {
    $('a[onclick*="openStorageModal"]').on('click', function(e) { ... });
});

// Action and selection type handlers
function updateActionType() { ... }
function updateSelectionType() { ... }

// Event handlers
$('#executeStorageAction').click(function() { ... });
</script>
```

## Integration Points

### 1. **Include Statement**
```php
include_once(__DIR__ . '/storage_management.php');
```
- Uses `include_once` to prevent multiple inclusions
- Relative path ensures portability
- Loads storage functionality when topbar is rendered

### 2. **JavaScript Functions**
The storage management functions are globally available:
- `openStorageModal(action, type)`
- `loadPreview()`
- `showStorageStats()`

### 3. **Button Click Handling**
```javascript
$('a[onclick*="openStorageModal"]').on('click', function(e) {
    // Extract parameters from onclick attribute
    // Call openStorageModal with extracted parameters
});
```

### 4. **Modal IDs**
Modals are referenced by ID:
- `#storageManagementModal`
- `#storageStatsModal`

## Best Practices Applied

### 1. **Consistency**
- Storage button uses same pattern as other menu items
- Same CSS classes and structure
- Same anchor function approach

### 2. **Single Responsibility Principle**
- Each file has one clear purpose
- Navigation logic separated from business logic

### 3. **DRY (Don't Repeat Yourself)**
- Storage functionality is in one place
- No code duplication between files

### 4. **Modularity**
- Components can be developed independently
- Easy to test individual components

### 5. **Maintainability**
- Clear file structure
- Easy to locate specific functionality
- Simple to update individual components

## Future Enhancements

### 1. **Additional Views**
Other functionality could be similarly separated:
- `activity_management.php`
- `settings_management.php`
- `report_management.php`

### 2. **View Components**
Create reusable components:
- `components/modal.php`
- `components/dropdown.php`
- `components/form.php`

### 3. **JavaScript Modules**
Separate JavaScript into modules:
- `js/storage.js`
- `js/navigation.js`
- `js/statistics.js`

## Migration Notes

### 1. **Backward Compatibility**
- All existing functionality remains unchanged
- No breaking changes to user experience
- Same API endpoints and JavaScript functions

### 2. **File Dependencies**
- `storage_management.php` depends on:
  - Users model for dropdown population
  - Storage controller for AJAX calls
  - Bootstrap for modal functionality

### 3. **Testing**
- Test navigation functionality in `topbar.php`
- Test storage functionality in `storage_management.php`
- Test integration between both files

## Troubleshooting

### 1. **Storage Button Not Working**
- Check if `storage_management.php` exists
- Verify include path is correct
- Check for PHP errors in error log
- Verify JavaScript event handling

### 2. **JavaScript Functions Not Available**
- Ensure `storage_management.php` is included
- Check browser console for JavaScript errors
- Verify modal IDs match between files

### 3. **AJAX Calls Failing**
- Check if storage controller routes are configured
- Verify AJAX URLs are correct
- Check network tab for failed requests

### 4. **Button Not Consistent**
- Verify anchor function usage
- Check CSS classes match other menu items
- Ensure onclick attribute is present

## Conclusion

This modular structure provides better organization, maintainability, and scalability while preserving all existing functionality. The separation of concerns makes the codebase easier to understand and modify. The storage management button is now consistent with other menu items, following the same patterns and structure as the existing navigation.
