# Screenshot Organization Guide

## Overview

The Tracebit plugin now organizes screenshots in a structured folder hierarchy with username identification for better management, navigation, and storage optimization.

## New Folder Structure

### Before (Flat Structure)
```
plugins/Tracebit/screenshots/
├── 1_1234567890.png
├── 1_1234567891.png
├── 5_1234567892.png
├── 1_1234567893.png
└── 1_1234567894.png
```

### After (Organized Structure with Username)
```
plugins/Tracebit/screenshots/
├── 2024/
│   ├── 01/
│   │   ├── 1_John_Doe/
│   │   │   ├── screenshot_1234567890.png
│   │   │   └── screenshot_1234567891.png
│   │   └── 5_Jane_Smith/
│   │       └── screenshot_1234567892.png
│   └── 02/
│       └── 1_John_Doe/
│           └── screenshot_1234567893.png
└── 2025/
    └── 01/
        └── 10_Bob_Wilson/
            └── screenshot_1234567894.png
```

## Folder Structure Details

### Path Format
```
plugins/Tracebit/screenshots/{YEAR}/{MONTH}/{USER_ID}_{USERNAME}/screenshot_{TIMESTAMP}.png
```

### Components
- **YEAR**: 4-digit year (e.g., 2024, 2025)
- **MONTH**: 2-digit month (e.g., 01, 02, 12)
- **USER_ID**: User identifier
- **USERNAME**: User's full name (first_name + last_name, cleaned for folder safety)
- **TIMESTAMP**: Unix timestamp for uniqueness

### Examples
```
plugins/Tracebit/screenshots/2024/01/1_John_Doe/screenshot_1704067200000.png
plugins/Tracebit/screenshots/2024/12/5_Jane_Smith/screenshot_1735689600000.png
plugins/Tracebit/screenshots/2025/06/10_Bob_Wilson/screenshot_1746144000000.png
```

## Username Processing

### Username Generation
The system automatically generates usernames from user data:

```php
private function getUsername($user_id) {
    // Get user info from database
    $user_info = $this->Native_app_model->user_info($user_id);

    if ($user_info && !empty($user_info)) {
        $user = $user_info[0];

        // Combine first_name and last_name
        $first_name = trim($user->first_name ?? '');
        $last_name = trim($user->last_name ?? '');

        if (!empty($first_name) || !empty($last_name)) {
            $username = trim($first_name . ' ' . $last_name);

            // Clean username for folder name
            $username = preg_replace('/[^a-zA-Z0-9\s\-_]/', '', $username);
            $username = preg_replace('/\s+/', '_', $username);
            $username = trim($username, '_');

            return $username;
        }
    }

    // Fallback to user_id if no name available
    return $user_id;
}
```

### Username Cleaning Rules
1. **Character Filtering**: Removes special characters except letters, numbers, spaces, hyphens, and underscores
2. **Space Replacement**: Converts spaces to underscores
3. **Trimming**: Removes leading/trailing underscores
4. **Fallback**: Uses user_id if no valid name is available

### Examples of Username Processing
| Original Name | Cleaned Username | Folder Name |
|---------------|------------------|-------------|
| "John Doe" | "John_Doe" | "1_John_Doe" |
| "Jane Smith" | "Jane_Smith" | "5_Jane_Smith" |
| "Bob Wilson" | "Bob_Wilson" | "10_Bob_Wilson" |
| "Mary O'Connor" | "Mary_OConnor" | "15_Mary_OConnor" |
| "José García" | "Jos_Garca" | "20_Jos_Garca" |
| "User 123" | "User_123" | "25_User_123" |

## Implementation Details

### API Changes

The `createScreenshot` API now automatically creates the organized folder structure with usernames:

```php
// Old implementation
$outputFile = "plugins/Tracebit/screenshots/{$user_id}_{$getTime}.png";

// New implementation with username
$date_obj = new \DateTime($date);
$year = $date_obj->format('Y');
$month = $date_obj->format('m');
$username = $this->getUsername($user_id);
$base_path = "plugins/Tracebit/screenshots/{$year}/{$month}/{$user_id}_{$username}";
$filename = "screenshot_{$getTime}.png";
$outputFile = "{$base_path}/{$filename}";
```

### Directory Creation

The system automatically creates directories as needed:

```php
private function createScreenshotDirectory($base_path) {
    if (!is_dir($base_path)) {
        mkdir($base_path, 0755, true);
    }
    return true;
}
```

### Unique Filename Generation

To prevent file conflicts, the system generates unique filenames:

```php
private function generateUniqueFilename($base_path, $filename) {
    $counter = 1;
    $original_filename = $filename;

    while (file_exists($base_path . '/' . $filename)) {
        $path_info = pathinfo($original_filename);
        $filename = $path_info['filename'] . "_{$counter}." . $path_info['extension'];
        $counter++;
    }

    return $filename;
}
```

## Benefits

### 1. Better Organization
- **Chronological Order**: Screenshots are organized by year and month
- **User Identification**: Easy to identify users by name in folder structure
- **User Separation**: Each user has their own folder with readable name
- **Easy Navigation**: Find screenshots quickly by date and user name

### 2. Storage Management
- **Easy Cleanup**: Remove old screenshots by year/month
- **Size Optimization**: Monitor storage usage per time period
- **Backup Efficiency**: Backup specific time periods easily
- **User-Specific Management**: Manage screenshots per user easily

### 3. Performance
- **Faster Access**: Reduced file system overhead
- **Better Caching**: Organized structure improves caching
- **Efficient Queries**: Database queries can target specific time periods
- **User Lookup**: Quick user identification by folder name

### 4. Maintenance
- **Automated Cleanup**: Remove old screenshots automatically
- **Statistics**: Get detailed statistics per user and time period
- **Monitoring**: Track storage usage and file counts
- **User Tracking**: Easy to track which users have screenshots

## Utility Functions

### Get Screenshot Directory with Username
```php
private function getScreenshotDirectory($user_id, $date) {
    $date_obj = new \DateTime($date);
    $year = $date_obj->format('Y');
    $month = $date_obj->format('m');

    // Get username for better folder naming
    $username = $this->getUsername($user_id);

    return "plugins/Tracebit/screenshots/{$year}/{$month}/{$user_id}_{$username}";
}
```

### Get Username for User ID
```php
private function getUsername($user_id) {
    // Returns cleaned username or user_id as fallback
    // Handles database errors gracefully
}
```

### Screenshot Statistics
```php
public function getScreenshotStats($user_id, $start_date = null, $end_date = null) {
    // Returns detailed statistics including:
    // - Total screenshots count
    // - Total file size
    // - Monthly breakdown
    // - Directory list with username folders
}
```

### Cleanup Old Screenshots
```php
public function cleanupOldScreenshots($days_to_keep = 90) {
    // Removes screenshots older than specified days
    // Works with username-based folder structure
    // Returns cleanup results and statistics
}
```

## Migration

### Existing Screenshots
If you have existing screenshots in the old format, you can migrate them:

```php
// Migration script example with username support
function migrateExistingScreenshots() {
    $old_dir = "plugins/Tracebit/screenshots";
    $files = glob($old_dir . "/*.png");

    foreach ($files as $file) {
        // Extract user_id and timestamp from filename
        $filename = basename($file);
        if (preg_match('/(\d+)_(\d+)\.png/', $filename, $matches)) {
            $user_id = $matches[1];
            $timestamp = $matches[2];

            // Convert timestamp to date
            $date = date('Y-m-d', $timestamp / 1000);

            // Create new organized path with username
            $new_path = getScreenshotDirectory($user_id, $date);
            $new_filename = "screenshot_{$timestamp}.png";
            $new_file = $new_path . '/' . $new_filename;

            // Move file
            if (!is_dir($new_path)) {
                mkdir($new_path, 0755, true);
            }
            rename($file, $new_file);
        }
    }
}
```

## Configuration

### Settings
The screenshot organization uses these settings:

```php
// Screenshot quality (1-100)
'screenshot_quality' => 80,

// Data retention period (days)
'data_retention_days' => 90,

// Enable screenshot compression
'enable_screenshot_compression' => true
```

### File Permissions
Directories are created with permissions `0755` for security.

## Testing

### Test Script
Run the test script to verify the organization works:

```bash
php plugins/Tracebit/test_screenshot_structure.php
```

### Test Cases
The test script covers:
1. Username generation from user data
2. Directory path generation with username suffix
3. Directory creation with proper permissions
4. Unique filename generation to avoid conflicts
5. Screenshot statistics calculation with username folders

## Error Handling

### Common Issues
1. **Permission Errors**: Ensure web server has write permissions
2. **Disk Space**: Monitor available storage
3. **File Conflicts**: Handled by unique filename generation
4. **Database Errors**: Graceful fallback to user_id if username lookup fails
5. **Invalid Characters**: Username cleaning handles special characters

### Logging
All operations are logged for debugging:

```php
Error_handler::info('Screenshot directory created', [
    'path' => $base_path
]);

Error_handler::info('Screenshot file created successfully', [
    'original_path' => $outputFile,
    'final_path' => $final_output_file,
    'file_size' => filesize($final_output_file),
    'user_id' => $options['user_id'],
    'username' => $username
]);
```

## API Response

### Success Response
```json
{
    "success": true,
    "message": "Record saved",
    "data": {
        "file_path": "plugins/Tracebit/screenshots/2024/01/1_John_Doe/screenshot_1704067200000.png",
        "file_size": 245760,
        "username": "John_Doe"
    }
}
```

### Error Response
```json
{
    "success": false,
    "message": "Failed to create directory structure",
    "code": 500
}
```

## Best Practices

### 1. Regular Cleanup
Schedule regular cleanup of old screenshots:

```php
// Clean up screenshots older than 90 days
$controller->cleanupOldScreenshots(90);
```

### 2. Monitor Storage
Regularly check storage usage:

```php
$stats = $controller->getScreenshotStats($user_id);
echo "Total size: " . number_format($stats['total_size']) . " bytes";
```

### 3. Backup Strategy
Backup screenshots by year/month for efficient restoration.

### 4. Performance Monitoring
Monitor screenshot creation performance and file sizes.

### 5. User Management
Keep user names updated in the database for accurate folder naming.

## Support

For issues or questions:
1. Check the error logs
2. Run the test script
3. Verify file permissions
4. Check user data in database
5. Contact support team
