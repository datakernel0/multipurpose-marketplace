# Tracebit Plugin - Late Status Feature Implementation

## Overview
This implementation adds status tracking and late detection functionality to the Tracebit timesheet based on the `working_hours_start` setting from the `tracker_settings` table.

## Features Added

### 1. Database Schema Changes
- Added `status` column to `tracker_attendance` table (VARCHAR(20), default 'present')
- Added `late` column to `tracker_attendance` table (TINYINT(1), default 0)
- Added appropriate indexes for performance optimization

### 2. Enhanced Attendance Model (`Tracker_attendance_model.php`)
- **New Method**: `calculate_late_status()` - Calculates if check-in time is late based on working hours
- **Enhanced Method**: `clock_in()` - Now automatically calculates and stores late status
- **New Method**: `get_attendance_with_status()` - Retrieves attendance records with status information

### 3. Enhanced Employee Status Controller (`Employee_status.php`)
- **New Method**: `check_late_status()` - Checks if a user was late for timesheet display
- **Enhanced Method**: `_make_timeSheet_row()` - Now includes late status detection and display
- **Updated**: Status mapping to include 'late' status with orange warning styling

### 4. Status Types Supported
- **Present**: Employee checked in on time (green badge)
- **Late**: Employee checked in after working_hours_start (orange badge)
- **Absent**: Employee did not check in (red badge)
- **Weekend**: Weekend days (blue badge)
- **Holiday**: Company holidays (info badge)
- **On Leave**: Full day leave (secondary badge)
- **Half Leave**: Half day leave (warning badge)

## Technical Implementation Details

### Late Detection Logic
1. **During Check-in**: 
   - Compares current time with `working_hours_start` from `tracker_settings`
   - Sets `status` = 'late' or 'on_time'
   - Sets `late` = 1 or 0

2. **During Timesheet Display**:
   - Checks existing `status` and `late` fields from database
   - Falls back to calculating from `inTime` and `working_hours_start` if fields are empty
   - Supports both timestamp and formatted time strings

### Database Query Optimization
- Added composite indexes for better query performance
- Efficient status lookup without affecting existing functionality

### Backward Compatibility
- All changes are additive - existing data continues to work
- Fallback logic for records without status/late fields
- Default values ensure smooth migration

## Files Modified

### Database
- `/Database/tracker_schema.sql` - Updated with new columns
- `/Database/add_status_late_columns.sql` - Migration script for existing installations

### Models
- `/Models/Tracker_attendance_model.php` - Enhanced with late detection logic

### Controllers
- `/Controllers/Employee_status.php` - Enhanced timesheet display with late status

### CSS (Already Available)
- Late status uses existing `bg-warning` styling (orange gradient)

## Configuration

### Working Hours Setting
The late detection uses the `working_hours_start` setting from `tracker_settings`:
- Setting name: `working_hours_start`
- Default value: `09:00`
- Format: `HH:MM` (24-hour format)

### Customization
To modify the working hours:
1. Update the `working_hours_start` value in `tracker_settings` table
2. Or modify through the tracker settings interface

## Usage Examples

### Check-in Process
```php
// When user checks in at 09:30 and working_hours_start is 09:00
$attendance_model->clock_in($user_id, $note);
// Results in: status='late', late=1
```

### Timesheet Display
- **On Time**: Green "Present" badge
- **Late**: Orange "Late" badge  
- **Other statuses**: Maintain existing behavior

## Migration Instructions

### For New Installations
- Use the updated `tracker_schema.sql` which includes the new columns

### For Existing Installations
1. Run the migration script: `add_status_late_columns.sql`
2. No data migration needed - new logic handles existing records gracefully

## Testing

### Test Scenarios
1. **On-time check-in**: Before working_hours_start → status='on_time', late=0
2. **Late check-in**: After working_hours_start → status='late', late=1
3. **Timesheet display**: Correctly shows late status with orange badge
4. **Backward compatibility**: Existing records display correctly

## Future Enhancements

### Potential Additions
1. **Grace period**: Allow X minutes buffer before marking as late
2. **Late notifications**: Alert managers when employees are late
3. **Tardiness reports**: Analytics on late arrival patterns
4. **Configurable late threshold**: Different late definitions per user/role

### API Endpoints
Consider adding REST endpoints for:
- Late status statistics
- Tardiness reporting
- Real-time late alerts
