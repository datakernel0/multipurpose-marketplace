# Manual Time Entry Feature - Implementation Guide

## Overview
The Manual Time Entry feature allows users to add manual time records to the `tracker_attendance` table through a Rise CRM modal interface. This feature is particularly useful for:
- Adding time entries for periods not tracked automatically
- Correcting attendance records
- Recording offline work hours
- Managing remote work time tracking

## Features Implemented

### ✅ **Modal Interface**
- **Title**: "Add time manually"
- **Team Member Display**: Shows user avatar and name (uppercase)
- **In Time**: Time picker for start time
- **Out Time**: Time picker for end time  
- **Description**: Textarea for work description
- **Remove Late Entry**: Checkbox option to remove late status
- **Duration Calculator**: Real-time calculation of work duration

### ✅ **Database Integration**
- **Table**: `tracker_attendance`
- **Project**: Automatically set to `'manual-10'`
- **Timestamps**: Converted to milliseconds with timezone handling
- **Status**: Set to `'manual'` (not considered late)
- **Note Field**: Stores description

### ✅ **Data Structure**
```php
// Example record created:
[
    'id' => 3,
    'user_id' => 1,
    'inTime' => 1752061735553,      // Timestamp in milliseconds
    'outTime' => 1752065587779,     // Timestamp in milliseconds  
    'note' => 'Manual work entry',   // Description from form
    'status' => 'manual',            // Manual entry status
    'late' => 0,                     // Not late
    'timezone' => 360,               // +6 hours (Bangladesh time)
    'sign' => '+',
    'project' => 'manual-10',        // As specified
    'created_at' => '2025-07-24 14:19:48',
    'updated_at' => '2025-07-24 14:21:30',
    'isMinusBreak' => 0,
    'deleted' => 0
]
```

## Technical Implementation

### 1. **Modal View** (`manual_time_modal.php`)
- Form action: `tracebit/save_manual_time`
- Responsive layout with proper Rise CRM styling
- Real-time duration calculation
- User avatar and name display
- Input validation with required fields

### 2. **Controller Method** (`Employee_status::save_manual_time()`)
- Validates required fields (date, in_time, out_time)
- Converts time to proper timestamp format
- Handles timezone conversion (default: +6 hours)
- Saves to `tracker_attendance` table
- Optional late status removal for the date
- Comprehensive error handling and logging

### 3. **Modal Loading** (`Employee_status::manual_time_modal_form()`)
- Retrieves user information for display
- Passes date and user data to modal
- Handles both GET and POST requests

### 4. **Database Schema Updates**
- Added `status` column for tracking entry type
- Added `late` column for late status tracking
- Added `project` column for manual entry identification
- Added `isMinusBreak` column for break calculations
- Proper indexing for performance

## Usage Instructions

### 1. **Access Manual Time Modal**
- Navigate to Tracebit → Timesheet
- Click the edit icon (✏️) in the "Manual Time" column for any date
- Modal opens with "Add time manually" title

### 2. **Fill Time Entry**
1. **Team Member**: Displays automatically (read-only)
2. **In Time**: Select start time (required)
3. **Out Time**: Select end time (required, must be after in time)
4. **Description**: Add work description (optional)
5. **Remove Late Entry**: Check to remove late status for this date

### 3. **Submit Entry**
- Click "Submit" to save the manual time entry
- Success message confirms save
- Timesheet automatically refreshes to show updated data

## Features in Detail

### ✅ **Timezone Handling**
- Uses Rise CRM timezone settings
- Default: +6 hours (Asia/Dhaka timezone)
- Timestamps stored in milliseconds for consistency
- Automatic conversion from local time input

### ✅ **Late Status Management**
- Manual entries are never marked as late (`late` = 0)
- Option to remove late status from existing entries for the same date
- Preserves attendance tracking integrity

### ✅ **Validation & Error Handling**
- Required field validation (date, in_time, out_time)
- Time logic validation (out_time must be after in_time)
- Database error handling
- User-friendly error messages

### ✅ **Integration with Timesheet**
- Manual entries appear in timesheet with "Manual" status badge
- Proper time calculations include manual entries
- Consistent with existing attendance records

## Status Display

Manual time entries show in the timesheet with:
- **Status Badge**: "Manual" (distinct from Present/Late/Absent)
- **Color**: Will use existing badge styling
- **Time Display**: Shows entered in/out times
- **Duration**: Calculated and displayed properly

## Database Schema

### Required Columns in `tracker_attendance`:
```sql
-- Core columns (existing)
id, user_id, inTime, outTime, note, timezone, sign, created_at, updated_at, deleted

-- New columns (added)
status VARCHAR(20) DEFAULT 'present'           -- Entry type
late TINYINT(1) DEFAULT 0                     -- Late flag  
project VARCHAR(50) DEFAULT NULL              -- Project identifier
isMinusBreak TINYINT(1) DEFAULT 0            -- Break flag
```

## Testing Scenarios

### ✅ **Basic Functionality**
1. **Valid Entry**: In: 09:00, Out: 17:00 → Success
2. **Invalid Time**: Out before In → Error message
3. **Missing Fields**: Empty required fields → Validation error
4. **Duration Calculation**: Real-time duration display

### ✅ **Integration Testing**
1. **Timesheet Display**: Manual entries appear correctly
2. **Status Badges**: Shows "Manual" status
3. **Time Calculations**: Includes manual time in totals
4. **Refresh**: Timesheet updates after adding entry

### ✅ **Advanced Features**
1. **Late Removal**: Checkbox removes late status
2. **Multiple Entries**: Can add multiple manual entries per day
3. **User Context**: Correct user information displayed
4. **Error Recovery**: Graceful error handling

## Configuration

### **Timezone Setting**
```sql
-- Update timezone offset in tracker_settings
UPDATE tracker_settings 
SET setting_value = '360'  -- +6 hours in minutes
WHERE setting_name = 'timezone_offset';
```

### **Project Identifier**
- Fixed to `'manual-10'` as specified
- Can be modified in `Employee_status::save_manual_time()` method
- Helps distinguish manual entries from automatic tracking

## Routes

The feature uses these routes:
```php
// Modal form loading
GET/POST: tracebit/manual_time_modal_form

// Form submission  
POST: tracebit/save_manual_time
```

## Troubleshooting

### **Modal Not Opening**
- Check JavaScript console for errors
- Verify route configuration
- Ensure user permissions

### **Save Errors**
- Check database connection
- Verify required columns exist
- Review error logs for details

### **Time Display Issues**
- Verify timezone settings
- Check timestamp conversion
- Ensure proper date format

## Future Enhancements

### **Potential Improvements**
1. **Bulk Entry**: Add multiple time entries at once
2. **Templates**: Save common time entry patterns
3. **Approval Workflow**: Require manager approval for manual entries
4. **Time Categories**: Different types of manual work
5. **Reporting**: Separate reporting for manual vs automatic time

This implementation provides a comprehensive manual time entry system that integrates seamlessly with the existing Tracebit timesheet functionality while maintaining data integrity and user experience consistency.
