# Installation Guide: Late Status Feature for Tracebit Plugin

## Prerequisites
- Tracebit plugin already installed and working
- Database access to run SQL scripts
- PHP 7.4+ with CodeIgniter 4

## Installation Steps

### Step 1: Database Migration
Run the SQL script to add the required columns:

```sql
-- Connect to your database and run this script
-- File: /plugins/Tracebit/Database/add_status_late_columns.sql

ALTER TABLE `tracker_attendance` 
ADD COLUMN `status` VARCHAR(20) DEFAULT 'present' COMMENT 'Attendance status: present, absent, late, on_time, etc.' AFTER `note`;

ALTER TABLE `tracker_attendance` 
ADD COLUMN `late` TINYINT(1) DEFAULT 0 COMMENT '1 if employee was late, 0 if on time' AFTER `status`;

ALTER TABLE `tracker_attendance` 
ADD INDEX `idx_status` (`status`);

ALTER TABLE `tracker_attendance` 
ADD INDEX `idx_late` (`late`);

ALTER TABLE `tracker_attendance` 
ADD INDEX `idx_user_status` (`user_id`, `status`);
```

### Step 2: Verify Installation
1. **Test the functionality**:
   - Navigate to `/plugins/Tracebit/test_late_status.php` in your browser
   - Check that all tests pass

2. **Check the timesheet**:
   - Go to Tracebit → Timesheet
   - Verify that the status column shows appropriate badges
   - Test check-in functionality

### Step 3: Configure Working Hours
1. **Access Tracker Settings**:
   - Navigate to Tracebit settings
   - Look for "Work Day Start Time" setting
   - Default is 09:00 (9:00 AM)

2. **Or update directly in database**:
   ```sql
   UPDATE tracker_settings 
   SET setting_value = '08:30' 
   WHERE setting_name = 'working_hours_start';
   ```

## Verification Checklist

### ✅ Database Structure
- [ ] `tracker_attendance` table has `status` column
- [ ] `tracker_attendance` table has `late` column
- [ ] Indexes are created successfully
- [ ] `tracker_settings` has `working_hours_start` setting

### ✅ Functionality
- [ ] Check-in before working hours → status: "on_time", late: 0
- [ ] Check-in after working hours → status: "late", late: 1
- [ ] Timesheet displays correct status badges
- [ ] Late entries show orange "Late" badge

### ✅ User Interface
- [ ] Timesheet loads without errors
- [ ] Status column shows appropriate badges
- [ ] Colors are correct (green=present, orange=late, red=absent, etc.)

## Troubleshooting

### Issue: Columns not found error
**Solution**: Run the migration SQL script in Step 1

### Issue: Status always shows "Present"
**Possible causes**:
1. Old attendance records don't have status/late fields
2. Check the `working_hours_start` setting value
3. Verify timezone settings

### Issue: Test script errors
**Solution**: Ensure the script is accessed through the web server, not directly

### Issue: Timesheet not updating
**Solution**: 
1. Clear browser cache
2. Check browser console for JavaScript errors
3. Verify backend API responses

## Configuration Options

### Working Hours Format
- Use 24-hour format: `08:30`, `09:00`, `17:30`
- Examples:
  - `08:00` = 8:00 AM
  - `09:30` = 9:30 AM
  - `17:00` = 5:00 PM

### Status Types
The system automatically assigns these statuses:
- **on_time**: Checked in before/at working_hours_start
- **late**: Checked in after working_hours_start
- **present**: Default for existing records
- **absent**: No check-in record

### Badge Colors
- Green: Present/On Time
- Orange: Late/Half Leave
- Red: Absent
- Blue: Weekend/Holiday
- Gray: On Leave

## Testing Different Scenarios

### Test Late Detection
1. Set `working_hours_start` to current time + 5 minutes
2. Wait 6 minutes and check in
3. Should show "Late" status

### Test On-Time Detection
1. Set `working_hours_start` to current time + 5 minutes
2. Check in within 5 minutes
3. Should show "Present" status

## Support

### Log Files
Check these log files for debugging:
- `writable/logs/log-YYYY-mm-dd.php`
- Look for entries with `[TRACKER]` prefix

### Common Log Messages
- `User X checked in successfully with status: late`
- `Late calculation: working_hours_start=09:00, current_time=09:15, is_late=YES`

### Database Queries for Debugging
```sql
-- Check attendance records with status
SELECT user_id, inTime, status, late, created_at 
FROM tracker_attendance 
WHERE deleted = 0 
ORDER BY created_at DESC 
LIMIT 10;

-- Check working hours setting
SELECT * FROM tracker_settings 
WHERE setting_name = 'working_hours_start';
```
