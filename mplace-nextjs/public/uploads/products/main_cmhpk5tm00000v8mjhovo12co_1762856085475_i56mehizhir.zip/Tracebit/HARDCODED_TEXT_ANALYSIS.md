# Hardcoded Text Analysis - Tracebit Plugin

## Overview

This document identifies all hardcoded text strings found in the Tracebit plugin views that need to be converted to `app_lang()` calls for proper multi-language support.

## Dashboard View (`plugins/Tracebit/Views/tracker/index.php`)

### ❌ **Hardcoded Text Found (Lines 115-200)**

#### Main Header
```php
// Line 115
<h1><i data-feather="activity" class="icon-16 mr10"></i>Dashboard</h1>

// Line 120-121
<strong>Database Setup Required</strong><br>
Please run the tracker database schema to enable check-in functionality.
```

#### Overview Cards
```php
// Line 145
<p><strong>Total time tracked</strong></p>

// Line 153
<p><strong>Productivity</strong></p>

// Line 161
<p><strong>Project Time</strong></p>

// Line 169
<p><strong>Idle Times</strong></p>

// Line 177
<p><strong>Manual Time</strong></p>

// Line 185
<p><strong>Away Time</strong></p>
```

#### Recent Screenshots Section
```php
// Line 193
<p><strong><i data-feather="camera" class="icon-16 mr5"></i>Recent snapshots</strong></p>

// Line 194
<a href="<?php echo get_uri('tracebit/tracker/screenshots'); ?>"><i data-feather="external-link" class="icon-12 mr5"></i>All snapshots</a>
```

#### Team Activity Section
```php
// Line 250
<p><strong><i data-feather="users" class="icon-16 mr5"></i>Team Activity</strong></p>
<small class="text-muted">Real-time status</small>

// Line 300-305 (Status text in PHP)
<?php if($status === 'active') echo 'Currently working';
      elseif($status === 'leave') echo 'On leave';
      elseif($status === 'absent') echo 'Not checked in';
      else echo 'Inactive'; ?>
```

#### Attendance Recap Widget
```php
// Line 320
<p><strong><i data-feather="check" class="icon-16 mr5"></i>Attendance Recap</strong></p>
<a href="<?php echo get_uri('tracebit/tracker/attendance'); ?>"><i data-feather="external-link" class="icon-12 mr5"></i>Current Month</a>

// Line 340-360 (Summary items)
<span class="project-name">
    <i data-feather="calendar" class="icon-12 mr5 text-primary"></i>
    Workable Days
</span>

<span class="project-name">
    <i data-feather="check" class="icon-12 mr5 text-success"></i>
    Present Days
</span>

<span class="project-name">
    <i data-feather="x" class="icon-12 mr5 text-danger"></i>
    Absent Days
</span>

<span class="project-name">
    <i data-feather="clock" class="icon-12 mr5 text-warning"></i>
    Late Arrivals
</span>

<span class="project-name">
    <i data-feather="calendar" class="icon-12 mr5 text-info"></i>
    Leave Days
</span>
```

#### Project Recap Widget
```php
// Line 370
<p><strong><i data-feather="bar-chart-2" class="icon-16 mr5"></i>Project Recap</strong></p>

// Line 375-380 (Filter buttons)
<a href="javascript:void(0)" class="filter-btn active" data-filter="weekly">
    <i data-feather="calendar" class="icon-12 mr5"></i>Weekly
</a>
<a href="javascript:void(0)" class="filter-btn" data-filter="monthly">
    <i data-feather="calendar" class="icon-12 mr5"></i>Monthly
</a>

// Line 400-410 (Project status)
<span class="project-status <?php echo strtolower($project['status']); ?>">
    <?php echo ucfirst($project['status']); ?>
</span>

<span class="project-leader">
    <i data-feather="star" class="icon-10"></i>Leader
</span>

// Line 420-430 (More projects)
<?php echo count($project_recap_data['projects']) - 5; ?> more projects

// Line 440-450 (No project activity)
<span class="project-name">
    <i data-feather="info" class="icon-12 mr5"></i>
    No project activity
</span>
```

## Settings Views

### ❌ **Hardcoded Text Found in Settings**

#### Main Settings (`plugins/Tracebit/Views/settings/index.php`)
```php
// Line 30-50 (Tab labels)
<a class="nav-link active" id="app-settings-tab" data-bs-toggle="tab" href="#app-settings" role="tab">
    <i data-feather="settings" class="icon-16"></i> App Settings
</a>
<a class="nav-link" id="web-settings-tab" data-bs-toggle="tab" href="#web-settings" role="tab">
    <i data-feather="monitor" class="icon-16"></i> Web Settings
</a>
<a class="nav-link" id="break-settings-tab" data-bs-toggle="tab" href="#break-settings" role="tab">
    <i data-feather="coffee" class="icon-16"></i> Break Settings
</a>
<a class="nav-link" id="weekend-settings-tab" data-bs-toggle="tab" href="#weekend-settings" role="tab">
    <i data-feather="calendar" class="icon-16"></i> Weekend Settings
</a>
<a class="nav-link" id="holidays-settings-tab" data-bs-toggle="tab" href="#holidays-settings" role="tab">
    <i data-feather="sun" class="icon-16"></i> Holiday Settings
</a>
```

#### App Settings Tab (`plugins/Tracebit/Views/settings/tabs/app_settings.php`)
```php
// Line 10
<h5>Application Settings</h5>

// Line 20-25 (Form labels)
<label for="idle_timeout">Idle Timeout (seconds):</label>
<small class="form-text text-muted">Idle detection timeout in seconds</small>

<label for="auto_update_time">Auto Update Time (seconds):</label>
<small class="form-text text-muted">Idle detection timeout in seconds</small>

<label for="working_hours_start">Work Day Start Time:</label>
<label for="working_hours_end">Work Day End Time:</label>

// Line 40-50 (Feature toggles)
<h6 class="mt-4 mb-3">Feature Toggles</h6>
<label class="form-check-label" for="enable_screenshots">Enable Screenshot Capture</label>
<label class="form-check-label" for="screen_shot_on_break">Enable Screenshot on Break</label>
<label class="form-check-label" for="enable_activity_tracking">Enable Activity Tracking</label>
<label class="form-check-label" for="enable_idle_detection">Enable Idle Detection</label>
<label class="form-check-label" for="productivity_tracking">Enable Productivity Tracking</label>

// Line 60-70 (Screenshot settings)
<h6 class="mt-4 mb-3">Screenshot & Performance Settings</h6>
<label for="screenshot_interval">Screenshot Interval (seconds):</label>
<small class="form-text text-muted">Screenshot capture interval in seconds</small>

<label for="screenshot_quality">Screenshot Quality (1-100):</label>
<label for="screenshot_width">Screenshot width size:</label>
<label for="screenshot_height">Screenshot height:</label>
<label for="max_screenshot_size">Max Screenshot Size (bytes):</label>
<small class="form-text text-muted">Maximum screenshot size (default: 5MB)</small>

// Line 80-90 (Performance settings)
<h6 class="mt-4 mb-3">Performance & Monitoring</h6>
<label for="performance_threshold">Performance Threshold (%):</label>

// Line 100-110 (Buttons)
<span class="btn-text">Save App Settings</span>
<span class="btn-loader d-none">
    <span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
    Saving...
</span>
```

#### Web Settings Tab (`plugins/Tracebit/Views/settings/tabs/web_settings.php`)
```php
// Line 10
<h5>Desktop App & Interface Settings</h5>

// Line 25
<h6 class="mt-3 mb-3">Display Settings</h6>

// Line 35
<label class="form-check-label" for="dashboard_checkin">Dashboard CheckIn ON-Off</label>

// Line 45
<button type="submit" class="btn btn-primary"><span data-feather="check-circle" class="icon-16"></span> Save Interface Settings</button>
```

#### Break Settings Tab (`plugins/Tracebit/Views/settings/tabs/break_settings.php`)
```php
// Line 10
<h5>Break Settings</h5>

// Line 20-25 (Card header)
<h6 class="mb-0">Break List</h6>
<button type="button" id="refresh-break-list" class="btn btn-default btn-sm me-2">
    <i data-feather="refresh-cw" class="icon-16"></i> Refresh
</button>
<?php echo modal_anchor(get_uri("tracebit/tracker_breaks/modal_form"), "<i data-feather='plus-circle' class='icon-16'></i> Add Break", array("class" => "btn btn-primary btn-sm", "title" => "Add Break", "data-post-id" => "")); ?>

// Line 35-45 (Table headers)
<th>Break Name</th>
<th>Value</th>
<th>Icon</th>
<th>Description</th>
<th>Is Minus Break</th>
<th>Max Time</th>
<th class="text-center">Actions</th>
```

## Timesheet View (`plugins/Tracebit/Views/tracker/timeSheet.php`)

### ❌ **Hardcoded Text Found**

#### Summary Statistics
```php
// Line 29-45
<span class="summary-label">Workable Days</span>
<span class="summary-label">Present Days</span>
<span class="summary-label">Absent Days</span>
<span class="summary-label">Weekend Days</span>
<span class="summary-label">Leave/Holiday</span>
<span class="summary-label">Worked Hours</span>
<span class="summary-label">Estimate Hours</span>
<span class="summary-label">Overtime</span>
<span class="summary-label">Due Hours</span>
```

#### Filter Section
```php
// Line 60-70
<label for="user-filter"><strong>Select User:</strong></label>
<option value="">All Users</option>
<label for="month-filter"><strong>Select Month:</strong></label>
<button type="button" class="btn btn-primary" id="apply-filter">Apply Filter</button>
<button type="button" class="btn btn-secondary" id="reset-filter">Reset</button>
```

#### JavaScript Content
```php
// Line 230-240
title: "Manual Time",

// Line 430-440
status = "<span class='badge bg-secondary' data-status='on_leave'>On Leave</span>";

// Line 440-450
manualTime = "<i data-feather='edit-3' class='text-warning' style='width:16px;height:16px;' title='Add Manual Time'></i>";
manualTime = "<i data-feather='edit-3' class='text-danger' style='width:16px;height:16px;' title='Add Manual Time'></i>";
manualTime = "<i data-feather='edit-3' class='text-success' style='width:16px;height:16px;' title='Add Manual Time'></i>";
```

## JavaScript Messages

### ❌ **Hardcoded Text in JavaScript**

#### Success Messages
```javascript
"Settings saved successfully!"
"Web settings saved successfully!"
"App settings saved successfully!"
```

#### Error Messages
```javascript
"Failed to save settings"
"An error occurred while saving settings"
"Failed to save web settings"
"An error occurred while saving web settings"
"Failed to save app settings"
"An error occurred while saving app settings"
```

#### Confirmation Messages
```javascript
"This will initialize all default settings. Are you sure?"
"An error occurred while initializing settings"
```

#### Loading States
```javascript
"Saving..."
```

## Required Actions

### 1. **Immediate Fixes Needed**

All hardcoded text strings identified above need to be replaced with `app_lang()` calls:

```php
// ❌ Before (Hardcoded)
<h1>Dashboard</h1>

// ✅ After (Multi-language)
<h1><?php echo app_lang("dashboard"); ?></h1>
```

### 2. **Files to Update**

1. **`plugins/Tracebit/Views/tracker/index.php`** - Main dashboard view
2. **`plugins/Tracebit/Views/settings/index.php`** - Main settings view
3. **`plugins/Tracebit/Views/settings/tabs/app_settings.php`** - App settings tab
4. **`plugins/Tracebit/Views/settings/tabs/web_settings.php`** - Web settings tab
5. **`plugins/Tracebit/Views/settings/tabs/break_settings.php`** - Break settings tab
6. **`plugins/Tracebit/Views/tracker/timeSheet.php`** - Timesheet view

### 3. **Translation Keys Already Available**

All the required translation keys are already present in the language files:
- English: Complete coverage
- Dutch: Complete coverage
- Other languages: Basic coverage, needs new additions

### 4. **Priority Order**

1. **High Priority**: Dashboard main view (most visible to users)
2. **Medium Priority**: Settings views (administrative interface)
3. **Low Priority**: JavaScript messages (user feedback)

## Implementation Example

### Before (Hardcoded)
```php
<div class="card tracker-overview">
    <article>
        <p><strong>Total time tracked</strong></p>
        <p><?php echo $total_working_time; ?></p>
    </article>
</div>
```

### After (Multi-language)
```php
<div class="card tracker-overview">
    <article>
        <p><strong><?php echo app_lang("total_time_tracked"); ?></strong></p>
        <p><?php echo $total_working_time; ?></p>
    </article>
</div>
```

## Conclusion

The Tracebit plugin has comprehensive multi-language support in the language files, but the views still contain significant amounts of hardcoded text that prevents users from seeing the interface in their preferred language.

**Total hardcoded strings identified**: 50+ text elements
**Files requiring updates**: 6 main view files
**Translation keys available**: 100% coverage in language files

Converting all hardcoded text to `app_lang()` calls will provide complete multi-language support and significantly improve the user experience for international users.
