/**
 * Tracebit Plugin - Responsive JavaScript Enhancements
 * Enhances mobile and tablet experience with better interactions
 */

(function($) {
    'use strict';

    // Responsive utility functions
    const TracebitResponsive = {
        
        // Initialize responsive features
        init: function() {
            this.detectDevice();
            this.setupMobileNavigation();
            this.setupTouchInteractions();
            this.setupResponsiveTables();
            this.setupMobileFilters();
            this.setupResponsiveCharts();
            this.setupMobileModals();
            this.setupScrollOptimizations();
        },

        // Detect device type and set appropriate classes
        detectDevice: function() {
            const isMobile = window.innerWidth <= 767;
            const isTablet = window.innerWidth > 767 && window.innerWidth <= 1023;
            const isDesktop = window.innerWidth > 1023;

            $('body').removeClass('device-mobile device-tablet device-desktop');
            
            if (isMobile) {
                $('body').addClass('device-mobile');
            } else if (isTablet) {
                $('body').addClass('device-tablet');
            } else {
                $('body').addClass('device-desktop');
            }

            // Store device info for other functions
            this.deviceInfo = {
                isMobile: isMobile,
                isTablet: isTablet,
                isDesktop: isDesktop,
                width: window.innerWidth
            };
        },

        // Setup mobile navigation enhancements
        setupMobileNavigation: function() {
            if (!this.deviceInfo.isMobile) return;

            // Enhance left sidebar menu on mobile
            const $sidebar = $('.sidebar-menu');
            if ($sidebar.length) {
                // Add mobile menu toggle for submenus
                $sidebar.find('.has-submenu > a').append('<span class="submenu-toggle"><i class="fa fa-chevron-down"></i></span>');
                
                // Handle submenu toggles on mobile
                $sidebar.find('.submenu-toggle').on('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    const $parent = $(this).closest('li');
                    const $submenu = $parent.find('.submenu');
                    
                    $parent.toggleClass('submenu-open');
                    $submenu.slideToggle(200);
                });

                // Close other submenus when one is opened
                $sidebar.find('.submenu-toggle').on('click', function() {
                    const $currentParent = $(this).closest('li');
                    $sidebar.find('li.submenu-open').not($currentParent).removeClass('submenu-open').find('.submenu').slideUp(200);
                });
            }

            // Mobile menu toggle for complex navigation
            $('.mobile-menu-toggle').on('click', function(e) {
                e.preventDefault();
                $(this).toggleClass('active');
                $('.mobile-menu').toggleClass('active');
            });
        },

        // Setup touch-friendly interactions
        setupTouchInteractions: function() {
            if (!this.deviceInfo.isMobile) return;

            // Better touch feedback for buttons
            $('.btn, .form-control, .form-select').on('touchstart', function() {
                $(this).addClass('touch-active');
            }).on('touchend touchcancel', function() {
                $(this).removeClass('touch-active');
            });

            // Swipe gestures for navigation
            let startX = 0;
            let startY = 0;
            let endX = 0;
            let endY = 0;

            $('.tracker-dashboard').on('touchstart', function(e) {
                startX = e.originalEvent.touches[0].clientX;
                startY = e.originalEvent.touches[0].clientY;
            }).on('touchend', function(e) {
                endX = e.originalEvent.changedTouches[0].clientX;
                endY = e.originalEvent.changedTouches[0].clientY;
                
                const diffX = startX - endX;
                const diffY = startY - endY;
                
                // Horizontal swipe detection
                if (Math.abs(diffX) > Math.abs(diffY) && Math.abs(diffX) > 50) {
                    if (diffX > 0) {
                        // Swipe left - could be used for next/previous navigation
                        $(this).trigger('swipeleft');
                    } else {
                        // Swipe right
                        $(this).trigger('swiperight');
                    }
                }
            });
        },

        // Setup responsive tables
        setupResponsiveTables: function() {
            if (!this.deviceInfo.isMobile) return;

            // Enhance DataTables mobile experience
            if ($.fn.DataTable) {
                $('.dataTable').each(function() {
                    const $table = $(this);
                    const $wrapper = $table.closest('.dataTables_wrapper');
                    
                    // Add mobile-friendly controls
                    if (!$wrapper.find('.mobile-table-controls').length) {
                        $wrapper.prepend(`
                            <div class="mobile-table-controls" style="margin-bottom: 15px;">
                                <div class="row">
                                    <div class="col-6">
                                        <select class="form-control form-control-sm mobile-page-size">
                                            <option value="5">5 rows</option>
                                            <option value="10" selected>10 rows</option>
                                            <option value="25">25 rows</option>
                                        </select>
                                    </div>
                                    <div class="col-6">
                                        <input type="text" class="form-control form-control-sm mobile-search" placeholder="Search...">
                                    </div>
                                </div>
                            </div>
                        `);
                    }

                    // Handle mobile page size changes
                    $wrapper.find('.mobile-page-size').on('change', function() {
                        const pageSize = parseInt($(this).val());
                        if ($table.DataTable) {
                            $table.DataTable().page.len(pageSize).draw();
                        }
                    });

                    // Handle mobile search
                    $wrapper.find('.mobile-search').on('input', function() {
                        const searchTerm = $(this).val();
                        if ($table.DataTable) {
                            $table.DataTable().search(searchTerm).draw();
                        }
                    });
                });
            }
        },

        // Setup mobile-friendly filters
        setupMobileFilters: function() {
            if (!this.deviceInfo.isMobile) return;

            // Enhance filter sections for mobile
            $('.filter-section').each(function() {
                const $section = $(this);
                
                // Add mobile filter toggle
                if (!$section.find('.mobile-filter-toggle').length) {
                    $section.prepend(`
                        <div class="mobile-filter-toggle" style="margin-bottom: 15px;">
                            <button type="button" class="btn btn-outline-primary btn-sm w-100" data-toggle="collapse" data-target="#mobile-filters-${$section.index()}">
                                <i class="fa fa-filter"></i> Show/Hide Filters
                            </button>
                        </div>
                    `);
                    
                    // Wrap filter groups in collapsible container
                    const $filterGroups = $section.find('.filter-group').parent();
                    $filterGroups.wrap('<div class="collapse" id="mobile-filters-' + $section.index() + '"></div>');
                }
            });

            // Mobile-friendly date pickers
            $('input[type="date"], input[type="month"]').each(function() {
                const $input = $(this);
                if (this.deviceInfo.isMobile) {
                    $input.attr('type', 'date'); // Force date type on mobile for better UX
                }
            });
        },

        // Setup responsive charts
        setupResponsiveCharts: function() {
            // Resize charts on window resize
            $(window).on('resize', $.throttle(250, function() {
                this.resizeCharts();
            }.bind(this)));

            // Initial chart resize
            this.resizeCharts();
        },

        // Resize all charts to fit container
        resizeCharts: function() {
            $('canvas').each(function() {
                const $canvas = $(this);
                const $container = $canvas.closest('.chart-container, .doughnutchart-inner');
                
                if ($container.length) {
                    const containerWidth = $container.width();
                    const containerHeight = $container.height();
                    
                    // Maintain aspect ratio
                    const aspectRatio = 1; // Assuming square charts
                    const size = Math.min(containerWidth, containerHeight);
                    
                    $canvas.css({
                        'width': size + 'px',
                        'height': size + 'px',
                        'max-width': '100%',
                        'max-height': '100%'
                    });
                }
            });
        },

        // Setup mobile modal enhancements
        setupMobileModals: function() {
            if (!this.deviceInfo.isMobile) return;

            // Enhance modal positioning on mobile
            $('.modal').on('show.bs.modal', function() {
                const $modal = $(this);
                const $dialog = $modal.find('.modal-dialog');
                
                // Center modal on mobile
                $dialog.css({
                    'margin': '10px auto',
                    'max-width': 'calc(100% - 20px)'
                });
            });

            // Better mobile modal scrolling
            $('.modal-body').css({
                'max-height': '60vh',
                'overflow-y': 'auto',
                '-webkit-overflow-scrolling': 'touch'
            });
        },

        // Setup scroll optimizations
        setupScrollOptimizations: function() {
            if (!this.deviceInfo.isMobile) return;

            // Smooth scrolling for mobile
            $('html').css('scroll-behavior', 'smooth');

            // Optimize scroll performance
            $('.tracker-dashboard, .table-responsive').css({
                '-webkit-overflow-scrolling': 'touch',
                'scroll-behavior': 'smooth'
            });

            // Lazy load images for better performance
            if ('IntersectionObserver' in window) {
                const imageObserver = new IntersectionObserver((entries, observer) => {
                    entries.forEach(entry => {
                        if (entry.isIntersecting) {
                            const img = entry.target;
                            img.src = img.dataset.src || img.src;
                            img.classList.remove('lazy');
                            observer.unobserve(img);
                        }
                    });
                });

                $('img[data-src]').each(function() {
                    imageObserver.observe(this);
                });
            }
        },

        // Utility function to check if element is in viewport
        isInViewport: function(element) {
            const rect = element.getBoundingClientRect();
            return (
                rect.top >= 0 &&
                rect.left >= 0 &&
                rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
                rect.right <= (window.innerWidth || document.documentElement.clientWidth)
            );
        },

        // Debounce function for performance
        debounce: function(func, wait, immediate) {
            let timeout;
            return function() {
                const context = this, args = arguments;
                const later = function() {
                    timeout = null;
                    if (!immediate) func.apply(context, args);
                };
                const callNow = immediate && !timeout;
                clearTimeout(timeout);
                timeout = setTimeout(later, wait);
                if (callNow) func.apply(context, args);
            };
        }
    };

    // Throttle function for performance
    $.throttle = function(delay, callback) {
        let lastCall = 0;
        return function() {
            const now = Date.now();
            if (now - lastCall >= delay) {
                lastCall = now;
                callback.apply(this, arguments);
            }
        };
    };

    // Initialize when document is ready
    $(document).ready(function() {
        TracebitResponsive.init();
    });

    // Re-initialize on window resize
    $(window).on('resize', $.throttle(250, function() {
        TracebitResponsive.detectDevice();
    }));

    // Make TracebitResponsive available globally
    window.TracebitResponsive = TracebitResponsive;

})(jQuery);
