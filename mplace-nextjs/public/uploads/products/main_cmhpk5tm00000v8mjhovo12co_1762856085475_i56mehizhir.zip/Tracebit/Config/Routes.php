<?php

// Tracebit Plugin Routes
// Note: $routes variable is provided by the main Routes.php file

$routes->get('tracebit/api/getSettingsData', 'Native_app_controller::getSettingsData', ['namespace' => 'Tracebit\Controllers']);
$routes->get('tracebit/api/user_info', 'Native_app_controller::user_info', ['namespace' => 'Tracebit\Controllers']);
$routes->get('tracebit/api/projects', 'Native_app_controller::getProjects', ['namespace' => 'Tracebit\Controllers']);
$routes->get('tracebit/api/user_projects', 'Native_app_controller::getProjects', ['namespace' => 'Tracebit\Controllers']);
$routes->get('tracebit/api/authentication', 'Native_app_controller::authenticate', ['namespace' => 'Tracebit\Controllers']);
$routes->post('tracebit/api/synced', 'Native_app_controller::synced', ['namespace' => 'Tracebit\Controllers']);
$routes->post('tracebit/api/createScreenshot', 'Native_app_controller::createScreenshot', ['namespace' => 'Tracebit\Controllers']);
$routes->post('tracebit/api/create_status', 'Native_app_controller::create_status', ['namespace' => 'Tracebit\Controllers']);
$routes->post('tracebit/api/addProject', 'Native_app_controller::addProject', ['namespace' => 'Tracebit\Controllers']);

// Tracebit Settings API Routes
$routes->get('tracebit/api/getTrackerSettings', 'Native_app_controller::getTrackerSettings', ['namespace' => 'Tracebit\Controllers']);
$routes->get('tracebit/api/getTrackerSettings/(:any)', 'Native_app_controller::getTrackerSettings/$1', ['namespace' => 'Tracebit\Controllers']);
$routes->post('tracebit/api/updateTrackerSettings', 'Native_app_controller::updateTrackerSettings', ['namespace' => 'Tracebit\Controllers']);

// Tracebit Breaks API Routes
$routes->get('tracebit/api/breaks', 'Breaks_api_controller::index', ['namespace' => 'Tracebit\Controllers']);
$routes->get('tracebit/api/breaks/defaults', 'Breaks_api_controller::defaults', ['namespace' => 'Tracebit\Controllers']);
$routes->post('tracebit/api/breaks', 'Breaks_api_controller::create', ['namespace' => 'Tracebit\Controllers']);
$routes->get('tracebit/api/breaks/(:num)', 'Breaks_api_controller::show/$1', ['namespace' => 'Tracebit\Controllers']);
$routes->put('tracebit/api/breaks/(:num)', 'Breaks_api_controller::update/$1', ['namespace' => 'Tracebit\Controllers']);
$routes->post('tracebit/api/breaks/(:num)', 'Breaks_api_controller::update/$1', ['namespace' => 'Tracebit\Controllers']); // Support POST for FormData
$routes->delete('tracebit/api/breaks/(:num)', 'Breaks_api_controller::delete/$1', ['namespace' => 'Tracebit\Controllers']);

// Tracebit Storage Management Routes
$routes->post('tracebit/storage/preview', 'Storage_controller::preview', ['namespace' => 'Tracebit\Controllers']);
$routes->post('tracebit/storage/execute', 'Storage_controller::execute', ['namespace' => 'Tracebit\Controllers']);
$routes->get('tracebit/storage/stats', 'Storage_controller::stats', ['namespace' => 'Tracebit\Controllers']);
$routes->get('tracebit/storage/download/(:any)', 'Storage_controller::download/$1', ['namespace' => 'Tracebit\Controllers']);

// Storage Management Page Route
$routes->get('tracebit/storage_management', 'Storage_management_controller::index', ['namespace' => 'Tracebit\Controllers']);

// Tracebit Invalid Apps API Routes
$routes->post('tracebit/api/report_invalid_app', 'InvalidAppController::report_invalid_app', ['namespace' => 'Tracebit\Controllers']);
$routes->get('tracebit/api/send_message', 'InvalidAppController::send_message', ['namespace' => 'Tracebit\Controllers']);
$routes->get('tracebit/invalid_app/get_user_invalid_apps', 'InvalidAppController::get_user_invalid_apps', ['namespace' => 'Tracebit\Controllers']);
$routes->get('tracebit/invalid_app/admin_dashboard', 'InvalidAppController::admin_dashboard', ['namespace' => 'Tracebit\Controllers']);
$routes->post('tracebit/invalid_app/admin_get_invalid_apps', 'InvalidAppController::admin_get_invalid_apps', ['namespace' => 'Tracebit\Controllers']);
$routes->post('tracebit/invalid_app/update_invalid_app_status', 'InvalidAppController::update_invalid_app_status', ['namespace' => 'Tracebit\Controllers']);
$routes->post('tracebit/invalid_app/delete_invalid_app', 'InvalidAppController::delete_invalid_app', ['namespace' => 'Tracebit\Controllers']);
$routes->get('tracebit/invalid_app/get_statistics', 'InvalidAppController::get_statistics', ['namespace' => 'Tracebit\Controllers']);

$routes->get('tracebit', 'Tracker::index', ['namespace' => 'Tracebit\Controllers']);
$routes->get('tracebit/screenshots', 'Tracker::screenshots', ['namespace' => 'Tracebit\Controllers']);
$routes->post('tracebit/screenshots', 'Tracker::screenshots', ['namespace' => 'Tracebit\Controllers']);
$routes->get('tracebit/attendance', 'Tracker::attendance', ['namespace' => 'Tracebit\Controllers']);
$routes->post('tracebit/attendance', 'Tracker::attendance', ['namespace' => 'Tracebit\Controllers']);
$routes->get('tracebit/timesheet', 'Tracker::timeSheet', ['namespace' => 'Tracebit\Controllers']);
$routes->post('tracebit/timesheet', 'Tracker::timeSheet', ['namespace' => 'Tracebit\Controllers']);
$routes->get('tracebit/activity-log', 'Tracker::activityLog', ['namespace' => 'Tracebit\Controllers']);
$routes->post('tracebit/activity-log', 'Tracker::activityLog', ['namespace' => 'Tracebit\Controllers']);

// Dashboard attendance routes
$routes->post('tracebit/tracker/clock_toggle', 'Tracker::clock_toggle', ['namespace' => 'Tracebit\Controllers']);
$routes->get('tracebit/tracker/get_attendance_status', 'Tracker::get_attendance_status', ['namespace' => 'Tracebit\Controllers']);
$routes->get('tracebit/tracker/test_database', 'Tracker::test_database', ['namespace' => 'Tracebit\Controllers']);

$routes->get('tracebit/employee_status', 'Employee_status::index', ['namespace' => 'Tracebit\Controllers']);
$routes->get('tracebit/employee_status/get_status_counts', 'Employee_status::get_status_counts', ['namespace' => 'Tracebit\Controllers']);
$routes->get('tracebit/get_attendance_list', 'Employee_status::get_attendance_list', ['namespace' => 'Tracebit\Controllers']);
$routes->post('tracebit/get_attendance_list', 'Employee_status::get_attendance_list', ['namespace' => 'Tracebit\Controllers']);
$routes->get('tracebit/get_timesheet_list', 'Employee_status::get_timesheet_list', ['namespace' => 'Tracebit\Controllers']);
$routes->post('tracebit/get_timesheet_list', 'Employee_status::get_timesheet_list', ['namespace' => 'Tracebit\Controllers']);
$routes->get('tracebit/get_timeSheet_list', 'Employee_status::get_timeSheet_list', ['namespace' => 'Tracebit\Controllers']);
$routes->post('tracebit/get_timeSheet_list', 'Employee_status::get_timeSheet_list', ['namespace' => 'Tracebit\Controllers']);
$routes->get('tracebit/get_timesheet_summary', 'Employee_status::get_timesheet_summary', ['namespace' => 'Tracebit\Controllers']);
$routes->post('tracebit/get_timesheet_summary', 'Employee_status::get_timesheet_summary', ['namespace' => 'Tracebit\Controllers']);
$routes->get('tracebit/get_session_data', 'Employee_status::get_session_data', ['namespace' => 'Tracebit\Controllers']);
$routes->post('tracebit/get_session_data', 'Employee_status::get_session_data', ['namespace' => 'Tracebit\Controllers']);
$routes->get('tracebit/sessions_modal_form', 'Employee_status::sessions_modal_form', ['namespace' => 'Tracebit\Controllers']);
$routes->post('tracebit/sessions_modal_form', 'Employee_status::sessions_modal_form', ['namespace' => 'Tracebit\Controllers']);
$routes->get('tracebit/manual_time_modal_form', 'Employee_status::manual_time_modal_form', ['namespace' => 'Tracebit\Controllers']);
$routes->post('tracebit/manual_time_modal_form', 'Employee_status::manual_time_modal_form', ['namespace' => 'Tracebit\Controllers']);
$routes->post('tracebit/save_manual_time', 'Employee_status::save_manual_time', ['namespace' => 'Tracebit\Controllers']);
$routes->post('tracebit/delete_session', 'Employee_status::delete_session', ['namespace' => 'Tracebit\Controllers']);
$routes->get('tracebit/get_activityLog_list', 'Employee_status::get_activityLog_list', ['namespace' => 'Tracebit\Controllers']);
$routes->post('tracebit/get_activityLog_list', 'Employee_status::get_activityLog_list', ['namespace' => 'Tracebit\Controllers']);

$routes->get('tracebit/tracker', 'Tracker::index', ['namespace' => 'Tracebit\Controllers']);
$routes->post('tracebit/tracker', 'Tracker::index', ['namespace' => 'Tracebit\Controllers']);
$routes->get('tracebit/tracker/(:any)', 'Tracker::$1', ['namespace' => 'Tracebit\Controllers']);
$routes->post('tracebit/tracker/(:any)', 'Tracker::$1', ['namespace' => 'Tracebit\Controllers']);

$routes->get('tracebit/tracker_settings', 'Tracker_settings::index', ['namespace' => 'Tracebit\Controllers']);
$routes->get('tracebit/tracker_settings/(:any)', 'Tracker_settings::$1', ['namespace' => 'Tracebit\Controllers']);
$routes->post('tracebit/tracker_settings/(:any)', 'Tracker_settings::$1', ['namespace' => 'Tracebit\Controllers']);

// break settings
$routes->post('tracebit/tracker_breaks/list_data', 'Tracker_breaks::list_data', ['namespace' => 'Tracebit\Controllers']);
$routes->post('tracebit/tracker_breaks/modal_form', 'Tracker_breaks::modal_form', ['namespace' => 'Tracebit\Controllers']);
$routes->post('tracebit/tracker_breaks/save', 'Tracker_breaks::save', ['namespace' => 'Tracebit\Controllers']);
$routes->get('tracebit/tracker_breaks/get/(:num)', 'Tracker_breaks::get/$1', ['namespace' => 'Tracebit\Controllers']);
$routes->post('tracebit/tracker_breaks/delete', 'Tracker_breaks::delete', ['namespace' => 'Tracebit\Controllers']);

// Register tracker_settings routes
$routes->add('tracebit/tracker_settings', 'Tracker_settings::index', ['namespace' => 'Tracebit\Controllers']);
$routes->add('tracebit/tracker_settings/save', 'Tracker_settings::save', ['namespace' => 'Tracebit\Controllers']);
$routes->add('tracebit/tracker_settings/save_by_type', 'Tracker_settings::save_by_type', ['namespace' => 'Tracebit\Controllers']);
$routes->add('tracebit/tracker_settings/public_test', 'Tracker_settings::public_test', ['namespace' => 'Tracebit\Controllers']);
$routes->get('tracebit/tracker_settings/public_test', 'Tracker_settings::public_test', ['namespace' => 'Tracebit\Controllers']);
$routes->post('tracebit/tracker_settings/public_test', 'Tracker_settings::public_test', ['namespace' => 'Tracebit\Controllers']);
$routes->add('tracebit/tracker_settings/get_by_type', 'Tracker_settings::get_by_type', ['namespace' => 'Tracebit\Controllers']);
$routes->add('tracebit/tracker_settings/test_endpoint', 'Tracker_settings::test_endpoint', ['namespace' => 'Tracebit\Controllers']);
$routes->post('tracebit/tracker_settings/initialize_defaults', 'Tracker_settings::initialize_defaults', ['namespace' => 'Tracebit\Controllers']);

// Register tracker_holidays routes with proper namespacing
$routes->add('tracebit/tracker_holidays', 'Tracker_holidays::index', ['namespace' => 'Tracebit\Controllers']);
$routes->add('tracebit/tracker_holidays/list_data', 'Tracker_holidays::list_data', ['namespace' => 'Tracebit\Controllers']);
$routes->post('tracebit/tracker_holidays/list_data', 'Tracker_holidays::list_data', ['namespace' => 'Tracebit\Controllers']); // Explicit POST route
$routes->add('tracebit/tracker_holidays/modal_form', 'Tracker_holidays::modal_form', ['namespace' => 'Tracebit\Controllers']);
$routes->post('tracebit/tracker_holidays/modal_form', 'Tracker_holidays::modal_form', ['namespace' => 'Tracebit\Controllers']); // Explicit POST route
$routes->add('tracebit/tracker_holidays/save', 'Tracker_holidays::save', ['namespace' => 'Tracebit\Controllers']);
$routes->post('tracebit/tracker_holidays/save', 'Tracker_holidays::save', ['namespace' => 'Tracebit\Controllers']); // Explicit POST route
$routes->add('tracebit/tracker_holidays/delete', 'Tracker_holidays::delete', ['namespace' => 'Tracebit\Controllers']);
$routes->post('tracebit/tracker_holidays/delete', 'Tracker_holidays::delete', ['namespace' => 'Tracebit\Controllers']); // Explicit POST route
$routes->add('tracebit/tracker_holidays/get_holidays_by_date', 'Tracker_holidays::get_holidays_by_date', ['namespace' => 'Tracebit\Controllers']);
$routes->post('tracebit/tracker_holidays/get_holidays_by_date', 'Tracker_holidays::get_holidays_by_date', ['namespace' => 'Tracebit\Controllers']); // Explicit POST route
$routes->add('tracebit/tracker_holidays/save_from_settings', 'Tracker_holidays::save_from_settings', ['namespace' => 'Tracebit\Controllers']);
$routes->post('tracebit/tracker_holidays/save_from_settings', 'Tracker_holidays::save_from_settings', ['namespace' => 'Tracebit\Controllers']); // Explicit POST route
