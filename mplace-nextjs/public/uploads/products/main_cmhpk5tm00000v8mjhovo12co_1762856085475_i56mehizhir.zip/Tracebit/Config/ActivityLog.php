<?php

namespace Tracebit\Config;

/**
 * Activity Log Configuration
 * Centralized configuration for Activity Log module
 */
class ActivityLog {
    
    /**
     * Cache settings
     */
    public $cache = [
        'enabled' => true,
        'default_ttl' => 300, // 5 minutes
        'employee_summary_ttl' => 600, // 10 minutes
        'tracker_settings_ttl' => 3600, // 1 hour
        'date_range_info_ttl' => 1800, // 30 minutes
    ];
    
    /**
     * Performance settings
     */
    public $performance = [
        'max_date_range_days' => 365,
        'query_timeout' => 30, // seconds
        'memory_limit_warning_percent' => 80,
        'slow_query_threshold' => 2.0, // seconds
        'batch_size' => 1000, // for large datasets
    ];
    
    /**
     * Database optimization settings
     */
    public $database = [
        'use_prepared_statements' => true,
        'connection_timeout' => 10,
        'read_timeout' => 30,
        'retry_attempts' => 3,
        'retry_delay' => 1, // seconds
    ];
    
    /**
     * Default working hours and time settings
     */
    public $work_settings = [
        'default_working_hours_start' => '09:00',
        'default_working_hours_end' => '18:00',
        'default_daily_worked_time' => 8.0,
        'default_break_duration' => 1.0, // hours
        'timezone' => 'Asia/Dhaka',
        'weekend_days' => [0, 6], // Sunday, Saturday
    ];
    
    /**
     * UI and display settings
     */
    public $ui = [
        'default_page_size' => 25,
        'max_page_size' => 100,
        'date_format' => 'Y-m-d',
        'time_format' => 'H:i:s',
        'show_avatars' => true,
        'avatar_size' => 32,
        'highlight_late_attendance' => true,
        'highlight_overtime' => true,
    ];
    
    /**
     * Logging and debugging settings
     */
    public $logging = [
        'log_performance_issues' => true,
        'log_cache_operations' => false, // Set to true for debugging
        'log_database_errors' => true,
        'log_memory_usage' => true,
        'debug_mode' => false, // Set to true for development
    ];
    
    /**
     * Security settings
     */
    public $security = [
        'sanitize_sql_logs' => true,
        'hide_sensitive_data_in_logs' => true,
        'max_query_log_length' => 500,
        'validate_date_ranges' => true,
    ];
    
    /**
     * Feature flags
     */
    public $features = [
        'enable_caching' => true,
        'enable_performance_monitoring' => true,
        'enable_database_optimization' => true,
        'enable_memory_monitoring' => true,
        'enable_query_logging' => false, // Enable for debugging
    ];
    
    /**
     * Business logic settings
     */
    public $business = [
        'include_weekends_in_workdays' => false,
        'include_holidays_in_workdays' => false,
        'calculate_overtime_automatically' => true,
        'consider_breaks_as_work_time' => false,
        'late_threshold_minutes' => 15,
        'grace_period_minutes' => 5,
    ];
    
    /**
     * Get configuration value with fallback
     */
    public function get($section, $key, $default = null) {
        if (isset($this->{$section}[$key])) {
            return $this->{$section}[$key];
        }
        return $default;
    }
    
    /**
     * Check if a feature is enabled
     */
    public function isFeatureEnabled($feature) {
        return $this->features[$feature] ?? false;
    }
    
    /**
     * Get cache TTL for specific operation
     */
    public function getCacheTTL($operation) {
        switch ($operation) {
            case 'employee_summary':
                return $this->cache['employee_summary_ttl'];
            case 'tracker_settings':
                return $this->cache['tracker_settings_ttl'];
            case 'date_range_info':
                return $this->cache['date_range_info_ttl'];
            default:
                return $this->cache['default_ttl'];
        }
    }
    
    /**
     * Get working hours configuration
     */
    public function getWorkingHours() {
        return [
            'start' => $this->work_settings['default_working_hours_start'],
            'end' => $this->work_settings['default_working_hours_end'],
            'daily_hours' => $this->work_settings['default_daily_worked_time'],
            'break_duration' => $this->work_settings['default_break_duration'],
            'timezone' => $this->work_settings['timezone'],
            'weekend_days' => $this->work_settings['weekend_days'],
        ];
    }
}
