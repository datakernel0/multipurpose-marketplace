<?php

namespace Tracebit\Config;

use CodeIgniter\Config\BaseConfig;
use Tracebit\Models\Tracker_settings_model;

class Tracker extends BaseConfig {

    public $app_settings_array = array(
        "tracker_file_path" => "plugins/Tracebit/files/demo_files/"
    );

    private static $loading_settings = false; // Recursion guard

    public function __construct() {
        // Prevent infinite recursion
        if (self::$loading_settings) {
            return;
        }

        self::$loading_settings = true;

        try {
            // Use direct database query to avoid model recursion
            $db = \Config\Database::connect();

            // Check if table exists first
            $tables = $db->listTables();
            if (in_array($db->prefixTable('tracker_settings'), $tables)) {
                $query = $db->query("SELECT setting_name, setting_value FROM " .
                                   $db->prefixTable('tracker_settings') .
                                   " WHERE deleted = 0");

                if ($query) {
                    $settings = $query->getResult();
                    foreach ($settings as $setting) {
                        $this->app_settings_array[$setting->setting_name] = $setting->setting_value;
                    }
                }
            } else {
                // Log error but continue with default settings
            }
        } catch (\Exception $e) {
            // Log error but continue with default settings
        } finally {
            self::$loading_settings = false; // Always reset the guard
        }
    }

}
