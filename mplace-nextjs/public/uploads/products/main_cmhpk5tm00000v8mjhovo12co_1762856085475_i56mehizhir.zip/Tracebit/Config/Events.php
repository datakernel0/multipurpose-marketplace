<?php

namespace Tracker\Config;

use CodeIgniter\Events\Events;

Events::on('pre_system', function () {
    helper("tracker_general");
});