<?php

if (!function_exists('verify_tracebit_plugins_purchase_code')) {

    function verify_tracebit_plugins_purchase_code($product, $code) {
        // Tracebit plugin does not require purchase code verification
        // Users can install the plugin without entering a purchase code
        // This allows for easier distribution and installation
        return "verified";
    }
}

//validate purchase code (always returns verified for Tracebit)
$verification = verify_tracebit_plugins_purchase_code($product, $item_purchase_code);


