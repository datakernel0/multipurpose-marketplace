<?php

ini_set('max_execution_time', 300);

$product = "Tracebit";

// Include purchase verification (support both Install/ and install/) 
$verify_upper = PLUGINPATH . "$product/Install/verfiy_purchase_code.php";
$verify_lower = PLUGINPATH . "$product/install/verfiy_purchase_code.php";
if (is_file($verify_upper)) {
    include $verify_upper;
} elseif (is_file($verify_lower)) {
    include $verify_lower;
}

if (isset($verification) && $verification !== "verified") {
    echo json_encode(array("success" => false, "message" => "Please enter a valid purchase code."));
    exit();
}

$db = db_connect('default');
$dbprefix = get_db_prefix();

// Ensure holidays and breaks tables via existing helpers
if (function_exists('install_tracker_holidays_table')) {
    install_tracker_holidays_table();
}
if (function_exists('install_tracker_breaks_table')) {
    install_tracker_breaks_table();
}

// status tables will be created via status_tables.sql

// Build SQL from schema files
$sql_files = [];
$schema_path = PLUGINPATH . "$product/Database/tracker_schema.sql";
if (is_file($schema_path)) {
    $sql_files[] = $schema_path;
}
$setup_attendance = PLUGINPATH . "$product/Database/setup_attendance.sql";
if (is_file($setup_attendance)) {
    $sql_files[] = $setup_attendance;
}
$add_dashboard_setting = PLUGINPATH . "$product/Database/add_dashboard_checkin_setting.sql";
if (is_file($add_dashboard_setting)) {
    $sql_files[] = $add_dashboard_setting;
}
$activity_log_indexes = PLUGINPATH . "$product/Database/activity_log_indexes.sql";
if (is_file($activity_log_indexes)) {
    $sql_files[] = $activity_log_indexes;
}

// Add attendance late/status alterations if present
$status_late_columns = PLUGINPATH . "$product/Database/add_status_late_columns.sql";
if (is_file($status_late_columns)) {
    $sql_files[] = $status_late_columns;
}

// Add tracker status tables
$status_tables = PLUGINPATH . "$product/Database/status_tables.sql";
if (is_file($status_tables)) {
    $sql_files[] = $status_tables;
}

// Add tracker status tables
$status_tables = PLUGINPATH . "$product/Database/status_tables.sql";
if (is_file($status_tables)) {
    $sql_files[] = $status_tables;
}

// Execute files in order
foreach ($sql_files as $file) {
    $sql = file_get_contents($file);
    // Inject DB prefix
    $sql = str_replace('CREATE TABLE IF NOT EXISTS `', 'CREATE TABLE IF NOT EXISTS `'.$dbprefix, $sql);
    $sql = str_replace('CREATE TABLE `', 'CREATE TABLE `'.$dbprefix, $sql);
    $sql = str_replace('INSERT INTO `', 'INSERT INTO `'.$dbprefix, $sql);
    $sql = str_replace('INSERT IGNORE INTO `', 'INSERT IGNORE INTO `'.$dbprefix, $sql);
    $sql = str_replace('ALTER TABLE `', 'ALTER TABLE `'.$dbprefix, $sql);

    // Prefix tables in CREATE INDEX/ANALYZE/SHOW statements where applicable
    $tablesToPrefix = [
        'tracker_attendance',
        'leave_applications',
        'tracker_holidays',
        'tracker_performance',
        'tracker_settings',
        'users',
        'tracker_status',
        'tracker_status_log'
    ];
    foreach ($tablesToPrefix as $t) {
        $sql = str_replace(' ON `'.$t.'`', ' ON `'.$dbprefix.$t.'`', $sql);
        $sql = str_replace(' ON '.$t.' ', ' ON '.$dbprefix.$t.' ', $sql);
        $sql = str_replace(' FROM `'.$t.'`', ' FROM `'.$dbprefix.$t.'`', $sql);
        $sql = str_replace(' FROM '.$t.' ', ' FROM '.$dbprefix.$t.' ', $sql);
        $sql = str_replace(' SHOW INDEX FROM `'.$t.'`', ' SHOW INDEX FROM `'.$dbprefix.$t.'`', $sql);
        $sql = str_replace(' SHOW INDEX FROM '.$t, ' SHOW INDEX FROM '.$dbprefix.$t, $sql);
        $sql = str_replace(' ANALYZE TABLE `'.$t.'`', ' ANALYZE TABLE `'.$dbprefix.$t.'`', $sql);
        $sql = str_replace(' ANALYZE TABLE '.$t, ' ANALYZE TABLE '.$dbprefix.$t, $sql);
    }

    $parts = preg_split('/;\s*(\r?\n|$)/', $sql);
    foreach ($parts as $query) {
        $query = trim($query);
        if ($query) {
            try {
                $upper = strtoupper(ltrim($query));
                // Execute only DDL/DML we care about
                if (strpos($upper, 'CREATE ') === 0 || strpos($upper, 'ALTER ') === 0 || strpos($upper, 'INSERT ') === 0) {
                    $db->query($query);
                }
            } catch (\Throwable $e) {
                // Log and continue
                error_log("Tracebit install: failed query from $file => " . $e->getMessage());
            }
        }
    }
}

// Final verification for status tables
try {
    $statusCreates = [
        $dbprefix . 'tracker_status' => "CREATE TABLE IF NOT EXISTS `" . $dbprefix . "tracker_status` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `user_id` int(11) NOT NULL,
            `status` enum('active','inactive','away','break','lunch','meeting','offline') NOT NULL DEFAULT 'offline',
            `status_message` varchar(255) DEFAULT NULL,
            `project_id` int(11) DEFAULT NULL,
            `current_task` varchar(500) DEFAULT NULL,
            `last_activity` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            `session_start` datetime DEFAULT NULL,
            `total_active_time` int(11) DEFAULT 0,
            `performance_score` decimal(5,2) DEFAULT 0.00,
            `is_tracking` tinyint(1) NOT NULL DEFAULT 0,
            `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
            `deleted` tinyint(1) NOT NULL DEFAULT 0,
            PRIMARY KEY (`id`),
            UNIQUE KEY `idx_unique_user_status` (`user_id`, `deleted`),
            KEY `idx_user_activity` (`user_id`, `last_activity`),
            KEY `idx_status_recent` (`status`, `last_activity`, `deleted`),
            KEY `idx_active_users` (`status`, `is_tracking`, `deleted`),
            KEY `idx_project_users` (`project_id`, `status`),
            KEY `idx_performance_range` (`user_id`, `performance_score`),
            KEY `idx_session_tracking` (`user_id`, `session_start`),
            KEY `idx_deleted_status` (`deleted`, `status`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;",
        $dbprefix . 'tracker_status_log' => "CREATE TABLE IF NOT EXISTS `" . $dbprefix . "tracker_status_log` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `user_id` int(11) NOT NULL,
            `status` varchar(50) NOT NULL,
            `timestamp` datetime NOT NULL,
            `ip_address` varchar(45) DEFAULT NULL,
            `user_agent` text DEFAULT NULL,
            `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            KEY `idx_user_timestamp` (`user_id`, `timestamp`),
            KEY `idx_timestamp` (`timestamp`),
            KEY `idx_status` (`status`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;"
    ];
    foreach ($statusCreates as $tableName => $createSql) {
        $exists = $db->query("SHOW TABLES LIKE ?", [$tableName])->getResult();
        if (!$exists) {
            $db->query($createSql);
        }
    }
} catch (\Throwable $e) {
    // ignore
}

// Final verification: ensure core tables exist, create if missing
try {
    $coreCreates = [
        $dbprefix . 'tracker_settings' => "CREATE TABLE IF NOT EXISTS `" . $dbprefix . "tracker_settings` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `setting_name` varchar(100) NOT NULL,
            `setting_value` text DEFAULT NULL,
            `type` varchar(50) DEFAULT 'app',
            `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
            `deleted` tinyint(1) NOT NULL DEFAULT 0,
            PRIMARY KEY (`id`),
            UNIQUE KEY `idx_setting_name` (`setting_name`, `deleted`),
            KEY `idx_type_deleted` (`type`, `deleted`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;",
        $dbprefix . 'tracker_screenshots' => "CREATE TABLE IF NOT EXISTS `" . $dbprefix . "tracker_screenshots` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `user_id` int(11) NOT NULL,
            `project_id` int(11) DEFAULT NULL,
            `path` varchar(500) NOT NULL,
            `title` varchar(255) DEFAULT NULL,
            `description` text DEFAULT NULL,
            `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
            `deleted` tinyint(1) NOT NULL DEFAULT 0,
            PRIMARY KEY (`id`),
            KEY `idx_user_project_date` (`user_id`, `project_id`, `created_at`),
            KEY `idx_user_date` (`user_id`, `created_at`),
            KEY `idx_project_date` (`project_id`, `created_at`),
            KEY `idx_deleted_created` (`deleted`, `created_at`),
            KEY `idx_path_hash` (`path`(100))
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;",
        $dbprefix . 'tracker_performance' => "CREATE TABLE IF NOT EXISTS `" . $dbprefix . "tracker_performance` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `user_id` int(11) NOT NULL,
            `project` varchar(255) NOT NULL,
            `performance` int(11) NOT NULL DEFAULT 0,
            `takenTime` datetime NOT NULL,
            `timestamp` bigint(20) DEFAULT NULL,
            `timezone` int(11) DEFAULT 0,
            `sign` varchar(10) DEFAULT '+',
            `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
            `deleted` tinyint(1) NOT NULL DEFAULT 0,
            PRIMARY KEY (`id`),
            UNIQUE KEY `idx_unique_performance` (`user_id`, `timestamp`),
            KEY `idx_user_project_time` (`user_id`, `project`, `takenTime`),
            KEY `idx_user_taken_time` (`user_id`, `takenTime`),
            KEY `idx_project_performance` (`project`, `performance`),
            KEY `idx_deleted_user_time` (`deleted`, `user_id`, `takenTime`),
            KEY `idx_performance_analysis` (`user_id`, `performance`, `takenTime`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;",
        $dbprefix . 'tracker_attendance' => "CREATE TABLE IF NOT EXISTS `" . $dbprefix . "tracker_attendance` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `user_id` int(11) NOT NULL,
            `inTime` bigint(20) NOT NULL,
            `outTime` bigint(20) DEFAULT NULL,
            `note` varchar(255) DEFAULT '0',
            `timezone` int(11) DEFAULT 0,
            `late` tinyint(1) NOT NULL DEFAULT 0,
            `sign` varchar(10) DEFAULT '+',
            `project` varchar(255) DEFAULT NULL,
            `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
            `isMinusBreak` tinyint(1) NOT NULL DEFAULT 0,
            `deleted` tinyint(1) NOT NULL DEFAULT 0,
            PRIMARY KEY (`id`),
            UNIQUE KEY `idx_unique_attendance` (`user_id`, `inTime`, `project`),
            KEY `idx_user_intime` (`user_id`, `inTime`),
            KEY `idx_user_project_time` (`user_id`, `project`, `inTime`),
            KEY `idx_time_range` (`inTime`, `outTime`),
            KEY `idx_deleted_user_time` (`deleted`, `user_id`, `inTime`),
            KEY `idx_project_pattern` (`project`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;"
    ];
    foreach ($coreCreates as $tableName => $createSql) {
        $exists = $db->query("SHOW TABLES LIKE ?", [$tableName])->getResult();
        if (!$exists) {
            $db->query($createSql);
        }
    }
    // Ensure status tables as well
    $statusCreates = [
        $dbprefix . 'tracker_status' => "CREATE TABLE IF NOT EXISTS `" . $dbprefix . "tracker_status` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `user_id` int(11) NOT NULL,
            `status` enum('active','inactive','away','break','lunch','meeting','offline') NOT NULL DEFAULT 'offline',
            `status_message` varchar(255) DEFAULT NULL,
            `project_id` int(11) DEFAULT NULL,
            `current_task` varchar(500) DEFAULT NULL,
            `last_activity` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            `session_start` datetime DEFAULT NULL,
            `total_active_time` int(11) DEFAULT 0,
            `performance_score` decimal(5,2) DEFAULT 0.00,
            `is_tracking` tinyint(1) NOT NULL DEFAULT 0,
            `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
            `deleted` tinyint(1) NOT NULL DEFAULT 0,
            PRIMARY KEY (`id`),
            UNIQUE KEY `idx_unique_user_status` (`user_id`, `deleted`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;",
        $dbprefix . 'tracker_status_log' => "CREATE TABLE IF NOT EXISTS `" . $dbprefix . "tracker_status_log` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `user_id` int(11) NOT NULL,
            `status` varchar(50) NOT NULL,
            `timestamp` datetime NOT NULL,
            `ip_address` varchar(45) DEFAULT NULL,
            `user_agent` text DEFAULT NULL,
            `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            KEY `idx_user_timestamp` (`user_id`, `timestamp`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;"
    ];
    foreach ($statusCreates as $tableName => $createSql) {
        $exists = $db->query("SHOW TABLES LIKE ?", [$tableName])->getResult();
        if (!$exists) {
            $db->query($createSql);
        }
    }

     // Add columns to users table if they don't exist
        // Check and add attendance_date column
    $check_attendance_date = "SELECT COUNT(*) as count FROM INFORMATION_SCHEMA.COLUMNS
                              WHERE TABLE_SCHEMA = DATABASE()
                              AND TABLE_NAME = '" . $dbprefix . "users'
                              AND COLUMN_NAME = 'attendance_date'";
    $result = $db->query($check_attendance_date)->getRow();

    if ($result->count == 0) {
        try {
            $db->query("ALTER TABLE `" . $dbprefix . "users` ADD COLUMN `attendance_date` VARCHAR(30) DEFAULT NULL");
        } catch (Exception $e) {
            // Column might already exist, ignore error
        }
    }

    // Check and add attendance_status column
    $check_attendance_status = "SELECT COUNT(*) as count FROM INFORMATION_SCHEMA.COLUMNS
                                WHERE TABLE_SCHEMA = DATABASE()
                                AND TABLE_NAME = '" . $dbprefix . "users'
                                AND COLUMN_NAME = 'attendance_status'";
    $result = $db->query($check_attendance_status)->getRow();


    // Insert default settings
    $default_settings = [
      // Screenshot settings
      ['screenshot_interval', '300', 'app_settings'],
      ['enable_screenshots', '1', 'app_settings'],
      ['enable_screenshot_notifications', '1', 'app_settings'],
      ['screenshot_width', '800', 'app_settings'],
      ['screenshot_height', '600', 'app_settings'],
      ['screenshot_quality', '80', 'app_settings'],
      ['max_screenshot_size', '5242880', 'app_settings'],
      ['screen_shot_on_break', '1', 'app_settings'],

      // Time tracking settings
      ['tracking_time', '120', 'app_settings'],
      ['auto_update_time', '1800', 'app_settings'],
      ['idle_timeout', '300', 'app_settings'],
      ['performance_threshold', '60', 'app_settings'],
      ['sync_interval', '600', 'app_settings'],
      ['enable_idle_detection', '1', 'app_settings'],
      ['working_hours_start', '09:00', 'app_settings'],
      ['working_hours_end', '17:00', 'app_settings'],
     
      ['daily_worked_time', '8', 'app_settings'], // Daily target working hours

      // Activity detection settings
      ['enable_activity_tracking', '1', 'app_settings'],
      ['productivity_tracking', '1', 'app_settings'],
      ['mouse_move_threshold', '10', 'app_settings'],
      ['keyboard_intensity_weight', '1.5', 'app_settings'],
      ['mouse_click_weight', '1.0', 'app_settings'],
      ['mouse_wheel_weight', '0.8', 'app_settings'],
      ['mouse_move_weight', '0.5', 'app_settings'],
      ['pattern_detection_enabled', '1', 'app_settings'],
      ['pattern_sample_size', '20', 'app_settings'],
      ['pattern_threshold', '0.85', 'app_settings'],

      // Invalid app detection settings
      ['invalid_app_detection_enabled', '1', 'app_settings'],
      ['invalid_app_scan_interval', '300', 'app_settings'],
      ['invalid_app_score_threshold', '70', 'app_settings'],
      ['invalid_app_report_enabled', '1', 'app_settings'],
      ['invalid_app_notify_user', '1', 'app_settings'],
      ['invalid_app_notify_admin', '1', 'app_settings'],
      ['invalid_app_detail_level', 'full', 'app_settings'],

      // UI settings
      ['prevent_sleep', '0', 'app_settings'],
      ['dev_tools', '0', 'app_settings'],
      ['inactivity_display', '1', 'app_settings'],
      ['performance_graph_enabled', '1', 'app_settings'],

      // Alert settings
      ['idle_warning_threshold', '240', 'app_settings'],
      ['low_performance_threshold', '40', 'app_settings'],
      ['inactivity_notification', '1', 'app_settings'],
      ['suspicious_activity_notification', '1', 'app_settings'],
      ['invalid_app_notification', '1', 'app_settings'],            
      ['weekend_days', 'Friday,Saturday', 'weekend_settings']
  ];

  foreach ($default_settings as $setting) {
      try {
          $insert_setting = "INSERT INTO `" . $dbprefix . "tracker_settings`
                            (`setting_name`, `setting_value`, `type`) VALUES (?, ?, ?)";
          $result = $db->query($insert_setting, $setting);
          if (!$result) {
              throw new Exception("Failed to insert setting: " . $setting[0]);
          }
      } catch (Exception $e) {
          // If INSERT fails, try INSERT IGNORE in case of duplicates
          try {
              $insert_ignore = "INSERT IGNORE INTO `" . $dbprefix . "tracker_settings`
                               (`setting_name`, `setting_value`, `type`) VALUES (?, ?, ?)";
              $db->query($insert_ignore, $setting);
          } catch (Exception $e2) {
              // Log the error but continue with installation
              error_log("Tracker plugin: Failed to insert setting " . $setting[0] . ": " . $e2->getMessage());
          }
      }
  }

    if ($result->count == 0) {
        try {
            $db->query("ALTER TABLE `" . $dbprefix . "users` ADD COLUMN `attendance_status` ENUM('active','inactive','away','leave','absent') NOT NULL DEFAULT 'absent'");
        } catch (Exception $e) {
            // Column might already exist, ignore error
        }
    }
} catch (\Throwable $e) {
    // ignore
}

// Done
// echo json_encode(array("success" => true, "message" => "Tracebit installed successfully."));
