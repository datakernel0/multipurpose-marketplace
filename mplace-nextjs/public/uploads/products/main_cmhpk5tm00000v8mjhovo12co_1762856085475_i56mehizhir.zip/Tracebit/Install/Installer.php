<?php

namespace Tracebit\Install;

class Installer
{
    public static function install($item_purchase_code)
    {
        \install_tracker_holidays_table();
        \install_tracker_breaks_table();

        $this_is_required = true;
        if (!$this_is_required) {
            echo json_encode(array("success" => false, "message" => "This is required!"));
            exit();
        }

        $db = \db_connect('default');
        $dbprefix = \get_db_prefix();

        try {
            $drop_tables = [
                $dbprefix . "tracker_settings",
                $dbprefix . "tracker_screenshots",
                $dbprefix . "tracker_performance",
                $dbprefix . "tracker_attendance",
                $dbprefix . "tracker_status"
            ];

            foreach ($drop_tables as $table) {
                try {
                    $db->query("DROP TABLE IF EXISTS `$table`");
                } catch (\Exception $e) {
                }
            }

            $settings_table = "CREATE TABLE `" . $dbprefix . "tracker_settings` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `setting_name` varchar(100) NOT NULL,
                `setting_value` text DEFAULT NULL,
                `type` varchar(50) DEFAULT 'app',
                `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
                `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
                `deleted` tinyint(1) NOT NULL DEFAULT 0,
                PRIMARY KEY (`id`),
                UNIQUE KEY `idx_setting_name` (`setting_name`, `deleted`),
                KEY `idx_type_deleted` (`type`, `deleted`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";

            $result = $db->query($settings_table);
            if (!$result) {
                throw new \Exception("Failed to create tracker_settings table: " . $db->error());
            }

            $verify_table = $db->query("SHOW TABLES LIKE '" . $dbprefix . "tracker_settings'");
            if (!$verify_table || $verify_table->getNumRows() == 0) {
                throw new \Exception("tracker_settings table was not created successfully");
            }

            $verify_columns = $db->query("DESCRIBE `" . $dbprefix . "tracker_settings`");
            $columns = [];
            if ($verify_columns && method_exists($verify_columns, 'getResult')) {
                foreach ($verify_columns->getResult() as $row) {
                    $columns[] = $row->Field;
                }
            }

            $required_columns = ['id', 'setting_name', 'setting_value', 'type'];
            foreach ($required_columns as $col) {
                if (!in_array($col, $columns)) {
                    throw new \Exception("Required column '$col' not found in tracker_settings table");
                }
            }

            $default_settings = [
                ['screenshot_interval', '300', 'app_settings'],
                ['enable_screenshots', '1', 'app_settings'],
                ['enable_screenshot_notifications', '1', 'app_settings'],
                ['screenshot_width', '800', 'app_settings'],
                ['screenshot_height', '600', 'app_settings'],
                ['screenshot_quality', '80', 'app_settings'],
                ['max_screenshot_size', '5242880', 'app_settings'],
                ['screen_shot_on_break', '1', 'app_settings'],
                ['tracking_time', '120', 'app_settings'],
                ['auto_update_time', '1800', 'app_settings'],
                ['idle_timeout', '600', 'app_settings'],
                ['performance_threshold', '100', 'app_settings'],
                ['sync_interval', '600', 'app_settings'],
                ['enable_idle_detection', '1', 'app_settings'],
                ['working_hours_start', '09:00', 'app_settings'],
                ['working_hours_end', '17:00', 'app_settings'],
                ['daily_worked_time', '8', 'app_settings'],
                ['enable_activity_tracking', '1', 'app_settings'],
                ['productivity_tracking', '1', 'app_settings'],
                ['mouse_move_threshold', '10', 'app_settings'],
                ['keyboard_intensity_weight', '1.5', 'app_settings'],
                ['mouse_click_weight', '1.0', 'app_settings'],
                ['mouse_wheel_weight', '0.8', 'app_settings'],
                ['mouse_move_weight', '0.5', 'app_settings'],
                ['pattern_detection_enabled', '1', 'app_settings'],
                ['pattern_sample_size', '20', 'app_settings'],
                ['pattern_threshold', '0.85', 'app_settings'],
                ['invalid_app_detection_enabled', '1', 'app_settings'],
                ['invalid_app_scan_interval', '300', 'app_settings'],
                ['invalid_app_score_threshold', '70', 'app_settings'],
                ['invalid_app_report_enabled', '1', 'app_settings'],
                ['invalid_app_notify_user', '1', 'app_settings'],
                ['invalid_app_notify_admin', '1', 'app_settings'],
                ['invalid_app_detail_level', 'full', 'app_settings'],
                ['prevent_sleep', '0', 'app_settings'],
                ['dev_tools', '0', 'app_settings'],
                ['inactivity_display', '1', 'app_settings'],
                ['performance_graph_enabled', '1', 'app_settings'],
                ['idle_warning_threshold', '240', 'app_settings'],
                ['low_performance_threshold', '40', 'app_settings'],
                ['inactivity_notification', '1', 'app_settings'],
                ['suspicious_activity_notification', '1', 'app_settings'],
                ['invalid_app_notification', '1', 'app_settings'],
                ['weekend_days', 'Friday,Saturday', 'weekend_settings']
            ];

            foreach ($default_settings as $setting) {
                try {
                    $insert_setting = "INSERT INTO `" . $dbprefix . "tracker_settings`
                                      (`setting_name`, `setting_value`, `type`) VALUES (?, ?, ?)";
                    $result = $db->query($insert_setting, $setting);
                    if (!$result) {
                        throw new \Exception("Failed to insert setting: " . $setting[0]);
                    }
                } catch (\Exception $e) {
                    try {
                        $insert_ignore = "INSERT IGNORE INTO `" . $dbprefix . "tracker_settings`
                                         (`setting_name`, `setting_value`, `type`) VALUES (?, ?, ?)";
                        $db->query($insert_ignore, $setting);
                    } catch (\Exception $e2) {
                        \error_log("Tracker plugin: Failed to insert setting " . $setting[0] . ": " . $e2->getMessage());
                    }
                }
            }

            $screenshots = "CREATE TABLE IF NOT EXISTS `" . $dbprefix . "tracker_screenshots` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `user_id` int(11) NOT NULL,
                `project_id` int(11) DEFAULT NULL,
                `path` varchar(500) NOT NULL,
                `title` varchar(255) DEFAULT NULL,
                `description` text DEFAULT NULL,
                `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
                `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
                `deleted` tinyint(1) NOT NULL DEFAULT 0,
                PRIMARY KEY (`id`),
                KEY `idx_user_project_date` (`user_id`, `project_id`, `created_at`),
                KEY `idx_user_date` (`user_id`, `created_at`),
                KEY `idx_project_date` (`project_id`, `created_at`),
                KEY `idx_deleted_created` (`deleted`, `created_at`),
                KEY `idx_path_hash` (`path`(100))
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";
            $db->query($screenshots);

            $performance = "CREATE TABLE IF NOT EXISTS `" . $dbprefix . "tracker_performance` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `user_id` int(11) NOT NULL,
                `project` varchar(255) NOT NULL,
                `performance` int(11) NOT NULL DEFAULT 0,
                `takenTime` datetime NOT NULL,
                `timestamp` bigint(20) DEFAULT NULL,
                `timezone` int(11) DEFAULT 0,
                `sign` varchar(10) DEFAULT '+',
                `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
                `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
                `deleted` tinyint(1) NOT NULL DEFAULT 0,
                PRIMARY KEY (`id`),
                UNIQUE KEY `idx_unique_performance` (`user_id`, `timestamp`),
                KEY `idx_user_project_time` (`user_id`, `project`, `takenTime`),
                KEY `idx_user_taken_time` (`user_id`, `takenTime`),
                KEY `idx_project_performance` (`project`, `performance`),
                KEY `idx_deleted_user_time` (`deleted`, `user_id`, `takenTime`),
                KEY `idx_performance_analysis` (`user_id`, `performance`, `takenTime`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";
            $db->query($performance);

            $attendance = "CREATE TABLE IF NOT EXISTS `" . $dbprefix . "tracker_attendance` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `user_id` int(11) NOT NULL,
                `inTime` bigint(20) NOT NULL,
                `outTime` bigint(20) DEFAULT NULL,
                `note` varchar(255) DEFAULT '0',
                `timezone` int(11) DEFAULT 0,
                `late` tinyint(1) NOT NULL DEFAULT 0,
                `sign` varchar(10) DEFAULT '+',
                `project` varchar(255) DEFAULT NULL,
                `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
                `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
                `isMinusBreak` tinyint(1) NOT NULL DEFAULT 0,
                `deleted` tinyint(1) NOT NULL DEFAULT 0,
                PRIMARY KEY (`id`),
                UNIQUE KEY `idx_unique_attendance` (`user_id`, `inTime`, `project`),
                KEY `idx_user_intime` (`user_id`, `inTime`),
                KEY `idx_user_project_time` (`user_id`, `project`, `inTime`),
                KEY `idx_time_range` (`inTime`, `outTime`),
                KEY `idx_deleted_user_time` (`deleted`, `user_id`, `inTime`),
                KEY `idx_project_pattern` (`project`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";
            $db->query($attendance);

            $status = "CREATE TABLE IF NOT EXISTS `" . $dbprefix . "tracker_status` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `user_id` int(11) NOT NULL,
                `status` enum('active','inactive','away','break','lunch','meeting','offline') NOT NULL DEFAULT 'offline',
                `status_message` varchar(255) DEFAULT NULL,
                `project_id` int(11) DEFAULT NULL,
                `current_task` varchar(500) DEFAULT NULL,
                `last_activity` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
                `session_start` datetime DEFAULT NULL,
                `total_active_time` int(11) DEFAULT 0,
                `performance_score` decimal(5,2) DEFAULT 0.00,
                `is_tracking` tinyint(1) NOT NULL DEFAULT 0,
                `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
                `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
                `deleted` tinyint(1) NOT NULL DEFAULT 0,
                PRIMARY KEY (`id`),
                UNIQUE KEY `idx_unique_user_status` (`user_id`, `deleted`),
                KEY `idx_user_activity` (`user_id`, `last_activity`),
                KEY `idx_status_recent` (`status`, `last_activity`, `deleted`),
                KEY `idx_active_users` (`status`, `is_tracking`, `deleted`),
                KEY `idx_project_users` (`project_id`, `status`),
                KEY `idx_performance_range` (`user_id`, `performance_score`),
                KEY `idx_session_tracking` (`user_id`, `session_start`),
                KEY `idx_deleted_status` (`deleted`, `status`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";
            $db->query($status);

            $status_log = "CREATE TABLE IF NOT EXISTS `" . $dbprefix . "tracker_status_log` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `user_id` int(11) NOT NULL,
                `status` varchar(50) NOT NULL,
                `timestamp` datetime NOT NULL,
                `ip_address` varchar(45) DEFAULT NULL,
                `user_agent` text DEFAULT NULL,
                `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`),
                KEY `idx_user_timestamp` (`user_id`, `timestamp`),
                KEY `idx_timestamp` (`timestamp`),
                KEY `idx_status` (`status`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";
            $db->query($status_log);

            $check_attendance_date = "SELECT COUNT(*) as count FROM INFORMATION_SCHEMA.COLUMNS
                                     WHERE TABLE_SCHEMA = DATABASE()
                                     AND TABLE_NAME = '" . $dbprefix . "users'
                                     AND COLUMN_NAME = 'attendance_date'";
            $result = $db->query($check_attendance_date)->getRow();

            if ($result->count == 0) {
                try {
                    $db->query("ALTER TABLE `" . $dbprefix . "users` ADD COLUMN `attendance_date` VARCHAR(30) DEFAULT NULL");
                } catch (\Exception $e) {
                }
            }

            $check_attendance_status = "SELECT COUNT(*) as count FROM INFORMATION_SCHEMA.COLUMNS
                                       WHERE TABLE_SCHEMA = DATABASE()
                                       AND TABLE_NAME = '" . $dbprefix . "users'
                                       AND COLUMN_NAME = 'attendance_status'";
            $result = $db->query($check_attendance_status)->getRow();

            if ($result->count == 0) {
                try {
                    $db->query("ALTER TABLE `" . $dbprefix . "users` ADD COLUMN `attendance_status` ENUM('active','inactive','away','leave','absent') NOT NULL DEFAULT 'absent'");
                } catch (\Exception $e) {
                }
            }

            try {
                $sql_query = "DROP TABLE IF EXISTS `Calendar`;";
                $db->query($sql_query);

                $calendar_table = "CREATE TABLE IF NOT EXISTS `Calendar` (
                    `date` date NOT NULL,
                    `day_of_week` tinyint(1) NOT NULL,
                    `is_weekend` tinyint(1) NOT NULL DEFAULT 0,
                    `is_holiday` tinyint(1) NOT NULL DEFAULT 0,
                    PRIMARY KEY (`date`),
                    KEY `idx_date_range` (`date`, `is_weekend`),
                    KEY `idx_workdays` (`is_weekend`, `is_holiday`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";
                $db->query($calendar_table);

                $check_calendar = "SELECT COUNT(*) as count FROM `Calendar`";
                $calendar_result = $db->query($check_calendar)->getRow();

                if ($calendar_result->count == 0) {
                    $current_year = date('Y');
                    $start_timestamp = strtotime($current_year . '-01-01');
                    $end_timestamp = strtotime(($current_year + 1) . '-12-31');

                    $values = [];
                    $params = [];

                    for ($timestamp = $start_timestamp; $timestamp <= $end_timestamp; $timestamp += 86400) {
                        $date = date('Y-m-d', $timestamp);
                        $day_of_week = date('N', $timestamp);
                        $is_weekend = ($day_of_week >= 6) ? 1 : 0;

                        $values[] = "(?, ?, ?)";
                        $params[] = $date;
                        $params[] = $day_of_week;
                        $params[] = $is_weekend;

                        if (count($values) >= 100) {
                            $batch_sql = "INSERT IGNORE INTO `Calendar` (`date`, `day_of_week`, `is_weekend`) VALUES " . implode(', ', $values);
                            $db->query($batch_sql, $params);
                            $values = [];
                            $params = [];
                        }
                    }

                    if (!empty($values)) {
                        $batch_sql = "INSERT IGNORE INTO `Calendar` (`date`, `day_of_week`, `is_weekend`) VALUES " . implode(', ', $values);
                        $db->query($batch_sql, $params);
                    }
                }
            } catch (\Exception $e) {
                \error_log("Calendar table creation warning: " . $e->getMessage());
            }

            echo json_encode(array("success" => true, "message" => "Tracker plugin installed successfully with optimized database schema!"));
        } catch (\Exception $e) {
            echo json_encode(array("success" => false, "message" => "Installation failed: " . $e->getMessage()));
            exit();
        }
    }
}


