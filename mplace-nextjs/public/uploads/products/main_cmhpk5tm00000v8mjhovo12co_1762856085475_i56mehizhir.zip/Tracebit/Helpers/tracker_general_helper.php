<?php

/**
 * get the defined config value by a key
 * @param string $key
 * @return config value
 */
if (!function_exists('get_tracker_setting')) {

    function get_tracker_setting($key = "") {
        $config = new Tracebit\Config\Tracker();

        $setting_value = get_array_value($config->app_settings_array, $key);
        if ($setting_value !== NULL) {
            return $setting_value;
        } else {
            return "";
        }
    }

}

/**
 * link the css files
 *
 * @param array $array
 * @return print css links
 */
if (!function_exists('tracker_load_css')) {

    function tracker_load_css(array $array) {
        $version = get_setting("app_version");

        foreach ($array as $uri) {
            echo "<link rel='stylesheet' type='text/css' href='" . base_url(PLUGIN_URL_PATH . "Tracebit/$uri") . "?v=$version' />";
        }
    }

}

if (!function_exists('tracker_get_source_url')) {

    function tracker_get_source_url($demo_file = "") {
        if (!$demo_file) {
            return "";
        }

        try {
            $file = unserialize($demo_file);
            if (is_array($file)) {
                return get_source_url_of_file($file, get_tracker_setting("demo_file_path"), "thumbnail", false, false, true);
            }
        } catch (\Exception $ex) {

        }
    }

}

/**
 * Format time for display
 *
 * @param string $time
 * @param string $timezone_offset
 * @param string $sign
 * @return formatted time string
 */
if (!function_exists('tracker_format_time')) {

    function tracker_format_time($time, $timezone_offset = 0, $sign = '+') {
        try {
            $datetime = new DateTime($time);

            if ($timezone_offset && $sign) {
                $interval = new DateInterval('PT' . abs($timezone_offset) . 'M');
                if ($sign === '+') {
                    $datetime->add($interval);
                } else {
                    $datetime->sub($interval);
                }
            }

            return $datetime->format('H:i:s a');
        } catch (Exception $e) {
            return $time;
        }
    }

}

/**
 * Get user activity status
 *
 * @param int $user_id
 * @return string status
 */
if (!function_exists('tracker_get_user_status')) {

    function tracker_get_user_status($user_id) {
        $db = \Config\Database::connect();

        $attendance_table = $db->prefixTable('tracker_attendance');

        $sql = "SELECT id FROM $attendance_table
                WHERE user_id = ?
                AND DATE(FROM_UNIXTIME(inTime / 1000)) = CURDATE()
                AND outTime IS NULL
                AND deleted = 0";

        $query = $db->query($sql, [$user_id]);

        return $query && $query->getRow() ? 'Active' : 'Inactive';
    }

}

/**
 * Calculate total working hours
 *
 * @param int $inTime timestamp
 * @param int $outTime timestamp
 * @return string formatted hours
 */
if (!function_exists('tracker_calculate_hours')) {

    function tracker_calculate_hours($inTime, $outTime = null) {
        if (!$outTime) {
            $outTime = time() * 1000; // Current time in milliseconds
        }

        $diff = ($outTime - $inTime) / 1000; // Convert to seconds
        $hours = floor($diff / 3600);
        $minutes = floor(($diff % 3600) / 60);

        return sprintf('%02d:%02d', $hours, $minutes);
    }

}

/**
 * Check if screenshot feature is enabled
 *
 * @return boolean
 */
if (!function_exists('tracker_screenshots_enabled')) {

    function tracker_screenshots_enabled() {
        return get_tracker_setting('enable_screenshots') === '1';
    }

}

/**
 * Get tracker settings by type
 *
 * @param string $type Setting type (app_settings, web_settings, holidays_settings, break_settings, weekend_settings)
 * @return array Array of settings for the specified type
 */
if (!function_exists('get_tracker_settings_by_type')) {

    function get_tracker_settings_by_type($type = 'app_settings') {
        try {
            $model = new \Tracebit\Models\Tracker_settings_model();
            return $model->get_settings_array_by_type($type);
        } catch (Exception $e) {
            return [];
        }
    }

}

/**
 * Get specific setting by name from a type
 *
 * @param string $key Setting key
 * @param string $type Setting type (app_settings, web_settings, holidays_settings, break_settings, weekend_settings)
 * @param mixed $default Default value if setting not found
 * @return mixed Setting value or default
 */
if (!function_exists('get_tracker_setting_by_type')) {

    function get_tracker_setting_by_type($key, $type = 'app_settings', $default = '') {
        try {
            $settings = get_tracker_settings_by_type($type);
            return isset($settings[$key]) ? $settings[$key] : $default;
        } catch (Exception $e) {
            return $default;
        }
    }

}

/**
 * Save tracker setting with type
 *
 * @param string $key Setting key
 * @param mixed $value Setting value
 * @param string $type Setting type (app_settings, web_settings, holidays_settings, break_settings, weekend_settings)
 * @return boolean Success status
 */
if (!function_exists('save_tracker_setting_by_type')) {

    function save_tracker_setting_by_type($key, $value, $type = 'app_settings') {
        try {
            $model = new \Tracebit\Models\Tracker_settings_model();
            return $model->save_setting($key, $value, $type);
        } catch (Exception $e) {
            return false;
        }
    }

}

/**
 * Get break settings as an array
 *
 * @return array Break configuration settings
 */
if (!function_exists('get_tracker_break_settings')) {

    function get_tracker_break_settings() {
        return get_tracker_settings_by_type('break_settings');
    }

}

/**
 * Get weekend settings as an array
 *
 * @return array Weekend configuration settings
 */
if (!function_exists('get_tracker_weekend_settings')) {

    function get_tracker_weekend_settings() {
        return get_tracker_settings_by_type('weekend_settings');
    }

}

/**
 * Get holiday settings as an array
 *
 * @return array Holiday configuration settings
 */
if (!function_exists('get_tracker_holiday_settings')) {

    function get_tracker_holiday_settings() {
        return get_tracker_settings_by_type('holidays_settings');
    }

}

/**
 * Get web/UI settings as an array
 *
 * @return array Web interface configuration settings
 */
if (!function_exists('get_tracker_web_settings')) {

    function get_tracker_web_settings() {
        return get_tracker_settings_by_type('web_settings');
    }

}

/**
 * Check if today is a weekend day
 *
 * @return boolean True if today is a weekend day
 */
if (!function_exists('tracker_is_weekend')) {

    function tracker_is_weekend($date = null) {
        $weekend_settings = get_tracker_weekend_settings();
        $weekend_days_setting = get_array_value($weekend_settings, 'weekend_days');
        
        // Get the day name for the provided date or today
        if ($date) {
            // If a date is provided, get the day name for that date
            if (is_numeric($date)) {
                // If it's a numeric day of week (0=Sunday, 1=Monday, etc.)
                $day_number = intval($date);
                $day_name = [
                    0 => 'Sunday',
                    1 => 'Monday',
                    2 => 'Tuesday',
                    3 => 'Wednesday',
                    4 => 'Thursday',
                    5 => 'Friday',
                    6 => 'Saturday'
                ][$day_number];
            } else {
                // If it's a date string, get the day name
                $day_name = date('l', strtotime($date));
            }
        } else {
            // Use today's date
            $day_name = date('l');
        }
        
        // Saturday and Sunday are always weekend days
        if (in_array($day_name, ['Saturday', 'Sunday'])) {
            return true;
        }
        
        // Check if the day is in the custom weekend days list
        $custom_weekend_days = $weekend_days_setting ? explode(',', $weekend_days_setting) : [];
        return in_array($day_name, $custom_weekend_days);
    }

}

/**
 * Check if tracking should be enabled on weekends
 *
 * @return boolean True if weekend tracking is enabled
 */
if (!function_exists('tracker_weekend_tracking_enabled')) {

    function tracker_weekend_tracking_enabled() {
        return get_tracker_setting_by_type('weekend_tracking_enabled', 'weekend_settings', '0') === '1';
    }

}

/**
 * Check if break reminders are enabled
 *
 * @return boolean True if break reminders are enabled
 */
if (!function_exists('tracker_break_reminders_enabled')) {

    function tracker_break_reminders_enabled() {
        return get_tracker_setting_by_type('break_reminder_enabled', 'break_settings', '1') === '1';
    }

}
