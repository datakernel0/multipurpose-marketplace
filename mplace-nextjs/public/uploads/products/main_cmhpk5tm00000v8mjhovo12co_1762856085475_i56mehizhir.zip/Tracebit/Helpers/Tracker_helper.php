<?php

/**
 * Tracker Helper Functions
 * Helper functions for the Tracebit Tracker plugin
 */

if (!function_exists('get_current_attendance_status')) {
    /**
     * Get current attendance status for the logged-in user
     */
    function get_current_attendance_status($user_id = null) {
        try {
            if (!$user_id) {
                // Try to get current user ID from session
                $session = session();
                $user_id = $session->get('user_id');
                
                if (!$user_id) {
                    return null;
                }
            }

            $attendance_model = model("Tracebit\Models\Tracker_attendance_model");
            return $attendance_model->get_current_status($user_id);

        } catch (\Exception $e) {
            error_log("get_current_attendance_status error: " . $e->getMessage());
            return null;
        }
    }
}

if (!function_exists('format_attendance_time')) {
    /**
     * Format attendance time from milliseconds timestamp
     */
    function format_attendance_time($timestamp_ms) {
        try {
            if (!$timestamp_ms) {
                return null;
            }
            
            $timestamp = $timestamp_ms / 1000; // Convert from milliseconds to seconds
            return date('H:i:s', $timestamp);

        } catch (\Exception $e) {
            error_log("format_attendance_time error: " . $e->getMessage());
            return null;
        }
    }
}

if (!function_exists('get_tracker_setting')) {
    /**
     * Get a tracker setting value
     */
    function get_tracker_setting($setting_name, $default = null) {
        try {
            $tracker_settings_model = model("Tracebit\Models\Tracker_settings_model");
            $value = $tracker_settings_model->get_setting($setting_name);
            
            return $value !== null ? $value : $default;

        } catch (\Exception $e) {
            error_log("get_tracker_setting error: " . $e->getMessage());
            return $default;
        }
    }
}

if (!function_exists('is_dashboard_checkin_enabled')) {
    /**
     * Check if dashboard check-in is enabled
     */
    function is_dashboard_checkin_enabled() {
        $setting = get_tracker_setting('dashboard_checkin_active', '1');
        return $setting === '1' || $setting === 'true';
    }
}

if (!function_exists('tracker_load_css')) {
    /**
     * Load CSS files for tracker
     */
    function tracker_load_css($css_files = array()) {
        if (empty($css_files)) {
            return;
        }
        
        foreach ($css_files as $css_file) {
            echo '<link rel="stylesheet" type="text/css" href="' . base_url($css_file) . '" />' . "\n";
        }
    }
}
