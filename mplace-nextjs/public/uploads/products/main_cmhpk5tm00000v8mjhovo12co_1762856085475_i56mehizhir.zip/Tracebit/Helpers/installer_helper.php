<?php

// Helper function to clean SQL content
if (!function_exists('clean_sql_content')) {
    function clean_sql_content($sql) {
        $lines = explode("\n", $sql);
        $cleanLines = [];
        foreach ($lines as $line) {
            $line = trim($line);
            if (empty($line) ||
                strpos($line, '--') === 0 ||
                strpos($line, '/*') === 0 ||
                strpos($line, '*/') !== false ||
                strpos($line, 'SET SQL_MODE') === 0 ||
                strpos($line, 'START TRANSACTION') === 0 ||
                strpos($line, 'SET time_zone') === 0 ||
                strpos($line, 'SET @OLD_') === 0 ||
                strpos($line, 'SET NAMES') === 0 ||
                strpos($line, 'COMMIT') === 0 ||
                (strpos($line, 'ALTER TABLE') === 0 && strpos($line, 'ADD PRIMARY KEY') !== false) ||
                (strpos($line, 'ALTER TABLE') === 0 && strpos($line, 'MODIFY') !== false && strpos($line, 'AUTO_INCREMENT') !== false)) {
                continue;
            }
            $cleanLines[] = $line;
        }

        $cleanSql = implode("\n", $cleanLines);
        $cleanSql = str_replace('INSERT INTO', 'INSERT IGNORE INTO', $cleanSql);
        return $cleanSql;
    }
}

// Helper function to execute SQL statements safely
if (!function_exists('execute_sql_statements')) {
    function execute_sql_statements($db, $sql, $context = 'SQL execution') {
        $statements = [];
        $currentStatement = '';
        $lines = explode("\n", $sql);

        foreach ($lines as $line) {
            $line = trim($line);
            if (empty($line)) continue;
            $currentStatement .= $line . "\n";
            if (substr(rtrim($line), -1) === ';') {
                $statement = trim($currentStatement);
                if (!empty($statement) && strlen($statement) > 10) {
                    $statements[] = rtrim($statement, ';');
                }
                $currentStatement = '';
            }
        }

        if (!empty(trim($currentStatement))) {
            $statement = trim($currentStatement);
            if (strlen($statement) > 10) {
                $statements[] = $statement;
            }
        }

        foreach ($statements as $index => $statement) {
            $statement = trim($statement);
            if (empty($statement)) continue;
            try {
                $upperStatement = strtoupper($statement);
                if (strpos($upperStatement, 'CREATE ') === 0 ||
                    strpos($upperStatement, 'INSERT ') === 0 ||
                    strpos($upperStatement, 'UPDATE ') === 0 ||
                    strpos($upperStatement, 'DELETE ') === 0 ||
                    strpos($upperStatement, 'ALTER ') === 0) {
                    $result = $db->query($statement);
                    if (!$result) {
                        throw new Exception("Query returned false - possible syntax error");
                    }
                }
            } catch (Exception $e) {
                log_message('error', $context . ' - Statement ' . ($index + 1) . ' failed: ' . $e->getMessage());
                log_message('error', $context . ' - Failed statement was: ' . substr($statement, 0, 300) . '...');
                throw new Exception($context . ' failed at statement ' . ($index + 1) . ': ' . $e->getMessage());
            }
        }
        return true;
    }
}

// Install/update holidays table if needed
if (!function_exists('install_tracker_holidays_table')) {
    function install_tracker_holidays_table() {
        $db = db_connect();
        $prefix = $db->getPrefix();
        $sqlFilePath = ROOTPATH . 'plugins/Tracebit/sql/tracker_holidays.sql';
        if (!file_exists($sqlFilePath)) {
            log_message('error', 'Tracker holidays SQL file not found: ' . $sqlFilePath);
            return false;
        }
        $sql = file_get_contents($sqlFilePath);
        $sql = str_replace('{PREFIX}', $prefix, $sql);
        $sql = str_replace('{dbprefix}', $prefix, $sql);
        $cleanSql = clean_sql_content($sql);
        try {
            execute_sql_statements($db, $cleanSql, 'Tracker holidays table installation');
            log_message('info', 'Tracker holidays table created/updated successfully.');
            return true;
        } catch (\Exception $e) {
            log_message('error', 'Failed to create/update tracker holidays table: ' . $e->getMessage());
            return false;
        }
    }
}

// Install/update breaks table if needed
if (!function_exists('install_tracker_breaks_table')) {
    function install_tracker_breaks_table() {
        $db = db_connect();
        $prefix = $db->getPrefix();
        $sqlFilePath = ROOTPATH . 'plugins/Tracebit/sql/tracker_breaks.sql';
        if (!file_exists($sqlFilePath)) {
            log_message('error', 'Tracker breaks SQL file not found: ' . $sqlFilePath);
            return false;
        }
        $sql = file_get_contents($sqlFilePath);
        $sql = str_replace('{PREFIX}', $prefix, $sql);
        $sql = str_replace('{dbprefix}', $prefix, $sql);
        $cleanSql = clean_sql_content($sql);
        try {
            execute_sql_statements($db, $cleanSql, 'Tracker breaks table installation');
            log_message('info', 'Tracker breaks table created/updated successfully.');
            return true;
        } catch (\Exception $e) {
            log_message('error', 'Failed to create/update tracker breaks table: ' . $e->getMessage());
            return false;
        }
    }
}


