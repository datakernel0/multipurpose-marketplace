<?php

namespace Tracebit\Controllers;

use App\Controllers\Security_Controller;

class Storage_management_controller extends Security_Controller {

    protected $db;
    protected $dbprefix;

    function __construct() {
        parent::__construct();
        
        // Initialize database connection
        $this->db = \Config\Database::connect();
        $this->dbprefix = $this->db->getPrefix();
        
        // Allow access to authenticated users (no specific permission check needed)
        // You can add specific permission checks here later if needed
    }

    /**
     * Display the storage management page
     */
    function index() {
        // Prepare view data
        $view_data = array(
            "login_user" => $this->login_user,
            "current_year" => date('Y')
        );
        
        // Load the storage management view with data
        return $this->template->rander('Tracebit\Views\storage_management\index', $view_data);
    }
} 
