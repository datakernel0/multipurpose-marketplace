<?php

namespace Tracebit\Controllers;

use App\Controllers\Security_Controller;
use Tracebit\Libraries\Error_handler;
use Tracebit\Traits\Error_handling_trait;

class Error_monitor extends Security_Controller {

    use Error_handling_trait;

    function __construct() {
        parent::__construct();

        // Only admin can access error monitoring
        $permission_error = $this->checkPermission('error_monitoring', ['admin']);
        if ($permission_error) {
            show_404();
            return;
        }
    }

    /**
     * Error monitoring dashboard
     */
    function index() {
        return $this->executeWithErrorHandling(function() {
            $this->logOperation('error_monitor_dashboard');

            $view_data = [
                'page_title' => 'Error Monitoring Dashboard',
                'error_stats' => $this->getErrorStatistics(),
                'recent_errors' => $this->getRecentErrors(),
                'system_health' => $this->getSystemHealth()
            ];

            return $this->template->rander('Tracebit\Views\error_monitor\dashboard', $view_data);
        }, 'load_error_monitor_dashboard');
    }

    /**
     * Get error statistics for API endpoint
     */
    function get_error_stats() {
        $hours = $this->getSanitizedParam('hours', 24, 'GET');

        $response = $this->executeWithErrorHandling(function() use ($hours) {
            $stats = Error_handler::getErrorStats($hours);
            return Error_handler::formatSuccessResponse('Error statistics retrieved', $stats);
        }, 'get_error_statistics');

        $this->sendJsonResponse($response);
    }

    /**
     * Get detailed error log
     */
    function get_error_log() {
        $page = (int) $this->getSanitizedParam('page', 1, 'GET');
        $limit = (int) $this->getSanitizedParam('limit', 50, 'GET');
        $level = $this->getSanitizedParam('level', '', 'GET');

        $response = $this->executeWithErrorHandling(function() use ($page, $limit, $level) {
            $errors = $this->getErrorLogPaginated($page, $limit, $level);
            return Error_handler::formatSuccessResponse('Error log retrieved', $errors);
        }, 'get_error_log');

        $this->sendJsonResponse($response);
    }

    /**
     * Clear error logs
     */
    function clear_logs() {
        // Check additional permission for log clearing
        $permission_error = $this->checkPermission('clear_logs', ['admin']);
        if ($permission_error) {
            $this->sendJsonResponse($permission_error, 403);
            return;
        }

        $response = $this->executeWithErrorHandling(function() {
            $log_file = ROOTPATH . 'writable/logs/tracker_errors.log';

            if (file_exists($log_file)) {
                // Backup current log before clearing
                $backup_file = ROOTPATH . 'writable/logs/tracker_errors_backup_' . date('Y-m-d_H-i-s') . '.log';
                copy($log_file, $backup_file);

                // Clear the log file
                file_put_contents($log_file, '');

                Error_handler::info('Error logs cleared by admin', [
                    'admin_id' => $this->login_user->id,
                    'backup_file' => $backup_file
                ]);

                return Error_handler::formatSuccessResponse('Error logs cleared successfully');
            } else {
                return Error_handler::formatSuccessResponse('No error log file found');
            }
        }, 'clear_error_logs');

        $this->sendJsonResponse($response);
    }

    /**
     * Download error log file
     */
    function download_log() {
        $log_file = ROOTPATH . 'writable/logs/tracker_errors.log';

        if (file_exists($log_file)) {
            $this->logOperation('download_error_log');

            $this->response->setHeader('Content-Type', 'text/plain');
            $this->response->setHeader('Content-Disposition', 'attachment; filename="tracker_errors_' . date('Y-m-d') . '.log"');
            $this->response->setBody(file_get_contents($log_file));

            return $this->response;
        } else {
            show_404();
        }
    }

    /**
     * Test error handling (development only)
     */
    function test_error() {
        if (ENVIRONMENT !== 'development') {
            show_404();
            return;
        }

        $type = $this->getSanitizedParam('type', 'info', 'GET');

        switch ($type) {
            case 'error':
                Error_handler::error('Test error message', ['test' => true, 'user_id' => $this->login_user->id]);
                break;
            case 'warning':
                Error_handler::warning('Test warning message', ['test' => true, 'user_id' => $this->login_user->id]);
                break;
            case 'exception':
                try {
                    throw new \Exception('Test exception');
                } catch (\Exception $e) {
                    $response = Error_handler::handleException($e, 'test_exception');
                    $this->sendJsonResponse($response, 500);
                    return;
                }
                break;
            default:
                Error_handler::info('Test info message', ['test' => true, 'user_id' => $this->login_user->id]);
                break;
        }

        $this->sendJsonResponse(Error_handler::formatSuccessResponse("Test {$type} logged successfully"));
    }

    /**
     * Get error statistics
     *
     * @return array Error statistics
     */
    private function getErrorStatistics() {
        $stats_24h = Error_handler::getErrorStats(24);
        $stats_7d = Error_handler::getErrorStats(24 * 7);

        return [
            'last_24h' => $stats_24h,
            'last_7d' => $stats_7d,
            'log_file_size' => $this->getLogFileSize(),
            'disk_usage' => $this->getDiskUsage()
        ];
    }

    /**
     * Get recent errors
     *
     * @param int $limit Number of errors to retrieve
     * @return array Recent errors
     */
    private function getRecentErrors($limit = 20) {
        $log_file = ROOTPATH . 'writable/logs/tracker_errors.log';

        if (!file_exists($log_file)) {
            return [];
        }

        $lines = file($log_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        $recent_lines = array_slice(array_reverse($lines), 0, $limit);

        $errors = [];
        foreach ($recent_lines as $line) {
            if (preg_match('/\[(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})\] \[(\w+)\] (.+)/', $line, $matches)) {
                $errors[] = [
                    'timestamp' => $matches[1],
                    'level' => $matches[2],
                    'message' => $matches[3]
                ];
            }
        }

        return $errors;
    }

    /**
     * Get system health indicators
     *
     * @return array System health data
     */
    private function getSystemHealth() {
        return [
            'php_version' => PHP_VERSION,
            'memory_usage' => $this->formatBytes(memory_get_usage(true)),
            'memory_peak' => $this->formatBytes(memory_get_peak_usage(true)),
            'disk_free_space' => $this->formatBytes(disk_free_space(ROOTPATH)),
            'environment' => ENVIRONMENT,
            'database_status' => $this->checkDatabaseHealth(),
            'file_permissions' => $this->checkFilePermissions()
        ];
    }

    /**
     * Get paginated error log
     */
    private function getErrorLogPaginated($page, $limit, $level = '') {
        $log_file = ROOTPATH . 'writable/logs/tracker_errors.log';

        if (!file_exists($log_file)) {
            return ['errors' => [], 'total' => 0, 'page' => $page, 'limit' => $limit];
        }

        $lines = file($log_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        $errors = [];

        foreach (array_reverse($lines) as $line) {
            if (preg_match('/\[(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})\] \[(\w+)\] (.+)/', $line, $matches)) {
                if (empty($level) || strtolower($matches[2]) === strtolower($level)) {
                    $errors[] = [
                        'timestamp' => $matches[1],
                        'level' => $matches[2],
                        'message' => $matches[3]
                    ];
                }
            }
        }

        $total = count($errors);
        $offset = ($page - 1) * $limit;
        $paginated_errors = array_slice($errors, $offset, $limit);

        return [
            'errors' => $paginated_errors,
            'total' => $total,
            'page' => $page,
            'limit' => $limit,
            'total_pages' => ceil($total / $limit)
        ];
    }

    /**
     * Get log file size
     */
    private function getLogFileSize() {
        $log_file = ROOTPATH . 'writable/logs/tracker_errors.log';
        return file_exists($log_file) ? $this->formatBytes(filesize($log_file)) : '0 B';
    }

    /**
     * Get disk usage
     */
    private function getDiskUsage() {
        $total = disk_total_space(ROOTPATH);
        $free = disk_free_space(ROOTPATH);
        $used = $total - $free;

        return [
            'total' => $this->formatBytes($total),
            'used' => $this->formatBytes($used),
            'free' => $this->formatBytes($free),
            'percentage' => round(($used / $total) * 100, 2)
        ];
    }

    /**
     * Check database health
     */
    private function checkDatabaseHealth() {
        try {
            $db = \Config\Database::connect();
            $db->query("SELECT 1");
            return 'OK';
        } catch (\Exception $e) {
            return 'ERROR: ' . $e->getMessage();
        }
    }

    /**
     * Check file permissions
     */
    private function checkFilePermissions() {
        $paths = [
            'writable/logs' => ROOTPATH . 'writable/logs',
            'writable/cache' => ROOTPATH . 'writable/cache',
            'plugins/Tracker' => ROOTPATH . 'plugins/Tracker'
        ];

        $permissions = [];
        foreach ($paths as $name => $path) {
            if (is_dir($path)) {
                $permissions[$name] = is_writable($path) ? 'Writable' : 'Not Writable';
            } else {
                $permissions[$name] = 'Not Found';
            }
        }

        return $permissions;
    }

    /**
     * Format bytes to human readable format
     */
    private function formatBytes($bytes, $precision = 2) {
        $units = ['B', 'KB', 'MB', 'GB', 'TB'];

        for ($i = 0; $bytes > 1024 && $i < count($units) - 1; $i++) {
            $bytes /= 1024;
        }

        return round($bytes, $precision) . ' ' . $units[$i];
    }
}
