<?php

namespace Tracebit\Controllers;

use App\Controllers\App_Controller;
use Tracebit\Traits\Error_handling_trait;
use Exception;

class InvalidAppController extends App_Controller {

    use Error_handling_trait;

    private $db;
    private $dbprefix;

    public function __construct() {
        parent::__construct();
        $this->InvalidApp_model = model("Tracebit\Models\InvalidAppModel");
        
        // Initialize database connection
        $this->db = \Config\Database::connect();
        $this->dbprefix = $this->db->getPrefix();
    }

    /**
     * API endpoint to report invalid apps (newer version)
     */
    public function report_invalid_app() {
        // Get request data with improved handling
        $user_id = $this->request->getPost('user_id');
        $app_name = $this->request->getPost('app_name');
        $suspicion_score = $this->request->getPost('suspicion_score') ?: 5;
        $project_id = $this->request->getPost('project_id') ?: null;
        $detection_time = $this->request->getPost('detection_time') ?: date('Y-m-d H:i:s');
        $system_info = $this->request->getPost('system_info');

        // Get app details if provided
        $app_details = $this->request->getPost('app_details');

        // Process app_details with better handling for different formats
        if ($app_details) {
            // Decode if it's already a JSON string
            $decoded = json_decode($app_details, true);

            if (is_array($decoded)) {
                // Valid JSON, add system_info if available
                if ($system_info) {
                    $system_data = json_decode($system_info, true);
                    if (is_array($system_data)) {
                        $decoded['system_info'] = $system_data;
                    }
                }

                // Re-encode the enriched data
                $app_details = json_encode($decoded);
            } else {
                // Not valid JSON, encode as raw text
                $app_details = json_encode([
                    'raw' => $app_details,
                    'system_info' => json_decode($system_info, true)
                ]);
            }
        } else {
            // No details provided, create minimal object
            $app_details = json_encode([
                'app_name' => $app_name,
                'system_info' => json_decode($system_info, true)
            ]);
        }

        // Validate required fields
        if (!$user_id || !$app_name) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Missing required fields: user_id and app_name are required'
            ])->setStatusCode(400);
        }

        try {
            // Prepare data for model
            $data = [
                'user_id' => $user_id,
                'app_name' => $app_name,
                'suspicion_score' => $suspicion_score,
                'project_id' => $project_id,
                'app_details' => $app_details,
                'detection_time' => $detection_time
            ];

            // Use model to insert record
            $result = $this->InvalidApp_model->insert($data);

            // Send notification to admin
            $this->notify_admin($data);

            // Get insert ID safely
            $insert_id = null;
            if ($result && $this->db) {
                try {
                    $insert_id = $this->db->insertID();
                } catch (Exception $e) {
                    // Fallback to model's insertID if available
                    if (method_exists($this->InvalidApp_model, 'getInsertID')) {
                        $insert_id = $this->InvalidApp_model->getInsertID();
                    }
                }
            }

            return $this->response->setJSON([
                'success' => true,
                'message' => 'Invalid app reported successfully',
                'data' => ['id' => $insert_id]
            ]);

        } catch (Exception $e) {
            error_log("Error reporting invalid app: " . $e->getMessage());

            return $this->response->setJSON([
                'success' => false,
                'message' => 'Error reporting invalid app: ' . $e->getMessage()
            ])->setStatusCode(500);
        }
    }

    /**
     * Legacy endpoint to maintain backward compatibility
     */
    public function send_message() {
        $user_id = $this->request->getGet('user_id');
        $app_name = $this->request->getGet('appName');

        if (!$user_id || !$app_name) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Missing required parameters'
            ]);
        }

        try {
            // Use model to insert record
            $data = [
                'user_id' => $user_id,
                'app_name' => $app_name,
                'detection_time' => date('Y-m-d H:i:s')
            ];
            $this->InvalidApp_model->insert($data);

            // Legacy success response
            return $this->response->setJSON([
                'success' => true
            ]);

        } catch (Exception $e) {
            error_log("Error in legacy invalid app reporting: " . $e->getMessage());

            return $this->response->setJSON([
                'success' => false,
                'message' => 'Error occurred'
            ]);
        }
    }

    /**
     * Get invalid apps for a user
     */
    public function get_user_invalid_apps() {
        $user_id = $this->request->getGet('user_id');
        $limit = $this->request->getGet('limit') ?: 100;
        $offset = $this->request->getGet('offset') ?: 0;

        if (!$user_id) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'User ID is required'
            ]);
        }

        try {
            // Check if database is available
            if (!$this->db) {
                throw new Exception('Database connection not available');
            }

            $query = "SELECT * FROM `" . $this->dbprefix . "tracker_invalid_apps`
                     WHERE `user_id` = ? AND `deleted` = 0
                     ORDER BY `detection_time` DESC
                     LIMIT ? OFFSET ?";

            $result = $this->db->query($query, [$user_id, $limit, $offset]);

            return $this->response->setJSON([
                'success' => true,
                'data' => $result->getResult()
            ]);

        } catch (Exception $e) {
            error_log("Error fetching invalid apps: " . $e->getMessage());

            return $this->response->setJSON([
                'success' => false,
                'message' => 'Error fetching invalid apps'
            ]);
        }
    }

    /**
     * Admin dashboard to view and manage invalid apps
     */
    public function admin_dashboard() {
        // Check if user is admin
        if (!$this->check_admin_access()) {
            return redirect()->to('dashboard');
        }

        $data = [
            'title' => 'Invalid Apps Dashboard',
            'view' => 'invalid_apps/dashboard'
        ];

        return view('invalid_apps/dashboard', $data);
    }

    /**
     * Admin API to get all invalid apps
     */
    public function admin_get_invalid_apps() {
        // Check if user is admin
        if (!$this->check_admin_access()) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Unauthorized access'
            ]);
        }

        $limit = $this->request->getGet('limit') ?: 100;
        $offset = $this->request->getGet('offset') ?: 0;
        $search = $this->request->getGet('search');
        $sort_by = $this->request->getGet('sort_by') ?: 'detection_time';
        $sort_dir = $this->request->getGet('sort_dir') ?: 'DESC';

        try {
            // Check if database is available
            if (!$this->db) {
                throw new Exception('Database connection not available');
            }

            // Build query with search support
            $params = [];
            $where_clause = "`deleted` = 0";

            if ($search) {
                $where_clause .= " AND (`app_name` LIKE ? OR `app_details` LIKE ?)";
                $params[] = "%{$search}%";
                $params[] = "%{$search}%";
            }

            // Validate sort parameters
            $allowed_sort_columns = ['id', 'user_id', 'app_name', 'suspicion_score', 'detection_time', 'resolved'];
            if (!in_array($sort_by, $allowed_sort_columns)) {
                $sort_by = 'detection_time';
            }

            $sort_dir = strtoupper($sort_dir) === 'ASC' ? 'ASC' : 'DESC';

            // Get total count for pagination
            $count_query = "SELECT COUNT(*) as total FROM `" . $this->dbprefix . "tracker_invalid_apps` WHERE {$where_clause}";
            $count_result = $this->db->query($count_query, $params)->getRow();
            $total = $count_result->total;

            // Get data with sorting and pagination
            $query = "SELECT ia.*, u.first_name, u.last_name, p.title as project_title
                     FROM `" . $this->dbprefix . "tracker_invalid_apps` ia
                     LEFT JOIN `" . $this->dbprefix . "users` u ON ia.user_id = u.id
                     LEFT JOIN `" . $this->dbprefix . "projects` p ON ia.project_id = p.id
                     WHERE {$where_clause}
                     ORDER BY {$sort_by} {$sort_dir}
                     LIMIT ? OFFSET ?";

            $params[] = $limit;
            $params[] = $offset;

            $result = $this->db->query($query, $params)->getResult();

            return $this->response->setJSON([
                'success' => true,
                'data' => $result,
                'total' => $total,
                'page' => floor($offset / $limit) + 1,
                'limit' => $limit,
                'pages' => ceil($total / $limit)
            ]);

        } catch (Exception $e) {
            error_log("Admin error fetching invalid apps: " . $e->getMessage());

            return $this->response->setJSON([
                'success' => false,
                'message' => 'Error fetching invalid apps: ' . $e->getMessage()
            ]);
        }
    }

    /**
     * Update invalid app record status (admin function)
     */
    public function update_invalid_app_status() {
        // Check if user is admin
        if (!$this->check_admin_access()) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Unauthorized access'
            ]);
        }

        $id = $this->request->getPost('id');
        $resolved = $this->request->getPost('resolved');
        $action_taken = $this->request->getPost('action_taken');
        $notes = $this->request->getPost('notes');

        if (!$id) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Invalid app ID is required'
            ]);
        }

        try {
            // Check if database is available
            if (!$this->db) {
                throw new Exception('Database connection not available');
            }

            $update_data = [];
            $params = [];

            if (isset($resolved)) {
                $update_data[] = "`resolved` = ?";
                $params[] = $resolved ? 1 : 0;
            }

            if (isset($action_taken)) {
                $update_data[] = "`action_taken` = ?";
                $params[] = $action_taken;
            }

            if (isset($notes)) {
                $update_data[] = "`notes` = ?";
                $params[] = $notes;
            }

            if (empty($update_data)) {
                return $this->response->setJSON([
                    'success' => false,
                    'message' => 'No data to update'
                ]);
            }

            $update_query = "UPDATE `" . $this->dbprefix . "tracker_invalid_apps`
                            SET " . implode(", ", $update_data) . ", `updated_at` = NOW()
                            WHERE `id` = ?";

            $params[] = $id;

            $this->db->query($update_query, $params);

            return $this->response->setJSON([
                'success' => true,
                'message' => 'Invalid app record updated successfully'
            ]);

        } catch (Exception $e) {
            error_log("Error updating invalid app: " . $e->getMessage());

            return $this->response->setJSON([
                'success' => false,
                'message' => 'Error updating invalid app: ' . $e->getMessage()
            ]);
        }
    }

    /**
     * Delete invalid app record (admin function)
     */
    public function delete_invalid_app() {
        // Check if user is admin
        if (!$this->check_admin_access()) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Unauthorized access'
            ]);
        }

        $id = $this->request->getPost('id');

        if (!$id) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Invalid app ID is required'
            ]);
        }

        try {
            // Check if database is available
            if (!$this->db) {
                throw new Exception('Database connection not available');
            }

            // Soft delete (set deleted flag)
            $delete_query = "UPDATE `" . $this->dbprefix . "tracker_invalid_apps`
                            SET `deleted` = 1, `updated_at` = NOW()
                            WHERE `id` = ?";

            $this->db->query($delete_query, [$id]);

            return $this->response->setJSON([
                'success' => true,
                'message' => 'Invalid app record deleted successfully'
            ]);

        } catch (Exception $e) {
            error_log("Error deleting invalid app: " . $e->getMessage());

            return $this->response->setJSON([
                'success' => false,
                'message' => 'Error deleting invalid app: ' . $e->getMessage()
            ]);
        }
    }

    /**
     * Send notification to admin about invalid app detection
     */
    private function notify_admin($data) {
        try {
            // Use model to notify admin
            $this->InvalidApp_model->notifyAdmin($data);
        } catch (Exception $e) {
            error_log("Error sending admin notification: " . $e->getMessage());
        }
    }

    /**
     * Check if the current user has admin access
     *
     * @return bool True if user is admin, false otherwise
     */
    private function check_admin_access() {
        try {
            // Use model to check admin access
            return $this->InvalidApp_model->checkAdminAccess();
        } catch (Exception $e) {
            error_log("Error checking admin access: " . $e->getMessage());
            return false;
        }
    }
}
