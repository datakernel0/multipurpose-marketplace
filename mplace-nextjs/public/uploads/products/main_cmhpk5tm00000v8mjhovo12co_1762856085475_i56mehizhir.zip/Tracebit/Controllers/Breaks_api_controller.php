<?php

namespace Tracebit\Controllers;

use Tracebit\Models\Tracker_breaks_model;
use CodeIgniter\API\ResponseTrait;

class Breaks_api_controller extends \CodeIgniter\Controller
{
    use ResponseTrait;

    protected $breaks_model;

    public function __construct()
    {
        $this->breaks_model = model("Tracebit\Models\Tracker_breaks_model");
    }

    /**
     * Get all active breaks
     * GET /tracker/api/breaks
     */
    public function index()
    {
        try {
            $breaks = $this->breaks_model->get_active_breaks();

            if ($breaks === false) {
                return $this->fail('Failed to retrieve breaks', 500);
            }

            // Format response for frontend consumption
            $formatted_breaks = $this->format_breaks_for_api($breaks);

            return $this->respond([
                'status' => 'success',
                'data' => $formatted_breaks,
                'meta' => [
                    'count' => count($formatted_breaks),
                    'timestamp' => date('Y-m-d H:i:s'),
                    'version' => '1.0'
                ]
            ]);

        } catch (\Exception $e) {
            log_message('error', '[TRACKER_API] Breaks API error: ' . $e->getMessage());
            error_log($e->getMessage());
            return $this->fail('Internal server error', 500);
        }
    }

    /**
     * Get a specific break by ID or value
     * GET /tracker/api/breaks/{id}
     */
    public function show($id = null)
    {
        try {
            if (empty($id)) {
                return $this->fail('Break ID is required', 400);
            }

            $break = $this->breaks_model->get_break_by_id($id);

            if (!$break) {
                return $this->failNotFound('Break not found');
            }

            return $this->respond([
                'status' => 'success',
                'data' => $this->format_single_break($break)
            ]);

        } catch (\Exception $e) {
            log_message('error', '[TRACKER_API] Break show error: ' . $e->getMessage());
            return $this->fail('Internal server error', 500);
        }
    }

    /**
     * Create a new break (Admin only)
     * POST /tracker/api/breaks
     */
    public function create()
    {
        try {
            $input = $this->request->getJSON(true);

            if (!$input) {
                return $this->fail('Invalid JSON data', 400);
            }

            // Validate required fields
            $validation_rules = [
                'name' => 'required|max_length[100]',
                'icon' => 'required|max_length[10]',
                'description' => 'permit_empty|max_length[255]',
                'isMinusBreak' => 'required|in_list[0,1,true,false]',
                'is_active' => 'permit_empty|in_list[0,1,true,false]'
            ];

            if (!$this->validateInput($input, $validation_rules)) {
                return $this->fail([
                    'status' => 'error',
                    'message' => 'Validation failed',
                    'errors' => $this->validator->getErrors()
                ], 400);
            }

            $break_id = $this->breaks_model->create_break($input);

            if (!$break_id) {
                return $this->fail('Failed to create break', 500);
            }

            $created_break = $this->breaks_model->get_break_by_id($break_id);

            return $this->respondCreated([
                'status' => 'success',
                'message' => 'Break created successfully',
                'data' => $this->format_single_break($created_break)
            ]);

        } catch (\Exception $e) {
            log_message('error', '[TRACKER_API] Break create error: ' . $e->getMessage());
            return $this->fail('Internal server error', 500);
        }
    }

    /**
     * Update an existing break (Admin only)
     * PUT /tracker/api/breaks/{id}
     */
    public function update($id = null)
    {
        try {
            if (empty($id)) {
                return $this->fail('Break ID is required', 400);
            }

            $input = $this->request->getJSON(true);

            if (!$input) {
                return $this->fail('Invalid JSON data', 400);
            }

            $existing_break = $this->breaks_model->get_break_by_id($id);
            if (!$existing_break) {
                return $this->failNotFound('Break not found');
            }

            $updated = $this->breaks_model->update_break($id, $input);

            if (!$updated) {
                return $this->fail('Failed to update break', 500);
            }

            $updated_break = $this->breaks_model->get_break_by_id($id);

            return $this->respond([
                'status' => 'success',
                'message' => 'Break updated successfully',
                'data' => $this->format_single_break($updated_break)
            ]);

        } catch (\Exception $e) {
            log_message('error', '[TRACKER_API] Break update error: ' . $e->getMessage());
            return $this->fail('Internal server error', 500);
        }
    }

    /**
     * Delete a break (Admin only)
     * DELETE /tracker/api/breaks/{id}
     */
    public function delete($id = null)
    {
        try {
            if (empty($id)) {
                return $this->fail('Break ID is required', 400);
            }

            $existing_break = $this->breaks_model->get_break_by_id($id);
            if (!$existing_break) {
                return $this->failNotFound('Break not found');
            }

            $deleted = $this->breaks_model->soft_delete_break($id);

            if (!$deleted) {
                return $this->fail('Failed to delete break', 500);
            }

            return $this->respondDeleted([
                'status' => 'success',
                'message' => 'Break deleted successfully'
            ]);

        } catch (\Exception $e) {
            log_message('error', '[TRACKER_API] Break delete error: ' . $e->getMessage());
            return $this->fail('Internal server error', 500);
        }
    }

    /**
     * Get default fallback breaks (for offline/error scenarios)
     * GET /tracker/api/breaks/defaults
     */
    public function defaults()
    {
        try {
            $default_breaks = $this->get_default_breaks();

            return $this->respond([
                'status' => 'success',
                'data' => $default_breaks,
                'meta' => [
                    'count' => count($default_breaks),
                    'source' => 'defaults',
                    'timestamp' => date('Y-m-d H:i:s')
                ]
            ]);

        } catch (\Exception $e) {
            log_message('error', '[TRACKER_API] Default breaks error: ' . $e->getMessage());
            return $this->fail('Internal server error', 500);
        }
    }

    /**
     * Format breaks array for API response
     */
    private function format_breaks_for_api($breaks)
    {
        $formatted = [];

        foreach ($breaks as $break) {
            $formatted[] = $this->format_single_break($break);
        }

        return $formatted;
    }

    /**
     * Format single break for API response
     */
    private function format_single_break($break)
    {
        return [
            'id' => (int)$break->id,
            'value' => $break->value,
            'name' => $break->name,
            'icon' => $break->icon,
            'max_time' => $break->max_time,
            'description' => $break->description ?? '',
            'isMinusBreak' => (bool)$break->is_minus_break,
            'is_active' => (bool)$break->is_active,
            'sort_order' => (int)$break->sort_order,
            'created_at' => $break->created_at,
            'updated_at' => $break->updated_at
        ];
    }

    /**
     * Get default breaks for fallback
     */
    private function get_default_breaks()
    {
        return [
            [
                'id' => 1,
                'value' => 'b-1',
                'name' => 'Team Collaboration',
                'icon' => '👥',
                'description' => 'Working with team members',
                'isMinusBreak' => false,
                'is_active' => true,
                'sort_order' => 1
            ],
            [
                'id' => 2,
                'value' => 'b-2',
                'name' => 'General Meeting',
                'icon' => '📋',
                'description' => 'Attending meetings',
                'isMinusBreak' => false,
                'is_active' => true,
                'sort_order' => 2
            ],
            [
                'id' => 3,
                'value' => 'b-3',
                'name' => 'Standup Meeting',
                'icon' => '🏃',
                'description' => 'Daily standup session',
                'isMinusBreak' => false,
                'is_active' => true,
                'sort_order' => 3
            ],
            [
                'id' => 4,
                'value' => 'b-4',
                'name' => 'Project Planning',
                'icon' => '📊',
                'description' => 'Planning and strategizing',
                'isMinusBreak' => false,
                'is_active' => true,
                'sort_order' => 4
            ],
            [
                'id' => 5,
                'value' => 'b-5',
                'name' => 'Personal Break',
                'icon' => '☕',
                'description' => 'Short personal break',
                'isMinusBreak' => true,
                'is_active' => true,
                'sort_order' => 5
            ],
            [
                'id' => 6,
                'value' => 'b-6',
                'name' => 'Project Review',
                'icon' => '🔍',
                'description' => 'Reviewing project progress',
                'isMinusBreak' => false,
                'is_active' => true,
                'sort_order' => 6
            ],
            [
                'id' => 7,
                'value' => 'b-7',
                'name' => 'Training & Learning',
                'icon' => '📚',
                'description' => 'Professional development',
                'isMinusBreak' => false,
                'is_active' => true,
                'sort_order' => 7
            ],
            [
                'id' => 8,
                'value' => 'b-8',
                'name' => 'Client Communication',
                'icon' => '📞',
                'description' => 'Client calls and communication',
                'isMinusBreak' => false,
                'is_active' => true,
                'sort_order' => 8
            ],
            [
                'id' => 9,
                'value' => 'b-9',
                'name' => 'Other',
                'icon' => '🔧',
                'description' => 'Other work-related activities',
                'isMinusBreak' => false,
                'is_active' => true,
                'sort_order' => 9
            ]
        ];
    }

    /**
     * Validate input data using CodeIgniter validation
     */
    private function validateInput($data, $rules)
    {
        $validation = \Config\Services::validation();
        $validation->setRules($rules);

        return $validation->run($data);
    }
}
