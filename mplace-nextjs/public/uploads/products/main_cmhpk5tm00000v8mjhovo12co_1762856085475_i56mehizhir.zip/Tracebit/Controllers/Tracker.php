<?php

namespace Tracebit\Controllers;

use App\Controllers\Security_Controller;

class Tracker extends Security_Controller {

    protected $Employee_status_model;
    protected $Screenshots_model;
    public $Users_model;

    function __construct() {
        parent::__construct();
        $this->Employee_status_model = model("Tracebit\Models\Employee_status_model");
        $this->Screenshots_model = model("Tracebit\Models\Screenshots_model");
        $this->Users_model = model("App\Models\Users_model");
    }

    function index() {
        // Handle AJAX requests
        if ($this->request->isAJAX()) {
            $action = $this->request->getPost('action');

            if ($action === 'get_project_recap') {
                return $this->get_project_recap();
            }
        }

        // Basic error handling with try-catch
        try {
            // Use user's timezone for date calculation
            $originalTimezone = date_default_timezone_get();
            date_default_timezone_set('Asia/Dhaka'); // Set to local timezone
            $current_date = date('Y-m-d');
            date_default_timezone_set($originalTimezone); // Reset to original

            $view_data = array(
                "date" => $current_date,
                "user_id" => $this->login_user->id,
            );

            // Get user activity status with basic error handling
            try {
                // Use dashboard helper for team status instead of attendance data
                require_once(FCPATH . 'plugins/Tracebit/Views/tracker/dashboard_helpers.php');
                $dashboardHelper = \Tracebit\Helpers\TrackerDashboardHelper::getInstance();
                $view_data['team_members'] = $dashboardHelper->getTeamMembersStatus();

            } catch (\Exception $e) {
                error_log("Failed to get team members: " . $e->getMessage());
                $view_data['team_members'] = [];
            }

            // Get latest screenshots with basic error handling
            try {
                $screenshot_data = array(
                    'user_id' => $this->login_user->id,
                    'limit' => 6  // Get 6 recent screenshots for dashboard
                );
                $view_data['screenshots'] = $this->Screenshots_model->getLatestScreenshots($screenshot_data);
                if ($view_data['screenshots'] === false) {
                    $view_data['screenshots'] = [];
                }
            } catch (\Exception $e) {
                error_log("Failed to get screenshots: " . $e->getMessage());
                $view_data['screenshots'] = [];
            }

            return $this->template->rander('Tracebit\Views\tracker\index', $view_data);

        } catch (\Exception $e) {
            error_log("TRACKER DEBUG: Exception in index: " . $e->getMessage());
            return;
        }
    }

    function get_project_recap() {
        try {
            $filter = $this->request->getPost('filter') ?: 'weekly';
            $user_id = $this->login_user->id;

            // Load dashboard helper
            require_once(FCPATH . 'plugins/Tracebit/Views/tracker/dashboard_helpers.php');
            $dashboardHelper = \Tracebit\Helpers\TrackerDashboardHelper::getInstance();

            // Get project recap data
            $project_recap = $dashboardHelper->calculateProjectRecap($user_id, $filter);

            // Return JSON response
            $response = [
                'success' => true,
                'filter' => $filter,
                'chart' => [
                    'labels' => $project_recap['chart_labels'],
                    'values' => $project_recap['chart_values'],
                    'colors' => $project_recap['chart_colors']
                ],
                'projects' => $project_recap['projects'],
                'total_time' => $project_recap['total_project_time']
            ];

            return $this->response
                ->setContentType('application/json')
                ->setBody(json_encode($response));

        } catch (\Exception $e) {
            error_log("Failed to get project recap: " . $e->getMessage());

            $response = [
                'success' => false,
                'error' => $e->getMessage()
            ];

            return $this->response
                ->setContentType('application/json')
                ->setBody(json_encode($response));
        }
    }

    function screenshots() {
        try {
            $date = $this->request->getPost('date') ? $this->request->getPost('date') : date('Y-m-d');
            $user_id = $this->request->getPost('user_id') ? $this->request->getPost('user_id') : $this->login_user->id;

            $view_data = array(
                "date" => $date,
                "user_id" => $user_id,
            );

            // Get team members for dropdown with error handling
            try {
                $members = $this->Users_model->get_dropdown_list(array("first_name", "last_name"), "id");

                if ($members === false || empty($members)) {
                    $view_data['team_members_dropdown'] = array("" => "Select Team Member");
                } else {
                    $view_data['team_members_dropdown'] = array("" => "Select Team Member") + $members;
                }
            } catch (\Exception $e) {
                $view_data['team_members_dropdown'] = array("" => "Select Team Member");
            }

            // Get screenshots with error handling
            try {
                $view_data['screenshot'] = $this->Screenshots_model->getScreenshots($view_data);
                if ($view_data['screenshot'] === false) {
                    $view_data['screenshot'] = [];
                }
            } catch (\Exception $e) {
                error_log("Screenshots Controller Exception: " . $e->getMessage());
                $view_data['screenshot'] = [];
            }

            return $this->template->rander('Tracebit\Views\tracker\screenshots', $view_data);

        } catch (\Exception $e) {
            echo "Error loading screenshots: " . $e->getMessage();
            return;
        }
    }

    function attendance() {
        try {
            $date = $this->request->getPost('date') ? $this->request->getPost('date') : date('Y-m-d');
            $user_id = $this->request->getPost('user_id') ? $this->request->getPost('user_id') : $this->login_user->id;

            $view_data = array(
                "date" => $date,
                "user_id" => $user_id,
            );

            // Get team members for dropdown
            try {
                $members = $this->Users_model->get_dropdown_list(array("first_name", "last_name"), "id");

                if ($members === false || empty($members)) {
                    $view_data['team_members_dropdown'] = array("" => "Select Team Member");
                } else {
                    $view_data['team_members_dropdown'] = array("" => "Select Team Member") + $members;
                }
            } catch (\Exception $e) {
                error_log("Failed to get team members dropdown: " . $e->getMessage());
                $view_data['team_members_dropdown'] = array("" => "Select Team Member");
            }

            // Get attendance data
            try {
                $view_data['attendance'] = $this->Employee_status_model->getAttendance($view_data);
                if ($view_data['attendance'] === false) {
                    $view_data['attendance'] = [];
                }
            } catch (\Exception $e) {
                error_log("Failed to get attendance: " . $e->getMessage());
                $view_data['attendance'] = [];
            }

            return $this->template->rander('Tracebit\Views\tracker\attendance', $view_data);

        } catch (\Exception $e) {
            error_log("Tracker attendance error: " . $e->getMessage());
            echo "Error loading attendance: " . $e->getMessage();
            return;
        }
    }

    function timeSheet() {
        try {
            $date = $this->request->getPost('date') ? $this->request->getPost('date') : date('Y-m-d');
            $user_id = $this->request->getPost('user_id') ? $this->request->getPost('user_id') : $this->login_user->id;

            $view_data = array(
                "date" => $date,
                "user_id" => $user_id,
                "login_user" => $this->login_user,
            );

            // Get team members for dropdown
            try {
                $members = $this->Users_model->get_dropdown_list(array("first_name", "last_name"), "id");

                if ($members === false || empty($members)) {
                    error_log("Failed to get team members dropdown for timesheet");
                    $view_data['team_members_dropdown'] = array("" => "Select Team Member");
                } else {
                    $view_data['team_members_dropdown'] = array("" => "Select Team Member") + $members;
                }
            } catch (\Exception $e) {
                error_log("Failed to get team members dropdown: " . $e->getMessage());
                $view_data['team_members_dropdown'] = array("" => "Select Team Member");
            }

            // Get timesheet data
            try {
                $view_data['timesheet'] = $this->Employee_status_model->getTimeSheet($view_data);
                if ($view_data['timesheet'] === false) {
                    $view_data['timesheet'] = [];
                }
            } catch (\Exception $e) {
                $view_data['timesheet'] = [];
            }

            return $this->template->rander('Tracebit\Views\tracker\timeSheet', $view_data);

        } catch (\Exception $e) {
            echo "Error loading timesheet: " . $e->getMessage();
            return;
        }
    }

    function activityLog() {
        try {
            $view_data = array();

            // Pass login_user to the view to prevent undefined variable error
            $view_data['login_user'] = $this->login_user;

            return $this->template->rander('Tracebit\Views\tracker\activityLog', $view_data);

        } catch (\Exception $e) {
            error_log("Tracebit activity_log error: " . $e->getMessage());
            echo "Error loading activity log: " . $e->getMessage();
            return;
        }
    }

    /**
     * Handle check-in/check-out requests
     */
    function clock_toggle() {
        try {
            $this->validate_submitted_data(array(
                "action" => "required"
            ));

            $action = $this->request->getPost('action');
            $note = $this->request->getPost('note') ?: '';
            $user_id = $this->login_user->id;

            // Initialize attendance model
            $attendance_model = model("Tracebit\Models\Tracker_attendance_model");

            if ($action === 'checkin') {
                $result = $attendance_model->clock_in($user_id, $note);
                if ($result) {
                    $status = $attendance_model->get_current_status($user_id);
                    echo json_encode([
                        "success" => true,
                        "message" => "Successfully checked in",
                        "action" => "checkin",
                        "status" => $status,
                        "time" => format_to_time(get_current_utc_time())
                    ]);
                } else {
                    echo json_encode(["success" => false, "message" => "Failed to check in"]);
                }
            } else if ($action === 'checkout') {
                $attendance_id = $this->request->getPost('attendance_id');
                $result = $attendance_model->clock_out($user_id, $attendance_id, $note);
                if ($result) {
                    echo json_encode([
                        "success" => true,
                        "message" => "Successfully checked out",
                        "action" => "checkout",
                        "status" => null
                    ]);
                } else {
                    echo json_encode(["success" => false, "message" => "Failed to check out"]);
                }
            } else {
                echo json_encode(["success" => false, "message" => "Invalid action"]);
            }

        } catch (\Exception $e) {
            error_log("Clock toggle error: " . $e->getMessage());
            echo json_encode(["success" => false, "message" => "An error occurred: " . $e->getMessage()]);
        }
    }

    /**
     * Get current attendance status for the logged in user
     */
    function get_attendance_status() {
        try {
            $user_id = $this->login_user->id;
            $attendance_model = model("Tracebit\Models\Tracker_attendance_model");
            $status = $attendance_model->get_current_status($user_id);

            echo json_encode([
                "success" => true,
                "status" => $status,
                "is_checked_in" => $status ? true : false,
                "check_in_time" => $status ? format_to_time($status->inTime) : null
            ]);
        } catch (\Exception $e) {
            error_log("Get attendance status error: " . $e->getMessage());
            echo json_encode(["success" => false, "message" => "Failed to get status"]);
        }
    }


}
