<?php

namespace Tracebit\Controllers;

use App\Controllers\Security_Controller;

class Tracker_settings extends Security_Controller {

    protected $Tracker_settings_model;
    protected $Tracker_holidays_model;

    function __construct() {
        parent::__construct();
        $this->access_only_admin_or_settings_admin();
        $this->Tracker_settings_model = model("Tracebit\Models\Tracker_settings_model");
    }

    function index() {
        // Check if settings exist, if not, initialize them
        $app_settings = $this->Tracker_settings_model->get_settings_array_by_type('app_settings');

        // If no settings exist, initialize defaults
        if (empty($app_settings)) {
            log_message('info', '[TRACKER] No settings found, initializing defaults');
            $this->Tracker_settings_model->initialize_default_settings();

            // Re-fetch settings after initialization
            $app_settings = $this->Tracker_settings_model->get_settings_array_by_type('app_settings');
        }

        // Get all setting types for the settings page
        $data['app_settings'] = $app_settings;
        $data['web_settings'] = $this->Tracker_settings_model->get_settings_array_by_type('web_settings');
        $data['break_settings'] = $this->Tracker_settings_model->get_settings_array_by_type('break_settings');
        $data['weekend_settings'] = $this->Tracker_settings_model->get_settings_array_by_type('weekend_settings');

        // Get holidays settings
        $holiday_tracking = $this->Tracker_settings_model->get_setting('holiday_tracking');

        // If holidays model exists, get holidays from the database
        $holidays = [];
        if (class_exists('Tracebit\Models\Tracker_holidays_model')) {
            $this->Tracker_holidays_model = model("Tracebit\Models\Tracker_holidays_model");
            $holidays = $this->Tracker_holidays_model->get_holidays_for_settings();
        }

        $data['holidays_settings'] = [
            'holiday_tracking' => $holiday_tracking,
            'holidays' => !empty($holidays) ? json_encode($holidays) : '[]'
        ];

        return $this->template->rander("Tracebit\Views\settings\index", $data);
    }

    function save() {
        $this->Tracker_settings_model->save_setting("setting_tracker", $this->request->getPost("setting_tracker"));

        //save file
        $files_data = move_files_from_temp_dir_to_permanent_dir(get_tracker_setting("demo_file_path"), "demo");
        $unserialize_files_data = unserialize($files_data);
        $demo_file = get_array_value($unserialize_files_data, 0);
        if ($demo_file) {
            if (get_tracker_setting("file_demo")) {
                //delete old file if exists
                $this->delete_demo_file(get_tracker_setting("file_demo"));
            }

            $this->Tracker_settings_model->save_setting("file_demo", serialize($demo_file));
        }

        echo json_encode(array("success" => true, 'message' => app_lang('settings_updated')));
    }

    /**
     * Save settings by type
     */
    function save_by_type() {

        $type = $this->request->getPost('type');
        $settings = $this->request->getPost('settings');
        error_log(print_r($settings, true));
        // Validate type
        $allowed_types = ['app_settings', 'web_settings', 'holidays_settings', 'break_settings', 'weekend_settings'];

        if (!in_array($type, $allowed_types)) {
            echo json_encode(array("success" => false, 'message' => 'Invalid setting type'));
            return;
        }

        if (!is_array($settings)) {
            echo json_encode(array("success" => false, 'message' => 'Invalid settings data'));
            return;
        }

        // Handle checkbox fields for all types (unchecked checkboxes don't get sent)
        if ($type === 'web_settings') {
            $checkbox_fields = ['enable_notifications', 'minimize_to_tray', 'start_with_system', 'show_detailed_stats', 'dashboard_checkin', 'compact_view'];
            foreach ($checkbox_fields as $field) {
                if (!isset($settings[$field])) {
                    $settings[$field] = '0';
                }
            }
        }

        if ($type === 'app_settings') {
            $checkbox_fields = ['enable_screenshots', 'enable_activity_tracking', 'enable_idle_detection', 'productivity_tracking', 'dashboard_checkin_active', 'query_cache_enabled', 'force_screenshot_encryption', 'require_checkout_confirmation'];
            error_log(print_r($checkbox_fields, true));
            foreach ($checkbox_fields as $field) {
                if (!isset($settings[$field])) {
                    $settings[$field] = '0';
                    file_put_contents(ROOTPATH . 'debug_save.txt', "Set {$field} to 0 (unchecked)\n", FILE_APPEND);
                }
            }
        }

        // Special handling for weekend_days array in weekend_settings
        if ($type === 'weekend_settings') {
            // We need to handle both array and non-array formats due to different ways form data can be submitted
            if (isset($settings['weekend_days'])) {
                if (is_array($settings['weekend_days'])) {
                    // When submitted as array (normal case)
                    $valid_days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
                    $weekend_days = [];

                    // Extract only valid days and clean any empty values
                    foreach ($settings['weekend_days'] as $day) {
                        if (!empty($day) && in_array($day, $valid_days)) {
                            $weekend_days[] = $day;
                        }
                    }

                    // Convert clean array to comma-separated string
                    $settings['weekend_days'] = implode(',', $weekend_days);

                } else if (is_string($settings['weekend_days'])) {
                    // Handle case when submitted as string (fallback or empty case)
                    if (empty($settings['weekend_days'])) {
                        $settings['weekend_days'] = '';
                    } else {
                        $days = explode(',', $settings['weekend_days']);
                        $valid_days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
                        $days = array_filter($days, function($day) use ($valid_days) {
                            return in_array($day, $valid_days);
                        });
                        $settings['weekend_days'] = implode(',', $days);
                    }
                }
            } else {
                // If weekend_days is not set at all, set it to empty string
                $settings['weekend_days'] = '';
            }

        }

        try {
            $success = $this->Tracker_settings_model->save_settings_batch_by_type($settings, $type);

            if ($success) {
                // Check if this is an AJAX request
                echo json_encode(array("success" => true, 'message' => app_lang('settings_updated'), 'debug' => 'Saved successfully to database'));

            } else {
                echo json_encode(array("success" => false, 'message' => 'Failed to save settings', 'debug' => 'Model save returned false'));
            }
        } catch (\Exception $e) {
            echo json_encode(array("success" => false, 'message' => $e->getMessage()));
        }
    }

    /**
     * Get settings by type (AJAX endpoint)
     */
    function get_by_type() {
        $type = $this->request->getGet('type');

        // Validate type
        $allowed_types = ['app_settings', 'web_settings', 'holidays_settings', 'break_settings', 'weekend_settings'];
        if (!in_array($type, $allowed_types)) {
            echo json_encode(array("success" => false, 'message' => 'Invalid setting type'));
            return;
        }

        try {
            $settings = $this->Tracker_settings_model->get_settings_array_by_type($type);
            echo json_encode(array("success" => true, 'settings' => $settings));
        } catch (\Exception $e) {
            echo json_encode(array("success" => false, 'message' => $e->getMessage()));
        }
    }

    /**
     * Initialize default settings for all types
     */
    function initialize_defaults() {
        try {
            $success = $this->Tracker_settings_model->initialize_default_settings();

            if ($success) {
                echo json_encode(array("success" => true, 'message' => 'Default settings initialized successfully'));
            } else {
                echo json_encode(array("success" => false, 'message' => 'Failed to initialize default settings'));
            }
        } catch (\Exception $e) {
            echo json_encode(array("success" => false, 'message' => $e->getMessage()));
        }
    }

    private function delete_demo_file($demo_file) {
        try {
            $demo_file = unserialize($demo_file);
        } catch (\Exception $ex) {
            echo json_encode(array("success" => false, 'message' => $ex->getMessage()));
            exit();
        }

        delete_app_files(get_tracker_setting("demo_file_path"), array($demo_file));
    }

    /* upload a file */

    function upload_file() {
        upload_file_to_temp();
    }

    /* check valid file */

    function validate_demo_file() {
        return validate_post_file($this->request->getPost("file_name"));
    }

    /**
     * Test endpoint to verify routing
     */
    function test_endpoint() {
        echo json_encode(array("success" => true, "message" => "Test endpoint working", "timestamp" => date('Y-m-d H:i:s')));
        return;
    }

    /**
     * Public test endpoint - no authentication required
     */
    function public_test() {
        // Create debug file to prove this method was called
        file_put_contents(ROOTPATH . 'public_test_called.txt', date('Y-m-d H:i:s') . " - public_test called\n", FILE_APPEND);

        echo json_encode(array(
            "success" => true,
            "message" => "Public test endpoint working",
            "timestamp" => date('Y-m-d H:i:s'),
            "method" => $_SERVER['REQUEST_METHOD'],
            "post_data" => $_POST
        ));
        return;
    }

}
