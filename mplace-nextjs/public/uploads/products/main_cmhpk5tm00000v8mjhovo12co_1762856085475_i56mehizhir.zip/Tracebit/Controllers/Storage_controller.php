<?php

namespace Tracebit\Controllers;

use App\Controllers\App_Controller;
use Tracebit\Traits\Error_handling_trait;
use Exception;

class Storage_controller extends App_Controller {

    use Error_handling_trait;

    private $db;
    private $dbprefix;

    public function __construct() {
        parent::__construct();
        
        // Initialize database connection
        $this->db = \Config\Database::connect();
        $this->dbprefix = $this->db->getPrefix();
    }

    /**
     * Preview storage management action
     */
    public function preview() {
        try {
            // Get parameters from form (action_type and selection_type)
            $action = $this->request->getPost('action_type');
            $type = $this->request->getPost('selection_type');
            
            // Fallback to old parameter names if new ones are not available
            if (!$action) {
                $action = $this->request->getPost('action');
            }
            if (!$type) {
                $type = $this->request->getPost('type');
            }
            
            if (!$action || !$type) {
                return $this->response->setJSON([
                    'success' => false,
                    'message' => 'Missing required parameters: action_type and selection_type'
                ]);
            }

            // Get preview data based on type
            $preview_data = $this->getPreviewData($type);
            
            // Check if there was an error in getting preview data
            if (isset($preview_data['error'])) {
                return $this->response->setJSON([
                    'success' => false,
                    'message' => $preview_data['error']
                ]);
            }
            
            $html = $this->generatePreviewHtml($action, $type, $preview_data);
            
            return $this->response->setJSON([
                'success' => true,
                'html' => $html
            ]);

        } catch (Exception $e) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Error generating preview: ' . $e->getMessage()
            ]);
        }
    }

    /**
     * Execute storage management action
     */
    public function execute() {
        try {
            // Get parameters from form (action_type and selection_type)
            $action = $this->request->getPost('action_type');
            $type = $this->request->getPost('selection_type');
            
            // Fallback to old parameter names if new ones are not available
            if (!$action) {
                $action = $this->request->getPost('action');
            }
            if (!$type) {
                $type = $this->request->getPost('type');
            }
            
            if (!$action || !$type) {
                return $this->response->setJSON([
                    'success' => false,
                    'message' => 'Missing required parameters: action_type and selection_type'
                ]);
            }

            // Validate user permissions
            if (!$this->checkStoragePermissions()) {
                return $this->response->setJSON([
                    'success' => false,
                    'message' => 'Unauthorized access'
                ]);
            }

            if ($action === 'export') {
                $result = $this->executeExport($type);
            } elseif ($action === 'delete') {
                $result = $this->executeDelete($type);
            } else {
                return $this->response->setJSON([
                    'success' => false,
                    'message' => 'Invalid action'
                ]);
            }

            return $this->response->setJSON($result);

        } catch (Exception $e) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Error executing action: ' . $e->getMessage()
            ]);
        }
    }

    /**
     * Get storage statistics
     */
    public function stats() {
        try {
            $stats = $this->getStorageStatistics();
            $html = $this->generateStatsHtml($stats);
            
            return $this->response->setJSON([
                'success' => true,
                'html' => $html
            ]);

        } catch (Exception $e) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Error loading statistics: ' . $e->getMessage()
            ]);
        }
    }

    /**
     * Get preview data based on type
     */
    private function getPreviewData($type) {
        try {
            // Check if tracker_screenshots table exists
            $table_exists = $this->db->tableExists($this->dbprefix . 'tracker_screenshots');
            if (!$table_exists) {
                return [
                    'error' => 'Screenshots table not found. Please ensure the tracker_screenshots table exists.',
                    'data' => []
                ];
            }
            
            $data = [];
            
            switch ($type) {
                case 'date_range':
                    $start_date = $this->request->getPost('start_date');
                    $end_date = $this->request->getPost('end_date');
                    
                    if ($start_date && $end_date) {
                        $data = $this->getScreenshotsByDateRange($start_date, $end_date);
                    }
                    break;
                    
                case 'user':
                    $user_id = $this->request->getPost('user_id');
                    $year = $this->request->getPost('year');
                    
                    $data = $this->getScreenshotsByUser($user_id, $year);
                    break;
                    
                case 'year':
                    $year = $this->request->getPost('year');
                    $month = $this->request->getPost('month');
                    
                    if ($year) {
                        $data = $this->getScreenshotsByYear($year, $month);
                    }
                    break;
            }
            
            return $data;
            
        } catch (Exception $e) {
            return [
                'error' => 'Database error: ' . $e->getMessage(),
                'data' => []
            ];
        }
    }

    /**
     * Generate preview HTML
     */
    private function generatePreviewHtml($action, $type, $data) {
        $html = '<div class="preview-content">';
        
        if (empty($data)) {
            $html .= '<div class="alert alert-info">No screenshots found for the selected criteria.</div>';
            return $html;
        }

        $total_files = count($data);
        $total_size = 0;
        
        // Calculate total size from objects
        foreach ($data as $file) {
            $total_size += isset($file->size) ? $file->size : 0;
        }
        
        $size_formatted = $this->formatBytes($total_size);

        $html .= '<div class="row mb-3">';
        $html .= '<div class="col-md-4"><strong>Total Files:</strong> ' . number_format($total_files) . '</div>';
        $html .= '<div class="col-md-4"><strong>Total Size:</strong> ' . $size_formatted . '</div>';
        $html .= '<div class="col-md-4"><strong>Action:</strong> ' . ucfirst($action) . '</div>';
        $html .= '</div>';

        if ($total_files > 0) {
            $html .= '<div class="table-responsive">';
            $html .= '<table class="table table-sm table-striped">';
            $html .= '<thead><tr><th>File</th><th>User</th><th>Date</th><th>Size</th></tr></thead>';
            $html .= '<tbody>';
            
            foreach (array_slice($data, 0, 10) as $file) {
                $html .= '<tr>';
                $html .= '<td>' . basename($file->path ?? 'unknown') . '</td>';
                $html .= '<td>' . ($file->user_name ?? 'Unknown') . '</td>';
                $html .= '<td>' . date('Y-m-d H:i', strtotime($file->created_at ?? 'now')) . '</td>';
                $html .= '<td>' . $this->formatBytes($file->size ?? 0) . '</td>';
                $html .= '</tr>';
            }
            
            if ($total_files > 10) {
                $html .= '<tr><td colspan="4" class="text-center">... and ' . ($total_files - 10) . ' more files</td></tr>';
            }
            
            $html .= '</tbody></table>';
            $html .= '</div>';
        }

        $html .= '</div>';
        return $html;
    }

    /**
     * Execute export action
     */
    private function executeExport($type) {
        $format = $this->request->getPost('format') ?: 'zip';
        $include_metadata = $this->request->getPost('include_metadata') ? true : false;
        
        $data = $this->getPreviewData($type);
        
        if (empty($data)) {
            return [
                'success' => false,
                'message' => 'No screenshots found for export'
            ];
        }

        try {
            $export_file = $this->createExport($data, $format, $include_metadata);
            
            return [
                'success' => true,
                'message' => 'Export completed successfully',
                'download_url' => $export_file
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Export failed: ' . $e->getMessage()
            ];
        }
    }

    /**
     * Execute delete action
     */
    private function executeDelete($type) {
        $data = $this->getPreviewData($type);
        
        if (empty($data)) {
            return [
                'success' => false,
                'message' => 'No screenshots found for deletion'
            ];
        }

        try {
            $deleted_count = $this->deleteScreenshots($data);
            
            return [
                'success' => true,
                'message' => "Successfully deleted {$deleted_count} screenshots",
                'refresh' => true
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Delete failed: ' . $e->getMessage()
            ];
        }
    }

    /**
     * Get screenshots by date range
     */
    private function getScreenshotsByDateRange($start_date, $end_date) {
        try {
            $sql = "SELECT ts.*, u.first_name, u.last_name, CONCAT(u.first_name, ' ', u.last_name) as user_name
                    FROM {$this->dbprefix}tracker_screenshots ts
                    LEFT JOIN {$this->dbprefix}users u ON ts.user_id = u.id
                    WHERE DATE(ts.created_at) BETWEEN ? AND ?
                    AND ts.deleted = 0
                    ORDER BY ts.created_at DESC";
            
            $result = $this->db->query($sql, [$start_date, $end_date]);
            $screenshots = $result->getResult();
            
            return $this->addFileInfo($screenshots);
        } catch (Exception $e) {
            error_log("Error in getScreenshotsByDateRange: " . $e->getMessage());
            return [];
        }
    }

    /**
     * Get screenshots by user
     */
    private function getScreenshotsByUser($user_id, $year = null) {
        try {
            $sql = "SELECT ts.*, u.first_name, u.last_name, CONCAT(u.first_name, ' ', u.last_name) as user_name
                    FROM {$this->dbprefix}tracker_screenshots ts
                    LEFT JOIN {$this->dbprefix}users u ON ts.user_id = u.id
                    WHERE ts.deleted = 0";
            
            $params = [];
            
            if ($user_id) {
                $sql .= " AND ts.user_id = ?";
                $params[] = $user_id;
            }
            
            if ($year) {
                $sql .= " AND YEAR(ts.created_at) = ?";
                $params[] = $year;
            }
            
            $sql .= " ORDER BY ts.created_at DESC";
            
            $result = $this->db->query($sql, $params);
            $screenshots = $result->getResult();
            
            return $this->addFileInfo($screenshots);
        } catch (Exception $e) {
            error_log("Error in getScreenshotsByUser: " . $e->getMessage());
            return [];
        }
    }

    /**
     * Get screenshots by year
     */
    private function getScreenshotsByYear($year, $month = null) {
        try {
            $sql = "SELECT ts.*, u.first_name, u.last_name, CONCAT(u.first_name, ' ', u.last_name) as user_name
                    FROM {$this->dbprefix}tracker_screenshots ts
                    LEFT JOIN {$this->dbprefix}users u ON ts.user_id = u.id
                    WHERE YEAR(ts.created_at) = ?
                    AND ts.deleted = 0";
            
            $params = [$year];
            
            if ($month) {
                $sql .= " AND MONTH(ts.created_at) = ?";
                $params[] = $month;
            }
            
            $sql .= " ORDER BY ts.created_at DESC";
            
            $result = $this->db->query($sql, $params);
            $screenshots = $result->getResult();
            
            return $this->addFileInfo($screenshots);
        } catch (Exception $e) {
            error_log("Error in getScreenshotsByYear: " . $e->getMessage());
            return [];
        }
    }

    /**
     * Add file information to screenshots
     */
    private function addFileInfo($screenshots) {
        foreach ($screenshots as $screenshot) {
            $file_path = $screenshot->path;
            if (file_exists($file_path)) {
                $screenshot->size = filesize($file_path);
                $screenshot->exists = true;
            } else {
                $screenshot->size = 0;
                $screenshot->exists = false;
            }
        }
        
        return $screenshots;
    }

    /**
     * Create export file
     */
    private function createExport($data, $format, $include_metadata) {
        $export_dir = 'plugins/Tracebit/exports/';
        if (!is_dir($export_dir)) {
            mkdir($export_dir, 0755, true);
        }
        
        $timestamp = date('Y-m-d_H-i-s');
        $filename = "screenshots_export_{$timestamp}";
        
        switch ($format) {
            case 'zip':
                return $this->createZipExport($data, $export_dir, $filename, $include_metadata);
            case 'csv':
                return $this->createCsvExport($data, $export_dir, $filename);
            case 'json':
                return $this->createJsonExport($data, $export_dir, $filename);
            default:
                throw new Exception('Unsupported export format');
        }
    }

    /**
     * Create ZIP export
     */
    private function createZipExport($data, $export_dir, $filename, $include_metadata) {
        $zip_file = $export_dir . $filename . '.zip';
        $zip = new \ZipArchive();
        
        if ($zip->open($zip_file, \ZipArchive::CREATE) !== TRUE) {
            throw new Exception('Could not create ZIP file');
        }
        
        // Add screenshots to ZIP
        foreach ($data as $screenshot) {
            if ($screenshot->exists) {
                $zip->addFile($screenshot->path, basename($screenshot->path));
            }
        }
        
        // Add metadata if requested
        if ($include_metadata) {
            $total_size = 0;
            foreach ($data as $item) {
                $total_size += $item->size ?? 0;
            }
            
            $metadata = [
                'export_date' => date('Y-m-d H:i:s'),
                'total_files' => count($data),
                'total_size' => $total_size,
                'files' => array_map(function($item) {
                    return [
                        'path' => $item->path,
                        'user' => $item->user_name,
                        'created_at' => $item->created_at,
                        'size' => $item->size
                    ];
                }, $data)
            ];
            
            $zip->addFromString('metadata.json', json_encode($metadata, JSON_PRETTY_PRINT));
        }
        
        $zip->close();
        
        return get_uri("tracebit/storage/download/" . basename($zip_file));
    }

    /**
     * Create CSV export
     */
    private function createCsvExport($data, $export_dir, $filename) {
        $csv_file = $export_dir . $filename . '.csv';
        $handle = fopen($csv_file, 'w');
        
        // Write header
        fputcsv($handle, ['File Path', 'User', 'Created Date', 'Size (bytes)', 'File Exists']);
        
        // Write data
        foreach ($data as $screenshot) {
            fputcsv($handle, [
                $screenshot->path,
                $screenshot->user_name,
                $screenshot->created_at,
                $screenshot->size,
                $screenshot->exists ? 'Yes' : 'No'
            ]);
        }
        
        fclose($handle);
        
        return get_uri("tracebit/storage/download/" . basename($csv_file));
    }

    /**
     * Create JSON export
     */
    private function createJsonExport($data, $export_dir, $filename) {
        $json_file = $export_dir . $filename . '.json';
        
        $total_size = 0;
        foreach ($data as $item) {
            $total_size += $item->size ?? 0;
        }
        
        $export_data = [
            'export_date' => date('Y-m-d H:i:s'),
            'total_files' => count($data),
            'total_size' => $total_size,
            'files' => array_map(function($item) {
                return [
                    'path' => $item->path,
                    'user' => $item->user_name,
                    'created_at' => $item->created_at,
                    'size' => $item->size,
                    'exists' => $item->exists
                ];
            }, $data)
        ];
        
        file_put_contents($json_file, json_encode($export_data, JSON_PRETTY_PRINT));
        
        return get_uri("tracebit/storage/download/" . basename($json_file));
    }

    /**
     * Delete screenshots
     */
    private function deleteScreenshots($data) {
        $deleted_count = 0;
        
        foreach ($data as $screenshot) {
            if ($screenshot->exists) {
                // Delete physical file
                if (unlink($screenshot->path)) {
                    // Mark as deleted in database
                    $this->db->query(
                        "UPDATE {$this->dbprefix}tracker_screenshots SET deleted = 1 WHERE id = ?",
                        [$screenshot->id]
                    );
                    $deleted_count++;
                }
            }
        }
        
        return $deleted_count;
    }

    /**
     * Get storage statistics
     */
    private function getStorageStatistics() {
        $stats = [];
        
        // Total statistics
        $total_sql = "SELECT COUNT(*) as total_files, SUM(CASE WHEN deleted = 0 THEN 1 ELSE 0 END) as active_files
                      FROM {$this->dbprefix}tracker_screenshots";
        $total_result = $this->db->query($total_sql)->getRow();
        $stats['total'] = $total_result;
        
        // Year-wise statistics
        $year_sql = "SELECT YEAR(created_at) as year, COUNT(*) as count
                     FROM {$this->dbprefix}tracker_screenshots
                     WHERE deleted = 0
                     GROUP BY YEAR(created_at)
                     ORDER BY year DESC";
        $year_result = $this->db->query($year_sql)->getResult();
        $stats['by_year'] = $year_result;
        
        // User-wise statistics
        $user_sql = "SELECT ts.user_id, u.first_name, u.last_name, COUNT(*) as count
                     FROM {$this->dbprefix}tracker_screenshots ts
                     LEFT JOIN {$this->dbprefix}users u ON ts.user_id = u.id
                     WHERE ts.deleted = 0
                     GROUP BY ts.user_id
                     ORDER BY count DESC";
        $user_result = $this->db->query($user_sql)->getResult();
        $stats['by_user'] = $user_result;
        
        // File size statistics
        $stats['file_sizes'] = $this->calculateFileSizes();
        
        return $stats;
    }

    /**
     * Calculate file sizes
     */
    private function calculateFileSizes() {
        $base_dir = 'plugins/Tracebit/screenshots/';
        $total_size = 0;
        $file_count = 0;
        
        if (is_dir($base_dir)) {
            $iterator = new \RecursiveIteratorIterator(
                new \RecursiveDirectoryIterator($base_dir, \RecursiveDirectoryIterator::SKIP_DOTS)
            );
            
            foreach ($iterator as $file) {
                if ($file->isFile() && pathinfo($file->getPathname(), PATHINFO_EXTENSION) === 'png') {
                    $total_size += $file->getSize();
                    $file_count++;
                }
            }
        }
        
        return [
            'total_size' => $total_size,
            'file_count' => $file_count,
            'average_size' => $file_count > 0 ? $total_size / $file_count : 0
        ];
    }

    /**
     * Generate statistics HTML
     */
    private function generateStatsHtml($stats) {
        $html = '<div class="storage-stats">';
        
        // Overview
        $html .= '<div class="row mb-4">';
        $html .= '<div class="col-md-3"><div class="card text-center"><div class="card-body">';
        $html .= '<h5>' . number_format($stats['total']->active_files) . '</h5>';
        $html .= '<small class="text-muted">Active Screenshots</small>';
        $html .= '</div></div></div>';
        
        $html .= '<div class="col-md-3"><div class="card text-center"><div class="card-body">';
        $html .= '<h5>' . $this->formatBytes($stats['file_sizes']['total_size']) . '</h5>';
        $html .= '<small class="text-muted">Total Size</small>';
        $html .= '</div></div></div>';
        
        $html .= '<div class="col-md-3"><div class="card text-center"><div class="card-body">';
        $html .= '<h5>' . $this->formatBytes($stats['file_sizes']['average_size']) . '</h5>';
        $html .= '<small class="text-muted">Average File Size</small>';
        $html .= '</div></div></div>';
        
        $html .= '<div class="col-md-3"><div class="card text-center"><div class="card-body">';
        $html .= '<h5>' . count($stats['by_user']) . '</h5>';
        $html .= '<small class="text-muted">Active Users</small>';
        $html .= '</div></div></div>';
        $html .= '</div>';
        
        // Year-wise breakdown
        if (!empty($stats['by_year'])) {
            $html .= '<h6>By Year</h6><div class="table-responsive mb-4">';
            $html .= '<table class="table table-sm"><thead><tr><th>Year</th><th>Files</th></tr></thead><tbody>';
            foreach ($stats['by_year'] as $year) {
                $html .= '<tr><td>' . $year->year . '</td><td>' . number_format($year->count) . '</td></tr>';
            }
            $html .= '</tbody></table></div>';
        }
        
        // User-wise breakdown
        if (!empty($stats['by_user'])) {
            $html .= '<h6>By User</h6><div class="table-responsive">';
            $html .= '<table class="table table-sm"><thead><tr><th>User</th><th>Files</th></tr></thead><tbody>';
            foreach (array_slice($stats['by_user'], 0, 10) as $user) {
                $user_name = trim($user->first_name . ' ' . $user->last_name);
                $html .= '<tr><td>' . $user_name . '</td><td>' . number_format($user->count) . '</td></tr>';
            }
            if (count($stats['by_user']) > 10) {
                $html .= '<tr><td colspan="2" class="text-center">... and ' . (count($stats['by_user']) - 10) . ' more users</td></tr>';
            }
            $html .= '</tbody></table></div>';
        }
        
        $html .= '</div>';
        return $html;
    }

    /**
     * Check storage permissions
     */
    private function checkStoragePermissions() {
        // Check if user is admin or has storage management permissions
        return $this->login_user->is_admin || $this->login_user->role_id == 1;
    }

    /**
     * Format bytes to human readable format
     */
    private function formatBytes($bytes, $precision = 2) {
        $units = array('B', 'KB', 'MB', 'GB', 'TB');
        
        for ($i = 0; $bytes > 1024 && $i < count($units) - 1; $i++) {
            $bytes /= 1024;
        }
        
        return round($bytes, $precision) . ' ' . $units[$i];
    }

    /**
     * Download export file
     */
    public function download($filename) {
        $file_path = 'plugins/Tracebit/exports/' . $filename;
        
        if (!file_exists($file_path)) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'File not found'
            ]);
        }
        
        return $this->response->download($file_path, $filename);
    }
} 
