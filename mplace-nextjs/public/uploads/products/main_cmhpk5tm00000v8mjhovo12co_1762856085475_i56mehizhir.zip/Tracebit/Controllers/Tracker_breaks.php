<?php
namespace Tracebit\Controllers;
use App\Controllers\Security_Controller;

class Tracker_breaks extends Security_Controller {
    protected $Tracker_breaks_model;

    function __construct() {
        parent::__construct();
        $this->access_only_admin_or_settings_admin();
        $this->Tracker_breaks_model = model("Tracebit\\Models\\Tracker_breaks_model");
    }

    public function index() {
        return $this->template->view("Tracebit\\Views\\breaks\\index");
    }

    public function modal_form() {
        $id = $this->request->getPost('id');

        if($id) {
            $view_data['model_info'] = $this->Tracker_breaks_model->get_one($id);
        } else {
            $view_data['model_info'] = new \stdClass();
            $view_data['model_info']->id = 0;
            $view_data['model_info']->name = '';
            $view_data['model_info']->value = '';
            $view_data['model_info']->icon = '';
            $view_data['model_info']->description = '';
            $view_data['model_info']->is_minus_break = 0;
            $view_data['model_info']->max_time = '';
        }


        return $this->template->view('Tracebit\\Views\\breaks\\modal_form', $view_data);
    }

    public function list_data() {
        $list_data = $this->Tracker_breaks_model->get_details();
        $result_data = array();
        foreach ($list_data as $data) {
            $result_data[] = $this->_make_row($data);
        }
        $result = array("data" => $result_data);
        echo json_encode($result);
    }

    private function _make_row($data) {

        $options = modal_anchor(get_uri("tracebit/tracker_breaks/modal_form"), "<i data-feather='edit' class='icon-16'></i>", array("class" => "edit", "title" => "Edit Break", "data-post-id" => $data->id));
        $options .= js_anchor("<i data-feather='x' class='icon-16'></i>", array('title' => "Delete Break", "class" => "delete", "data-id" => $data->id, "data-action-url" => get_uri("tracebit/tracker_breaks/delete"), "data-action" => "delete-confirmation"));

        return array(
            $data->name,
            $data->value,
            $data->icon,
            $data->description,
            $data->is_minus_break ? "Yes" : "No",
            $data->max_time,
            $options
        );
    }

    public function save() {
        $this->validate_submitted_data([
            "id" => "numeric",
            "name" => "required"
        ]);

        $id = $this->request->getPost('id');

        $data = [
            "name" => $this->request->getPost('name'),
            "value" => $this->request->getPost('value'),
            "icon" => $this->request->getPost('icon'),
            "description" => $this->request->getPost('description'),
            "is_minus_break" => $this->request->getPost('is_minus_break') ? 1 : 0,
            "max_time" => $this->request->getPost('max_time')
        ];

        $save_id = $this->Tracker_breaks_model->save($data, $id);

        if ($save_id) {
            echo json_encode([
                "success" => true,
                "data" => $this->_make_row($this->Tracker_breaks_model->get_one($save_id)),
                "id" => $save_id,
                "message" => "Record saved."
            ]);
        } else {
            echo json_encode([
                "success" => false,
                "message" => "Error saving record."
            ]);
        }
    }

    public function get($id) {
        $break = $this->Tracker_breaks_model->get_break($id);
        return $this->response->setJSON($break);
    }

    public function delete() {
        $id = $this->request->getPost('id');
        $this->Tracker_breaks_model->delete_break(
            $id
        );
        return $this->response->setJSON(["success" => true, "message" => "Break deleted successfully."]);
    }
}
