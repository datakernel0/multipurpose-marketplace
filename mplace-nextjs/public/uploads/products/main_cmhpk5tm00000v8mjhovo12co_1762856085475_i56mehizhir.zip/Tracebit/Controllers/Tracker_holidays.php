<?php

namespace Tracebit\Controllers;

use App\Controllers\Security_Controller;
use Tracebit\Models\Tracker_holidays_model;

class Tracker_holidays extends Security_Controller {

    private $tracker_holidays_model;

    public function __construct() {
        parent::__construct();
        $this->tracker_holidays_model = model("Tracebit\Models\Tracker_holidays_model");
    }

    /**
     * Show holidays list view
     *
     * @return string
     */
    public function index() {        $this->access_only_admin();

        $view_data = [];
        return $this->template->rander('Tracebit\Views\holidays\index', $view_data);
    }

    /**
     * Get holidays list data for DataTable
     *
     * @return void
     */    public function list_data() {
        $this->access_only_admin();

        $options = [
            "order_by" => "start_date ASC"
        ];

        // Support both GET and POST requests
        $start_date = $this->request->getGet("start_date") ?: $this->request->getPost("start_date");
        $end_date = $this->request->getGet("end_date") ?: $this->request->getPost("end_date");
        $type = $this->request->getGet("type") ?: $this->request->getPost("type");

        if ($start_date) {
            $options["start_date"] = $start_date;
        }

        if ($end_date) {
            $options["end_date"] = $end_date;
        }

        if ($type) {
            $options["type"] = $type;
        }

        $list_data = $this->tracker_holidays_model->get_all($options);

        $result = [];
        foreach ($list_data as $data) {
            $date_range = $data['start_date'];
            if ($data['start_date'] != $data['end_date']) {
                $date_range .= ' to ' . $data['end_date'];
            }

            $day_name = date('l', strtotime($data['start_date']));

            // Format holiday type display
            $type_display = ucfirst($data['type']);
            $type_badge_class = 'badge bg-primary';
            if ($data['type'] == 'religious') {
                $type_badge_class = 'badge bg-info';
            } else if ($data['type'] == 'company') {
                $type_badge_class = 'badge bg-success';
            }

            $result[] = [
                $data['name'],
                $date_range,
                $day_name,
                $data['duration'],
                '<span class="' . $type_badge_class . '">' . $type_display . '</span>',
                modal_anchor(get_uri("tracebit/tracker_holidays/modal_form"), "<i data-feather='edit-2' class='icon-16'></i>", ["class" => "edit", "title" => "Edit Holiday", "data-post-id" => $data['id']]) .
                js_anchor("<i data-feather='trash-2' class='icon-16'></i>", ["class" => "delete", "title" => "Delete Holiday", "data-id" => $data['id'], "data-action-url" => get_uri("tracebit/tracker_holidays/delete"), "data-action" => "delete"])
            ];
        }

        echo json_encode(["data" => $result]);
    }

    /**
     * Show add/edit holiday modal form
     *
     * @return string
     */
    public function modal_form() {
        $this->access_only_admin();

        $view_data = [
            "model_info" => null
        ];

        $id = $this->request->getPost('id');
        if ($id) {
            $view_data["model_info"] = $this->tracker_holidays_model->get_one($id);
        }
        return $this->template->view('Tracebit\Views\holidays\modal_form', $view_data);
    }

    /**
     * Save holiday from modal form
     *
     * @return void
     */
    public function save() {
        $this->access_only_admin();

        $this->validate_submitted_data([
            "id" => "numeric",
            "name" => "required",
            "start_date" => "required|valid_date",
            "end_date" => "valid_date"
        ]);

        $id = $this->request->getPost('id');

        $start_date = $this->request->getPost('start_date');
        $end_date = $this->request->getPost('end_date') ? $this->request->getPost('end_date') : $start_date;

        // Calculate duration
        $start = new \DateTime($start_date);
        $end = new \DateTime($end_date);
        $interval = $start->diff($end);
        $duration = $interval->days + 1; // Including start and end dates

        $data = [
            "name" => $this->request->getPost('name'),
            "start_date" => $start_date,
            "end_date" => $end_date,
            "duration" => $duration,
            "type" => $this->request->getPost('type') ? $this->request->getPost('type') : 'national'
        ];

        if ($id) {
            $save_id = $this->tracker_holidays_model->update_holiday($id, $data);
            $message = "Holiday updated";
        } else {
            $save_id = $this->tracker_holidays_model->insert_holiday($data);
            $message = "Holiday added";
        }

        if ($save_id) {
            echo json_encode([
                "success" => true,
                "data" => $this->tracker_holidays_model->get_one($save_id),
                "id" => $save_id,
                "message" => $message
            ]);
        } else {
            echo json_encode([
                "success" => false,
                "message" => "Error saving holiday"
            ]);
        }
    }

    /**
     * Delete a holiday
     *
     * @return void
     */
    public function delete() {
        $this->access_only_admin();

        $this->validate_submitted_data([
            "id" => "required|numeric"
        ]);

        $id = $this->request->getPost('id');

        if ($this->tracker_holidays_model->delete_holiday($id)) {
            echo json_encode([
                "success" => true,
                "message" => "Holiday deleted"
            ]);
        } else {
            echo json_encode([
                "success" => false,
                "message" => "Error deleting holiday"
            ]);
        }
    }

    /**
     * Get holidays for given date range
     * For API use
     *
     * @return void
     */
    public function get_holidays() {
        $start_date = $this->request->getGet('start_date');
        $end_date = $this->request->getGet('end_date');

        if (!$start_date || !$end_date) {
            echo json_encode([
                "success" => false,
                "message" => "Start date and end date required"
            ]);
            return;
        }

        $holidays = $this->tracker_holidays_model->get_all([
            "start_date" => $start_date,
            "end_date" => $end_date
        ]);

        echo json_encode([
            "success" => true,
            "holidays" => $holidays
        ]);
    }

    /**
     * Save holidays from settings
     *
     * @return void
     */
    public function save_from_settings() {
        $this->access_only_admin();

        $holidays = json_decode($this->request->getPost('holidays'), true);

        if ($this->tracker_holidays_model->save_holidays_from_settings($holidays)) {
            echo json_encode([
                "success" => true,
                "message" => "Holidays saved successfully!"
            ]);
        } else {
            echo json_encode([
                "success" => false,
                "message" => "Error saving holidays"
            ]);
        }
    }
}
