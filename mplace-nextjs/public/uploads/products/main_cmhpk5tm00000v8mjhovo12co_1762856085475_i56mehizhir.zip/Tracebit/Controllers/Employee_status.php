<?php

namespace Tracebit\Controllers;

use App\Controllers\Security_Controller;
use Tracebit\Libraries\Error_handler;
use Tracebit\Traits\Error_handling_trait;
use DateTime;

class Employee_status extends Security_Controller {
  use Error_handling_trait;
  
  protected $Employee_status_model;
  public $Users_model;
  
  function __construct() {
    parent::__construct();
    
    try {
      
            $this->db = \Config\Database::connect();
            $this->access_only_admin_or_settings_admin();
            $this->Employee_status_model = model("Tracebit\Models\Employee_status_model");
            $this->Users_model = model("App\Models\Users_model");
            Error_handler::info('Employee_status controller initialized successfully');
        } catch (\Exception $e) {
            Error_handler::error('Failed to initialize Employee_status controller', [
                'exception' => $e->getMessage(),
                'file' => $e->getFile(),
                'line' => $e->getLine()
            ]);
            throw $e;
        }
    }

    private function _get_members_dropdown_list_for_filter() {
        return $this->executeWithErrorHandling(function() {
            $where = array("user_type" => "staff");

            $members = $this->Users_model->get_dropdown_list(array("first_name", "last_name"), "id", $where);

            if ($members === false) {
                Error_handler::warning('Failed to get members dropdown list');
                return array(array("id" => 0, "text" => "- " . app_lang("team_member") . " -"));
            }

            $members_dropdown = array(array("id" => 0, "text" => "- " . app_lang("team_member") . " -"));
            foreach ($members as $id => $name) {
                $members_dropdown[] = array("id" => $id, "text" => $name);
            }
            return $members_dropdown;
        }, 'get_members_dropdown_filter', array());
    }

    private function _get_members_dropdown_list() {
        return $this->executeWithErrorHandling(function() {
            $where = array("user_type" => "staff");

            $members = $this->Users_model->get_dropdown_list(array("first_name", "last_name"), "id", $where);

            if ($members === false) {
                Error_handler::warning('Failed to get members dropdown list');
                return array("0" => "- " . app_lang("team_member") . " -");
            }

            return array_merge(array("0" => "- " . app_lang("team_member") . " -"), $members);
        }, 'get_members_dropdown', array());
    }

    function index() {
        try {
            $this->logOperation('employee_status_index');

            // Render the attendance view directly
            $view_data = array();
            return $this->template->rander('Tracebit\Views\tracker\attendance', $view_data);

        } catch (\Exception $e) {
            Error_handler::error('Failed to load employee status index', [
                'exception' => $e->getMessage(),
                'file' => $e->getFile(),
                'line' => $e->getLine()
            ]);

            // Return error view or simple error message
            echo "Error loading employee status page: " . $e->getMessage();
            return;
        }
    }

    function timeSheet() {
        return $this->executeWithErrorHandling(function() {
            $this->logOperation('timesheet_view');

            $view_data = array();

            // Get team members dropdown with error handling - same approach as snapShoot
            $team_members = $this->Users_model->get_dropdown_list(array("first_name", "last_name"), "id", array("user_type" => "staff"));
            if ($team_members === false || empty($team_members)) {
                Error_handler::warning('Failed to get team members dropdown for timeSheet or no staff users found');
                $view_data['team_members_dropdown'] = array("" => "Select Team Member");
            } else {
                $view_data['team_members_dropdown'] = array("" => "Select Team Member") + $team_members;
            }

            // Pass login_user to the view to prevent undefined variable error
            $view_data['login_user'] = $this->login_user;

            return $this->template->rander('Tracebit\Views\tracker\timeSheet', $view_data);
        }, 'load_timesheet_view');
    }

    function activityLog() {
        return $this->executeWithErrorHandling(function() {
            $this->logOperation('activityLog_view');

            $view_data = array();

            // Get team members dropdown with error handling - same approach as timeSheet
            $team_members = $this->Users_model->get_dropdown_list(array("first_name", "last_name"), "id", array("user_type" => "staff"));
            if ($team_members === false || empty($team_members)) {
                Error_handler::warning('Failed to get team members dropdown for activityLog or no staff users found');
                $view_data['team_members_dropdown'] = array("" => "Select Team Member");
            } else {
                $view_data['team_members_dropdown'] = array("" => "Select Team Member") + $team_members;
            }

            // Also prepare JSON dropdown for filter (keeping backward compatibility)
            $view_data['team_members_dropdown_json'] = json_encode($this->_get_members_dropdown_list_for_filter());

            // Pass login_user to the view to prevent undefined variable error
            $view_data['login_user'] = $this->login_user;

            return $this->template->rander('Tracebit\Views\tracker\activityLog', $view_data);
        }, 'load_activityLog_view');
    }

    function get_attendance_list(){

        $start_date = $this->request->getPost('start_date');
        $end_date = $this->request->getPost('end_date');

        // Server-side pagination parameters
        $length = $this->request->getPost('length') ?? 10;
        $start = $this->request->getPost('start') ?? 0;
        $search_value = $this->request->getPost('search')['value'] ?? '';
        $order_column = $this->request->getPost('order')[0]['column'] ?? 1;
        $order_dir = $this->request->getPost('order')[0]['dir'] ?? 'asc';
        $draw = $this->request->getPost('draw') ?? 1;

        $view_data["start_date"] = $start_date;
        $view_data["end_date"] = $end_date;
        $view_data["length"] = $length;
        $view_data["start"] = $start;
        $view_data["search"] = $search_value;
        $view_data["order_column"] = $order_column;
        $view_data["order_dir"] = $order_dir;

        $this->Employee_status_model->createCalender($view_data);

        // Get paginated data and total count
        $list_data = $this->Employee_status_model->getAttendance($view_data);
        $total_records = $this->Employee_status_model->getAttendanceCount($view_data);

        $result = array();
        foreach ($list_data as $data) {
            $result[] = $this->_make_row($data, $start_date);
        }

        echo json_encode(array(
            "draw" => intval($draw),
            "recordsTotal" => $total_records,
            "recordsFiltered" => $total_records,
            "data" => $result
        ));
    }

    private function _make_row($data, $date)
    {
        // Get tracker settings for calculations using model
        $settings = $this->Employee_status_model->getTrackerSettingsForCalculations();
        $daily_work_hours = $settings['daily_work_hours'] ?? 8;
        $work_start_time = $settings['work_start_time'] ?? '09:00';

        $progress = (int) $data->activity;

        // Enhanced activity classification with new styling
        $activity = (int) $data->activity;
        $activity_class = '';
        $activity_tooltip = '';

        if($activity >= 80) {
            $activity_class = 'activity-high';
            $activity_tooltip = 'High Activity - Excellent productivity';
        } else if ($activity >= 60) {
            $activity_class = 'activity-medium';
            $activity_tooltip = 'Moderate Activity - Good productivity';
        } else if ($activity >= 40) {
            $activity_class = 'activity-medium';
            $activity_tooltip = 'Low-Moderate Activity - Could improve';
        } else {
            $activity_class = 'activity-low';
            $activity_tooltip = 'Low Activity - Needs attention';
        }

        // Simple activity display without progress bar
        $activity_display = "<span class=\"activity-simple\" data-toggle=\"tooltip\" title=\"$activity_tooltip\">$activity%</span>";


        $image_url = get_avatar($data->employee_image);
        $user_avatar = "<span class=\"avatar avatar-xs\"><img src=\"$image_url\" alt=\"$data->employee_name\" title=\"$data->employee_name\"></span>";
        $full_name = $data->employee_name;

        // Format times with proper timezone handling using helper function
        $in_time = $data->inTime ?
            "<span class=\"time-cell\" data-toggle=\"tooltip\" title=\"Check-in time\">" .
            $this->formatTimestampToLocalTime($data->inTime) . "</span>" :
            "<span class=\"text-muted\">--:--</span>";

        $out_time = $data->outTime ?
            "<span class=\"time-cell\" data-toggle=\"tooltip\" title=\"Last check-out time\">" .
            $this->formatTimestampToLocalTime($data->outTime) . "</span>" :
            "<span class=\"text-muted\">--:--</span>";

        // Calculate worked time properly
        $worked_seconds = 0;
        if (isset($data->worked_hours) && $data->worked_hours) {
            // Convert worked_hours to seconds if it's in HH:MM:SS format
            if (strpos($data->worked_hours, ':') !== false) {
                $time_parts = explode(':', $data->worked_hours);
                $worked_seconds = ($time_parts[0] * 3600) + ($time_parts[1] * 60) + (isset($time_parts[2]) ? $time_parts[2] : 0);
            } else {
                // If it's already in hours format
                $worked_seconds = floatval($data->worked_hours) * 3600;
            }
        }

        // Calculate overtime and due time based on daily_worked_time setting
        $daily_work_seconds = $daily_work_hours * 3600;
        $overtime_seconds = max(0, $worked_seconds - $daily_work_seconds);
        $due_seconds = max(0, $daily_work_seconds - $worked_seconds);

        // Format time durations consistently
        $worked_time = "<span class=\"time-cell text-primary\" data-toggle=\"tooltip\" title=\"Total worked time today\">" .
                      $this->formatSecondsToTime($worked_seconds) . "</span>";

        $overtime = $overtime_seconds > 0 ?
            "<span class=\"time-cell text-success\" data-toggle=\"tooltip\" title=\"Overtime worked beyond " . $daily_work_hours . "h\">" .
            $this->formatSecondsToTime($overtime_seconds) . "</span>" :
            "<span class=\"text-muted\">00:00</span>";

        $due_time = $due_seconds > 0 ?
            "<span class=\"time-cell text-warning\" data-toggle=\"tooltip\" title=\"Remaining work time to complete " . $daily_work_hours . "h\">" .
            $this->formatSecondsToTime($due_seconds) . "</span>" :
            "<span class=\"text-success\">Complete</span>";

        // Calculate idle time from database (projects with 'idle-' prefix)
        $idle_seconds = isset($data->idle_seconds) ? (int)$data->idle_seconds : 0;
        $idle_time = $idle_seconds > 0 ?
            "<span class=\"time-cell text-warning\" data-toggle=\"tooltip\" title=\"Total idle time (projects: idle-)\">" .
            $this->formatSecondsToTime($idle_seconds) . "</span>" :
            "<span class=\"text-muted\">00:00</span>";

        // Calculate away time from database (projects with 'b-' prefix, excluding MinusBreak=true)
        $away_seconds = isset($data->away_seconds) ? (int)$data->away_seconds : 0;
        $away_time = $away_seconds > 0 ?
            "<span class=\"time-cell text-info\" data-toggle=\"tooltip\" title=\"Away/Break time (projects: b-, excluding MinusBreak=true)\">" .
            $this->formatSecondsToTime($away_seconds) . "</span>" :
            "<span class=\"text-muted\">00:00</span>";

        $row_data = array(
            $user_avatar,
            "<span class=\"profile-link\">" . get_team_member_profile_link($data->user_id, $full_name) . "</span>",
            $in_time,
            $out_time,
            $worked_time,
            $overtime,
            $due_time,
            $idle_time,
            $away_time,
            $activity_display
        );

        return $row_data;
    }

    /**
     * Get status counts for dashboard summary
     */
    function get_status_counts() {
        try {
            // Get all attendance data to count statuses
            $all_data = $this->Employee_status_model->get_all_attendance_data();

            $counts = [
                'total' => 0,
                'active' => 0,
                'idle' => 0,
                'inactive' => 0,
                'productivity_sum' => 0,
                'avg_productivity' => 0
            ];

            if ($all_data && count($all_data) > 0) {
                foreach ($all_data as $data) {
                    $counts['total']++;

                    // Use simple presence logic since tracker_status table may not exist
                    if ($data->present && $data->present == 1) {
                        if ($data->total_leave && $data->total_leave > 0) {
                            $counts['idle']++; // On leave
                        } else {
                            $counts['active']++; // Present and working
                        }
                    } else {
                        $counts['inactive']++; // Not present
                    }

                    // Add to productivity sum
                    if (isset($data->activity) && is_numeric($data->activity)) {
                        $counts['productivity_sum'] += (int)$data->activity;
                    }
                }

                // Calculate average productivity
                if ($counts['total'] > 0) {
                    $counts['avg_productivity'] = round($counts['productivity_sum'] / $counts['total'], 1);
                }
            }

            echo json_encode($counts);

        } catch (\Exception $e) {
            Error_handler::error('Failed to get status counts', [
                'exception' => $e->getMessage(),
                'file' => $e->getFile(),
                'line' => $e->getLine()
            ]);

            // Return zero counts on error
            echo json_encode([
                'total' => 0,
                'active' => 0,
                'idle' => 0,
                'inactive' => 0,
                'productivity_sum' => 0,
                'avg_productivity' => 0
            ]);
        }
    }

    /**
     * Format timestamp to local time in 12-hour format (consistent with dashboard_helpers.php)
     */
    private function formatTimestampToLocalTime($timestamp) {
        if (!$timestamp) return '--:--';
        
        // Ensure timestamp is numeric
        if (!is_numeric($timestamp)) {
            return '--:--';
        }

        $originalTimezone = date_default_timezone_get();
        date_default_timezone_set('Asia/Dhaka'); // Same as dashboard_helpers.php
        $formatted_time = date('h:i A', $timestamp / 1000);
        date_default_timezone_set($originalTimezone);

        return $formatted_time;
    }

    private function getCurrentDate($date)
    {
        $originalTimezone = date_default_timezone_get();
        date_default_timezone_set('Asia/Dhaka'); // Set to local timezone
        $today = !$date ? date('Y-m-d') : $date;
        date_default_timezone_set($originalTimezone); // Reset to original
        return $today;
    }

    /**
     * Format seconds to HH:MM format
     */
    private function formatSecondsToTime($seconds) {
        if ($seconds <= 0) return '00:00';

        $hours = floor($seconds / 3600);
        $minutes = floor(($seconds % 3600) / 60);

        return sprintf('%02d:%02d', $hours, $minutes);
    }

    function get_timeSheet_list(){
      
        try {
            // Get filter parameters only (no pagination)
            $start_date = $this->request->getPost("start_date");
            $end_date = $this->request->getPost("end_date");
            $applicant_id = $this->request->getPost("applicant_id");
            // If no specific date range provided, use current month up to today as default
            if (!$start_date || !$end_date) {
                $today = date('Y-m-d');
                $current_month_start = date('Y-m-01');
                $last_day_of_month = date('Y-m-t');

                // Default behavior: current month up to today (unless it's last day of month)
                if ($today != $last_day_of_month) {
                    $start_date = $current_month_start;
                    $end_date = $today;
                } else {
                    // If today is the last day, show full month
                    $start_date = $current_month_start;
                    $end_date = $last_day_of_month;
                }
            }

            $view_data = [
                "start_date" => $this->getCurrentDate($start_date),
                "end_date" => $this->getCurrentDate($end_date),
                "user_id" => $applicant_id ?: $this->login_user->id,
                "no_pagination" => true // Flag to disable pagination in model
            ];

            $use_test_data = false;

            try {
               
                $this->Employee_status_model->createCalender($view_data);
               
                $list_data = $this->Employee_status_model->timeSheet($view_data);
              
                // Handle the model's return structure which includes pagination
                if (is_array($list_data) && isset($list_data['data'])) {
                    $timesheet_data = $list_data['data'];                    
                } else if (is_array($list_data)) {
                    $timesheet_data = $list_data;
                    
                } else {
                    $timesheet_data = [];
                    $use_test_data = true;
                    
                }
                
            } catch (\Exception $model_error) { 
              $timesheet_data = [];
                $use_test_data = true;
            }

            // If no data from model, create test data
            if (empty($timesheet_data) || $use_test_data) {
                $timesheet_data = $this->generateTestTimesheetData($this->getCurrentDate($start_date), $this->getCurrentDate($end_date), $view_data['user_id']);
            }
            
            $result = array();

              foreach ($timesheet_data as $data) {  
                try {
                    $row_result = $this->_make_timeSheet_row($data, $view_data['user_id']);                   
                    $result[] = $row_result;
                } catch (\Exception $e) {
                    error_log("Error in _make_timeSheet_row: " . $e->getMessage());
                    error_log("Error file: " . $e->getFile() . " line: " . $e->getLine());
                }
              }
              
             
            $response = array("data" => $result);
           
            echo json_encode($response);

        } catch (\Exception $e) {
            Error_handler::error('Failed to get timesheet list', [
                'exception' => $e->getMessage(),
                'file' => $e->getFile(),
                'line' => $e->getLine()
            ]);

            // Return empty result on error
            echo json_encode(array("data" => []));
        }
    }

    /**
     * Generate test timesheet data for debugging
     */
    private function generateTestTimesheetData($start_date, $end_date, $user_id = null) {
        if ($user_id === null) {
            $user_id = $this->login_user->id;
        }
        
        $test_data = [];
        $current = strtotime($start_date);
        $end = strtotime($end_date);

        while ($current <= $end) {
            $date = date('Y-m-d', $current);
            $day_of_week = date('w', $current);
            $day_num = date('j', $current);

            // Create varied test scenarios
            $is_weekend = ($day_of_week == 0 || $day_of_week == 6);
            $is_leave = ($day_num == 15); // 15th is leave day
            $is_half_leave = ($day_num == 10); // 10th is half leave
            $is_holiday = ($day_num == 5); // 5th is holiday

            // Create test timesheet entry with varied scenarios
            if ($is_weekend) {
                $entry = (object) array(
                    'date' => $date,
                    'user_id' => $user_id,
                    'worked_hours' => '00:00:00',
                    'inTime' => null,
                    'outTime' => null,
                    'total_leave' => 0,
                    'idle' => '00:00:00',
                    'group_discussion' => '00:00:00',
                    'activity' => 0
                );
            } else if ($is_leave) {
                $entry = (object) array(
                    'date' => $date,
                    'user_id' => $user_id,
                    'worked_hours' => '00:00:00',
                    'inTime' => null,
                    'outTime' => null,
                    'total_leave' => 1.0, // Full day leave
                    'idle' => '00:00:00',
                    'group_discussion' => '00:00:00',
                    'activity' => 0
                );
            } else if ($is_half_leave) {
                $entry = (object) array(
                    'date' => $date,
                    'user_id' => $user_id,
                    'worked_hours' => '04:00:00',
                    'inTime' => '09:00 AM',
                    'outTime' => '01:00 PM',
                    'total_leave' => 0.5, // Half day leave
                    'idle' => '00:10:00',
                    'group_discussion' => '00:15:00',
                    'activity' => rand(40, 60)
                );
            } else if ($is_holiday) {
                $entry = (object) array(
                    'date' => $date,
                    'user_id' => $user_id,
                    'worked_hours' => '00:00:00',
                    'inTime' => null,
                    'outTime' => null,
                    'total_leave' => 0,
                    'idle' => '00:00:00',
                    'group_discussion' => '00:00:00',
                    'activity' => 0,
                    'is_holiday' => true
                );
            } else {
                // Regular working day
                $entry = (object) array(
                    'date' => $date,
                    'user_id' => $user_id,
                    'worked_hours' => '08:' . rand(15, 45) . ':00',
                    'inTime' => '09:' . rand(0, 15) . ' AM',
                    'outTime' => '05:' . rand(30, 59) . ' PM',
                    'total_leave' => 0,
                    'idle' => '00:' . rand(10, 30) . ':00',
                    'group_discussion' => '00:' . rand(15, 45) . ':00',
                    'activity' => rand(60, 90)
                );
            }

            $test_data[] = $entry;
            $current = strtotime('+1 day', $current);
        }

        return $test_data;
    }

    /**
     * Generate employee summary activity log data using model methods (IMPROVED VERSION)
     */
    private function generateEmployeeSummaryData($start_date, $end_date) {
        try {
            // Initialize error handler and cache
            $error_handler = new \Tracebit\Libraries\Activity_error_handler();
            $cache = new \Tracebit\Libraries\Activity_cache();
            
            // Start performance monitoring
            $start_time = microtime(true);
            $error_handler->checkMemoryUsage('generateEmployeeSummaryData_start');
            
            // Try to get cached data first
            if ($cache->isCacheEnabled()) {
                $cached_data = $cache->getEmployeeSummary($start_date, $end_date);
                if ($cached_data !== null) {
                    $error_handler->logCacheOperation('hit', "employee_summary_{$start_date}_{$end_date}");
                    return $this->formatEmployeeSummaryForDisplay($cached_data);
                }
            }
            
            // Get data from model
            $employees_raw_data = $this->Employee_status_model->getEmployeeSummaryData($start_date, $end_date);
            
            if (empty($employees_raw_data)) {
                // Fallback to original method if model returns empty
                return $this->generateEmployeeSummaryDataFallback($start_date, $end_date);
            }
            
            // Format data for display
            $employees_display_data = $this->formatEmployeeSummaryForDisplay($employees_raw_data);
            
            // Cache the result
            if ($cache->isCacheEnabled() && !empty($employees_display_data)) {
                $cache->setEmployeeSummary($start_date, $end_date, null, $employees_raw_data);
                $error_handler->logCacheOperation('store', "employee_summary_{$start_date}_{$end_date}", null, count($employees_display_data));
            }
            
            // Log performance
            $end_time = microtime(true);
            $duration = $end_time - $start_time;
            $error_handler->logPerformanceIssue('generateEmployeeSummaryData_model', $duration);
            $error_handler->checkMemoryUsage('generateEmployeeSummaryData_end');
            
            return $employees_display_data;
            
        } catch (\Exception $e) {
            Error_handler::error('Failed to generate employee summary from model', [
                'exception' => $e->getMessage(),
                'file' => $e->getFile(),
                'line' => $e->getLine()
            ]);
            
            // Fallback to original method if model fails
            return $this->generateEmployeeSummaryDataFallback($start_date, $end_date);
        }
    }
    
    /**
     * Format employee summary data for display
     */
    private function formatEmployeeSummaryForDisplay($employees_raw_data) {
        $employees_display_data = [];
        
        foreach ($employees_raw_data as $employee) {
            // Handle both array and object formats
            $data = is_array($employee) ? (object)$employee : $employee;
            
            // Create proper avatar with user image
            $avatar_url = get_avatar($data->image ?? null);
            $avatar_html = '<div class="avatar-wrapper"><img src="' . $avatar_url . '" alt="Avatar" class="user-avatar" /></div>';
            
            $employees_display_data[] = [
                'avatar' => $avatar_html,
                'name' => strtoupper($data->first_name . ' ' . $data->last_name),
                'work_days' => $data->work_days,
                'present' => $data->present,
                'leave' => $data->leave,
                'absent' => $data->absent,
                'late' => $data->late,
                'estimated_hours' => $this->formatHours($data->estimated_hours),
                'worked_hours' => $this->formatHours($data->worked_hours),
                'due_hours' => $this->formatHoursShort($data->due_hours),
                'overtime' => $this->formatHoursShort($data->overtime_hours),
                'group_discussion' => $this->formatHours($data->group_discussion_hours),
                'activities' => $data->avg_performance . '%'
            ];
        }
        
        return $employees_display_data;
    }
    
    /**
     * Helper method to get tracker settings efficiently (deprecated - use model)
     * @deprecated Use Employee_status_model->getTrackerSettings() instead
     */
    private function getTrackerSettings($setting_names) {
        return $this->Employee_status_model->getTrackerSettings($setting_names);
    }
    
    /**
     * Helper method to calculate date range information once (deprecated - use model)
     * @deprecated Use Employee_status_model->calculateDateRangeInfo() instead  
     */
    private function calculateDateRangeInfo($start_date, $end_date) {
        // Calculate basic date info
        $start_dt = new \DateTime($start_date);
        $end_dt = new \DateTime($end_date);
        $interval = $start_dt->diff($end_dt);
        $total_days = $interval->days + 1;
        
        // Calculate weekend days
        $weekend_days = 0;
        $current = clone $start_dt;
        while ($current <= $end_dt) {
            $day_of_week = $current->format('w');
            if ($day_of_week == 0 || $day_of_week == 6) { // Sunday or Saturday
                $weekend_days++;
            }
            $current->add(new \DateInterval('P1D'));
        }
        
        // Get holiday days from model
        $holiday_days = $this->Employee_status_model->getHolidayDays($start_date, $end_date);
        
        return [
            'total_days' => $total_days,
            'weekend_days' => $weekend_days,
            'holiday_days' => $holiday_days
        ];
    }
    
    /**
     * Helper method to format hours as HH:MM:SS
     */
    private function formatHours($hours) {
        return sprintf('%d:%02d:%02d', 
            floor($hours), 
            floor(($hours - floor($hours)) * 60),
            0);
    }
    
    /**
     * Helper method to format hours as HH:MM
     */
    private function formatHoursShort($hours) {
        return sprintf('%d:%02d', 
            floor($hours), 
            floor(($hours - floor($hours)) * 60));
    }
    
    /**
     * Fallback method using model methods for consistency
     */
    private function generateEmployeeSummaryDataFallback($start_date, $end_date) {
        try {
            // Use the model's improved method instead of direct DB queries
            return $this->Employee_status_model->getEmployeeSummaryDataWithQueries($start_date, $end_date);
        } catch (\Exception $e) {
            Error_handler::error('Failed to generate employee summary fallback', [
                'exception' => $e->getMessage(),
                'file' => $e->getFile(),
                'line' => $e->getLine()
            ]);
            return [];
        }
    }

    /**
     * Deprecated method - keeping for reference
     */
    private function generateEmployeeSummaryDataFallbackOriginal($start_date, $end_date) {
        $usersTable = $this->db->prefixTable('users');
        $settingsTable = $this->db->prefixTable('tracker_settings');
        $tracker_holidays_table = $this->db->prefixTable('tracker_holidays');
        $leaveTable = $this->db->prefixTable('leave_applications');
        $attendanceTable = $this->db->prefixTable('tracker_attendance');
        $performanceTable = $this->db->prefixTable('tracker_performance');

        try {
            // Get all staff users using model method
            $users = $this->Employee_status_model->getActiveStaffUsers();
            
            if (empty($users)) {
                return []; // No users found
            }
            
            // Get tracker settings using model method
            $settings = $this->Employee_status_model->getTrackerSettings(['working_hours_start', 'daily_worked_time']);
            $working_hours_start = $settings['working_hours_start'] ?? '09:00';
            $daily_worked_hours = (float)($settings['daily_worked_time'] ?? 8);
            
            // Calculate date range details using model method
            $date_info = $this->Employee_status_model->calculateDateRangeInfo($start_date, $end_date);
            
            $employees_data = [];
            
            foreach ($users as $user) {
                // Get user avatar
                $avatar_html = '<div class="avatar-wrapper"><img src="' . get_avatar($user->image) . '" alt="Avatar" class="user-avatar" /></div>';
                
                // Get leave days using model method
                $total_leave_days = $this->Employee_status_model->getUserLeaveDays($user->id, $start_date, $end_date);
                
                // Calculate workable days
                $workable_days = $date_info['total_days'] - $date_info['weekend_days'] - $date_info['holiday_days'] - $total_leave_days;
                $workable_days = max(0, $workable_days); // Ensure non-negative
                
                // Get attendance stats using model method
                $attendance_stats = $this->Employee_status_model->getUserAttendanceStats($user->id, $start_date, $end_date);
                if (!$attendance_stats) {
                    $attendance_stats = (object)[
                        'present_days' => 0,
                        'late_days' => 0,
                        'total_worked_minutes' => 0,
                        'group_discussion_minutes' => 0
                    ];
                }
                
                $unique_attendance_days = $attendance_stats->present_days;
                $present_days = $unique_attendance_days;
                
                // Calculate absent days (workable days - present days)
                $absent_days = max(0, $workable_days - $present_days);
                
                // Get worked hours from attendance stats
                $worked_hours = $attendance_stats->total_worked_minutes / 60;
                $worked_hours_formatted = sprintf('%d:%02d:%02d', 
                    floor($worked_hours), 
                    floor(($worked_hours - floor($worked_hours)) * 60),
                    0);
                
                // Calculate estimated hours
                $estimated_hours = $workable_days * $daily_worked_hours;
                $estimated_hours_formatted = sprintf('%d:%02d:%02d', 
                    floor($estimated_hours), 
                    floor(($estimated_hours - floor($estimated_hours)) * 60),
                    0);
                
                // Calculate due hours and overtime
                $due_hours = max(0, $estimated_hours - $worked_hours);
                $overtime_hours = max(0, $worked_hours - $estimated_hours);
                
                $due_hours_formatted = sprintf('%d:%02d', floor($due_hours), floor(($due_hours - floor($due_hours)) * 60));
                $overtime_hours_formatted = sprintf('%d:%02d', floor($overtime_hours), floor(($overtime_hours - floor($overtime_hours)) * 60));
                
                // Format group discussion time using model data
                $group_discussion_hours = $attendance_stats->group_discussion_minutes / 60;
                $group_discussion_formatted = sprintf('%d:%02d:%02d', 
                    floor($group_discussion_hours), 
                    floor(($group_discussion_hours - floor($group_discussion_hours)) * 60),
                    0);
                
                // Get activity percentage using model method
                $activity_percentage = $this->Employee_status_model->getUserPerformanceAverage($user->id, $start_date, $end_date);
                
                $employees_data[] = [
                    'avatar' => $avatar_html,
                    'name' => strtoupper($user->first_name . ' ' . $user->last_name),
                    'work_days' => $workable_days,
                    'present' => $present_days,
                    'leave' => round($total_leave_days, 1),
                    'absent' => $absent_days,
                    'late' => $attendance_stats->late_days,
                    'estimated_hours' => $estimated_hours_formatted,
                    'worked_hours' => $worked_hours_formatted,
                    'due_hours' => $due_hours_formatted,
                    'overtime' => $overtime_hours_formatted,
                    'group_discussion' => $group_discussion_formatted,
                    'activities' => $activity_percentage . '%'
                ];
            }
            
            return $employees_data;
            
        } catch (\Exception $e) {
            Error_handler::error('Failed to generate employee summary from database', [
                'exception' => $e->getMessage(),
                'file' => $e->getFile(),
                'line' => $e->getLine()
            ]);
            
            // Return empty array on error
            return [];
        }
    }

  
    /**
     * Helper method to generate realistic working hours
     */
    private function generateWorkingHours($days, $min_hours_per_day, $max_hours_per_day) {
        if ($days <= 0) return '00:00:00';
        
        $total_minutes = 0;
        for ($i = 0; $i < $days; $i++) {
            $hours = $min_hours_per_day + (rand(0, 100) / 100) * ($max_hours_per_day - $min_hours_per_day);
            $total_minutes += $hours * 60;
        }
        
        $hours = floor($total_minutes / 60);
        $minutes = floor($total_minutes % 60);
        $seconds = rand(0, 59);
        
        return sprintf('%d:%02d:%02d', $hours, $minutes, $seconds);
    }

    /**
     * Get timesheet summary statistics
     */
    function get_timesheet_summary() {
        $tracker_holidays_table = $this->db->prefixTable('tracker_holidays');
        $start_date = $this->request->getPost("start_date");
        $end_date = $this->request->getPost("end_date");
        $applicant_id = $this->request->getPost("applicant_id");
        // If no specific date range provided, use full current month (same as main data call)
        
            if (!$start_date || !$end_date) {
                $current_month = date('Y-m');
                $year = substr($current_month, 0, 4);
                $month = substr($current_month, 5, 2);

                $start_date = $year . '-' . $month . '-01';
                $last_day = date('t', strtotime($start_date)); // Get last day of month
                $end_date = $year . '-' . $month . '-' . str_pad($last_day, 2, '0', STR_PAD_LEFT);
            }

            $view_data = [
                "start_date" => $start_date,
                "end_date" => $end_date,
                "user_id" => $applicant_id ?: $this->login_user->id,
                "no_pagination" => true
            ];

            // Get daily work hours setting using model method
            $daily_work_hours = $this->Employee_status_model->getDailyWorkHoursSetting();

            try {
                $this->Employee_status_model->createCalender($view_data);
                $list_data = $this->Employee_status_model->timeSheet($view_data);

                if (is_array($list_data) && isset($list_data['data'])) {
                    $timesheet_data = $list_data['data'];
                } else if (is_array($list_data)) {
                    $timesheet_data = $list_data;
                } else {
                    $timesheet_data = [];
                }
            } catch (\Exception $model_error) {
                $timesheet_data = $this->generateTestTimesheetData($this->getCurrentDate($start_date), $this->getCurrentDate($end_date), $view_data['user_id']);
            }

            // If no data from model, create test data
            if (empty($timesheet_data)) {
                $timesheet_data = $this->generateTestTimesheetData($this->getCurrentDate($start_date), $this->getCurrentDate($end_date), $view_data['user_id']);
            }

            // Calculate summary statistics
            $summary = [
                'total_days' => 0,
                'workable_days' => 0,
                'present_days' => 0,
                'absent_days' => 0,
                'weekend_days' => 0,
                'leave_days' => 0,
                'worked_hours' => 0,
                'estimate_hours' => 0,
                'overtime_hours' => 0,
                'due_hours' => 0
            ];

            $db = \Config\Database::connect();
            $userId = $view_data['user_id'];

            foreach ($timesheet_data as $data) {
                $currentDate = $data->date ?? '';
                $weekDay = date('l', strtotime($currentDate));

                // Count total days first
                $summary['total_days']++;

                // Determine status
                $is_weekend = ($weekDay == 'Saturday' || $weekDay == 'Friday');
                $is_holiday = false;
                $leave_info = null;

                if (!$is_weekend) {
                    // Check for holidays using model method
                    $is_holiday = $this->Employee_status_model->isHoliday($currentDate);

                    // Check for leave using model method
                    $leave_info = $this->Employee_status_model->getUserLeaveInfo($userId, $currentDate);
                }

                // Count days based on status
                if ($is_weekend) {
                    $summary['weekend_days']++;
                } else if ($is_holiday) {
                    // Holiday - not workable, not countable for presence
                    $summary['leave_days']++;
                } else if ($leave_info && $leave_info->total_days == 1.0) {
                    // Full day leave - not workable
                    $summary['leave_days']++;
                } else if ($leave_info && $leave_info->total_days == 0.5) {
                    // Half day leave - still workable, count as present and leave
                    $summary['leave_days']++; // Count for leave statistics
                    $summary['present_days']++; // Count as present since they worked half day
                    $summary['estimate_hours'] += $daily_work_hours / 2;
                } else {
                    // Regular work day - check attendance
                    if (isset($data->inTime) && $data->inTime) {
                        $summary['present_days']++;
                    } else {
                        $summary['absent_days']++;
                    }
                    $summary['estimate_hours'] += $daily_work_hours;
                }

                // Calculate worked hours
                if (isset($data->worked_hours) && $data->worked_hours && $data->worked_hours !== '00:00:00') {
                    $worked_seconds = 0;
                    if (strpos($data->worked_hours, ':') !== false) {
                        $time_parts = explode(':', $data->worked_hours);
                        $worked_seconds = ($time_parts[0] * 3600) + ($time_parts[1] * 60) + (isset($time_parts[2]) ? $time_parts[2] : 0);
                    } else {
                        $worked_seconds = floatval($data->worked_hours) * 3600;
                    }

                    $worked_hours_day = $worked_seconds / 3600;
                    $summary['worked_hours'] += $worked_hours_day;

                    // Calculate overtime for this day
                    $expected_hours = $daily_work_hours;
                    if ($leave_info && $leave_info->total_days == 0.5) {
                        $expected_hours = $daily_work_hours / 2;
                    }

                    if ($worked_hours_day > $expected_hours) {
                        $summary['overtime_hours'] += ($worked_hours_day - $expected_hours);
                    }
                }
            }

            // Calculate workable days properly
            // Count half-day leaves separately since they should be workable
            $full_leave_days = 0;
            $half_day_leaves = 0;

            foreach ($timesheet_data as $data) {
                $currentDate = $data->date ?? '';
                $weekDay = date('l', strtotime($currentDate));

                // Skip weekends
                if ($weekDay == 'Saturday' || $weekDay == 'Friday') {
                    continue;
                }

                // Check for holidays using model method
                $is_holiday = $this->Employee_status_model->isHoliday($currentDate);

                // Check for leave using model method
                $leave_info = $this->Employee_status_model->getUserLeaveInfo($userId, $currentDate);

                // Count leave days properly
                if ($is_holiday) {
                    $full_leave_days++;
                } else if ($leave_info && $leave_info->total_days == 1.0) {
                    $full_leave_days++;
                } else if ($leave_info && $leave_info->total_days == 0.5) {
                    $half_day_leaves++;
                }
            }

            // Workable Days = Total Days - Weekend Days - Full Leave/Holiday Days
            // Half-day leaves are workable, so they don't reduce workable days
            $summary['workable_days'] = $summary['total_days'] - $summary['weekend_days'] - $full_leave_days;            // Calculate due hours (estimate - worked, but only positive values)
            $summary['due_hours'] = max(0, $summary['estimate_hours'] - $summary['worked_hours']);

            // Round values
            foreach (['worked_hours', 'estimate_hours', 'overtime_hours', 'due_hours'] as $key) {
                $summary[$key] = round($summary[$key], 1);
            }

            echo json_encode($summary);

        
    }

        private function _make_timeSheet_row($data, $filtered_user_id = null)
    {
        // Convert array to object if necessary
        if (is_array($data)) {
            $data = (object) $data;
        }

        $status = "";
        $weekDay = date('l', strtotime($data->date ?? ''));
        $status = "";
        $status_class = "";
        $currentDate = $data->date ?? '';
        // Use the filtered user ID passed as parameter, or fall back to data->user_id
        $userId = $filtered_user_id ?: ($data->user_id ?? null);

        // Get database connection for direct queries
        $db = \Config\Database::connect();

        if($weekDay == 'Saturday' || $weekDay == 'Friday') {
            $status = "weekend";
            $status_class = "bg-primary";
        } else {
            // Use model methods for holiday and leave checks
            $isHoliday = $this->Employee_status_model->isHoliday($currentDate);

            // Check for leave using model method
            $leaveInfo = null;
            if ($userId) {
                $leaveInfo = $this->Employee_status_model->getUserLeaveInfo($userId, $currentDate);
            }

            // Determine status based on checks
            if ($isHoliday) {
                $status = "holiday";
                $status_class = "bg-info";
            } else if ($leaveInfo) {
                if ($leaveInfo->total_days == 0.5) {
                    $status = "half_leave";
                    $status_class = "bg-warning";
                } else {
                    $status = "on_leave";
                    $status_class = "bg-secondary";
                }
            } else if ($data->inTime ?? null) {
                // Check if user was late based on attendance record or calculate from check-in time
                $late_status = $this->check_late_status($data, $currentDate);
                error_log(print_r($late_status, true));
                if ($late_status['is_late']) {
                    $status = "late";
                    $status_class = "bg-warning";
                } else {
                    $status = "present";
                    $status_class = "bg-success";
                }
            } else {
                $status = "absent";
                $status_class = "bg-danger";
            }
        }

        // Use consistent status text instead of translations
        $status_text_map = [
            'weekend' => 'Weekend',
            'holiday' => 'Holiday',
            'half_leave' => 'Half Leave',
            'on_leave' => 'On Leave',
            'present' => 'Present',
            'late' => 'Late',
            'manual' => 'Manual',
            'absent' => 'Absent'
        ];

        $status_display = isset($status_text_map[$status]) ? $status_text_map[$status] : ucfirst($status);
        $data->status_meta = "<span class='badge $status_class' data-status='$status'>" . $status_display . "</span>";

        $splittedDuration = explode('.', $data->worked_hours ?? '00:00:00');
        $splittedGd = explode('.', $data->group_discussion ?? '00:00:00');
        $splittedIdle = explode('.', $data->idle ?? '00:00:00');

        $duration = count($splittedDuration) > 1 ? $splittedDuration[0] : "---";
        $gdLength = count($splittedGd) > 1 ? $splittedGd[0] : "---";
        $idleLength = count($splittedIdle) > 1 ? $splittedIdle[0] : "---";
        $activity = (int) ($data->activity ?? 0);

        if($activity <= 45) {
            $activity = "<span style='color: red;'>$activity%</span>";
        } else if ($activity < 70) {
            $activity = "<span style='color: black;'>$activity%</span>";
        } else {
            $activity = "<span style='color: green;'>$activity%</span>";
        }

        // Generate sessions and manual time buttons using Rise modal system
        $dateForJs = $data->date ?? '';
        $sessions = "--";
        $btnManualAdd = "--";

        // Sessions button - only show for working days (not weekends/holidays/leave)
        if (!in_array($status, ['weekend', 'on_leave', 'holiday'])) {
            $sessions = modal_anchor(get_uri("tracebit/sessions_modal_form"), 
                "<i data-feather='clock' class='text-primary' style='width:16px;height:16px;' title='View Sessions'></i>", 
                array("data-post-date" => $dateForJs, "data-post-user_id" => $userId));
        } else {
            $sessions = "<i data-feather='minus' class='text-muted' style='width:16px;height:16px;'></i>";
        }

        // Manual time button - show for all days except weekends (allow for holidays/leave for manual entry)
        if (!in_array($status, ['weekend'])) {
            $iconColor = 'text-success';
            if ($status === 'absent') $iconColor = 'text-danger';
            if ($status === 'on_leave' || $status === 'holiday') $iconColor = 'text-warning';

            $btnManualAdd = modal_anchor(get_uri("tracebit/manual_time_modal_form"), 
                "<i data-feather='edit-3' class='{$iconColor}' style='width:16px;height:16px;' title='Add Manual Time'></i>", 
                array("data-post-date" => $dateForJs, "data-post-user_id" => $userId));
        } else {
            $btnManualAdd = "<i data-feather='minus' class='text-muted' style='width:16px;height:16px;'></i>";
        }

        $row_data = array(
            $data->date ?? '',
            $weekDay,
            ($data->inTime ?? null) ? $this->formatTimestampToLocalTime($data->inTime) : "--",
            ($data->inTime ?? null) ? $this->formatTimestampToLocalTime($data->outTime) : "--",  
            ($data->inTime ?? null) ? $duration : "--",
            ($data->inTime ?? null) ? $activity : "--",
            $sessions,
            $data->status_meta ?? '',
            $btnManualAdd

        );
        
        return $row_data;
    }

    /**
     * Check if a user was late based on attendance data and working hours settings
     */
    private function check_late_status($data, $currentDate) {
        try {
            // Use the model method for late status checking
            $user_id = $data->user_id ?? $this->login_user->id;
            return $this->Employee_status_model->checkLateStatus($user_id, $currentDate);
        } catch (\Exception $e) {
            return ['is_late' => false, 'late_by_minutes' => 0];
        }
    }

    function get_activityLog_list(){
        try {
            // Initialize error handler and cache
            $error_handler = new \Tracebit\Libraries\Activity_error_handler();
            $cache = new \Tracebit\Libraries\Activity_cache();
            
            // Start performance monitoring
            $start_time = microtime(true);
            
            // Server-side pagination parameters
            $length = $this->request->getPost('length') ?? 25;
            $start = $this->request->getPost('start') ?? 0;
            $search_value = $this->request->getPost('search')['value'] ?? '';
            $order_column = $this->request->getPost('order')[0]['column'] ?? 0;
            $order_dir = $this->request->getPost('order')[0]['dir'] ?? 'desc';
            $draw = $this->request->getPost('draw') ?? 1;

            // Get filter parameters
            $start_date = $this->request->getPost("start_date");
            $end_date = $this->request->getPost("end_date");
            $user_filter = $this->request->getPost("applicant_id");

            // Validate date range
            $validation_errors = $error_handler->validateDateRange($start_date, $end_date);
            if (!empty($validation_errors)) {
                throw new \Exception('Invalid date range: ' . implode(', ', $validation_errors));
            }

            // If no specific date range provided, use current month
            if (!$start_date || !$end_date) {
                $start_date = $this->getCurrentDate(date('Y-m-01'));
                $end_date = $this->getCurrentDate(date('Y-m-d'));
            } else {
                $start_date = $this->getCurrentDate($start_date);
                $end_date = $this->getCurrentDate($end_date);
            }

            // Column mapping for ordering (employee summary format)
            $columns = [
                0 => 'avatar',
                1 => 'name',
                2 => 'work_days',
                3 => 'present',
                4 => 'leave',
                5 => 'absent',
                6 => 'late',
                7 => 'estimated_hours',
                8 => 'worked_hours',
                9 => 'due_hours',
                10 => 'overtime',
                11 => 'group_discussion',
                12 => 'activities'
            ];

            $order_by = $columns[$order_column] ?? 'name';

            // Try to get cached data first
            $all_data = null;
            
            if ($cache->isCacheEnabled()) {
                $all_data = $cache->getEmployeeSummary($start_date, $end_date, $user_filter);
                if ($all_data !== null) {
                    $error_handler->logCacheOperation('hit', "employee_summary_{$start_date}_{$end_date}");
                }
            }

            // Generate data if not cached
            if ($all_data === null) {
                $error_handler->checkMemoryUsage('generate_employee_summary_start');
                $all_data = $this->generateEmployeeSummaryData($start_date, $end_date);
                $error_handler->checkMemoryUsage('generate_employee_summary_end');
                
                // Cache the result
                if ($cache->isCacheEnabled() && !empty($all_data)) {
                    $cache->setEmployeeSummary($start_date, $end_date, $user_filter, $all_data);
                    $error_handler->logCacheOperation('store', "employee_summary_{$start_date}_{$end_date}", null, count($all_data));
                }
            }

            // Get total count before filtering
            $total_records = count($all_data);

            // Apply user filter if specified
            if (!empty($user_filter) && $user_filter != '0') {
                $all_data = array_filter($all_data, function($row) use ($user_filter) {
                    return isset($row['user_id']) && $row['user_id'] == $user_filter;
                });
            }

            // Apply search filter
            if (!empty($search_value)) {
                $all_data = array_filter($all_data, function($row) use ($search_value) {
                    return (
                        stripos($row['name'], $search_value) !== false ||
                        stripos($row['work_days'], $search_value) !== false ||
                        stripos($row['present'], $search_value) !== false ||
                        stripos($row['leave'], $search_value) !== false ||
                        stripos($row['absent'], $search_value) !== false ||
                        stripos($row['late'], $search_value) !== false ||
                        stripos($row['estimated_hours'], $search_value) !== false ||
                        stripos($row['worked_hours'], $search_value) !== false ||
                        stripos($row['due_hours'], $search_value) !== false ||
                        stripos($row['overtime'], $search_value) !== false ||
                        stripos($row['group_discussion'], $search_value) !== false ||
                        stripos($row['activities'], $search_value) !== false
                    );
                });
            }

            // Get filtered count after search
            $filtered_records = count($all_data);

            // Apply ordering
            usort($all_data, function($a, $b) use ($order_by, $order_dir) {
                if (is_numeric($a[$order_by]) && is_numeric($b[$order_by])) {
                    $comparison = $a[$order_by] <=> $b[$order_by];
                } else {
                    $comparison = strcasecmp($a[$order_by], $b[$order_by]);
                }
                
                return ($order_dir === 'desc') ? -$comparison : $comparison;
            });

            // Apply pagination
            $paginated_data = array_slice($all_data, $start, $length);

            // Log performance
            $end_time = microtime(true);
            $duration = $end_time - $start_time;
            $error_handler->logPerformanceIssue('get_activityLog_list', $duration);

            // Format response for DataTables
            $response = [
                "draw" => intval($draw),
                "recordsTotal" => $total_records,
                "recordsFiltered" => $filtered_records,
                "data" => $paginated_data
            ];

            echo json_encode($response);

        } catch (\Exception $e) {
            Error_handler::error('Failed to get activity log list', [
                'exception' => $e->getMessage(),
                'file' => $e->getFile(),
                'line' => $e->getLine()
            ]);

            // Return empty result on error
            echo json_encode([
                "draw" => intval($this->request->getPost('draw') ?? 1),
                "recordsTotal" => 0,
                "recordsFiltered" => 0,
                "data" => []
            ]);
        }
    }

    private function _make_activityLog_row($data)
    {
        // Convert array to object if necessary
        if (is_array($data)) {
            $data = (object) $data;
        }

        try {
            // Get user information (handle both direct user data and user_id lookups)
            $user_id = $data->user_id ?? $this->login_user->id;
            $user_name = '';
            $user_avatar = '';

            // Try to get user info if we have user_id
            if ($user_id) {
                try {
                    // Try to get user from Users_model
                    $user_info = $this->Users_model->get_one($user_id);
                    if ($user_info) {
                        $user_name = $user_info->first_name . ' ' . $user_info->last_name;
                        $image_url = get_avatar($user_info->image ?? '');
                        $user_avatar = "<span class='avatar avatar-xs'><img src='$image_url' alt='$user_name'></span>";
                    }
                } catch (\Exception $e) {
                    // Fallback to basic display
                    $user_name = $data->employee_name ?? 'User #' . $user_id;
                    $image_url = get_avatar('');
                    $user_avatar = "<span class='avatar avatar-xs'><img src='$image_url' alt='$user_name'></span>";
                }
            }

            // Use fallback data if no user found
            if (empty($user_name)) {
                $user_name = $data->employee_name ?? $data->user_name ?? 'Unknown User';
                $image_url = get_avatar($data->employee_image ?? '');
                $user_avatar = "<span class='avatar avatar-xs'><img src='$image_url' alt='$user_name'></span>";
            }

            // Format activity timestamp
            $activity_time = '';
            $activity_date = '';
            
            if (isset($data->created_at)) {
                $timestamp = strtotime($data->created_at);
                $activity_date = date('Y-m-d', $timestamp);
                $activity_time = $this->formatTimestampToLocalTime($timestamp * 1000); // Convert to milliseconds
            } else if (isset($data->date) && isset($data->time)) {
                $activity_date = $data->date;
                $activity_time = $this->formatTimestampToLocalTime(strtotime($data->time) * 1000); // Convert to milliseconds
            } else {
                $activity_date = date('Y-m-d');
                $activity_time = $this->formatTimestampToLocalTime(time() * 1000); // Convert to milliseconds
            }

            // Activity type with proper formatting
            $activity_type = $data->activity_type ?? 'Unknown';
            $activity_type_formatted = ucwords(str_replace('_', ' ', $activity_type));

            // Activity description
            $description = $data->description ?? 'No description available';
            
            // Truncate long descriptions
            if (strlen($description) > 80) {
                $description = substr($description, 0, 77) . '...';
            }

            // IP Address with security consideration
            $ip_address = $data->ip_address ?? 'N/A';
            
            // Make IP address partially hidden for security
            if ($ip_address != 'N/A' && strpos($ip_address, '.') !== false) {
                $ip_parts = explode('.', $ip_address);
                if (count($ip_parts) == 4) {
                    $ip_address = $ip_parts[0] . '.' . $ip_parts[1] . '.***.' . $ip_parts[3];
                }
            }

            // Status badge based on activity type
            $status_class = 'bg-info';
            $status_text = 'Activity';
            
            switch ($activity_type) {
                case 'login':
                    $status_class = 'bg-success';
                    $status_text = 'Login';
                    break;
                case 'logout':
                    $status_class = 'bg-warning';
                    $status_text = 'Logout';
                    break;
                case 'task_create':
                case 'task_update':
                    $status_class = 'bg-primary';
                    $status_text = 'Task';
                    break;
                case 'file_upload':
                    $status_class = 'bg-info';
                    $status_text = 'Upload';
                    break;
                case 'settings_change':
                case 'password_change':
                    $status_class = 'bg-danger';
                    $status_text = 'Security';
                    break;
                default:
                    $status_class = 'bg-secondary';
                    $status_text = 'General';
            }

            $status_badge = "<span class='badge $status_class'>$status_text</span>";

            // Build the row data array for the DataTable
            $row_data = array(
                $user_avatar,
                get_team_member_profile_link($user_id, $user_name),
                $activity_date,
                $activity_time,
                $activity_type_formatted,
                $description,
                $ip_address,
                $status_badge
            );

            // Add raw data for potential sorting/filtering
            $row_data['DT_RowData'] = array(
                'user_id' => $user_id,
                'activity_type' => $activity_type,
                'timestamp' => $data->created_at ?? ($activity_date . ' ' . date('H:i:s', strtotime($activity_time))),
                'date' => $activity_date
            );

            return $row_data;

        } catch (\Exception $e) {
            // Error handling with fallback row
            Error_handler::warning('Error creating activity log row', [
                'error' => $e->getMessage(),
                'data' => $data
            ]);

            // Return a basic error row
            return array(
                '<span class="avatar avatar-xs"><img src="' . get_avatar('') . '" alt="Error"></span>',
                'Error loading user',
                date('Y-m-d'),
                $this->formatTimestampToLocalTime(time() * 1000), // Convert to milliseconds
                'Error',
                'Failed to load activity data',
                'N/A',
                '<span class="badge bg-danger">Error</span>'
            );
        }
    }

    function get_session_data() {
        return $this->executeWithErrorHandling(function() {
            $date = $this->request->getPost('date');
            $user_id = $this->request->getPost('user_id');

            if (!$date) {
                return $this->_make_error_response(app_lang('invalid_date'));
            }

            Error_handler::info('Getting session data', [
                'date' => $date,
                'user_id' => $user_id
            ]);

            // If no user_id provided, get current user's sessions
            if (!$user_id) {
                $user_id = $this->login_user->id;
            }

            // Get session data from the database
            $sessions_data = $this->Employee_status_model->get_session_data($date, $user_id);

            if ($sessions_data === false) {
                Error_handler::warning('Failed to get session data from model');
                return $this->_make_error_response('Failed to retrieve session data');
            }

            // Format sessions for the frontend
            $formatted_sessions = [];
            $total_minutes = 0;

            if (!empty($sessions_data)) {
                foreach ($sessions_data as $session) {
                    $duration_minutes = $this->_parse_duration_to_minutes($session->duration ?? '0m');
                    $total_minutes += $duration_minutes;

                    $formatted_sessions[] = [
                        'session_time' => $session->start_time ?? $this->formatTimestampToLocalTime(strtotime($session->created_at ?? 'now') * 1000),
                        'description' => $session->description ?? $session->activity ?? 'Work Session',
                        'duration' => $session->duration ?? $this->_format_duration($duration_minutes),
                        'action' => $session->status ?? 'Active',
                        'start_time' => $session->start_time ?? '',
                        'end_time' => $session->end_time ?? '',
                        'activity' => $session->activity ?? '',
                        'created_at' => $session->created_at ?? ''
                    ];
                }
            }

            $response_data = [
                'sessions' => $formatted_sessions,
                'total_sessions' => count($formatted_sessions),
                'total_time' => $this->_format_duration($total_minutes),
                'date' => $date,
                'user_id' => $user_id
            ];

            Error_handler::info('Session data retrieved successfully', [
                'sessions_count' => count($formatted_sessions),
                'total_time' => $this->_format_duration($total_minutes)
            ]);

            return $this->_make_success_response($response_data);

        }, 'get_session_data', []);
    }

    private function _parse_duration_to_minutes($duration) {
        if (!$duration) return 0;

        $minutes = 0;

        // Parse hours (e.g., "2h")
        if (preg_match('/(\d+)h/', $duration, $matches)) {
            $minutes += intval($matches[1]) * 60;
        }

        // Parse minutes (e.g., "30m")
        if (preg_match('/(\d+)m/', $duration, $matches)) {
            $minutes += intval($matches[1]);
        }

        return $minutes;
    }

    private function _format_duration($minutes) {
        if ($minutes < 60) {
            return $minutes . 'm';
        }

        $hours = floor($minutes / 60);
        $remaining_minutes = $minutes % 60;

        if ($remaining_minutes > 0) {
            return $hours . 'h ' . $remaining_minutes . 'm';
        }

        return $hours . 'h';
    }

    function sessions_modal_form() {
        // Handle both GET and POST requests
        $date = $this->request->getPost('date') ?: $this->request->getGet('date');

        if (!$date) {
            $date = date('Y-m-d');
        }

        $view_data['date'] = $date;
        $user_id = $this->request->getPost('user_id') ?: $this->request->getGet('user_id');
        
        // Only fall back to login_user if no user_id is provided at all
        if (!$user_id) {
            $user_id = $this->login_user->id;
        }
        
        $view_data['user_id'] = $user_id;

        // Get user name for modal title
        $user_model = model("App\\Models\\Users_model");
        $user_info = $user_model->get_one($view_data['user_id']);
        $view_data['user_name'] = '';
        if ($user_info) {
            $view_data['user_name'] = $user_info->first_name . ' ' . $user_info->last_name;
        }

            // Get session data for the modal
            $session_result = $this->Employee_status_model->get_session_data($date, $view_data['user_id']);

            if (is_array($session_result) && isset($session_result['sessions'])) {
                $view_data['sessions_data'] = $session_result['sessions'];
                $view_data['avg_productivity'] = $session_result['avg_productivity'] ?? 0;
            } else {
                // Fallback for old format
                $view_data['sessions_data'] = $session_result;
                $view_data['avg_productivity'] = 0;
            }

            Error_handler::info('Sessions modal form loaded', [
                'date' => $date,
                'user_id' => $view_data['user_id'],
                'user_name' => $view_data['user_name'],
                'sessions_count' => count($view_data['sessions_data']),
                'avg_productivity' => $view_data['avg_productivity']
            ]);

            // Set modal title for Rise CRM modal system
            $modal_title = "Daily Working Sessions - " . $date;
            if (!empty($view_data['user_name'])) {
                $modal_title .= " (" . $view_data['user_name'] . ")";
            }
            $view_data['modal_title'] = $modal_title;

            return $this->template->view('Tracebit\\Views\\modals\\sessions_modal', $view_data);
    }

    function manual_time_modal_form() {
        try {
            // Handle both GET and POST requests
            $date = $this->request->getPost('date') ?: $this->request->getGet('date');
            $user_id = $this->request->getPost('user_id') ?: $this->request->getGet('user_id');
            
            // Only fall back to login_user if no user_id is provided at all
            if (!$user_id) {
                $user_id = $this->login_user->id;
            }

            if (!$date) {
                $date = date('Y-m-d');
            }

            // Get user information
            $user_info = $this->Users_model->get_one($user_id);
            $user_name = '';
            $user_avatar_url = '';
            if ($user_info) {
                $user_name = $user_info->first_name . ' ' . $user_info->last_name;
                $user_avatar_url = $user_info->image ?? '';
            }
            
            $view_data = [
                'date' => $date,
                'user_id' => $user_id,
                'user_name' => $user_name,
                'user_avatar_url' => $user_avatar_url
            ];

            Error_handler::info('Manual time modal form loaded', [
                'date' => $date,
                'user_id' => $user_id,
                'user_name' => $view_data['user_name']
            ]);

            // Set modal title for Rise CRM modal system
            $modal_title = "Add Time Manually - " . $date;
            if (!empty($view_data['user_name'])) {
                $modal_title .= " (" . $view_data['user_name'] . ")";
            }
            $view_data['modal_title'] = $modal_title;

            // Return the view directly instead of using executeWithErrorHandling
            return $this->template->view('Tracebit\\Views\\modals\\manual_time_modal', $view_data);
            
        } catch (\Exception $e) {
            return Error_handler::handleException($e, 'manual_time_modal_form');
        }
    }

    function save_manual_time() {
        return $this->executeWithErrorHandling(function() {
            $date = $this->request->getPost('date');
            $in_time = $this->request->getPost('in_time');
            $out_time = $this->request->getPost('out_time');
            $description = $this->request->getPost('description') ?: '';
            $user_id = $this->request->getPost('user_id') ?: $this->login_user->id;

            // Validate required fields
            if (!$date || !$in_time || !$out_time) {
                $this->_make_error_response('Date, In Time, and Out Time are required');
                return;
            }

            // Prepare data for model
            $manual_time_data = [
                'date' => $date,
                'in_time' => $in_time,
                'out_time' => $out_time,
                'description' => $description,
                'user_id' => $user_id
            ];

            // Use model method to save manual time with proper timezone handling
            $result = $this->Employee_status_model->saveManualTime($manual_time_data);

            if ($result['success']) {
                $this->_make_success_response($result);
            } else {
                $this->_make_error_response($result['message']);
            }

        }, 'save_manual_time', []);
    }

    function delete_session() {
        $this->response->setContentType('application/json');

        try {
            $session_id = $this->request->getPost('session_id');
            $user_id = $this->request->getPost('user_id') ?: $this->login_user->id;

            if (!$session_id) {
                echo json_encode([
                    'success' => false,
                    'message' => 'Session ID is required'
                ]);
                return;
            }

            $result = $this->Employee_status_model->delete_session($session_id, $user_id);

            if ($result) {
                echo json_encode([
                    'success' => true,
                    'message' => 'Session deleted successfully'
                ]);
            } else {
                echo json_encode([
                    'success' => false,
                    'message' => 'Failed to delete session'
                ]);
            }

        } catch (\Exception $e) {
            echo json_encode([
                'success' => false,
                'message' => 'An error occurred while deleting the session'
            ]);
        }
    }

    private function _make_success_response($data) {
        echo json_encode([
            'success' => true,
            'message' => $data['message'] ?? 'Operation completed successfully',
            'data' => $data['data'] ?? $data
        ]);
        return;
    }

    private function _make_error_response($message) {
        echo json_encode([
            'success' => false,
            'message' => $message
        ]);
        return;
    }

    /**
     * Validate leave and holiday calculations for debugging
     */
    public function validate_leave_holiday_calculation() {
        $tracker_holidays_table = $this->db->prefixTable('tracker_holidays');
        try {
            // Only allow access for debugging (remove in production)
            if (!$this->login_user || $this->login_user->user_type !== 'staff') {
                show_404();
                return;
            }
            
            $start_date = $this->request->getGet('start_date') ?: date('Y-m-01');
            $end_date = $this->request->getGet('end_date') ?: date('Y-m-d');
            
            $db = \Config\Database::connect();
            
            echo "<h2>Leave & Holiday Calculation Validation</h2>";
            echo "<p><strong>Date Range:</strong> {$start_date} to {$end_date}</p>";
            
            // Test date range calculation
            $date_info = $this->calculateDateRangeInfo($start_date, $end_date);
            echo "<h3>Date Range Info:</h3>";
            echo "<ul>";
            echo "<li>Total days: {$date_info['total_days']}</li>";
            echo "<li>Weekend days: {$date_info['weekend_days']}</li>";
            echo "<li>Holiday days: {$date_info['holiday_days']}</li>";
            echo "</ul>";
            
            // Test holidays detail
            echo "<h3>Holiday Details:</h3>";
            $holidays_query = $db->query("
                SELECT start_date, end_date,
                       DATEDIFF(LEAST(end_date, ?), GREATEST(start_date, ?)) + 1 as days_in_range
                FROM $tracker_holidays_table 
                WHERE (start_date BETWEEN ? AND ?) 
                   OR (end_date BETWEEN ? AND ?) 
                   OR (start_date <= ? AND end_date >= ?)
                AND deleted = 0
            ", [$end_date, $start_date, $start_date, $end_date, $start_date, $end_date, $start_date, $end_date]);
            
            $holidays = $holidays_query->getResult();
            if ($holidays) {
                echo "<ul>";
                foreach ($holidays as $holiday) {
                    echo "<li>{$holiday->start_date} to {$holiday->end_date} = {$holiday->days_in_range} days</li>";
                }
                echo "</ul>";
            } else {
                echo "<p>No holidays found in date range</p>";
            }
            
            // Test leave calculation for current user
            echo "<h3>Leave Calculation for Current User:</h3>";
            $user_id = $this->login_user->id;
            
            $leave_query = $db->query("
                SELECT start_date, end_date, total_days,
                       CASE 
                           WHEN start_date > ? THEN 
                               DATEDIFF(LEAST(end_date, ?), start_date) + 1
                           WHEN end_date < ? THEN 
                               DATEDIFF(end_date, GREATEST(start_date, ?)) + 1
                           ELSE 
                               DATEDIFF(LEAST(end_date, ?), GREATEST(start_date, ?)) + 1
                       END as calculated_days
                FROM " . $db->prefixTable('leave_applications') . " 
                WHERE applicant_id = ? 
                AND status = 'approved'
                AND deleted = 0
                AND (
                    (start_date BETWEEN ? AND ?) 
                    OR (end_date BETWEEN ? AND ?) 
                    OR (start_date <= ? AND end_date >= ?)
                )
            ", [
                $start_date, $end_date, $start_date, $start_date, $end_date, $start_date,
                $user_id,
                $start_date, $end_date, $start_date, $end_date, $start_date, $end_date
            ]);
            
            $leaves = $leave_query->getResult();
            $total_leave_days = 0;
            
            if ($leaves) {
                echo "<ul>";
                foreach ($leaves as $leave) {
                    echo "<li>{$leave->start_date} to {$leave->end_date} = {$leave->calculated_days} days (total: {$leave->total_days})</li>";
                    $total_leave_days += $leave->calculated_days;
                }
                echo "</ul>";
                echo "<p><strong>Total leave days:</strong> {$total_leave_days}</p>";
            } else {
                echo "<p>No approved leave applications found</p>";
            }
            
            // Final calculation
            echo "<h3>Final Workable Days Calculation:</h3>";
            $workable_days = $date_info['total_days'] - $date_info['weekend_days'] - $date_info['holiday_days'] - $total_leave_days;
            $workable_days = max(0, $workable_days);
            
            echo "<p>";
            echo "{$date_info['total_days']} (total) - ";
            echo "{$date_info['weekend_days']} (weekends) - ";
            echo "{$date_info['holiday_days']} (holidays) - ";
            echo "{$total_leave_days} (leave) = ";
            echo "<strong>{$workable_days} workable days</strong>";
            echo "</p>";
            
        } catch (\Exception $e) {
            echo "<p style='color: red;'>Error: " . $e->getMessage() . "</p>";
        }
    }

    /**
     * Add a special holiday (proper way instead of hardcoding dates)
     * Example: /tracebit/employee_status/add_special_holiday/2025-07-06?reason=Company%20Special%20Day
     */
    function add_special_holiday($date = null) {
        return $this->executeWithErrorHandling(function() use ($date) {
            // Get date from URL parameter or POST
            if (!$date) {
                $date = $this->request->getPost('date') ?: $this->request->getGet('date');
            }
            
            $reason = $this->request->getPost('reason') ?: $this->request->getGet('reason') ?: '';
            
            if (!$date) {
                $this->_make_error_response('Date parameter is required (YYYY-MM-DD format)');
                return;
            }
            
            // Validate date format
            if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
                $this->_make_error_response('Date must be in YYYY-MM-DD format');
                return;
            }
            
            // Add the special holiday using model method
            $result = $this->Employee_status_model->addSpecialHoliday($date, $reason);
            
            if ($result) {
                $message = "Special holiday added successfully: $date";
                if ($reason) {
                    $message .= " - $reason";
                }
                
                $this->_make_success_response([
                    'message' => $message,
                    'data' => [
                        'date' => $date,
                        'reason' => $reason,
                        'method' => 'configurable_setting'
                    ]
                ]);
            } else {
                $this->_make_error_response('Failed to add special holiday');
            }
            
        }, 'add_special_holiday', []);
    }

    /**
     * Remove a special holiday
     * Example: /tracebit/employee_status/remove_special_holiday/2025-07-06
     */
    function remove_special_holiday($date = null) {
        return $this->executeWithErrorHandling(function() use ($date) {
            // Get date from URL parameter or POST
            if (!$date) {
                $date = $this->request->getPost('date') ?: $this->request->getGet('date');
            }
            
            if (!$date) {
                $this->_make_error_response('Date parameter is required (YYYY-MM-DD format)');
                return;
            }
            
            // Remove the special holiday using model method
            $result = $this->Employee_status_model->removeSpecialHoliday($date);
            
            if ($result) {
                $this->_make_success_response([
                    'message' => "Special holiday removed successfully: $date",
                    'data' => [
                        'date' => $date,
                        'action' => 'removed'
                    ]
                ]);
            } else {
                $this->_make_error_response('Failed to remove special holiday');
            }
            
        }, 'remove_special_holiday', []);
    }
}
