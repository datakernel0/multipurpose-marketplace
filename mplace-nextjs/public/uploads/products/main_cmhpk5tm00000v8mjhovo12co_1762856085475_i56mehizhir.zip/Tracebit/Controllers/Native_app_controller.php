<?php

namespace Tracebit\Controllers;

use App\Controllers\App_Controller;
use Tracebit\Libraries\Error_handler;
use Tracebit\Traits\Error_handling_trait;

class Native_app_controller extends App_Controller {

    use Error_handling_trait;

    protected $Native_app_model;

    function __construct() {
        parent::__construct();

        try {
            $this->Native_app_model = model("Tracebit\Models\Native_app_model");
            helper(['form', 'url']);
            Error_handler::info('Native_app_controller initialized successfully');
        } catch (\Exception $e) {
            Error_handler::error('Failed to initialize Native_app_controller', [
                'exception' => $e->getMessage(),
                'file' => $e->getFile(),
                'line' => $e->getLine()
            ]);
            throw $e;
        }
    }

    /**
     * Create or update user attendance status
     * Used by the desktop app to update attendance status (check-in/check-out)
     *
     * @return void
     */
    function create_status() {
        // Validate required parameters
        $validation_error = $this->validateRequestParams(['user_id', 'status'], 'POST');
        if ($validation_error) {
            $this->sendJsonResponse($validation_error, 400);
            return;
        }

        $user_id = $this->getSanitizedParam('user_id', null, 'POST');
        $status = $this->getSanitizedParam('status', null, 'POST');

        $response = $this->executeWithErrorHandling(function() use ($user_id, $status) {
            $this->logOperation('create_status', ['user_id' => $user_id, 'status' => $status]);

            // Check if we have a valid user
            $user = $this->Native_app_model->getUserById($user_id);
            if (!$user) {
                Error_handler::warning('User not found for status update', ['user_id' => $user_id]);
                return Error_handler::formatErrorResponse("User not found!", 404);
            }

            // Update the user's status in the tracker_status table
            $result = $this->updateUserStatus($user_id, $status);

            if ($result) {
                return Error_handler::formatSuccessResponse("Status updated successfully", ['status' => $status]);
            } else {
                Error_handler::error('Failed to update status', ['user_id' => $user_id, 'status' => $status]);
                return Error_handler::formatErrorResponse("Failed to update status", 500);
            }
        }, 'create_status');

        $this->sendJsonResponse($response, $response['success'] ? 200 : ($response['code'] ?? 500));
    }

    /**
     * Update user status in the database
     *
     * @param int $user_id User ID
     * @param string $status Status (check-in/check-out)
     * @return bool Success or failure
     */
    private function updateUserStatus($user_id, $status) {
        try {
            Error_handler::info('updateUserStatus started', [
                'user_id' => $user_id,
                'status' => $status
            ]);

            // Use model method for database operations
            $result = $this->Native_app_model->updateUserStatus($user_id, $status);

            if ($result) {
                Error_handler::info('User status updated successfully', [
                    'user_id' => $user_id,
                    'status' => $status
                ]);
            } else {
                Error_handler::error('Failed to update user status', [
                    'user_id' => $user_id,
                    'status' => $status
                ]);
            }

            return $result;
        } catch (\Exception $e) {
            Error_handler::error('Error in updateUserStatus', [
                'exception' => $e->getMessage(),
                'file' => $e->getFile(),
                'line' => $e->getLine(),
                'user_id' => $user_id,
                'status' => $status
            ]);
            return false;
        }
    }





    /**
     * Log status changes for auditing
     *
     * @param int $user_id User ID
     * @param string $status New status
     * @param string $timestamp Timestamp
     */




    /**
     * Send JSON response with proper headers
     *
     * @param array $data Response data
     * @param int $http_code HTTP status code
     * @return void
     */
    protected function sendJsonResponse($data, $http_code = 200) {
        // Set JSON headers
        $this->response->setHeader('Content-Type', 'application/json');
        $this->response->setStatusCode($http_code);

        // Send JSON response
        echo json_encode($data);
        exit();
    }

    /**
     * Validate required request parameters
     *
     * @param array $required_params Required parameter names
     * @param string $method Request method (GET, POST)
     * @return array|null Error response or null if valid
     */
    protected function validateRequestParams(array $required_params, $method = 'POST') {
        $missing_params = [];

        // Get JSON data for fallback validation - handle errors gracefully
        $json_data = [];
        try {
            $ci_json = $this->request->getJSON(true);
            if (is_array($ci_json)) {
                $json_data = $ci_json;
            }
        } catch (\Exception $e) {
            // Log but don't fail - we'll try other methods
        }

        // Also try to get raw body and decode it manually
        $raw_body_data = [];
        try {
            $raw_input = $this->request->getBody();
            if (!empty($raw_input)) {
                $decoded = json_decode($raw_input, true);
                if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
                    $raw_body_data = $decoded;
                }
            }
        } catch (\Exception $e) {
        }

        foreach ($required_params as $param) {
            $found = false;

            if ($method === 'POST') {
                // Check POST parameters first
                if ($this->request->getPost($param) !== null) {
                    $found = true;
                }
                // Fallback to JSON data from getJSON()
                elseif (isset($json_data[$param])) {
                    $found = true;
                }
                // Fallback to raw body JSON data
                elseif (isset($raw_body_data[$param])) {
                    $found = true;
                }
            } else {
                // Check GET parameters first
                if ($this->request->getGet($param) !== null) {
                    $found = true;
                }
                // Fallback to JSON data for GET requests too (some APIs might send JSON with GET)
                elseif (isset($json_data[$param])) {
                    $found = true;
                }
                elseif (isset($raw_body_data[$param])) {
                    $found = true;
                }
            }

            if (!$found) {
                $missing_params[] = $param;
            }
        }

        if (!empty($missing_params)) {
            // Log debugging info for missing parameters
            return Error_handler::formatErrorResponse(
                'Missing required parameters: ' . implode(', ', $missing_params),
                400
            );
        }

        return null;
    }

    /**
     * Get and sanitize request parameter
     *
     * @param string $param Parameter name
     * @param mixed $default Default value if not set
     * @param string $method Request method (GET, POST)
     * @return mixed Sanitized parameter value
     */
    protected function getSanitizedParam($param, $default = null, $method = 'POST') {
        $value = $method === 'POST'
            ? $this->request->getPost($param)
            : $this->request->getGet($param);

        // If not found in regular parameters, try JSON fallback
        if ($value === null) {
            try {
                $json_data = $this->request->getJSON(true);
                if (is_array($json_data) && isset($json_data[$param])) {
                    $value = $json_data[$param];
                }
            } catch (\Exception $e) {
                // Ignore JSON errors and continue
            }
        }

        if ($value === null) {
            return $default;
        }

        // Basic sanitization
        if (is_string($value)) {
            $value = trim($value);
            // Prevent XSS
            $value = htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
        }

        return $value;
    }

    /**
     * Get JSON parameter from request
     *
     * @param string $param Parameter name
     * @param mixed $default Default value if not set
     * @return mixed Parameter value
     */
    protected function getJsonParam($param, $default = null) {
        try {
            // First try CodeIgniter's getJSON method
            $json_data = $this->request->getJSON(true);

            // If getJSON returns valid array, use it
            if (is_array($json_data) && isset($json_data[$param])) {
                return $json_data[$param];
            }

            // Fallback: try to get raw body and decode manually
            $raw_input = $this->request->getBody();
            if (!empty($raw_input)) {
                $decoded_data = json_decode($raw_input, true);

                if (json_last_error() === JSON_ERROR_NONE && is_array($decoded_data)) {
                    if (isset($decoded_data[$param])) {
                        return $decoded_data[$param];
                    }
                } else {
                    // Log JSON decode error for debugging
                }
            }

            // Final fallback to regular parameter
            return $this->getSanitizedParam($param, $default);

        } catch (\Exception $e) {
            // Log the error and fall back to regular parameter
            Error_handler::error('Error getting JSON parameter', [
                'param' => $param,
                'exception' => $e->getMessage(),
                'file' => $e->getFile(),
                'line' => $e->getLine()
            ]);
            return $this->getSanitizedParam($param, $default);
        }
    }

    /**
     * Log operation with context
     *
     * @param string $operation Operation name
     * @param array $context Context data
     */
    protected function logOperation($operation, $context = []) {
        Error_handler::info("Operation: {$operation}", $context);
    }

    function authenticate() {
        // Validate required parameters
        $validation_error = $this->validateRequestParams(['email', 'password'], 'GET');
        if ($validation_error) {
            $this->sendJsonResponse($validation_error, 400);
            return;
        }

        $email = $this->getSanitizedParam('email', null, 'GET');
        $password = $this->getSanitizedParam('password', null, 'GET');

        $response = $this->executeWithErrorHandling(function() use ($email, $password) {
            $this->logOperation('authenticate_attempt', ['email' => $email]);

            $user_info = $this->Native_app_model->authenticate_for_native($email, $password);

            if ($user_info) {
                Error_handler::info('Authentication successful', ['email' => $email, 'user_id' => $user_info->id ?? null]);
                return Error_handler::formatSuccessResponse("Login Success!", $user_info);
            } else {
                Error_handler::warning('Authentication failed', ['email' => $email]);
                return Error_handler::formatErrorResponse("Login failed!", 401);
            }
        }, 'user_authentication');

        $this->sendJsonResponse($response, $response['success'] ? 200 : 401);
    }

    function getProjects() {
        // Validate required parameters
        $validation_error = $this->validateRequestParams(['user_id'], 'GET');
        if ($validation_error) {
            $this->sendJsonResponse($validation_error, 400);
            return;
        }

        $user_id = $this->getSanitizedParam('user_id', null, 'GET');

        $response = $this->executeWithErrorHandling(function() use ($user_id) {
            $this->logOperation('get_projects', ['user_id' => $user_id]);

            $projects = $this->Native_app_model->getProjects($user_id);

            if ($projects !== false) {
                return Error_handler::formatSuccessResponse("Success!", $projects);
            } else {
                Error_handler::warning('Failed to get projects', ['user_id' => $user_id]);
                return Error_handler::formatErrorResponse("Failed to retrieve projects!", 500);
            }
        }, 'get_projects');

        $this->sendJsonResponse($response, $response['success'] ? 200 : 500);
    }

    function addProject() {
        // Validate required parameters
        $validation_error = $this->validateRequestParams(['user_id', 'name']);
        if ($validation_error) {
            $this->sendJsonResponse($validation_error, 400);
            return;
        }

        $user_id = $this->getSanitizedParam('user_id');
        $name = $this->getSanitizedParam('name');
        $description = $this->getSanitizedParam('description', ''); // Optional parameter

        $response = $this->executeWithErrorHandling(function() use ($user_id, $name, $description) {
            $this->logOperation('add_project', [
                'user_id' => $user_id,
                'name' => $name,
                'description' => $description
            ]);

            // Validate project name
            if (empty(trim($name))) {
                Error_handler::warning('Empty project name provided', ['user_id' => $user_id]);
                return Error_handler::formatErrorResponse("Project name is required!", 400);
            }

            // Check if project name already exists for this user
            $existing_projects = $this->Native_app_model->getProjects($user_id);
            if ($existing_projects !== false && is_array($existing_projects)) {
                foreach ($existing_projects as $project) {
                    if (isset($project->title) && strtolower(trim($project->title)) === strtolower(trim($name))) {
                        Error_handler::warning('Duplicate project name', [
                            'user_id' => $user_id,
                            'name' => $name
                        ]);
                        return Error_handler::formatErrorResponse("A project with this name already exists!", 409);
                    }
                }
            }

            // Create the project
            $project_data = [
                'title' => trim($name),
                'description' => trim($description),
                'user_id' => $user_id,
                'created_at' => date('Y-m-d H:i:s'),
                'status' => 'active'
            ];

            $project_id = $this->Native_app_model->addProject($project_data);

            if ($project_id && $project_id > 0) {
                // Return the created project data
                $created_project = [
                    'id' => $project_id,
                    'title' => $project_data['title'],
                    'name' => $project_data['title'], // For backward compatibility
                    'description' => $project_data['description'],
                    'user_id' => $user_id,
                    'created_at' => $project_data['created_at'],
                    'status' => $project_data['status']
                ];

                Error_handler::info('Project created successfully', [
                    'user_id' => $user_id,
                    'project_id' => $project_id,
                    'name' => $name
                ]);

                return Error_handler::formatSuccessResponse("Project created successfully!", [
                    'project' => $created_project
                ]);
            } else {
                Error_handler::error('Failed to create project', [
                    'user_id' => $user_id,
                    'name' => $name,
                    'model_result' => $project_id
                ]);
                return Error_handler::formatErrorResponse("Failed to create project!", 500);
            }
        }, 'add_project');

        $this->sendJsonResponse($response, $response['success'] ? 200 : ($response['http_code'] ?? 500));
    }

    function user_info() {
        // Validate required parameters
        $validation_error = $this->validateRequestParams(['user_id'], 'GET');
        if ($validation_error) {
            $this->sendJsonResponse($validation_error, 400);
            return;
        }

        $user_id = $this->getSanitizedParam('user_id', null, 'GET');

        $response = $this->executeWithErrorHandling(function() use ($user_id) {
            $this->logOperation('get_user_info', ['user_id' => $user_id]);

            $info = $this->Native_app_model->user_info($user_id);

            if ($info !== false) {
                return Error_handler::formatSuccessResponse("Success!", $info);
            } else {
                Error_handler::warning('Failed to get user info', ['user_id' => $user_id]);
                return Error_handler::formatErrorResponse("Failed to retrieve user information!", 500);
            }
        }, 'get_user_info');

        $this->sendJsonResponse($response, $response['success'] ? 200 : 500);
    }

    // For app data update
    function synced() {
        // Validate required parameters
        $validation_error = $this->validateRequestParams(['attendance', 'performance', 'user_id']);
        if ($validation_error) {
            $this->sendJsonResponse($validation_error, 400);
            return;
        }

        $attendance_raw = $this->request->getPost('attendance');
        $performance_raw = $this->request->getPost('performance');
        $user_id = $this->getSanitizedParam('user_id');

        $response = $this->executeWithErrorHandling(function() use ($attendance_raw, $performance_raw, $user_id) {
            $this->logOperation('sync_data', ['user_id' => $user_id]);

            // Handle attendance data - getJsonParam should return decoded data
            $attendance = [];
            if (!empty($attendance_raw)) {
                if (is_array($attendance_raw)) {
                    $attendance = $attendance_raw;

                } else if (is_string($attendance_raw)) {
                    // If it's still a string, try to decode it
                    $decoded_attendance = json_decode($attendance_raw, true);
                    if (json_last_error() === JSON_ERROR_NONE && is_array($decoded_attendance)) {
                        $attendance = $decoded_attendance;
                    } else {
                        Error_handler::warning('Invalid attendance JSON data', ['user_id' => $user_id, 'data_preview' => substr($attendance_raw, 0, 100), 'error' => json_last_error_msg()]);
                    }
                } else {
                }
            }

            // Handle performance data - getJsonParam should return decoded data
            $performance = [];
            if (!empty($performance_raw)) {
                if (is_array($performance_raw)) {
                    $performance = $performance_raw;
                } else if (is_string($performance_raw)) {
                    // If it's still a string, try to decode it
                    $decoded_performance = json_decode($performance_raw, true);
                    if (json_last_error() === JSON_ERROR_NONE && is_array($decoded_performance)) {
                        $performance = $decoded_performance;
                    } else {
                        Error_handler::warning('Invalid performance JSON data', ['user_id' => $user_id, 'data_preview' => substr($performance_raw, 0, 100), 'error' => json_last_error_msg()]);
                    }
                } else {
                }
            }

            Error_handler::info('Sync data processed', [
                'user_id' => $user_id,
                'attendance_count' => count($attendance),
                'performance_count' => count($performance)
            ]);

            try {
                $returned = $this->Native_app_model->synced($attendance, $performance, $user_id);
            } catch (\Exception $modelEx) {
                Error_handler::error('Model synced method threw exception', [
                    'exception' => $modelEx->getMessage(),
                    'trace' => $modelEx->getTraceAsString()
                ]);
                $returned = false;
            }

            if ($returned !== false) {
                return Error_handler::formatSuccessResponse("Data synced successfully!", $returned);
            } else {
                Error_handler::warning('Failed to sync data', ['user_id' => $user_id]);
                return Error_handler::formatErrorResponse("Failed to sync data!", 500);
            }
        }, 'sync_data');

        $this->sendJsonResponse($response, $response['success'] ? 200 : 500);
    }

    /**
     * Create organized directory structure for screenshots
     * 
     * @param string $base_path The base path to create
     * @return bool Success or failure
     */
    private function createScreenshotDirectory($base_path) {
        try {
            // Create directory structure recursively
            if (!is_dir($base_path)) {
                if (!mkdir($base_path, 0755, true)) {
                    throw new \Exception("Failed to create directory: {$base_path}");
                }
                
                // Log directory creation
                Error_handler::info('Screenshot directory created', [
                    'path' => $base_path
                ]);
            }
            
            return true;
        } catch (\Exception $e) {
            Error_handler::error('Failed to create screenshot directory', [
                'path' => $base_path,
                'exception' => $e->getMessage()
            ]);
            return false;
        }
    }

    /**
     * Generate unique filename to avoid conflicts
     * 
     * @param string $base_path Base directory path
     * @param string $filename Original filename
     * @return string Unique filename
     */
    private function generateUniqueFilename($base_path, $filename) {
        $counter = 1;
        $original_filename = $filename;
        
        while (file_exists($base_path . '/' . $filename)) {
            $path_info = pathinfo($original_filename);
            $filename = $path_info['filename'] . "_{$counter}." . $path_info['extension'];
            $counter++;
        }
        
        return $filename;
    }

    private function dataUrlToFile($dataUrl, $outputFile, $options) {
        try {
            // Check if the data URL is valid
            if (!preg_match('/^data:([a-zA-Z0-9]+\/[a-zA-Z0-9-.+]+)?;base64,/', $dataUrl, $matches)) {
                throw new \Exception('Invalid data URL format');
            }

            $data = substr($dataUrl, strpos($dataUrl, ',') + 1);
            $data = base64_decode($data);

            // Check if the decoding was successful
            if ($data === false) {
                throw new \Exception('Base64 decoding failed');
            }

            // Create organized directory structure
            $dir = dirname($outputFile);
            if (!$this->createScreenshotDirectory($dir)) {
                throw new \Exception('Failed to create directory structure');
            }

            // Generate unique filename to avoid conflicts
            $filename = basename($outputFile);
            $unique_filename = $this->generateUniqueFilename($dir, $filename);
            $final_output_file = $dir . '/' . $unique_filename;

            // Write the data to a file
            if (file_put_contents($final_output_file, $data) === false) {
                throw new \Exception('Failed to write file');
            }

            // Update the path in options to reflect the actual saved file
            $options['path'] = $final_output_file;

            // Log successful file creation
            Error_handler::info('Screenshot file created successfully', [
                'original_path' => $outputFile,
                'final_path' => $final_output_file,
                'file_size' => filesize($final_output_file),
                'user_id' => $options['user_id']
            ]);

            $save_image = $this->Native_app_model->createScreenshot($options);

            if ($save_image) {
                $response = Error_handler::formatSuccessResponse(app_lang('record saved'), [
                    'file_path' => $final_output_file,
                    'file_size' => filesize($final_output_file)
                ]);
            } else {
                $response = Error_handler::formatErrorResponse(app_lang('record failed to saved'), 500);
            }

            $this->sendJsonResponse($response, $response['success'] ? 200 : 500);

        } catch (\Exception $e) {
            Error_handler::error('Screenshot creation failed', [
                'exception' => $e->getMessage(),
                'options' => $options,
                'file' => $outputFile
            ]);

            $response = Error_handler::formatErrorResponse($e->getMessage(), 500);
            $this->sendJsonResponse($response, 500);
        }
    }

    public function createScreenshot() {
        // Validate required parameters
        $validation_error = $this->validateRequestParams(['data_url', 'getTime', 'user_id', 'project_id', 'date']);
        if ($validation_error) {
            $this->sendJsonResponse($validation_error, 400);
            return;
        }

        $data_url = $this->getSanitizedParam('data_url');
        $getTime = $this->getSanitizedParam('getTime');
        $user_id = $this->getSanitizedParam('user_id');
        $project_id = $this->getSanitizedParam('project_id');
        $date = $this->getSanitizedParam('date');

        $this->logOperation('create_screenshot', [
            'user_id' => $user_id,
            'project_id' => $project_id,
            'date' => $date
        ]);

        // Create organized folder structure: screenshots/year/month/user_id_username/
        $date_obj = new \DateTime($date);
        $year = $date_obj->format('Y');
        $month = $date_obj->format('m');
        
        // Get username for better folder naming
        $username = $this->getUsername($user_id);
        
        // Create the organized path with username suffix
        $base_path = "plugins/Tracebit/screenshots/{$year}/{$month}/{$user_id}_{$username}";
        $filename = "screenshot_{$getTime}.png";
        $outputFile = "{$base_path}/{$filename}";

        $data = [
            "project_id" => $project_id,
            "user_id" => $user_id,
            "date" => $date,
            "path" => $outputFile
        ];

        $this->dataUrlToFile($data_url, $outputFile, $data);
    }

    function getSettingsData() {
        $response = $this->executeWithErrorHandling(function() {
            $this->logOperation('get_settings_data');

            $cPanelData = $this->Native_app_model->getSettingsData();

            if ($cPanelData !== false) {
                return Error_handler::formatSuccessResponse("Settings retrieved successfully!", $cPanelData);
            } else {
                Error_handler::warning('Failed to get settings data');
                return Error_handler::formatErrorResponse("Failed to retrieve settings!", 500);
            }
        }, 'get_settings_data');

        $this->sendJsonResponse($response, $response['success'] ? 200 : 500);
    }

    function updateTrackerSettings() {
        // Validate required parameters
        $validation_error = $this->validateRequestParams(['user_id'], 'POST');
        if ($validation_error) {
            $this->sendJsonResponse($validation_error, 400);
            return;
        }

        $user_id = $this->getSanitizedParam('user_id');

        // Get settings data from POST body
        try {
            $settings_data = $this->request->getJSON(true);
        } catch (\Exception $e) {
            Error_handler::error('Error parsing JSON data', [
                'exception' => $e->getMessage(),
                'user_id' => $user_id
            ]);
            $this->sendJsonResponse([
                'success' => false,
                'message' => 'Invalid JSON data provided'
            ], 400);
            return;
        }

        if (empty($settings_data) || !is_array($settings_data)) {
            $this->sendJsonResponse([
                'success' => false,
                'message' => 'Invalid settings data provided'
            ], 400);
            return;
        }

        $response = $this->executeWithErrorHandling(function() use ($user_id, $settings_data) {
            $this->logOperation('update_tracker_settings', [
                'user_id' => $user_id,
                'settings_count' => count($settings_data)
            ]);

            // Validate user has permission to update settings (admin or self)
            if (!$this->validateUserPermission($user_id)) {
                return Error_handler::formatErrorResponse("Unauthorized to update settings", 403);
            }

            $result = $this->Native_app_model->updateTrackerSettings($user_id, $settings_data);

            if ($result) {
                return Error_handler::formatSuccessResponse("Settings updated successfully!", $result);
            } else {
                Error_handler::warning('Failed to update tracker settings', [
                    'user_id' => $user_id,
                    'settings' => $settings_data
                ]);
                return Error_handler::formatErrorResponse("Failed to update settings!", 500);
            }
        }, 'update_tracker_settings');

        $this->sendJsonResponse($response, $response['success'] ? 200 : ($response['message'] === 'Unauthorized to update settings' ? 403 : 500));
    }

    function getTrackerSettings() {
        // Validate required parameters
        $validation_error = $this->validateRequestParams(['user_id'], 'GET');
        if ($validation_error) {
            $this->sendJsonResponse($validation_error, 400);
            return;
        }

        $user_id = $this->getSanitizedParam('user_id', null, 'GET');

        $response = $this->executeWithErrorHandling(function() use ($user_id) {
            $this->logOperation('get_tracker_settings', ['user_id' => $user_id]);

            $settings = $this->Native_app_model->getTrackerSettings($user_id);

            if ($settings !== false) {
                return Error_handler::formatSuccessResponse("Tracker settings retrieved successfully!", $settings);
            } else {
                Error_handler::warning('Failed to get tracker settings', ['user_id' => $user_id]);
                return Error_handler::formatErrorResponse("Failed to retrieve tracker settings!", 500);
            }
        }, 'get_tracker_settings');

        $this->sendJsonResponse($response, $response['success'] ? 200 : 500);
    }

    /**
     * Validate if user has permission to update settings
     */
    private function validateUserPermission($user_id) {
        // For now, allow all authenticated users to update their own settings
        // In production, you might want to restrict this to admins only
        return is_numeric($user_id) && $user_id > 0;
    }

    /**
     * Debug endpoint to test database connectivity and table operations
     * Call this endpoint to diagnose database issues
     */
    public function debug_status() {
        $response = $this->executeWithErrorHandling(function() {
            $debug_info = [];

            try {
                // Test database connection
                $db = \Config\Database::connect();
                $debug_info['db_connection'] = 'SUCCESS';
                $debug_info['db_version'] = $db->getVersion();

                // Test table listing
                $tables = $db->listTables();
                $debug_info['total_tables'] = count($tables);
                $debug_info['sample_tables'] = array_slice($tables, 0, 5);

                // Check if tracker_status table exists using model
                $table_exists = $this->Native_app_model->tableExists('tracker_status');
                $debug_info['tracker_status_exists'] = $table_exists;

                $prefixed_name = $db->prefixTable('tracker_status');
                $debug_info['prefixed_table_name'] = $prefixed_name;
                $debug_info['table_in_list'] = in_array($prefixed_name, $tables);

                if (!$table_exists) {
                    // Try to create the table using model
                    $creation_result = $this->Native_app_model->createTrackerStatusTable();
                    $debug_info['table_creation_attempted'] = true;
                    $debug_info['table_creation_result'] = $creation_result;

                    // Check again after creation
                    $table_exists_after = $this->Native_app_model->tableExists('tracker_status');
                    $debug_info['table_exists_after_creation'] = $table_exists_after;
                }

                if ($this->Native_app_model->tableExists('tracker_status')) {
                    // Try to perform a test operation using model
                    $test_result = $this->Native_app_model->updateUserStatus(999999, 'test');
                    $debug_info['test_insert'] = $test_result ? 'SUCCESS' : 'FAILED';

                    if ($test_result) {
                        // Clean up test data using model
                        $cleanup_result = $this->Native_app_model->deleteUserStatus(999999);
                        $debug_info['test_cleanup'] = $cleanup_result ? 'SUCCESS' : 'FAILED';
                    }
                }

                return Error_handler::formatSuccessResponse("Debug information collected", $debug_info);

            } catch (\Exception $e) {
                $debug_info['error'] = $e->getMessage();
                $debug_info['error_file'] = $e->getFile();
                $debug_info['error_line'] = $e->getLine();

                return Error_handler::formatErrorResponse("Debug failed: " . $e->getMessage(), 500, $debug_info);
            }
        }, 'debug_status');

        $this->sendJsonResponse($response, $response['success'] ? 200 : 500);
    }

    /**
     * Get username for a user ID
     * 
     * @param int $user_id User ID
     * @return string Username (first_name + last_name) or user_id if not found
     */
    private function getUsername($user_id) {
        try {
            // Get user info from the model
            $user_info = $this->Native_app_model->user_info($user_id);
            
            if ($user_info && !empty($user_info)) {
                $user = $user_info[0];
                
                // Create username from first_name and last_name
                $first_name = trim($user->first_name ?? '');
                $last_name = trim($user->last_name ?? '');
                
                if (!empty($first_name) || !empty($last_name)) {
                    $username = trim($first_name . ' ' . $last_name);
                    
                    // Clean username for folder name (remove special characters)
                    $username = preg_replace('/[^a-zA-Z0-9\s\-_]/', '', $username);
                    $username = preg_replace('/\s+/', '_', $username);
                    $username = trim($username, '_');
                    
                    // If username is empty after cleaning, use user_id
                    if (empty($username)) {
                        return $user_id;
                    }
                    
                    return $username;
                }
            }
            
            // Fallback to user_id if user info not found
            return $user_id;
            
        } catch (\Exception $e) {
            Error_handler::error('Failed to get username', [
                'user_id' => $user_id,
                'exception' => $e->getMessage()
            ]);
            
            // Fallback to user_id
            return $user_id;
        }
    }

    /**
     * Get screenshot directory path for a specific user and date
     * 
     * @param int $user_id User ID
     * @param string $date Date in Y-m-d format
     * @return string Directory path
     */
    private function getScreenshotDirectory($user_id, $date) {
        $date_obj = new \DateTime($date);
        $year = $date_obj->format('Y');
        $month = $date_obj->format('m');
        
        // Get username for better folder naming
        $username = $this->getUsername($user_id);
        
        return "plugins/Tracebit/screenshots/{$year}/{$month}/{$user_id}_{$username}";
    }

    /**
     * Clean up old screenshot directories (optional maintenance function)
     * 
     * @param int $days_to_keep Number of days to keep screenshots
     * @return array Cleanup results
     */
    public function cleanupOldScreenshots($days_to_keep = 90) {
        try {
            $base_dir = "plugins/Tracebit/screenshots";
            $cutoff_date = new \DateTime();
            $cutoff_date->modify("-{$days_to_keep} days");
            
            $cleaned_dirs = [];
            $errors = [];
            
            if (!is_dir($base_dir)) {
                return ['success' => true, 'message' => 'No screenshots directory found'];
            }
            
            // Iterate through year directories
            $year_dirs = glob($base_dir . '/*', GLOB_ONLYDIR);
            foreach ($year_dirs as $year_dir) {
                $year = basename($year_dir);
                
                // Check if year is older than cutoff
                if ($year < $cutoff_date->format('Y')) {
                    $this->removeDirectory($year_dir);
                    $cleaned_dirs[] = $year_dir;
                    continue;
                }
                
                // Iterate through month directories
                $month_dirs = glob($year_dir . '/*', GLOB_ONLYDIR);
                foreach ($month_dirs as $month_dir) {
                    $month = basename($month_dir);
                    $dir_date = new \DateTime("{$year}-{$month}-01");
                    
                    if ($dir_date < $cutoff_date) {
                        $this->removeDirectory($month_dir);
                        $cleaned_dirs[] = $month_dir;
                    }
                }
            }
            
            return [
                'success' => true,
                'cleaned_directories' => $cleaned_dirs,
                'errors' => $errors
            ];
            
        } catch (\Exception $e) {
            Error_handler::error('Screenshot cleanup failed', [
                'exception' => $e->getMessage()
            ]);
            
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }

    /**
     * Remove directory and all its contents
     * 
     * @param string $dir Directory path
     * @return bool Success or failure
     */
    private function removeDirectory($dir) {
        if (!is_dir($dir)) {
            return true;
        }
        
        $files = array_diff(scandir($dir), ['.', '..']);
        foreach ($files as $file) {
            $path = $dir . '/' . $file;
            if (is_dir($path)) {
                $this->removeDirectory($path);
            } else {
                unlink($path);
            }
        }
        
        return rmdir($dir);
    }

    /**
     * Get screenshot statistics for a user
     * 
     * @param int $user_id User ID
     * @param string $start_date Start date (Y-m-d)
     * @param string $end_date End date (Y-m-d)
     * @return array Statistics
     */
    public function getScreenshotStats($user_id, $start_date = null, $end_date = null) {
        try {
            $stats = [
                'total_screenshots' => 0,
                'total_size' => 0,
                'directories' => [],
                'monthly_breakdown' => []
            ];
            
            $base_dir = "plugins/Tracebit/screenshots";
            
            if (!is_dir($base_dir)) {
                return $stats;
            }
            
            $start_obj = $start_date ? new \DateTime($start_date) : new \DateTime('2020-01-01');
            $end_obj = $end_date ? new \DateTime($end_date) : new \DateTime();
            
            // Iterate through year directories
            $year_dirs = glob($base_dir . '/*', GLOB_ONLYDIR);
            foreach ($year_dirs as $year_dir) {
                $year = basename($year_dir);
                
                if ($year < $start_obj->format('Y') || $year > $end_obj->format('Y')) {
                    continue;
                }
                
                // Iterate through month directories
                $month_dirs = glob($year_dir . '/*', GLOB_ONLYDIR);
                foreach ($month_dirs as $month_dir) {
                    $month = basename($month_dir);
                    $dir_date = new \DateTime("{$year}-{$month}-01");
                    
                    if ($dir_date < $start_obj || $dir_date > $end_obj) {
                        continue;
                    }
                    
                    // Check user directory
                    $user_dir = $month_dir . '/' . $user_id;
                    if (is_dir($user_dir)) {
                        $files = glob($user_dir . '/*.png');
                        $month_key = $year . '-' . $month;
                        
                        $stats['monthly_breakdown'][$month_key] = [
                            'count' => count($files),
                            'size' => array_sum(array_map('filesize', $files))
                        ];
                        
                        $stats['total_screenshots'] += count($files);
                        $stats['total_size'] += array_sum(array_map('filesize', $files));
                        $stats['directories'][] = $user_dir;
                    }
                }
            }
            
            return $stats;
            
        } catch (\Exception $e) {
            Error_handler::error('Failed to get screenshot stats', [
                'exception' => $e->getMessage(),
                'user_id' => $user_id
            ]);
            
            return [
                'total_screenshots' => 0,
                'total_size' => 0,
                'directories' => [],
                'monthly_breakdown' => []
            ];
        }
    }
}
