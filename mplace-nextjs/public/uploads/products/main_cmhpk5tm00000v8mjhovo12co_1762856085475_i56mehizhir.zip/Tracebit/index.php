<?php
use Tracebit\Controllers\Tracebit_Updates;

defined('PLUGINPATH') or exit('No direct script access allowed');

/*
  Plugin Name: Tracebit
  Description: It's a employee tracking plugin.
  Version: 1.0
  Requires at least: 3.0
  Author: JS Techy
  Author URL: https://author_url.tracker
 */

// Register the Tracebit namespace if not already registered
if (!class_exists('Tracebit\\Config\\Tracker')) {
    // Get the current loader instance
    $loader = \Config\Services::autoloader();

    // Register the Tracebit namespace
    $loader->addNamespace('Tracebit', ROOTPATH . 'plugins/Tracebit');
}

// Register a view namespace for Tracebit plugin
if (function_exists('service')) {
    $renderer = service('renderer');
    if (method_exists($renderer, 'setPath')) {
        $renderer->setPath('tracebit_views', ROOTPATH . 'plugins/Tracebit/Views');
    }
}

// Load installer helper functions
require_once ROOTPATH . 'plugins/Tracebit/Helpers/installer_helper.php';

//add menu item to left menu with submenu
app_hooks()->add_filter('app_filter_staff_left_menu', function ($sidebar_menu) {
    $sidebar_menu["tracebit"] = array(
        "name" => "tracebit",
        "url" => "tracebit",
        "class" => "hash",
        "position" => 3,
        "submenu" => array(
            array(
                "name" => "dashboard",
                "url" => "tracebit",
                "class" => "hash",
                "icon" => "home"
            ),
            array(
                "name" => "employee_status",
                "url" => "tracebit/employee_status",
                "class" => "hash",
                "icon" => "bar-chart"
            ),
            array(
                "name" => "timesheet",
                "url" => "tracebit/timesheet",
                "class" => "hash",
                "icon" => "clock"
            ),
            array(
                "name" => "activity_log",
                "url" => "tracebit/activity-log",
                "class" => "hash",
                "icon" => "activity"
            ),
            array(
                "name" => "screenshot_title",
                "url" => "tracebit/screenshots",
                "class" => "hash",
                "icon" => "image"
            ),
            array(
                "name" => "storage_management",
                "url" => "tracebit/storage_management",
                "class" => "hash",
                "icon" => "hard-drive"
            ),
            array(
                "name" => "settings",
                "url" => "tracebit/tracker_settings",
                "class" => "hash",
                "icon" => "settings"
            )
        )
    );

    return $sidebar_menu;
});

//add admin setting menu item
app_hooks()->add_filter('app_filter_admin_settings_menu', function ($settings_menu) {
    $settings_menu["plugins"][] = array("name" => "tracebit", "url" => "tracebit/tracker_settings");
    return $settings_menu;
});

//install dependencies (aligned with Google Docs Integration pattern)
register_installation_hook("Tracebit", function ($item_purchase_code) {
    $upper = PLUGINPATH . "Tracebit/Install/do_install.php";
    $lower = PLUGINPATH . "Tracebit/install/do_install.php";
    if (is_file($upper)) {
        include $upper;
        return;
    }
    if (is_file($lower)) {
        include $lower;
        return;
    }
    echo json_encode(array("success" => false, "message" => "Tracebit installer script not found."));
    exit();
});

//add setting link to the plugin setting
app_hooks()->add_filter('app_filter_action_links_of_tracker', function () {
    $action_links_array = array(
        anchor(get_uri("tracebit"), "Tracebit"),
        anchor(get_uri("tracebit/tracker_settings"), "Tracebit settings"),
    );

    return $action_links_array;
});


//uninstallation: remove data from database
register_uninstallation_hook("Tracebit", function () {
    $dbprefix = get_db_prefix();
    $db = db_connect('default');

    try {
        // Drop tracker tables
        $sql_query = "DROP TABLE IF EXISTS `" . $dbprefix . "tracker_settings`;";
        $db->query($sql_query);

        $sql_query = "DROP TABLE IF EXISTS `" . $dbprefix . "tracker_screenshots`;";
        $db->query($sql_query);

        $sql_query = "DROP TABLE IF EXISTS `" . $dbprefix . "tracker_attendance`;";
        $db->query($sql_query);

        $sql_query = "DROP TABLE IF EXISTS `" . $dbprefix . "tracker_performance`;";
        $db->query($sql_query);

        $sql_query = "DROP TABLE IF EXISTS `" . $dbprefix . "tracker_status`;";
        $db->query($sql_query);

        $sql_query = "DROP TABLE IF EXISTS `" . $dbprefix . "tracker_status_log`;";
        $db->query($sql_query);

        $sql_query = "DROP TABLE IF EXISTS `" . "tracker_status`;";
        $db->query($sql_query);

        $sql_query = "DROP TABLE IF EXISTS `" . "tracker_status_log`;";
        $db->query($sql_query);

        $sql_query = "DROP TABLE IF EXISTS `" . $dbprefix . "tracker_holidays`;";
        $db->query($sql_query);

        $sql_query = "DROP TABLE IF EXISTS `" . $dbprefix . "tracker_breaks`;";
        $db->query($sql_query);

        // Drop Calendar table (only if no other plugins use it)
        $sql_query = "DROP TABLE IF EXISTS `Calendar`;";
        $db->query($sql_query);

        // Drop performance monitoring table
        $sql_query = "DROP TABLE IF EXISTS `" . $dbprefix . "tracker_query_performance`;";
        $db->query($sql_query);

            // echo json_encode(array("success" => true, "message" => "Tracker plugin uninstalled successfully!"));

    } catch (Exception $e) {
        echo json_encode(array("success" => false, "message" => "Uninstallation failed: " . $e->getMessage()));
    }
});
