<?php

namespace Tracebit\Libraries;

use Config\Services;

/**
 * Activity Log Error Handler
 * Enhanced error handling and logging for Activity Log operations
 */
class Activity_error_handler {
    
    private $logger;
    
    public function __construct() {
        $this->logger = Services::logger();
    }
    
    /**
     * Log database query errors with context
     */
    public function logDatabaseError($query, $params, $error, $context = []) {
        $error_data = [
            'type' => 'database_error',
            'query' => $this->sanitizeQuery($query),
            'params_count' => count($params),
            'error' => $error,
            'context' => $context,
            'timestamp' => date('Y-m-d H:i:s'),
            'memory_usage' => memory_get_usage(true),
            'peak_memory' => memory_get_peak_usage(true)
        ];
        
        $this->logger->error('Activity Log Database Error', $error_data);
        return $error_data;
    }
    
    /**
     * Log performance issues
     */
    public function logPerformanceIssue($operation, $duration, $threshold = 2.0) {
        if ($duration > $threshold) {
            $this->logger->warning('Activity Log Performance Issue', [
                'operation' => $operation,
                'duration' => $duration,
                'threshold' => $threshold,
                'timestamp' => date('Y-m-d H:i:s')
            ]);
        }
    }
    
    /**
     * Log cache operations
     */
    public function logCacheOperation($operation, $key, $hit = null, $size = null) {
        $this->logger->info('Activity Log Cache Operation', [
            'operation' => $operation,
            'key' => $key,
            'hit' => $hit,
            'size' => $size,
            'timestamp' => date('Y-m-d H:i:s')
        ]);
    }
    
    /**
     * Validate date range parameters
     */
    public function validateDateRange($start_date, $end_date) {
        $errors = [];
        
        if (empty($start_date)) {
            $errors[] = 'Start date is required';
        }
        
        if (empty($end_date)) {
            $errors[] = 'End date is required';
        }
        
        if (!empty($start_date) && !strtotime($start_date)) {
            $errors[] = 'Invalid start date format';
        }
        
        if (!empty($end_date) && !strtotime($end_date)) {
            $errors[] = 'Invalid end date format';
        }
        
        if (!empty($start_date) && !empty($end_date) && strtotime($start_date) > strtotime($end_date)) {
            $errors[] = 'Start date cannot be after end date';
        }
        
        // Check for reasonable date range (not more than 1 year)
        if (!empty($start_date) && !empty($end_date)) {
            $diff = (strtotime($end_date) - strtotime($start_date)) / (60 * 60 * 24);
            if ($diff > 365) {
                $errors[] = 'Date range cannot exceed 365 days';
            }
        }
        
        if (!empty($errors)) {
            $this->logger->warning('Activity Log Date Validation Failed', [
                'start_date' => $start_date,
                'end_date' => $end_date,
                'errors' => $errors
            ]);
        }
        
        return $errors;
    }
    
    /**
     * Sanitize SQL query for logging (remove sensitive data)
     */
    private function sanitizeQuery($query) {
        // Remove actual parameter values and replace with placeholders
        $sanitized = preg_replace('/\s+/', ' ', $query);
        $sanitized = trim($sanitized);
        
        // Truncate if too long
        if (strlen($sanitized) > 500) {
            $sanitized = substr($sanitized, 0, 500) . '...';
        }
        
        return $sanitized;
    }
    
    /**
     * Create error response for AJAX requests
     */
    public function createErrorResponse($message, $code = 500, $details = null) {
        $response = [
            'success' => false,
            'message' => $message,
            'code' => $code,
            'timestamp' => date('Y-m-d H:i:s')
        ];
        
        if ($details && app_env() !== 'production') {
            $response['details'] = $details;
        }
        
        return $response;
    }
    
    /**
     * Monitor memory usage
     */
    public function checkMemoryUsage($operation) {
        $current = memory_get_usage(true);
        $peak = memory_get_peak_usage(true);
        $limit = ini_get('memory_limit');
        
        if ($limit !== '-1') {
            $limit_bytes = $this->convertToBytes($limit);
            $usage_percent = ($current / $limit_bytes) * 100;
            
            if ($usage_percent > 80) {
                $this->logger->warning('Activity Log High Memory Usage', [
                    'operation' => $operation,
                    'current_usage' => $this->formatBytes($current),
                    'peak_usage' => $this->formatBytes($peak),
                    'memory_limit' => $limit,
                    'usage_percent' => round($usage_percent, 2)
                ]);
            }
        }
    }
    
    /**
     * Convert memory limit string to bytes
     */
    private function convertToBytes($size) {
        $unit = strtolower(substr($size, -1));
        $value = (int)$size;
        
        switch ($unit) {
            case 'g': return $value * 1024 * 1024 * 1024;
            case 'm': return $value * 1024 * 1024;
            case 'k': return $value * 1024;
            default: return $value;
        }
    }
    
    /**
     * Format bytes to human readable format
     */
    private function formatBytes($bytes) {
        $units = ['B', 'KB', 'MB', 'GB'];
        $bytes = max($bytes, 0);
        $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
        $pow = min($pow, count($units) - 1);
        
        $bytes /= pow(1024, $pow);
        
        return round($bytes, 2) . ' ' . $units[$pow];
    }
}
