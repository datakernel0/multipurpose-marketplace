<?php

namespace Tracebit\Libraries;

/**
 * Error Handler Library for Tracebit Plugin
 * Provides standardized error handling, logging, and response formatting
 */
class Error_handler {

    private static $log_file = 'writable/logs/tracker_errors.log';

    /**
     * Log error message to file
     *
     * @param string $level Error level (ERROR, WARNING, INFO, DEBUG)
     * @param string $message Error message
     * @param array $context Additional context data
     * @return void
     */
    public static function log($level, $message, $context = []) {
        $timestamp = date('Y-m-d H:i:s');
        $log_entry = "[{$timestamp}] [{$level}] {$message}";

        if (!empty($context)) {
            $log_entry .= " Context: " . json_encode($context);
        }

        $log_entry .= PHP_EOL;

        // Ensure log directory exists
        $log_dir = dirname(ROOTPATH . self::$log_file);
        if (!is_dir($log_dir)) {
            mkdir($log_dir, 0755, true);
        }

        file_put_contents(ROOTPATH . self::$log_file, $log_entry, FILE_APPEND | LOCK_EX);
    }

    /**
     * Log error
     *
     * @param string $message
     * @param array $context
     * @return void
     */
    public static function error($message, $context = []) {
        self::log('ERROR', $message, $context);
    }

    /**
     * Log warning
     *
     * @param string $message
     * @param array $context
     * @return void
     */
    public static function warning($message, $context = []) {
        self::log('WARNING', $message, $context);
    }

    /**
     * Log info
     *
     * @param string $message
     * @param array $context
     * @return void
     */
    public static function info($message, $context = []) {
        self::log('INFO', $message, $context);
    }

    /**
     * Log debug
     *
     * @param string $message
     * @param array $context
     * @return void
     */
    public static function debug($message, $context = []) {
        if (ENVIRONMENT === 'development') {
            self::log('DEBUG', $message, $context);
        }
    }

    /**
     * Format standardized error response for API endpoints
     *
     * @param string $message Error message
     * @param int $code Error code (default: 500)
     * @param array $data Additional data
     * @return array
     */
    public static function formatErrorResponse($message, $code = 500, $data = []) {
        return [
            'success' => false,
            'error' => true,
            'message' => $message,
            'code' => $code,
            'data' => $data,
            'timestamp' => date('Y-m-d H:i:s')
        ];
    }

    /**
     * Format standardized success response for API endpoints
     *
     * @param string $message Success message
     * @param array $data Response data
     * @return array
     */
    public static function formatSuccessResponse($message, $data = []) {
        return [
            'success' => true,
            'error' => false,
            'message' => $message,
            'data' => $data,
            'timestamp' => date('Y-m-d H:i:s')
        ];
    }

    /**
     * Handle and format exception
     *
     * @param \Exception $exception
     * @param string $operation Operation that failed
     * @return array
     */
    public static function handleException(\Exception $exception, $operation = 'Unknown operation') {
        $context = [
            'operation' => $operation,
            'exception_type' => get_class($exception),
            'file' => $exception->getFile(),
            'line' => $exception->getLine(),
            'trace' => $exception->getTraceAsString()
        ];

        self::error($exception->getMessage(), $context);

        // Don't expose internal errors in production
        if (ENVIRONMENT === 'production') {
            $message = 'An internal error occurred. Please try again later.';
        } else {
            $message = $exception->getMessage();
        }

        return self::formatErrorResponse($message, 500, [
            'operation' => $operation,
            'debug' => ENVIRONMENT !== 'production' ? $context : null
        ]);
    }

    /**
     * Validate required parameters
     *
     * @param array $params Parameters to validate
     * @param array $required Required parameter names
     * @return array|null Returns error response if validation fails, null if passes
     */
    public static function validateRequired($params, $required) {
        $missing = [];

        foreach ($required as $field) {
            if (!isset($params[$field]) || empty($params[$field])) {
                $missing[] = $field;
            }
        }

        if (!empty($missing)) {
            $message = 'Missing required parameters: ' . implode(', ', $missing);
            self::warning($message, ['params' => $params, 'required' => $required]);
            return self::formatErrorResponse($message, 400);
        }

        return null;
    }

    /**
     * Sanitize input data
     *
     * @param mixed $data Data to sanitize
     * @return mixed Sanitized data
     */
    public static function sanitizeInput($data) {
        if (is_array($data)) {
            return array_map([self::class, 'sanitizeInput'], $data);
        } elseif (is_string($data)) {
            // Don't sanitize if it's a valid number string
            if (is_numeric($data)) {
                return $data;
            }
            return trim(htmlspecialchars($data, ENT_QUOTES, 'UTF-8'));
        }

        return $data;
    }

    /**
     * Get error statistics for monitoring
     *
     * @param int $hours Hours to look back (default: 24)
     * @return array Error statistics
     */
    public static function getErrorStats($hours = 24) {
        $log_file = ROOTPATH . self::$log_file;

        if (!file_exists($log_file)) {
            return [
                'total_errors' => 0,
                'by_level' => [],
                'recent_errors' => []
            ];
        }

        $cutoff_time = time() - ($hours * 3600);
        $lines = file($log_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

        $stats = [
            'total_errors' => 0,
            'by_level' => [
                'ERROR' => 0,
                'WARNING' => 0,
                'INFO' => 0,
                'DEBUG' => 0
            ],
            'recent_errors' => []
        ];

        foreach (array_reverse($lines) as $line) {
            if (preg_match('/\[(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})\] \[(\w+)\] (.+)/', $line, $matches)) {
                $log_time = strtotime($matches[1]);

                if ($log_time >= $cutoff_time) {
                    $level = $matches[2];
                    $message = $matches[3];

                    $stats['total_errors']++;
                    if (isset($stats['by_level'][$level])) {
                        $stats['by_level'][$level]++;
                    }

                    if (count($stats['recent_errors']) < 10) {
                        $stats['recent_errors'][] = [
                            'timestamp' => $matches[1],
                            'level' => $level,
                            'message' => $message
                        ];
                    }
                }
            }
        }

        return $stats;
    }
}
