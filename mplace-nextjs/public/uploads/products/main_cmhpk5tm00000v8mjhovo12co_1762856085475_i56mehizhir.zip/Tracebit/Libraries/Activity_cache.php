<?php

namespace Tracebit\Libraries;

use Config\Services;

/**
 * Activity Log Cache Manager
 * Handles caching for expensive database operations in Activity Log
 */
class Activity_cache {
    
    private $cache;
    private $default_ttl = 300; // 5 minutes default cache time
    
    public function __construct() {
        $this->cache = Services::cache();
    }
    
    /**
     * Get cached employee summary data
     */
    public function getEmployeeSummary($start_date, $end_date, $user_filter = null) {
        $cache_key = $this->generateCacheKey('employee_summary', $start_date, $end_date, $user_filter);
        return $this->cache->get($cache_key);
    }
    
    /**
     * Cache employee summary data
     */
    public function setEmployeeSummary($start_date, $end_date, $user_filter, $data, $ttl = null) {
        $cache_key = $this->generateCacheKey('employee_summary', $start_date, $end_date, $user_filter);
        $ttl = $ttl ?? $this->default_ttl;
        return $this->cache->save($cache_key, $data, $ttl);
    }
    
    /**
     * Get cached tracker settings
     */
    public function getTrackerSettings() {
        return $this->cache->get('tracker_settings');
    }
    
    /**
     * Cache tracker settings
     */
    public function setTrackerSettings($settings, $ttl = 3600) { // 1 hour cache for settings
        return $this->cache->save('tracker_settings', $settings, $ttl);
    }
    
    /**
     * Get cached date range info
     */
    public function getDateRangeInfo($start_date, $end_date) {
        $cache_key = $this->generateCacheKey('date_range', $start_date, $end_date);
        return $this->cache->get($cache_key);
    }
    
    /**
     * Cache date range info
     */
    public function setDateRangeInfo($start_date, $end_date, $data, $ttl = 1800) { // 30 minutes cache
        $cache_key = $this->generateCacheKey('date_range', $start_date, $end_date);
        return $this->cache->save($cache_key, $data, $ttl);
    }
    
    /**
     * Clear activity log related caches
     */
    public function clearActivityCache() {
        $cache_keys = [
            'tracker_settings',
        ];
        
        foreach ($cache_keys as $key) {
            $this->cache->delete($key);
        }
        
        // Clear pattern-based caches
        $this->cache->deleteMatching('activity_log_*');
    }
    
    /**
     * Generate cache key
     */
    private function generateCacheKey($type, ...$params) {
        $key_parts = ['activity_log', $type];
        foreach ($params as $param) {
            if ($param !== null) {
                $key_parts[] = is_array($param) ? md5(serialize($param)) : $param;
            }
        }
        return implode('_', $key_parts);
    }
    
    /**
     * Check if caching is enabled
     */
    public function isCacheEnabled() {
        return $this->cache->isSupported();
    }
}
